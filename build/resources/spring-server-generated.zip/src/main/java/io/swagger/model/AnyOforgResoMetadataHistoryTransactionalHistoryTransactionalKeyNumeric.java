package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalHistoryTransactionalKeyNumeric
*/
public interface AnyOforgResoMetadataHistoryTransactionalHistoryTransactionalKeyNumeric {

}
