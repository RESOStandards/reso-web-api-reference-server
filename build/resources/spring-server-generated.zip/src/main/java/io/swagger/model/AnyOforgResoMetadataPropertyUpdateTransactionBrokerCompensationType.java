package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType
*/
public interface AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType {

}
