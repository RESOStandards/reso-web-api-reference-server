package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeOfficeStateOrProvince
*/
public interface AnyOforgResoMetadataOfficeOfficeStateOrProvince {

}
