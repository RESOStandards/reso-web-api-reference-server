package io.swagger.model;


/**
* AnyOforgResoMetadataMediaUpdateResourceRecordKeyNumeric
*/
public interface AnyOforgResoMetadataMediaUpdateResourceRecordKeyNumeric {

}
