package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeOfficeBroker
*/
public interface AnyOforgResoMetadataOfficeOfficeBroker {

}
