package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateChangedByMemberKeyNumeric
*/
public interface AnyOforgResoMetadataOUIDCreateChangedByMemberKeyNumeric {

}
