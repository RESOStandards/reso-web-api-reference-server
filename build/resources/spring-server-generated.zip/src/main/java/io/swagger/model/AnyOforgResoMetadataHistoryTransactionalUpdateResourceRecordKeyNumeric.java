package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalUpdateResourceRecordKeyNumeric
*/
public interface AnyOforgResoMetadataHistoryTransactionalUpdateResourceRecordKeyNumeric {

}
