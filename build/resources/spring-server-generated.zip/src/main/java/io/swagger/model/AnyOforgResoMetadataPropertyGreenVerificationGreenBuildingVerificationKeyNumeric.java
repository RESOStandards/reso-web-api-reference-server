package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationGreenBuildingVerificationKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationGreenBuildingVerificationKeyNumeric {

}
