package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric {

}
