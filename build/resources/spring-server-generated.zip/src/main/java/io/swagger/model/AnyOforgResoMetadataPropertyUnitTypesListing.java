package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesListing
*/
public interface AnyOforgResoMetadataPropertyUnitTypesListing {

}
