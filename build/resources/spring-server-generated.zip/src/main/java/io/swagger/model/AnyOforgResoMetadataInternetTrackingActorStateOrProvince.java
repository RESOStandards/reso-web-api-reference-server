package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingActorStateOrProvince
*/
public interface AnyOforgResoMetadataInternetTrackingActorStateOrProvince {

}
