package io.swagger.model;


/**
* AnyOforgResoMetadataMemberCreateMemberStatus
*/
public interface AnyOforgResoMetadataMemberCreateMemberStatus {

}
