package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateEntryLevel
*/
public interface AnyOforgResoMetadataPropertyUpdateEntryLevel {

}
