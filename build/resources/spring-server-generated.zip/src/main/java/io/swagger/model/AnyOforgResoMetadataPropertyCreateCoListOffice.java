package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoListOffice
*/
public interface AnyOforgResoMetadataPropertyCreateCoListOffice {

}
