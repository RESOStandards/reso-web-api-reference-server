package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyConcessionsAmount
*/
public interface AnyOforgResoMetadataPropertyConcessionsAmount {

}
