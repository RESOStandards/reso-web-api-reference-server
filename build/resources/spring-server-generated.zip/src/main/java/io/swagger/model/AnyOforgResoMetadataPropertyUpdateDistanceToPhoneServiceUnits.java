package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits {

}
