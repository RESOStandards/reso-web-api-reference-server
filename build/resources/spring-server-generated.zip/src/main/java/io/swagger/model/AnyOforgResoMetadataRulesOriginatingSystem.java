package io.swagger.model;


/**
* AnyOforgResoMetadataRulesOriginatingSystem
*/
public interface AnyOforgResoMetadataRulesOriginatingSystem {

}
