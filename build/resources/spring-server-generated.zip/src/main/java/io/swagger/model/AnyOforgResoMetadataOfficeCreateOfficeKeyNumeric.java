package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric {

}
