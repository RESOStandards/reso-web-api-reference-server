package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateTaxAssessedValue
*/
public interface AnyOforgResoMetadataPropertyCreateTaxAssessedValue {

}
