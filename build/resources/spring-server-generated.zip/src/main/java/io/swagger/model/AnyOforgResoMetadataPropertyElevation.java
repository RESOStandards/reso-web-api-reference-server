package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyElevation
*/
public interface AnyOforgResoMetadataPropertyElevation {

}
