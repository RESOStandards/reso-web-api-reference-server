package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataInternetTracking
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataInternetTracking   {
  @JsonProperty("ActorCity")
  private String actorCity = null;

  @JsonProperty("ActorEmail")
  private String actorEmail = null;

  @JsonProperty("ActorID")
  private String actorID = null;

  @JsonProperty("ActorIP")
  private String actorIP = null;

  @JsonProperty("ActorKey")
  private String actorKey = null;

  @JsonProperty("ActorKeyNumeric")
  private AnyOforgResoMetadataInternetTrackingActorKeyNumeric actorKeyNumeric = null;

  @JsonProperty("ActorLatitude")
  private AnyOforgResoMetadataInternetTrackingActorLatitude actorLatitude = null;

  @JsonProperty("ActorLongitude")
  private AnyOforgResoMetadataInternetTrackingActorLongitude actorLongitude = null;

  @JsonProperty("ActorOriginatingSystemID")
  private String actorOriginatingSystemID = null;

  @JsonProperty("ActorOriginatingSystemName")
  private String actorOriginatingSystemName = null;

  @JsonProperty("ActorPhone")
  private String actorPhone = null;

  @JsonProperty("ActorPhoneExt")
  private String actorPhoneExt = null;

  @JsonProperty("ActorPostalCode")
  private String actorPostalCode = null;

  @JsonProperty("ActorPostalCodePlus4")
  private String actorPostalCodePlus4 = null;

  @JsonProperty("ActorRegion")
  private String actorRegion = null;

  @JsonProperty("ActorSourceSystemID")
  private String actorSourceSystemID = null;

  @JsonProperty("ActorSourceSystemName")
  private String actorSourceSystemName = null;

  @JsonProperty("ActorStateOrProvince")
  private AnyOforgResoMetadataInternetTrackingActorStateOrProvince actorStateOrProvince = null;

  @JsonProperty("ActorType")
  private AnyOforgResoMetadataInternetTrackingActorType actorType = null;

  @JsonProperty("ColorDepth")
  private AnyOforgResoMetadataInternetTrackingColorDepth colorDepth = null;

  @JsonProperty("DeviceType")
  private AnyOforgResoMetadataInternetTrackingDeviceType deviceType = null;

  @JsonProperty("EventDescription")
  private String eventDescription = null;

  @JsonProperty("EventKey")
  private String eventKey = null;

  @JsonProperty("EventKeyNumeric")
  private AnyOforgResoMetadataInternetTrackingEventKeyNumeric eventKeyNumeric = null;

  @JsonProperty("EventLabel")
  private String eventLabel = null;

  @JsonProperty("EventOriginatingSystemID")
  private String eventOriginatingSystemID = null;

  @JsonProperty("EventOriginatingSystemName")
  private String eventOriginatingSystemName = null;

  @JsonProperty("EventSourceSystemID")
  private String eventSourceSystemID = null;

  @JsonProperty("EventSourceSystemName")
  private String eventSourceSystemName = null;

  @JsonProperty("EventTarget")
  private AnyOforgResoMetadataInternetTrackingEventTarget eventTarget = null;

  @JsonProperty("EventTimestamp")
  private OffsetDateTime eventTimestamp = null;

  @JsonProperty("EventType")
  private AnyOforgResoMetadataInternetTrackingEventType eventType = null;

  @JsonProperty("ObjectID")
  private String objectID = null;

  @JsonProperty("ObjectIdType")
  private AnyOforgResoMetadataInternetTrackingObjectIdType objectIdType = null;

  @JsonProperty("ObjectKey")
  private String objectKey = null;

  @JsonProperty("ObjectKeyNumeric")
  private AnyOforgResoMetadataInternetTrackingObjectKeyNumeric objectKeyNumeric = null;

  @JsonProperty("ObjectOriginatingSystemID")
  private String objectOriginatingSystemID = null;

  @JsonProperty("ObjectOriginatingSystemName")
  private String objectOriginatingSystemName = null;

  @JsonProperty("ObjectSourceSystemID")
  private String objectSourceSystemID = null;

  @JsonProperty("ObjectSourceSystemName")
  private String objectSourceSystemName = null;

  @JsonProperty("ObjectType")
  private AnyOforgResoMetadataInternetTrackingObjectType objectType = null;

  @JsonProperty("ObjectURL")
  private String objectURL = null;

  @JsonProperty("OriginatingSystemActorKey")
  private String originatingSystemActorKey = null;

  @JsonProperty("OriginatingSystemEventKey")
  private String originatingSystemEventKey = null;

  @JsonProperty("OriginatingSystemObjectKey")
  private String originatingSystemObjectKey = null;

  @JsonProperty("ReferringURL")
  private String referringURL = null;

  @JsonProperty("ScreenHeight")
  private AnyOforgResoMetadataInternetTrackingScreenHeight screenHeight = null;

  @JsonProperty("ScreenWidth")
  private AnyOforgResoMetadataInternetTrackingScreenWidth screenWidth = null;

  @JsonProperty("SessionID")
  private String sessionID = null;

  @JsonProperty("SourceSystemActorKey")
  private String sourceSystemActorKey = null;

  @JsonProperty("SourceSystemEventKey")
  private String sourceSystemEventKey = null;

  @JsonProperty("SourceSystemObjectKey")
  private String sourceSystemObjectKey = null;

  @JsonProperty("TimeZoneOffset")
  private AnyOforgResoMetadataInternetTrackingTimeZoneOffset timeZoneOffset = null;

  @JsonProperty("UserAgent")
  private String userAgent = null;

  @JsonProperty("ActorOriginatingSystem")
  private AnyOforgResoMetadataInternetTrackingActorOriginatingSystem actorOriginatingSystem = null;

  @JsonProperty("ActorSourceSystem")
  private AnyOforgResoMetadataInternetTrackingActorSourceSystem actorSourceSystem = null;

  @JsonProperty("EventOriginatingSystem")
  private AnyOforgResoMetadataInternetTrackingEventOriginatingSystem eventOriginatingSystem = null;

  @JsonProperty("EventSourceSystem")
  private AnyOforgResoMetadataInternetTrackingEventSourceSystem eventSourceSystem = null;

  @JsonProperty("ObjectOriginatingSystem")
  private AnyOforgResoMetadataInternetTrackingObjectOriginatingSystem objectOriginatingSystem = null;

  @JsonProperty("ObjectSourceSystem")
  private AnyOforgResoMetadataInternetTrackingObjectSourceSystem objectSourceSystem = null;

  public OrgResoMetadataInternetTracking actorCity(String actorCity) {
    this.actorCity = actorCity;
    return this;
  }

  /**
   * Get actorCity
   * @return actorCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getActorCity() {
    return actorCity;
  }

  public void setActorCity(String actorCity) {
    this.actorCity = actorCity;
  }

  public OrgResoMetadataInternetTracking actorEmail(String actorEmail) {
    this.actorEmail = actorEmail;
    return this;
  }

  /**
   * Get actorEmail
   * @return actorEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getActorEmail() {
    return actorEmail;
  }

  public void setActorEmail(String actorEmail) {
    this.actorEmail = actorEmail;
  }

  public OrgResoMetadataInternetTracking actorID(String actorID) {
    this.actorID = actorID;
    return this;
  }

  /**
   * Get actorID
   * @return actorID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getActorID() {
    return actorID;
  }

  public void setActorID(String actorID) {
    this.actorID = actorID;
  }

  public OrgResoMetadataInternetTracking actorIP(String actorIP) {
    this.actorIP = actorIP;
    return this;
  }

  /**
   * Get actorIP
   * @return actorIP
   **/
  @Schema(description = "")
  
  @Size(max=39)   public String getActorIP() {
    return actorIP;
  }

  public void setActorIP(String actorIP) {
    this.actorIP = actorIP;
  }

  public OrgResoMetadataInternetTracking actorKey(String actorKey) {
    this.actorKey = actorKey;
    return this;
  }

  /**
   * Get actorKey
   * @return actorKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getActorKey() {
    return actorKey;
  }

  public void setActorKey(String actorKey) {
    this.actorKey = actorKey;
  }

  public OrgResoMetadataInternetTracking actorKeyNumeric(AnyOforgResoMetadataInternetTrackingActorKeyNumeric actorKeyNumeric) {
    this.actorKeyNumeric = actorKeyNumeric;
    return this;
  }

  /**
   * Get actorKeyNumeric
   * @return actorKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorKeyNumeric getActorKeyNumeric() {
    return actorKeyNumeric;
  }

  public void setActorKeyNumeric(AnyOforgResoMetadataInternetTrackingActorKeyNumeric actorKeyNumeric) {
    this.actorKeyNumeric = actorKeyNumeric;
  }

  public OrgResoMetadataInternetTracking actorLatitude(AnyOforgResoMetadataInternetTrackingActorLatitude actorLatitude) {
    this.actorLatitude = actorLatitude;
    return this;
  }

  /**
   * Get actorLatitude
   * @return actorLatitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorLatitude getActorLatitude() {
    return actorLatitude;
  }

  public void setActorLatitude(AnyOforgResoMetadataInternetTrackingActorLatitude actorLatitude) {
    this.actorLatitude = actorLatitude;
  }

  public OrgResoMetadataInternetTracking actorLongitude(AnyOforgResoMetadataInternetTrackingActorLongitude actorLongitude) {
    this.actorLongitude = actorLongitude;
    return this;
  }

  /**
   * Get actorLongitude
   * @return actorLongitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorLongitude getActorLongitude() {
    return actorLongitude;
  }

  public void setActorLongitude(AnyOforgResoMetadataInternetTrackingActorLongitude actorLongitude) {
    this.actorLongitude = actorLongitude;
  }

  public OrgResoMetadataInternetTracking actorOriginatingSystemID(String actorOriginatingSystemID) {
    this.actorOriginatingSystemID = actorOriginatingSystemID;
    return this;
  }

  /**
   * Get actorOriginatingSystemID
   * @return actorOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getActorOriginatingSystemID() {
    return actorOriginatingSystemID;
  }

  public void setActorOriginatingSystemID(String actorOriginatingSystemID) {
    this.actorOriginatingSystemID = actorOriginatingSystemID;
  }

  public OrgResoMetadataInternetTracking actorOriginatingSystemName(String actorOriginatingSystemName) {
    this.actorOriginatingSystemName = actorOriginatingSystemName;
    return this;
  }

  /**
   * Get actorOriginatingSystemName
   * @return actorOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getActorOriginatingSystemName() {
    return actorOriginatingSystemName;
  }

  public void setActorOriginatingSystemName(String actorOriginatingSystemName) {
    this.actorOriginatingSystemName = actorOriginatingSystemName;
  }

  public OrgResoMetadataInternetTracking actorPhone(String actorPhone) {
    this.actorPhone = actorPhone;
    return this;
  }

  /**
   * Get actorPhone
   * @return actorPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getActorPhone() {
    return actorPhone;
  }

  public void setActorPhone(String actorPhone) {
    this.actorPhone = actorPhone;
  }

  public OrgResoMetadataInternetTracking actorPhoneExt(String actorPhoneExt) {
    this.actorPhoneExt = actorPhoneExt;
    return this;
  }

  /**
   * Get actorPhoneExt
   * @return actorPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getActorPhoneExt() {
    return actorPhoneExt;
  }

  public void setActorPhoneExt(String actorPhoneExt) {
    this.actorPhoneExt = actorPhoneExt;
  }

  public OrgResoMetadataInternetTracking actorPostalCode(String actorPostalCode) {
    this.actorPostalCode = actorPostalCode;
    return this;
  }

  /**
   * Get actorPostalCode
   * @return actorPostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getActorPostalCode() {
    return actorPostalCode;
  }

  public void setActorPostalCode(String actorPostalCode) {
    this.actorPostalCode = actorPostalCode;
  }

  public OrgResoMetadataInternetTracking actorPostalCodePlus4(String actorPostalCodePlus4) {
    this.actorPostalCodePlus4 = actorPostalCodePlus4;
    return this;
  }

  /**
   * Get actorPostalCodePlus4
   * @return actorPostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getActorPostalCodePlus4() {
    return actorPostalCodePlus4;
  }

  public void setActorPostalCodePlus4(String actorPostalCodePlus4) {
    this.actorPostalCodePlus4 = actorPostalCodePlus4;
  }

  public OrgResoMetadataInternetTracking actorRegion(String actorRegion) {
    this.actorRegion = actorRegion;
    return this;
  }

  /**
   * Get actorRegion
   * @return actorRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getActorRegion() {
    return actorRegion;
  }

  public void setActorRegion(String actorRegion) {
    this.actorRegion = actorRegion;
  }

  public OrgResoMetadataInternetTracking actorSourceSystemID(String actorSourceSystemID) {
    this.actorSourceSystemID = actorSourceSystemID;
    return this;
  }

  /**
   * Get actorSourceSystemID
   * @return actorSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getActorSourceSystemID() {
    return actorSourceSystemID;
  }

  public void setActorSourceSystemID(String actorSourceSystemID) {
    this.actorSourceSystemID = actorSourceSystemID;
  }

  public OrgResoMetadataInternetTracking actorSourceSystemName(String actorSourceSystemName) {
    this.actorSourceSystemName = actorSourceSystemName;
    return this;
  }

  /**
   * Get actorSourceSystemName
   * @return actorSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getActorSourceSystemName() {
    return actorSourceSystemName;
  }

  public void setActorSourceSystemName(String actorSourceSystemName) {
    this.actorSourceSystemName = actorSourceSystemName;
  }

  public OrgResoMetadataInternetTracking actorStateOrProvince(AnyOforgResoMetadataInternetTrackingActorStateOrProvince actorStateOrProvince) {
    this.actorStateOrProvince = actorStateOrProvince;
    return this;
  }

  /**
   * Get actorStateOrProvince
   * @return actorStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorStateOrProvince getActorStateOrProvince() {
    return actorStateOrProvince;
  }

  public void setActorStateOrProvince(AnyOforgResoMetadataInternetTrackingActorStateOrProvince actorStateOrProvince) {
    this.actorStateOrProvince = actorStateOrProvince;
  }

  public OrgResoMetadataInternetTracking actorType(AnyOforgResoMetadataInternetTrackingActorType actorType) {
    this.actorType = actorType;
    return this;
  }

  /**
   * Get actorType
   * @return actorType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorType getActorType() {
    return actorType;
  }

  public void setActorType(AnyOforgResoMetadataInternetTrackingActorType actorType) {
    this.actorType = actorType;
  }

  public OrgResoMetadataInternetTracking colorDepth(AnyOforgResoMetadataInternetTrackingColorDepth colorDepth) {
    this.colorDepth = colorDepth;
    return this;
  }

  /**
   * Get colorDepth
   * @return colorDepth
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingColorDepth getColorDepth() {
    return colorDepth;
  }

  public void setColorDepth(AnyOforgResoMetadataInternetTrackingColorDepth colorDepth) {
    this.colorDepth = colorDepth;
  }

  public OrgResoMetadataInternetTracking deviceType(AnyOforgResoMetadataInternetTrackingDeviceType deviceType) {
    this.deviceType = deviceType;
    return this;
  }

  /**
   * Get deviceType
   * @return deviceType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingDeviceType getDeviceType() {
    return deviceType;
  }

  public void setDeviceType(AnyOforgResoMetadataInternetTrackingDeviceType deviceType) {
    this.deviceType = deviceType;
  }

  public OrgResoMetadataInternetTracking eventDescription(String eventDescription) {
    this.eventDescription = eventDescription;
    return this;
  }

  /**
   * Get eventDescription
   * @return eventDescription
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getEventDescription() {
    return eventDescription;
  }

  public void setEventDescription(String eventDescription) {
    this.eventDescription = eventDescription;
  }

  public OrgResoMetadataInternetTracking eventKey(String eventKey) {
    this.eventKey = eventKey;
    return this;
  }

  /**
   * Get eventKey
   * @return eventKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getEventKey() {
    return eventKey;
  }

  public void setEventKey(String eventKey) {
    this.eventKey = eventKey;
  }

  public OrgResoMetadataInternetTracking eventKeyNumeric(AnyOforgResoMetadataInternetTrackingEventKeyNumeric eventKeyNumeric) {
    this.eventKeyNumeric = eventKeyNumeric;
    return this;
  }

  /**
   * Get eventKeyNumeric
   * @return eventKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingEventKeyNumeric getEventKeyNumeric() {
    return eventKeyNumeric;
  }

  public void setEventKeyNumeric(AnyOforgResoMetadataInternetTrackingEventKeyNumeric eventKeyNumeric) {
    this.eventKeyNumeric = eventKeyNumeric;
  }

  public OrgResoMetadataInternetTracking eventLabel(String eventLabel) {
    this.eventLabel = eventLabel;
    return this;
  }

  /**
   * Get eventLabel
   * @return eventLabel
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getEventLabel() {
    return eventLabel;
  }

  public void setEventLabel(String eventLabel) {
    this.eventLabel = eventLabel;
  }

  public OrgResoMetadataInternetTracking eventOriginatingSystemID(String eventOriginatingSystemID) {
    this.eventOriginatingSystemID = eventOriginatingSystemID;
    return this;
  }

  /**
   * Get eventOriginatingSystemID
   * @return eventOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getEventOriginatingSystemID() {
    return eventOriginatingSystemID;
  }

  public void setEventOriginatingSystemID(String eventOriginatingSystemID) {
    this.eventOriginatingSystemID = eventOriginatingSystemID;
  }

  public OrgResoMetadataInternetTracking eventOriginatingSystemName(String eventOriginatingSystemName) {
    this.eventOriginatingSystemName = eventOriginatingSystemName;
    return this;
  }

  /**
   * Get eventOriginatingSystemName
   * @return eventOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getEventOriginatingSystemName() {
    return eventOriginatingSystemName;
  }

  public void setEventOriginatingSystemName(String eventOriginatingSystemName) {
    this.eventOriginatingSystemName = eventOriginatingSystemName;
  }

  public OrgResoMetadataInternetTracking eventSourceSystemID(String eventSourceSystemID) {
    this.eventSourceSystemID = eventSourceSystemID;
    return this;
  }

  /**
   * Get eventSourceSystemID
   * @return eventSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getEventSourceSystemID() {
    return eventSourceSystemID;
  }

  public void setEventSourceSystemID(String eventSourceSystemID) {
    this.eventSourceSystemID = eventSourceSystemID;
  }

  public OrgResoMetadataInternetTracking eventSourceSystemName(String eventSourceSystemName) {
    this.eventSourceSystemName = eventSourceSystemName;
    return this;
  }

  /**
   * Get eventSourceSystemName
   * @return eventSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getEventSourceSystemName() {
    return eventSourceSystemName;
  }

  public void setEventSourceSystemName(String eventSourceSystemName) {
    this.eventSourceSystemName = eventSourceSystemName;
  }

  public OrgResoMetadataInternetTracking eventTarget(AnyOforgResoMetadataInternetTrackingEventTarget eventTarget) {
    this.eventTarget = eventTarget;
    return this;
  }

  /**
   * Get eventTarget
   * @return eventTarget
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingEventTarget getEventTarget() {
    return eventTarget;
  }

  public void setEventTarget(AnyOforgResoMetadataInternetTrackingEventTarget eventTarget) {
    this.eventTarget = eventTarget;
  }

  public OrgResoMetadataInternetTracking eventTimestamp(OffsetDateTime eventTimestamp) {
    this.eventTimestamp = eventTimestamp;
    return this;
  }

  /**
   * Get eventTimestamp
   * @return eventTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getEventTimestamp() {
    return eventTimestamp;
  }

  public void setEventTimestamp(OffsetDateTime eventTimestamp) {
    this.eventTimestamp = eventTimestamp;
  }

  public OrgResoMetadataInternetTracking eventType(AnyOforgResoMetadataInternetTrackingEventType eventType) {
    this.eventType = eventType;
    return this;
  }

  /**
   * Get eventType
   * @return eventType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingEventType getEventType() {
    return eventType;
  }

  public void setEventType(AnyOforgResoMetadataInternetTrackingEventType eventType) {
    this.eventType = eventType;
  }

  public OrgResoMetadataInternetTracking objectID(String objectID) {
    this.objectID = objectID;
    return this;
  }

  /**
   * Get objectID
   * @return objectID
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getObjectID() {
    return objectID;
  }

  public void setObjectID(String objectID) {
    this.objectID = objectID;
  }

  public OrgResoMetadataInternetTracking objectIdType(AnyOforgResoMetadataInternetTrackingObjectIdType objectIdType) {
    this.objectIdType = objectIdType;
    return this;
  }

  /**
   * Get objectIdType
   * @return objectIdType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingObjectIdType getObjectIdType() {
    return objectIdType;
  }

  public void setObjectIdType(AnyOforgResoMetadataInternetTrackingObjectIdType objectIdType) {
    this.objectIdType = objectIdType;
  }

  public OrgResoMetadataInternetTracking objectKey(String objectKey) {
    this.objectKey = objectKey;
    return this;
  }

  /**
   * Get objectKey
   * @return objectKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getObjectKey() {
    return objectKey;
  }

  public void setObjectKey(String objectKey) {
    this.objectKey = objectKey;
  }

  public OrgResoMetadataInternetTracking objectKeyNumeric(AnyOforgResoMetadataInternetTrackingObjectKeyNumeric objectKeyNumeric) {
    this.objectKeyNumeric = objectKeyNumeric;
    return this;
  }

  /**
   * Get objectKeyNumeric
   * @return objectKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingObjectKeyNumeric getObjectKeyNumeric() {
    return objectKeyNumeric;
  }

  public void setObjectKeyNumeric(AnyOforgResoMetadataInternetTrackingObjectKeyNumeric objectKeyNumeric) {
    this.objectKeyNumeric = objectKeyNumeric;
  }

  public OrgResoMetadataInternetTracking objectOriginatingSystemID(String objectOriginatingSystemID) {
    this.objectOriginatingSystemID = objectOriginatingSystemID;
    return this;
  }

  /**
   * Get objectOriginatingSystemID
   * @return objectOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getObjectOriginatingSystemID() {
    return objectOriginatingSystemID;
  }

  public void setObjectOriginatingSystemID(String objectOriginatingSystemID) {
    this.objectOriginatingSystemID = objectOriginatingSystemID;
  }

  public OrgResoMetadataInternetTracking objectOriginatingSystemName(String objectOriginatingSystemName) {
    this.objectOriginatingSystemName = objectOriginatingSystemName;
    return this;
  }

  /**
   * Get objectOriginatingSystemName
   * @return objectOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getObjectOriginatingSystemName() {
    return objectOriginatingSystemName;
  }

  public void setObjectOriginatingSystemName(String objectOriginatingSystemName) {
    this.objectOriginatingSystemName = objectOriginatingSystemName;
  }

  public OrgResoMetadataInternetTracking objectSourceSystemID(String objectSourceSystemID) {
    this.objectSourceSystemID = objectSourceSystemID;
    return this;
  }

  /**
   * Get objectSourceSystemID
   * @return objectSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getObjectSourceSystemID() {
    return objectSourceSystemID;
  }

  public void setObjectSourceSystemID(String objectSourceSystemID) {
    this.objectSourceSystemID = objectSourceSystemID;
  }

  public OrgResoMetadataInternetTracking objectSourceSystemName(String objectSourceSystemName) {
    this.objectSourceSystemName = objectSourceSystemName;
    return this;
  }

  /**
   * Get objectSourceSystemName
   * @return objectSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getObjectSourceSystemName() {
    return objectSourceSystemName;
  }

  public void setObjectSourceSystemName(String objectSourceSystemName) {
    this.objectSourceSystemName = objectSourceSystemName;
  }

  public OrgResoMetadataInternetTracking objectType(AnyOforgResoMetadataInternetTrackingObjectType objectType) {
    this.objectType = objectType;
    return this;
  }

  /**
   * Get objectType
   * @return objectType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingObjectType getObjectType() {
    return objectType;
  }

  public void setObjectType(AnyOforgResoMetadataInternetTrackingObjectType objectType) {
    this.objectType = objectType;
  }

  public OrgResoMetadataInternetTracking objectURL(String objectURL) {
    this.objectURL = objectURL;
    return this;
  }

  /**
   * Get objectURL
   * @return objectURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getObjectURL() {
    return objectURL;
  }

  public void setObjectURL(String objectURL) {
    this.objectURL = objectURL;
  }

  public OrgResoMetadataInternetTracking originatingSystemActorKey(String originatingSystemActorKey) {
    this.originatingSystemActorKey = originatingSystemActorKey;
    return this;
  }

  /**
   * Get originatingSystemActorKey
   * @return originatingSystemActorKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemActorKey() {
    return originatingSystemActorKey;
  }

  public void setOriginatingSystemActorKey(String originatingSystemActorKey) {
    this.originatingSystemActorKey = originatingSystemActorKey;
  }

  public OrgResoMetadataInternetTracking originatingSystemEventKey(String originatingSystemEventKey) {
    this.originatingSystemEventKey = originatingSystemEventKey;
    return this;
  }

  /**
   * Get originatingSystemEventKey
   * @return originatingSystemEventKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemEventKey() {
    return originatingSystemEventKey;
  }

  public void setOriginatingSystemEventKey(String originatingSystemEventKey) {
    this.originatingSystemEventKey = originatingSystemEventKey;
  }

  public OrgResoMetadataInternetTracking originatingSystemObjectKey(String originatingSystemObjectKey) {
    this.originatingSystemObjectKey = originatingSystemObjectKey;
    return this;
  }

  /**
   * Get originatingSystemObjectKey
   * @return originatingSystemObjectKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemObjectKey() {
    return originatingSystemObjectKey;
  }

  public void setOriginatingSystemObjectKey(String originatingSystemObjectKey) {
    this.originatingSystemObjectKey = originatingSystemObjectKey;
  }

  public OrgResoMetadataInternetTracking referringURL(String referringURL) {
    this.referringURL = referringURL;
    return this;
  }

  /**
   * Get referringURL
   * @return referringURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getReferringURL() {
    return referringURL;
  }

  public void setReferringURL(String referringURL) {
    this.referringURL = referringURL;
  }

  public OrgResoMetadataInternetTracking screenHeight(AnyOforgResoMetadataInternetTrackingScreenHeight screenHeight) {
    this.screenHeight = screenHeight;
    return this;
  }

  /**
   * Get screenHeight
   * @return screenHeight
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingScreenHeight getScreenHeight() {
    return screenHeight;
  }

  public void setScreenHeight(AnyOforgResoMetadataInternetTrackingScreenHeight screenHeight) {
    this.screenHeight = screenHeight;
  }

  public OrgResoMetadataInternetTracking screenWidth(AnyOforgResoMetadataInternetTrackingScreenWidth screenWidth) {
    this.screenWidth = screenWidth;
    return this;
  }

  /**
   * Get screenWidth
   * @return screenWidth
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingScreenWidth getScreenWidth() {
    return screenWidth;
  }

  public void setScreenWidth(AnyOforgResoMetadataInternetTrackingScreenWidth screenWidth) {
    this.screenWidth = screenWidth;
  }

  public OrgResoMetadataInternetTracking sessionID(String sessionID) {
    this.sessionID = sessionID;
    return this;
  }

  /**
   * Get sessionID
   * @return sessionID
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSessionID() {
    return sessionID;
  }

  public void setSessionID(String sessionID) {
    this.sessionID = sessionID;
  }

  public OrgResoMetadataInternetTracking sourceSystemActorKey(String sourceSystemActorKey) {
    this.sourceSystemActorKey = sourceSystemActorKey;
    return this;
  }

  /**
   * Get sourceSystemActorKey
   * @return sourceSystemActorKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemActorKey() {
    return sourceSystemActorKey;
  }

  public void setSourceSystemActorKey(String sourceSystemActorKey) {
    this.sourceSystemActorKey = sourceSystemActorKey;
  }

  public OrgResoMetadataInternetTracking sourceSystemEventKey(String sourceSystemEventKey) {
    this.sourceSystemEventKey = sourceSystemEventKey;
    return this;
  }

  /**
   * Get sourceSystemEventKey
   * @return sourceSystemEventKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemEventKey() {
    return sourceSystemEventKey;
  }

  public void setSourceSystemEventKey(String sourceSystemEventKey) {
    this.sourceSystemEventKey = sourceSystemEventKey;
  }

  public OrgResoMetadataInternetTracking sourceSystemObjectKey(String sourceSystemObjectKey) {
    this.sourceSystemObjectKey = sourceSystemObjectKey;
    return this;
  }

  /**
   * Get sourceSystemObjectKey
   * @return sourceSystemObjectKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemObjectKey() {
    return sourceSystemObjectKey;
  }

  public void setSourceSystemObjectKey(String sourceSystemObjectKey) {
    this.sourceSystemObjectKey = sourceSystemObjectKey;
  }

  public OrgResoMetadataInternetTracking timeZoneOffset(AnyOforgResoMetadataInternetTrackingTimeZoneOffset timeZoneOffset) {
    this.timeZoneOffset = timeZoneOffset;
    return this;
  }

  /**
   * Get timeZoneOffset
   * @return timeZoneOffset
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataInternetTrackingTimeZoneOffset getTimeZoneOffset() {
    return timeZoneOffset;
  }

  public void setTimeZoneOffset(AnyOforgResoMetadataInternetTrackingTimeZoneOffset timeZoneOffset) {
    this.timeZoneOffset = timeZoneOffset;
  }

  public OrgResoMetadataInternetTracking userAgent(String userAgent) {
    this.userAgent = userAgent;
    return this;
  }

  /**
   * Get userAgent
   * @return userAgent
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getUserAgent() {
    return userAgent;
  }

  public void setUserAgent(String userAgent) {
    this.userAgent = userAgent;
  }

  public OrgResoMetadataInternetTracking actorOriginatingSystem(AnyOforgResoMetadataInternetTrackingActorOriginatingSystem actorOriginatingSystem) {
    this.actorOriginatingSystem = actorOriginatingSystem;
    return this;
  }

  /**
   * Get actorOriginatingSystem
   * @return actorOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorOriginatingSystem getActorOriginatingSystem() {
    return actorOriginatingSystem;
  }

  public void setActorOriginatingSystem(AnyOforgResoMetadataInternetTrackingActorOriginatingSystem actorOriginatingSystem) {
    this.actorOriginatingSystem = actorOriginatingSystem;
  }

  public OrgResoMetadataInternetTracking actorSourceSystem(AnyOforgResoMetadataInternetTrackingActorSourceSystem actorSourceSystem) {
    this.actorSourceSystem = actorSourceSystem;
    return this;
  }

  /**
   * Get actorSourceSystem
   * @return actorSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingActorSourceSystem getActorSourceSystem() {
    return actorSourceSystem;
  }

  public void setActorSourceSystem(AnyOforgResoMetadataInternetTrackingActorSourceSystem actorSourceSystem) {
    this.actorSourceSystem = actorSourceSystem;
  }

  public OrgResoMetadataInternetTracking eventOriginatingSystem(AnyOforgResoMetadataInternetTrackingEventOriginatingSystem eventOriginatingSystem) {
    this.eventOriginatingSystem = eventOriginatingSystem;
    return this;
  }

  /**
   * Get eventOriginatingSystem
   * @return eventOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingEventOriginatingSystem getEventOriginatingSystem() {
    return eventOriginatingSystem;
  }

  public void setEventOriginatingSystem(AnyOforgResoMetadataInternetTrackingEventOriginatingSystem eventOriginatingSystem) {
    this.eventOriginatingSystem = eventOriginatingSystem;
  }

  public OrgResoMetadataInternetTracking eventSourceSystem(AnyOforgResoMetadataInternetTrackingEventSourceSystem eventSourceSystem) {
    this.eventSourceSystem = eventSourceSystem;
    return this;
  }

  /**
   * Get eventSourceSystem
   * @return eventSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingEventSourceSystem getEventSourceSystem() {
    return eventSourceSystem;
  }

  public void setEventSourceSystem(AnyOforgResoMetadataInternetTrackingEventSourceSystem eventSourceSystem) {
    this.eventSourceSystem = eventSourceSystem;
  }

  public OrgResoMetadataInternetTracking objectOriginatingSystem(AnyOforgResoMetadataInternetTrackingObjectOriginatingSystem objectOriginatingSystem) {
    this.objectOriginatingSystem = objectOriginatingSystem;
    return this;
  }

  /**
   * Get objectOriginatingSystem
   * @return objectOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingObjectOriginatingSystem getObjectOriginatingSystem() {
    return objectOriginatingSystem;
  }

  public void setObjectOriginatingSystem(AnyOforgResoMetadataInternetTrackingObjectOriginatingSystem objectOriginatingSystem) {
    this.objectOriginatingSystem = objectOriginatingSystem;
  }

  public OrgResoMetadataInternetTracking objectSourceSystem(AnyOforgResoMetadataInternetTrackingObjectSourceSystem objectSourceSystem) {
    this.objectSourceSystem = objectSourceSystem;
    return this;
  }

  /**
   * Get objectSourceSystem
   * @return objectSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataInternetTrackingObjectSourceSystem getObjectSourceSystem() {
    return objectSourceSystem;
  }

  public void setObjectSourceSystem(AnyOforgResoMetadataInternetTrackingObjectSourceSystem objectSourceSystem) {
    this.objectSourceSystem = objectSourceSystem;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataInternetTracking orgResoMetadataInternetTracking = (OrgResoMetadataInternetTracking) o;
    return Objects.equals(this.actorCity, orgResoMetadataInternetTracking.actorCity) &&
        Objects.equals(this.actorEmail, orgResoMetadataInternetTracking.actorEmail) &&
        Objects.equals(this.actorID, orgResoMetadataInternetTracking.actorID) &&
        Objects.equals(this.actorIP, orgResoMetadataInternetTracking.actorIP) &&
        Objects.equals(this.actorKey, orgResoMetadataInternetTracking.actorKey) &&
        Objects.equals(this.actorKeyNumeric, orgResoMetadataInternetTracking.actorKeyNumeric) &&
        Objects.equals(this.actorLatitude, orgResoMetadataInternetTracking.actorLatitude) &&
        Objects.equals(this.actorLongitude, orgResoMetadataInternetTracking.actorLongitude) &&
        Objects.equals(this.actorOriginatingSystemID, orgResoMetadataInternetTracking.actorOriginatingSystemID) &&
        Objects.equals(this.actorOriginatingSystemName, orgResoMetadataInternetTracking.actorOriginatingSystemName) &&
        Objects.equals(this.actorPhone, orgResoMetadataInternetTracking.actorPhone) &&
        Objects.equals(this.actorPhoneExt, orgResoMetadataInternetTracking.actorPhoneExt) &&
        Objects.equals(this.actorPostalCode, orgResoMetadataInternetTracking.actorPostalCode) &&
        Objects.equals(this.actorPostalCodePlus4, orgResoMetadataInternetTracking.actorPostalCodePlus4) &&
        Objects.equals(this.actorRegion, orgResoMetadataInternetTracking.actorRegion) &&
        Objects.equals(this.actorSourceSystemID, orgResoMetadataInternetTracking.actorSourceSystemID) &&
        Objects.equals(this.actorSourceSystemName, orgResoMetadataInternetTracking.actorSourceSystemName) &&
        Objects.equals(this.actorStateOrProvince, orgResoMetadataInternetTracking.actorStateOrProvince) &&
        Objects.equals(this.actorType, orgResoMetadataInternetTracking.actorType) &&
        Objects.equals(this.colorDepth, orgResoMetadataInternetTracking.colorDepth) &&
        Objects.equals(this.deviceType, orgResoMetadataInternetTracking.deviceType) &&
        Objects.equals(this.eventDescription, orgResoMetadataInternetTracking.eventDescription) &&
        Objects.equals(this.eventKey, orgResoMetadataInternetTracking.eventKey) &&
        Objects.equals(this.eventKeyNumeric, orgResoMetadataInternetTracking.eventKeyNumeric) &&
        Objects.equals(this.eventLabel, orgResoMetadataInternetTracking.eventLabel) &&
        Objects.equals(this.eventOriginatingSystemID, orgResoMetadataInternetTracking.eventOriginatingSystemID) &&
        Objects.equals(this.eventOriginatingSystemName, orgResoMetadataInternetTracking.eventOriginatingSystemName) &&
        Objects.equals(this.eventSourceSystemID, orgResoMetadataInternetTracking.eventSourceSystemID) &&
        Objects.equals(this.eventSourceSystemName, orgResoMetadataInternetTracking.eventSourceSystemName) &&
        Objects.equals(this.eventTarget, orgResoMetadataInternetTracking.eventTarget) &&
        Objects.equals(this.eventTimestamp, orgResoMetadataInternetTracking.eventTimestamp) &&
        Objects.equals(this.eventType, orgResoMetadataInternetTracking.eventType) &&
        Objects.equals(this.objectID, orgResoMetadataInternetTracking.objectID) &&
        Objects.equals(this.objectIdType, orgResoMetadataInternetTracking.objectIdType) &&
        Objects.equals(this.objectKey, orgResoMetadataInternetTracking.objectKey) &&
        Objects.equals(this.objectKeyNumeric, orgResoMetadataInternetTracking.objectKeyNumeric) &&
        Objects.equals(this.objectOriginatingSystemID, orgResoMetadataInternetTracking.objectOriginatingSystemID) &&
        Objects.equals(this.objectOriginatingSystemName, orgResoMetadataInternetTracking.objectOriginatingSystemName) &&
        Objects.equals(this.objectSourceSystemID, orgResoMetadataInternetTracking.objectSourceSystemID) &&
        Objects.equals(this.objectSourceSystemName, orgResoMetadataInternetTracking.objectSourceSystemName) &&
        Objects.equals(this.objectType, orgResoMetadataInternetTracking.objectType) &&
        Objects.equals(this.objectURL, orgResoMetadataInternetTracking.objectURL) &&
        Objects.equals(this.originatingSystemActorKey, orgResoMetadataInternetTracking.originatingSystemActorKey) &&
        Objects.equals(this.originatingSystemEventKey, orgResoMetadataInternetTracking.originatingSystemEventKey) &&
        Objects.equals(this.originatingSystemObjectKey, orgResoMetadataInternetTracking.originatingSystemObjectKey) &&
        Objects.equals(this.referringURL, orgResoMetadataInternetTracking.referringURL) &&
        Objects.equals(this.screenHeight, orgResoMetadataInternetTracking.screenHeight) &&
        Objects.equals(this.screenWidth, orgResoMetadataInternetTracking.screenWidth) &&
        Objects.equals(this.sessionID, orgResoMetadataInternetTracking.sessionID) &&
        Objects.equals(this.sourceSystemActorKey, orgResoMetadataInternetTracking.sourceSystemActorKey) &&
        Objects.equals(this.sourceSystemEventKey, orgResoMetadataInternetTracking.sourceSystemEventKey) &&
        Objects.equals(this.sourceSystemObjectKey, orgResoMetadataInternetTracking.sourceSystemObjectKey) &&
        Objects.equals(this.timeZoneOffset, orgResoMetadataInternetTracking.timeZoneOffset) &&
        Objects.equals(this.userAgent, orgResoMetadataInternetTracking.userAgent) &&
        Objects.equals(this.actorOriginatingSystem, orgResoMetadataInternetTracking.actorOriginatingSystem) &&
        Objects.equals(this.actorSourceSystem, orgResoMetadataInternetTracking.actorSourceSystem) &&
        Objects.equals(this.eventOriginatingSystem, orgResoMetadataInternetTracking.eventOriginatingSystem) &&
        Objects.equals(this.eventSourceSystem, orgResoMetadataInternetTracking.eventSourceSystem) &&
        Objects.equals(this.objectOriginatingSystem, orgResoMetadataInternetTracking.objectOriginatingSystem) &&
        Objects.equals(this.objectSourceSystem, orgResoMetadataInternetTracking.objectSourceSystem);
  }

  @Override
  public int hashCode() {
    return Objects.hash(actorCity, actorEmail, actorID, actorIP, actorKey, actorKeyNumeric, actorLatitude, actorLongitude, actorOriginatingSystemID, actorOriginatingSystemName, actorPhone, actorPhoneExt, actorPostalCode, actorPostalCodePlus4, actorRegion, actorSourceSystemID, actorSourceSystemName, actorStateOrProvince, actorType, colorDepth, deviceType, eventDescription, eventKey, eventKeyNumeric, eventLabel, eventOriginatingSystemID, eventOriginatingSystemName, eventSourceSystemID, eventSourceSystemName, eventTarget, eventTimestamp, eventType, objectID, objectIdType, objectKey, objectKeyNumeric, objectOriginatingSystemID, objectOriginatingSystemName, objectSourceSystemID, objectSourceSystemName, objectType, objectURL, originatingSystemActorKey, originatingSystemEventKey, originatingSystemObjectKey, referringURL, screenHeight, screenWidth, sessionID, sourceSystemActorKey, sourceSystemEventKey, sourceSystemObjectKey, timeZoneOffset, userAgent, actorOriginatingSystem, actorSourceSystem, eventOriginatingSystem, eventSourceSystem, objectOriginatingSystem, objectSourceSystem);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataInternetTracking {\n");
    
    sb.append("    actorCity: ").append(toIndentedString(actorCity)).append("\n");
    sb.append("    actorEmail: ").append(toIndentedString(actorEmail)).append("\n");
    sb.append("    actorID: ").append(toIndentedString(actorID)).append("\n");
    sb.append("    actorIP: ").append(toIndentedString(actorIP)).append("\n");
    sb.append("    actorKey: ").append(toIndentedString(actorKey)).append("\n");
    sb.append("    actorKeyNumeric: ").append(toIndentedString(actorKeyNumeric)).append("\n");
    sb.append("    actorLatitude: ").append(toIndentedString(actorLatitude)).append("\n");
    sb.append("    actorLongitude: ").append(toIndentedString(actorLongitude)).append("\n");
    sb.append("    actorOriginatingSystemID: ").append(toIndentedString(actorOriginatingSystemID)).append("\n");
    sb.append("    actorOriginatingSystemName: ").append(toIndentedString(actorOriginatingSystemName)).append("\n");
    sb.append("    actorPhone: ").append(toIndentedString(actorPhone)).append("\n");
    sb.append("    actorPhoneExt: ").append(toIndentedString(actorPhoneExt)).append("\n");
    sb.append("    actorPostalCode: ").append(toIndentedString(actorPostalCode)).append("\n");
    sb.append("    actorPostalCodePlus4: ").append(toIndentedString(actorPostalCodePlus4)).append("\n");
    sb.append("    actorRegion: ").append(toIndentedString(actorRegion)).append("\n");
    sb.append("    actorSourceSystemID: ").append(toIndentedString(actorSourceSystemID)).append("\n");
    sb.append("    actorSourceSystemName: ").append(toIndentedString(actorSourceSystemName)).append("\n");
    sb.append("    actorStateOrProvince: ").append(toIndentedString(actorStateOrProvince)).append("\n");
    sb.append("    actorType: ").append(toIndentedString(actorType)).append("\n");
    sb.append("    colorDepth: ").append(toIndentedString(colorDepth)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    eventDescription: ").append(toIndentedString(eventDescription)).append("\n");
    sb.append("    eventKey: ").append(toIndentedString(eventKey)).append("\n");
    sb.append("    eventKeyNumeric: ").append(toIndentedString(eventKeyNumeric)).append("\n");
    sb.append("    eventLabel: ").append(toIndentedString(eventLabel)).append("\n");
    sb.append("    eventOriginatingSystemID: ").append(toIndentedString(eventOriginatingSystemID)).append("\n");
    sb.append("    eventOriginatingSystemName: ").append(toIndentedString(eventOriginatingSystemName)).append("\n");
    sb.append("    eventSourceSystemID: ").append(toIndentedString(eventSourceSystemID)).append("\n");
    sb.append("    eventSourceSystemName: ").append(toIndentedString(eventSourceSystemName)).append("\n");
    sb.append("    eventTarget: ").append(toIndentedString(eventTarget)).append("\n");
    sb.append("    eventTimestamp: ").append(toIndentedString(eventTimestamp)).append("\n");
    sb.append("    eventType: ").append(toIndentedString(eventType)).append("\n");
    sb.append("    objectID: ").append(toIndentedString(objectID)).append("\n");
    sb.append("    objectIdType: ").append(toIndentedString(objectIdType)).append("\n");
    sb.append("    objectKey: ").append(toIndentedString(objectKey)).append("\n");
    sb.append("    objectKeyNumeric: ").append(toIndentedString(objectKeyNumeric)).append("\n");
    sb.append("    objectOriginatingSystemID: ").append(toIndentedString(objectOriginatingSystemID)).append("\n");
    sb.append("    objectOriginatingSystemName: ").append(toIndentedString(objectOriginatingSystemName)).append("\n");
    sb.append("    objectSourceSystemID: ").append(toIndentedString(objectSourceSystemID)).append("\n");
    sb.append("    objectSourceSystemName: ").append(toIndentedString(objectSourceSystemName)).append("\n");
    sb.append("    objectType: ").append(toIndentedString(objectType)).append("\n");
    sb.append("    objectURL: ").append(toIndentedString(objectURL)).append("\n");
    sb.append("    originatingSystemActorKey: ").append(toIndentedString(originatingSystemActorKey)).append("\n");
    sb.append("    originatingSystemEventKey: ").append(toIndentedString(originatingSystemEventKey)).append("\n");
    sb.append("    originatingSystemObjectKey: ").append(toIndentedString(originatingSystemObjectKey)).append("\n");
    sb.append("    referringURL: ").append(toIndentedString(referringURL)).append("\n");
    sb.append("    screenHeight: ").append(toIndentedString(screenHeight)).append("\n");
    sb.append("    screenWidth: ").append(toIndentedString(screenWidth)).append("\n");
    sb.append("    sessionID: ").append(toIndentedString(sessionID)).append("\n");
    sb.append("    sourceSystemActorKey: ").append(toIndentedString(sourceSystemActorKey)).append("\n");
    sb.append("    sourceSystemEventKey: ").append(toIndentedString(sourceSystemEventKey)).append("\n");
    sb.append("    sourceSystemObjectKey: ").append(toIndentedString(sourceSystemObjectKey)).append("\n");
    sb.append("    timeZoneOffset: ").append(toIndentedString(timeZoneOffset)).append("\n");
    sb.append("    userAgent: ").append(toIndentedString(userAgent)).append("\n");
    sb.append("    actorOriginatingSystem: ").append(toIndentedString(actorOriginatingSystem)).append("\n");
    sb.append("    actorSourceSystem: ").append(toIndentedString(actorSourceSystem)).append("\n");
    sb.append("    eventOriginatingSystem: ").append(toIndentedString(eventOriginatingSystem)).append("\n");
    sb.append("    eventSourceSystem: ").append(toIndentedString(eventSourceSystem)).append("\n");
    sb.append("    objectOriginatingSystem: ").append(toIndentedString(objectOriginatingSystem)).append("\n");
    sb.append("    objectSourceSystem: ").append(toIndentedString(objectSourceSystem)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
