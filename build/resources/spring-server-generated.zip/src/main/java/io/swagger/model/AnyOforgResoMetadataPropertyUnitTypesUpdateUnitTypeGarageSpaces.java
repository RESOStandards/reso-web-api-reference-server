package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUpdateUnitTypeGarageSpaces
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUpdateUnitTypeGarageSpaces {

}
