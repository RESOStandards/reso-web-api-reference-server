package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.ShowingContactType
 */
public enum OrgResoMetadataEnumsShowingContactType {
  AGENT("Agent"),
    OCCUPANT("Occupant"),
    OWNER("Owner"),
    PROPERTYMANAGER("PropertyManager");

  private String value;

  OrgResoMetadataEnumsShowingContactType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsShowingContactType fromValue(String text) {
    for (OrgResoMetadataEnumsShowingContactType b : OrgResoMetadataEnumsShowingContactType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
