package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDirectionFaces
*/
public interface AnyOforgResoMetadataPropertyDirectionFaces {

}
