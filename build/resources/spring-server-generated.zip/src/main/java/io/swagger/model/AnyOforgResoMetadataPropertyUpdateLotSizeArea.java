package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateLotSizeArea
*/
public interface AnyOforgResoMetadataPropertyUpdateLotSizeArea {

}
