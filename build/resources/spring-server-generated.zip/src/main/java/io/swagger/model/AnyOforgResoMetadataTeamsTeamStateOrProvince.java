package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsTeamStateOrProvince
*/
public interface AnyOforgResoMetadataTeamsTeamStateOrProvince {

}
