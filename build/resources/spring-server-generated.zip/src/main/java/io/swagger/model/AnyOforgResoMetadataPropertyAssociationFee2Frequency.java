package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyAssociationFee2Frequency
*/
public interface AnyOforgResoMetadataPropertyAssociationFee2Frequency {

}
