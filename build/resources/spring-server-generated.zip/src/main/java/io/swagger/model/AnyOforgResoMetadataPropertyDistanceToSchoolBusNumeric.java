package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric
*/
public interface AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric {

}
