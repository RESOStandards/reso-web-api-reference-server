package io.swagger.model;


/**
* AnyOforgResoMetadataSocialMediaResourceName
*/
public interface AnyOforgResoMetadataSocialMediaResourceName {

}
