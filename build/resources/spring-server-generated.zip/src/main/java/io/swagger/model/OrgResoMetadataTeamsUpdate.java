package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataTeamsUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataTeamsUpdate   {
  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("SocialMediaType")
  private AnyOforgResoMetadataTeamsUpdateSocialMediaType socialMediaType = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("TeamAddress1")
  private String teamAddress1 = null;

  @JsonProperty("TeamAddress2")
  private String teamAddress2 = null;

  @JsonProperty("TeamCarrierRoute")
  private String teamCarrierRoute = null;

  @JsonProperty("TeamCity")
  private String teamCity = null;

  @JsonProperty("TeamCountry")
  private AnyOforgResoMetadataTeamsUpdateTeamCountry teamCountry = null;

  @JsonProperty("TeamCountyOrParish")
  private AnyOforgResoMetadataTeamsUpdateTeamCountyOrParish teamCountyOrParish = null;

  @JsonProperty("TeamDescription")
  private String teamDescription = null;

  @JsonProperty("TeamDirectPhone")
  private String teamDirectPhone = null;

  @JsonProperty("TeamEmail")
  private String teamEmail = null;

  @JsonProperty("TeamFax")
  private String teamFax = null;

  @JsonProperty("TeamKeyNumeric")
  private AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric teamKeyNumeric = null;

  @JsonProperty("TeamLeadKey")
  private String teamLeadKey = null;

  @JsonProperty("TeamLeadKeyNumeric")
  private AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric teamLeadKeyNumeric = null;

  @JsonProperty("TeamLeadLoginId")
  private String teamLeadLoginId = null;

  @JsonProperty("TeamLeadMlsId")
  private String teamLeadMlsId = null;

  @JsonProperty("TeamLeadNationalAssociationId")
  private String teamLeadNationalAssociationId = null;

  @JsonProperty("TeamLeadStateLicense")
  private String teamLeadStateLicense = null;

  @JsonProperty("TeamLeadStateLicenseState")
  private AnyOforgResoMetadataTeamsUpdateTeamLeadStateLicenseState teamLeadStateLicenseState = null;

  @JsonProperty("TeamMobilePhone")
  private String teamMobilePhone = null;

  @JsonProperty("TeamName")
  private String teamName = null;

  @JsonProperty("TeamOfficePhone")
  private String teamOfficePhone = null;

  @JsonProperty("TeamOfficePhoneExt")
  private String teamOfficePhoneExt = null;

  @JsonProperty("TeamPostalCode")
  private String teamPostalCode = null;

  @JsonProperty("TeamPostalCodePlus4")
  private String teamPostalCodePlus4 = null;

  @JsonProperty("TeamPreferredPhone")
  private String teamPreferredPhone = null;

  @JsonProperty("TeamPreferredPhoneExt")
  private String teamPreferredPhoneExt = null;

  @JsonProperty("TeamStateOrProvince")
  private AnyOforgResoMetadataTeamsUpdateTeamStateOrProvince teamStateOrProvince = null;

  @JsonProperty("TeamStatus")
  private AnyOforgResoMetadataTeamsUpdateTeamStatus teamStatus = null;

  @JsonProperty("TeamTollFreePhone")
  private String teamTollFreePhone = null;

  @JsonProperty("TeamVoiceMail")
  private String teamVoiceMail = null;

  @JsonProperty("TeamVoiceMailExt")
  private String teamVoiceMailExt = null;

  public OrgResoMetadataTeamsUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataTeamsUpdate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataTeamsUpdate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataTeamsUpdate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataTeamsUpdate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataTeamsUpdate socialMediaType(AnyOforgResoMetadataTeamsUpdateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
    return this;
  }

  /**
   * Get socialMediaType
   * @return socialMediaType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateSocialMediaType getSocialMediaType() {
    return socialMediaType;
  }

  public void setSocialMediaType(AnyOforgResoMetadataTeamsUpdateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
  }

  public OrgResoMetadataTeamsUpdate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataTeamsUpdate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataTeamsUpdate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataTeamsUpdate teamAddress1(String teamAddress1) {
    this.teamAddress1 = teamAddress1;
    return this;
  }

  /**
   * Get teamAddress1
   * @return teamAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamAddress1() {
    return teamAddress1;
  }

  public void setTeamAddress1(String teamAddress1) {
    this.teamAddress1 = teamAddress1;
  }

  public OrgResoMetadataTeamsUpdate teamAddress2(String teamAddress2) {
    this.teamAddress2 = teamAddress2;
    return this;
  }

  /**
   * Get teamAddress2
   * @return teamAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamAddress2() {
    return teamAddress2;
  }

  public void setTeamAddress2(String teamAddress2) {
    this.teamAddress2 = teamAddress2;
  }

  public OrgResoMetadataTeamsUpdate teamCarrierRoute(String teamCarrierRoute) {
    this.teamCarrierRoute = teamCarrierRoute;
    return this;
  }

  /**
   * Get teamCarrierRoute
   * @return teamCarrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getTeamCarrierRoute() {
    return teamCarrierRoute;
  }

  public void setTeamCarrierRoute(String teamCarrierRoute) {
    this.teamCarrierRoute = teamCarrierRoute;
  }

  public OrgResoMetadataTeamsUpdate teamCity(String teamCity) {
    this.teamCity = teamCity;
    return this;
  }

  /**
   * Get teamCity
   * @return teamCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamCity() {
    return teamCity;
  }

  public void setTeamCity(String teamCity) {
    this.teamCity = teamCity;
  }

  public OrgResoMetadataTeamsUpdate teamCountry(AnyOforgResoMetadataTeamsUpdateTeamCountry teamCountry) {
    this.teamCountry = teamCountry;
    return this;
  }

  /**
   * Get teamCountry
   * @return teamCountry
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamCountry getTeamCountry() {
    return teamCountry;
  }

  public void setTeamCountry(AnyOforgResoMetadataTeamsUpdateTeamCountry teamCountry) {
    this.teamCountry = teamCountry;
  }

  public OrgResoMetadataTeamsUpdate teamCountyOrParish(AnyOforgResoMetadataTeamsUpdateTeamCountyOrParish teamCountyOrParish) {
    this.teamCountyOrParish = teamCountyOrParish;
    return this;
  }

  /**
   * Get teamCountyOrParish
   * @return teamCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamCountyOrParish getTeamCountyOrParish() {
    return teamCountyOrParish;
  }

  public void setTeamCountyOrParish(AnyOforgResoMetadataTeamsUpdateTeamCountyOrParish teamCountyOrParish) {
    this.teamCountyOrParish = teamCountyOrParish;
  }

  public OrgResoMetadataTeamsUpdate teamDescription(String teamDescription) {
    this.teamDescription = teamDescription;
    return this;
  }

  /**
   * Get teamDescription
   * @return teamDescription
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getTeamDescription() {
    return teamDescription;
  }

  public void setTeamDescription(String teamDescription) {
    this.teamDescription = teamDescription;
  }

  public OrgResoMetadataTeamsUpdate teamDirectPhone(String teamDirectPhone) {
    this.teamDirectPhone = teamDirectPhone;
    return this;
  }

  /**
   * Get teamDirectPhone
   * @return teamDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamDirectPhone() {
    return teamDirectPhone;
  }

  public void setTeamDirectPhone(String teamDirectPhone) {
    this.teamDirectPhone = teamDirectPhone;
  }

  public OrgResoMetadataTeamsUpdate teamEmail(String teamEmail) {
    this.teamEmail = teamEmail;
    return this;
  }

  /**
   * Get teamEmail
   * @return teamEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getTeamEmail() {
    return teamEmail;
  }

  public void setTeamEmail(String teamEmail) {
    this.teamEmail = teamEmail;
  }

  public OrgResoMetadataTeamsUpdate teamFax(String teamFax) {
    this.teamFax = teamFax;
    return this;
  }

  /**
   * Get teamFax
   * @return teamFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamFax() {
    return teamFax;
  }

  public void setTeamFax(String teamFax) {
    this.teamFax = teamFax;
  }

  public OrgResoMetadataTeamsUpdate teamKeyNumeric(AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
    return this;
  }

  /**
   * Get teamKeyNumeric
   * @return teamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric getTeamKeyNumeric() {
    return teamKeyNumeric;
  }

  public void setTeamKeyNumeric(AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
  }

  public OrgResoMetadataTeamsUpdate teamLeadKey(String teamLeadKey) {
    this.teamLeadKey = teamLeadKey;
    return this;
  }

  /**
   * Get teamLeadKey
   * @return teamLeadKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTeamLeadKey() {
    return teamLeadKey;
  }

  public void setTeamLeadKey(String teamLeadKey) {
    this.teamLeadKey = teamLeadKey;
  }

  public OrgResoMetadataTeamsUpdate teamLeadKeyNumeric(AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric teamLeadKeyNumeric) {
    this.teamLeadKeyNumeric = teamLeadKeyNumeric;
    return this;
  }

  /**
   * Get teamLeadKeyNumeric
   * @return teamLeadKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric getTeamLeadKeyNumeric() {
    return teamLeadKeyNumeric;
  }

  public void setTeamLeadKeyNumeric(AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric teamLeadKeyNumeric) {
    this.teamLeadKeyNumeric = teamLeadKeyNumeric;
  }

  public OrgResoMetadataTeamsUpdate teamLeadLoginId(String teamLeadLoginId) {
    this.teamLeadLoginId = teamLeadLoginId;
    return this;
  }

  /**
   * Get teamLeadLoginId
   * @return teamLeadLoginId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTeamLeadLoginId() {
    return teamLeadLoginId;
  }

  public void setTeamLeadLoginId(String teamLeadLoginId) {
    this.teamLeadLoginId = teamLeadLoginId;
  }

  public OrgResoMetadataTeamsUpdate teamLeadMlsId(String teamLeadMlsId) {
    this.teamLeadMlsId = teamLeadMlsId;
    return this;
  }

  /**
   * Get teamLeadMlsId
   * @return teamLeadMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTeamLeadMlsId() {
    return teamLeadMlsId;
  }

  public void setTeamLeadMlsId(String teamLeadMlsId) {
    this.teamLeadMlsId = teamLeadMlsId;
  }

  public OrgResoMetadataTeamsUpdate teamLeadNationalAssociationId(String teamLeadNationalAssociationId) {
    this.teamLeadNationalAssociationId = teamLeadNationalAssociationId;
    return this;
  }

  /**
   * Get teamLeadNationalAssociationId
   * @return teamLeadNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTeamLeadNationalAssociationId() {
    return teamLeadNationalAssociationId;
  }

  public void setTeamLeadNationalAssociationId(String teamLeadNationalAssociationId) {
    this.teamLeadNationalAssociationId = teamLeadNationalAssociationId;
  }

  public OrgResoMetadataTeamsUpdate teamLeadStateLicense(String teamLeadStateLicense) {
    this.teamLeadStateLicense = teamLeadStateLicense;
    return this;
  }

  /**
   * Get teamLeadStateLicense
   * @return teamLeadStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamLeadStateLicense() {
    return teamLeadStateLicense;
  }

  public void setTeamLeadStateLicense(String teamLeadStateLicense) {
    this.teamLeadStateLicense = teamLeadStateLicense;
  }

  public OrgResoMetadataTeamsUpdate teamLeadStateLicenseState(AnyOforgResoMetadataTeamsUpdateTeamLeadStateLicenseState teamLeadStateLicenseState) {
    this.teamLeadStateLicenseState = teamLeadStateLicenseState;
    return this;
  }

  /**
   * Get teamLeadStateLicenseState
   * @return teamLeadStateLicenseState
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamLeadStateLicenseState getTeamLeadStateLicenseState() {
    return teamLeadStateLicenseState;
  }

  public void setTeamLeadStateLicenseState(AnyOforgResoMetadataTeamsUpdateTeamLeadStateLicenseState teamLeadStateLicenseState) {
    this.teamLeadStateLicenseState = teamLeadStateLicenseState;
  }

  public OrgResoMetadataTeamsUpdate teamMobilePhone(String teamMobilePhone) {
    this.teamMobilePhone = teamMobilePhone;
    return this;
  }

  /**
   * Get teamMobilePhone
   * @return teamMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamMobilePhone() {
    return teamMobilePhone;
  }

  public void setTeamMobilePhone(String teamMobilePhone) {
    this.teamMobilePhone = teamMobilePhone;
  }

  public OrgResoMetadataTeamsUpdate teamName(String teamName) {
    this.teamName = teamName;
    return this;
  }

  /**
   * Get teamName
   * @return teamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamName() {
    return teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public OrgResoMetadataTeamsUpdate teamOfficePhone(String teamOfficePhone) {
    this.teamOfficePhone = teamOfficePhone;
    return this;
  }

  /**
   * Get teamOfficePhone
   * @return teamOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamOfficePhone() {
    return teamOfficePhone;
  }

  public void setTeamOfficePhone(String teamOfficePhone) {
    this.teamOfficePhone = teamOfficePhone;
  }

  public OrgResoMetadataTeamsUpdate teamOfficePhoneExt(String teamOfficePhoneExt) {
    this.teamOfficePhoneExt = teamOfficePhoneExt;
    return this;
  }

  /**
   * Get teamOfficePhoneExt
   * @return teamOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getTeamOfficePhoneExt() {
    return teamOfficePhoneExt;
  }

  public void setTeamOfficePhoneExt(String teamOfficePhoneExt) {
    this.teamOfficePhoneExt = teamOfficePhoneExt;
  }

  public OrgResoMetadataTeamsUpdate teamPostalCode(String teamPostalCode) {
    this.teamPostalCode = teamPostalCode;
    return this;
  }

  /**
   * Get teamPostalCode
   * @return teamPostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getTeamPostalCode() {
    return teamPostalCode;
  }

  public void setTeamPostalCode(String teamPostalCode) {
    this.teamPostalCode = teamPostalCode;
  }

  public OrgResoMetadataTeamsUpdate teamPostalCodePlus4(String teamPostalCodePlus4) {
    this.teamPostalCodePlus4 = teamPostalCodePlus4;
    return this;
  }

  /**
   * Get teamPostalCodePlus4
   * @return teamPostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getTeamPostalCodePlus4() {
    return teamPostalCodePlus4;
  }

  public void setTeamPostalCodePlus4(String teamPostalCodePlus4) {
    this.teamPostalCodePlus4 = teamPostalCodePlus4;
  }

  public OrgResoMetadataTeamsUpdate teamPreferredPhone(String teamPreferredPhone) {
    this.teamPreferredPhone = teamPreferredPhone;
    return this;
  }

  /**
   * Get teamPreferredPhone
   * @return teamPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamPreferredPhone() {
    return teamPreferredPhone;
  }

  public void setTeamPreferredPhone(String teamPreferredPhone) {
    this.teamPreferredPhone = teamPreferredPhone;
  }

  public OrgResoMetadataTeamsUpdate teamPreferredPhoneExt(String teamPreferredPhoneExt) {
    this.teamPreferredPhoneExt = teamPreferredPhoneExt;
    return this;
  }

  /**
   * Get teamPreferredPhoneExt
   * @return teamPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getTeamPreferredPhoneExt() {
    return teamPreferredPhoneExt;
  }

  public void setTeamPreferredPhoneExt(String teamPreferredPhoneExt) {
    this.teamPreferredPhoneExt = teamPreferredPhoneExt;
  }

  public OrgResoMetadataTeamsUpdate teamStateOrProvince(AnyOforgResoMetadataTeamsUpdateTeamStateOrProvince teamStateOrProvince) {
    this.teamStateOrProvince = teamStateOrProvince;
    return this;
  }

  /**
   * Get teamStateOrProvince
   * @return teamStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamStateOrProvince getTeamStateOrProvince() {
    return teamStateOrProvince;
  }

  public void setTeamStateOrProvince(AnyOforgResoMetadataTeamsUpdateTeamStateOrProvince teamStateOrProvince) {
    this.teamStateOrProvince = teamStateOrProvince;
  }

  public OrgResoMetadataTeamsUpdate teamStatus(AnyOforgResoMetadataTeamsUpdateTeamStatus teamStatus) {
    this.teamStatus = teamStatus;
    return this;
  }

  /**
   * Get teamStatus
   * @return teamStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamsUpdateTeamStatus getTeamStatus() {
    return teamStatus;
  }

  public void setTeamStatus(AnyOforgResoMetadataTeamsUpdateTeamStatus teamStatus) {
    this.teamStatus = teamStatus;
  }

  public OrgResoMetadataTeamsUpdate teamTollFreePhone(String teamTollFreePhone) {
    this.teamTollFreePhone = teamTollFreePhone;
    return this;
  }

  /**
   * Get teamTollFreePhone
   * @return teamTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamTollFreePhone() {
    return teamTollFreePhone;
  }

  public void setTeamTollFreePhone(String teamTollFreePhone) {
    this.teamTollFreePhone = teamTollFreePhone;
  }

  public OrgResoMetadataTeamsUpdate teamVoiceMail(String teamVoiceMail) {
    this.teamVoiceMail = teamVoiceMail;
    return this;
  }

  /**
   * Get teamVoiceMail
   * @return teamVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTeamVoiceMail() {
    return teamVoiceMail;
  }

  public void setTeamVoiceMail(String teamVoiceMail) {
    this.teamVoiceMail = teamVoiceMail;
  }

  public OrgResoMetadataTeamsUpdate teamVoiceMailExt(String teamVoiceMailExt) {
    this.teamVoiceMailExt = teamVoiceMailExt;
    return this;
  }

  /**
   * Get teamVoiceMailExt
   * @return teamVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getTeamVoiceMailExt() {
    return teamVoiceMailExt;
  }

  public void setTeamVoiceMailExt(String teamVoiceMailExt) {
    this.teamVoiceMailExt = teamVoiceMailExt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataTeamsUpdate orgResoMetadataTeamsUpdate = (OrgResoMetadataTeamsUpdate) o;
    return Objects.equals(this.modificationTimestamp, orgResoMetadataTeamsUpdate.modificationTimestamp) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataTeamsUpdate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataTeamsUpdate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataTeamsUpdate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataTeamsUpdate.originatingSystemName) &&
        Objects.equals(this.socialMediaType, orgResoMetadataTeamsUpdate.socialMediaType) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataTeamsUpdate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataTeamsUpdate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataTeamsUpdate.sourceSystemName) &&
        Objects.equals(this.teamAddress1, orgResoMetadataTeamsUpdate.teamAddress1) &&
        Objects.equals(this.teamAddress2, orgResoMetadataTeamsUpdate.teamAddress2) &&
        Objects.equals(this.teamCarrierRoute, orgResoMetadataTeamsUpdate.teamCarrierRoute) &&
        Objects.equals(this.teamCity, orgResoMetadataTeamsUpdate.teamCity) &&
        Objects.equals(this.teamCountry, orgResoMetadataTeamsUpdate.teamCountry) &&
        Objects.equals(this.teamCountyOrParish, orgResoMetadataTeamsUpdate.teamCountyOrParish) &&
        Objects.equals(this.teamDescription, orgResoMetadataTeamsUpdate.teamDescription) &&
        Objects.equals(this.teamDirectPhone, orgResoMetadataTeamsUpdate.teamDirectPhone) &&
        Objects.equals(this.teamEmail, orgResoMetadataTeamsUpdate.teamEmail) &&
        Objects.equals(this.teamFax, orgResoMetadataTeamsUpdate.teamFax) &&
        Objects.equals(this.teamKeyNumeric, orgResoMetadataTeamsUpdate.teamKeyNumeric) &&
        Objects.equals(this.teamLeadKey, orgResoMetadataTeamsUpdate.teamLeadKey) &&
        Objects.equals(this.teamLeadKeyNumeric, orgResoMetadataTeamsUpdate.teamLeadKeyNumeric) &&
        Objects.equals(this.teamLeadLoginId, orgResoMetadataTeamsUpdate.teamLeadLoginId) &&
        Objects.equals(this.teamLeadMlsId, orgResoMetadataTeamsUpdate.teamLeadMlsId) &&
        Objects.equals(this.teamLeadNationalAssociationId, orgResoMetadataTeamsUpdate.teamLeadNationalAssociationId) &&
        Objects.equals(this.teamLeadStateLicense, orgResoMetadataTeamsUpdate.teamLeadStateLicense) &&
        Objects.equals(this.teamLeadStateLicenseState, orgResoMetadataTeamsUpdate.teamLeadStateLicenseState) &&
        Objects.equals(this.teamMobilePhone, orgResoMetadataTeamsUpdate.teamMobilePhone) &&
        Objects.equals(this.teamName, orgResoMetadataTeamsUpdate.teamName) &&
        Objects.equals(this.teamOfficePhone, orgResoMetadataTeamsUpdate.teamOfficePhone) &&
        Objects.equals(this.teamOfficePhoneExt, orgResoMetadataTeamsUpdate.teamOfficePhoneExt) &&
        Objects.equals(this.teamPostalCode, orgResoMetadataTeamsUpdate.teamPostalCode) &&
        Objects.equals(this.teamPostalCodePlus4, orgResoMetadataTeamsUpdate.teamPostalCodePlus4) &&
        Objects.equals(this.teamPreferredPhone, orgResoMetadataTeamsUpdate.teamPreferredPhone) &&
        Objects.equals(this.teamPreferredPhoneExt, orgResoMetadataTeamsUpdate.teamPreferredPhoneExt) &&
        Objects.equals(this.teamStateOrProvince, orgResoMetadataTeamsUpdate.teamStateOrProvince) &&
        Objects.equals(this.teamStatus, orgResoMetadataTeamsUpdate.teamStatus) &&
        Objects.equals(this.teamTollFreePhone, orgResoMetadataTeamsUpdate.teamTollFreePhone) &&
        Objects.equals(this.teamVoiceMail, orgResoMetadataTeamsUpdate.teamVoiceMail) &&
        Objects.equals(this.teamVoiceMailExt, orgResoMetadataTeamsUpdate.teamVoiceMailExt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(modificationTimestamp, originalEntryTimestamp, originatingSystemID, originatingSystemKey, originatingSystemName, socialMediaType, sourceSystemID, sourceSystemKey, sourceSystemName, teamAddress1, teamAddress2, teamCarrierRoute, teamCity, teamCountry, teamCountyOrParish, teamDescription, teamDirectPhone, teamEmail, teamFax, teamKeyNumeric, teamLeadKey, teamLeadKeyNumeric, teamLeadLoginId, teamLeadMlsId, teamLeadNationalAssociationId, teamLeadStateLicense, teamLeadStateLicenseState, teamMobilePhone, teamName, teamOfficePhone, teamOfficePhoneExt, teamPostalCode, teamPostalCodePlus4, teamPreferredPhone, teamPreferredPhoneExt, teamStateOrProvince, teamStatus, teamTollFreePhone, teamVoiceMail, teamVoiceMailExt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataTeamsUpdate {\n");
    
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    socialMediaType: ").append(toIndentedString(socialMediaType)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    teamAddress1: ").append(toIndentedString(teamAddress1)).append("\n");
    sb.append("    teamAddress2: ").append(toIndentedString(teamAddress2)).append("\n");
    sb.append("    teamCarrierRoute: ").append(toIndentedString(teamCarrierRoute)).append("\n");
    sb.append("    teamCity: ").append(toIndentedString(teamCity)).append("\n");
    sb.append("    teamCountry: ").append(toIndentedString(teamCountry)).append("\n");
    sb.append("    teamCountyOrParish: ").append(toIndentedString(teamCountyOrParish)).append("\n");
    sb.append("    teamDescription: ").append(toIndentedString(teamDescription)).append("\n");
    sb.append("    teamDirectPhone: ").append(toIndentedString(teamDirectPhone)).append("\n");
    sb.append("    teamEmail: ").append(toIndentedString(teamEmail)).append("\n");
    sb.append("    teamFax: ").append(toIndentedString(teamFax)).append("\n");
    sb.append("    teamKeyNumeric: ").append(toIndentedString(teamKeyNumeric)).append("\n");
    sb.append("    teamLeadKey: ").append(toIndentedString(teamLeadKey)).append("\n");
    sb.append("    teamLeadKeyNumeric: ").append(toIndentedString(teamLeadKeyNumeric)).append("\n");
    sb.append("    teamLeadLoginId: ").append(toIndentedString(teamLeadLoginId)).append("\n");
    sb.append("    teamLeadMlsId: ").append(toIndentedString(teamLeadMlsId)).append("\n");
    sb.append("    teamLeadNationalAssociationId: ").append(toIndentedString(teamLeadNationalAssociationId)).append("\n");
    sb.append("    teamLeadStateLicense: ").append(toIndentedString(teamLeadStateLicense)).append("\n");
    sb.append("    teamLeadStateLicenseState: ").append(toIndentedString(teamLeadStateLicenseState)).append("\n");
    sb.append("    teamMobilePhone: ").append(toIndentedString(teamMobilePhone)).append("\n");
    sb.append("    teamName: ").append(toIndentedString(teamName)).append("\n");
    sb.append("    teamOfficePhone: ").append(toIndentedString(teamOfficePhone)).append("\n");
    sb.append("    teamOfficePhoneExt: ").append(toIndentedString(teamOfficePhoneExt)).append("\n");
    sb.append("    teamPostalCode: ").append(toIndentedString(teamPostalCode)).append("\n");
    sb.append("    teamPostalCodePlus4: ").append(toIndentedString(teamPostalCodePlus4)).append("\n");
    sb.append("    teamPreferredPhone: ").append(toIndentedString(teamPreferredPhone)).append("\n");
    sb.append("    teamPreferredPhoneExt: ").append(toIndentedString(teamPreferredPhoneExt)).append("\n");
    sb.append("    teamStateOrProvince: ").append(toIndentedString(teamStateOrProvince)).append("\n");
    sb.append("    teamStatus: ").append(toIndentedString(teamStatus)).append("\n");
    sb.append("    teamTollFreePhone: ").append(toIndentedString(teamTollFreePhone)).append("\n");
    sb.append("    teamVoiceMail: ").append(toIndentedString(teamVoiceMail)).append("\n");
    sb.append("    teamVoiceMailExt: ").append(toIndentedString(teamVoiceMailExt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
