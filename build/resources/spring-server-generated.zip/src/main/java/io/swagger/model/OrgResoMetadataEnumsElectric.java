package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.Electric
 */
public enum OrgResoMetadataEnumsElectric {
  AMPS100("Amps100"),
    AMPS150("Amps150"),
    AMPS200ORMORE("Amps200OrMore"),
    CIRCUITBREAKERS("CircuitBreakers"),
    ENERGYSTORAGEDEVICE("EnergyStorageDevice"),
    FUSES("Fuses"),
    GENERATOR("Generator"),
    NETMETER("NetMeter"),
    PHOTOVOLTAICSSELLEROWNED("PhotovoltaicsSellerOwned"),
    PHOTOVOLTAICSTHIRDPARTYOWNED("PhotovoltaicsThirdPartyOwned"),
    PREWIREDFORRENEWABLES("PreWiredForRenewables"),
    READYFORRENEWABLES("ReadyForRenewables"),
    UNDERGROUND("Underground"),
    VOLTS220("Volts220"),
    VOLTS220FORSPA("Volts220ForSpa"),
    VOLTS220INGARAGE("Volts220InGarage"),
    VOLTS220INKITCHEN("Volts220InKitchen"),
    VOLTS220INLANUDRY("Volts220InLanudry"),
    VOLTS220INWORKSHOP("Volts220InWorkshop"),
    VOLTS440("Volts440"),
    WINDTURBINESELLEROWNED("WindTurbineSellerOwned"),
    WINDTURBINETHIRDPARTYOWNED("WindTurbineThirdPartyOwned");

  private String value;

  OrgResoMetadataEnumsElectric(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsElectric fromValue(String text) {
    for (OrgResoMetadataEnumsElectric b : OrgResoMetadataEnumsElectric.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
