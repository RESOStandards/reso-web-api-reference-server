package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingUpdateContactKeyNumeric
*/
public interface AnyOforgResoMetadataProspectingUpdateContactKeyNumeric {

}
