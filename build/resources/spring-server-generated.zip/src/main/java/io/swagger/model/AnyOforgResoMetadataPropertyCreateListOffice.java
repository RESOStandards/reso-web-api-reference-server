package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateListOffice
*/
public interface AnyOforgResoMetadataPropertyCreateListOffice {

}
