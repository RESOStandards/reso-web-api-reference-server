package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingSavedSearch
*/
public interface AnyOforgResoMetadataProspectingSavedSearch {

}
