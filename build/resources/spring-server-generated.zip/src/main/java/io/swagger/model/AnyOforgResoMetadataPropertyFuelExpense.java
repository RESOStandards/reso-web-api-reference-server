package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyFuelExpense
*/
public interface AnyOforgResoMetadataPropertyFuelExpense {

}
