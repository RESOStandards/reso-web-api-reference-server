package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo
*/
public interface AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo {

}
