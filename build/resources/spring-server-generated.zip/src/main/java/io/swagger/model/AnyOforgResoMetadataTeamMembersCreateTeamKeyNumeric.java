package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric
*/
public interface AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric {

}
