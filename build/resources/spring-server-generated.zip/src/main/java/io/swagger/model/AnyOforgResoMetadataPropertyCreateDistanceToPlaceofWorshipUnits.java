package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits {

}
