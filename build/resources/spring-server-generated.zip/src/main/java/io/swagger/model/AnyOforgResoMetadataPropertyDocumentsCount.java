package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDocumentsCount
*/
public interface AnyOforgResoMetadataPropertyDocumentsCount {

}
