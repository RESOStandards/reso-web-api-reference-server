package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.ShowingRequirements
 */
public enum OrgResoMetadataEnumsShowingRequirements {
  APPOINTMENTONLY("AppointmentOnly"),
    CALLLISTINGAGENT("CallListingAgent"),
    CALLLISTINGOFFICE("CallListingOffice"),
    CALLMANAGER("CallManager"),
    CALLOWNER("CallOwner"),
    CALLTENANT("CallTenant"),
    COMBINATIONLOCKBOX("CombinationLockBox"),
    DAYSLEEPER("DaySleeper"),
    DONOTSHOW("DoNotShow"),
    EMAILLISTINGAGENT("EmailListingAgent"),
    KEYINOFFICE("KeyInOffice"),
    LOCKBOX("Lockbox"),
    NOLOCKBOX("NoLockbox"),
    NOSIGN("NoSign"),
    OCCUPIED("Occupied"),
    PETSONPREMISES("PetsOnPremises"),
    RESTRICTEDHOURS("RestrictedHours"),
    SECURITYSYSTEM("SecuritySystem"),
    SEEREMARKS("SeeRemarks"),
    SHOWINGSERVICE("ShowingService"),
    TEXTLISTINGAGENT("TextListingAgent"),
    TOBEBUILT("ToBeBuilt"),
    TWENTYFOURHOURNOTICE("TwentyFourHourNotice"),
    UNDERCONSTRUCTION("UnderConstruction");

  private String value;

  OrgResoMetadataEnumsShowingRequirements(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsShowingRequirements fromValue(String text) {
    for (OrgResoMetadataEnumsShowingRequirements b : OrgResoMetadataEnumsShowingRequirements.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
