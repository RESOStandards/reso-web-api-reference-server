package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.View
 */
public enum OrgResoMetadataEnumsView {
  BAY("Bay"),
    BEACH("Beach"),
    BRIDGES("Bridges"),
    CANAL("Canal"),
    CANYON("Canyon"),
    CITY("City"),
    CITYLIGHTS("CityLights"),
    CREEKSTREAM("CreekStream"),
    DESERT("Desert"),
    DOWNTOWN("Downtown"),
    FOREST("Forest"),
    GARDEN("Garden"),
    GOLFCOURSE("GolfCourse"),
    HILLS("Hills"),
    LAKE("Lake"),
    MARINA("Marina"),
    MEADOW("Meadow"),
    MOUNTAINS("Mountains"),
    NEIGHBORHOOD("Neighborhood"),
    NONE("None"),
    OCEAN("Ocean"),
    ORCHARD("Orchard"),
    OTHER("Other"),
    PANORAMIC("Panoramic"),
    PARKGREENBELT("ParkGreenbelt"),
    PASTURE("Pasture"),
    POND("Pond"),
    POOL("Pool"),
    RIDGE("Ridge"),
    RIVER("River"),
    RURAL("Rural"),
    SEEREMARKS("SeeRemarks"),
    SKYLINE("Skyline"),
    TERRITORIAL("Territorial"),
    TREESWOODS("TreesWoods"),
    VALLEY("Valley"),
    VINEYARD("Vineyard"),
    WATER("Water");

  private String value;

  OrgResoMetadataEnumsView(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsView fromValue(String text) {
    for (OrgResoMetadataEnumsView b : OrgResoMetadataEnumsView.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
