package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingNotesContactKeyNumeric
*/
public interface AnyOforgResoMetadataContactListingNotesContactKeyNumeric {

}
