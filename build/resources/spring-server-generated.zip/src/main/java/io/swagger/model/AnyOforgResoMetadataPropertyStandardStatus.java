package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyStandardStatus
*/
public interface AnyOforgResoMetadataPropertyStandardStatus {

}
