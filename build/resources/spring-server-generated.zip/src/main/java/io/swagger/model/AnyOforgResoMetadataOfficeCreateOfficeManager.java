package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeCreateOfficeManager
*/
public interface AnyOforgResoMetadataOfficeCreateOfficeManager {

}
