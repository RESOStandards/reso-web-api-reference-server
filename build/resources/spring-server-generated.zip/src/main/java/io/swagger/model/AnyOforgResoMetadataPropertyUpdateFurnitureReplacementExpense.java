package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense {

}
