package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.LockBoxType
 */
public enum OrgResoMetadataEnumsLockBoxType {
  CALLLISTINGOFFICE("CallListingOffice"),
    CALLSELLERDIRECT("CallSellerDirect"),
    COMBO("Combo"),
    NONE("None"),
    OTHER("Other"),
    SEEREMARKS("SeeRemarks"),
    SENTRILOCK("Sentrilock"),
    SUPRA("Supra");

  private String value;

  OrgResoMetadataEnumsLockBoxType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsLockBoxType fromValue(String text) {
    for (OrgResoMetadataEnumsLockBoxType b : OrgResoMetadataEnumsLockBoxType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
