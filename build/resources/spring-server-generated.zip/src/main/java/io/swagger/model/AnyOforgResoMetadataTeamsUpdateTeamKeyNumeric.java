package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric
*/
public interface AnyOforgResoMetadataTeamsUpdateTeamKeyNumeric {

}
