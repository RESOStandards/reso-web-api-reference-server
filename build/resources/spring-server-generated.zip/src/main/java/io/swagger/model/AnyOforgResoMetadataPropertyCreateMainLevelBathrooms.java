package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateMainLevelBathrooms
*/
public interface AnyOforgResoMetadataPropertyCreateMainLevelBathrooms {

}
