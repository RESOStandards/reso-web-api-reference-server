package io.swagger.model;


/**
* AnyOforgResoMetadataContactsHomeCountyOrParish
*/
public interface AnyOforgResoMetadataContactsHomeCountyOrParish {

}
