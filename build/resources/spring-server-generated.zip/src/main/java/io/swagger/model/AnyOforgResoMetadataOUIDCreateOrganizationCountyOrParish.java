package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationCountyOrParish
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationCountyOrParish {

}
