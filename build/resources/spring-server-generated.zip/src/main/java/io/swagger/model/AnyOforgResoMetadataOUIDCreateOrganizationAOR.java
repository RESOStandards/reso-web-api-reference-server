package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationAOR
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationAOR {

}
