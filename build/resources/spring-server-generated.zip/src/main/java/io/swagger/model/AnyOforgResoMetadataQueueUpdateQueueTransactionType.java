package io.swagger.model;


/**
* AnyOforgResoMetadataQueueUpdateQueueTransactionType
*/
public interface AnyOforgResoMetadataQueueUpdateQueueTransactionType {

}
