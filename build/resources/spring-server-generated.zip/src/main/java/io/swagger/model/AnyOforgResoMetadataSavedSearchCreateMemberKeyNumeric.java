package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchCreateMemberKeyNumeric
*/
public interface AnyOforgResoMetadataSavedSearchCreateMemberKeyNumeric {

}
