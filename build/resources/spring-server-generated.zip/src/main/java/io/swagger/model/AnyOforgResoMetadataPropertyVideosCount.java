package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyVideosCount
*/
public interface AnyOforgResoMetadataPropertyVideosCount {

}
