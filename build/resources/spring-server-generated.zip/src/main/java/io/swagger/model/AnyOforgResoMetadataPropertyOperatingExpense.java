package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyOperatingExpense
*/
public interface AnyOforgResoMetadataPropertyOperatingExpense {

}
