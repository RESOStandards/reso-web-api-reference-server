package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLeasableAreaUnits
*/
public interface AnyOforgResoMetadataPropertyLeasableAreaUnits {

}
