package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus
*/
public interface AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus {

}
