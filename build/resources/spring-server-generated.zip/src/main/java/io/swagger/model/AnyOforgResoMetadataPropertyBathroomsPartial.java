package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBathroomsPartial
*/
public interface AnyOforgResoMetadataPropertyBathroomsPartial {

}
