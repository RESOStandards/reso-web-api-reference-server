package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchCreateOriginatingSystem
*/
public interface AnyOforgResoMetadataSavedSearchCreateOriginatingSystem {

}
