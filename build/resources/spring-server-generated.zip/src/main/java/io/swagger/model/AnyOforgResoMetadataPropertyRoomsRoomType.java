package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsRoomType
*/
public interface AnyOforgResoMetadataPropertyRoomsRoomType {

}
