package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingCreateOwnerMember
*/
public interface AnyOforgResoMetadataProspectingCreateOwnerMember {

}
