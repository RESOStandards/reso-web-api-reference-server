package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersUpdateTeamMemberType
*/
public interface AnyOforgResoMetadataTeamMembersUpdateTeamMemberType {

}
