package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateContactStatus
*/
public interface AnyOforgResoMetadataContactsCreateContactStatus {

}
