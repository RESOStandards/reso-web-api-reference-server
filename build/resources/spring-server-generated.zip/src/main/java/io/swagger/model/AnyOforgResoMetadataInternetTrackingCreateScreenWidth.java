package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateScreenWidth
*/
public interface AnyOforgResoMetadataInternetTrackingCreateScreenWidth {

}
