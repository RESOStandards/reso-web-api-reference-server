package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits
*/
public interface AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits {

}
