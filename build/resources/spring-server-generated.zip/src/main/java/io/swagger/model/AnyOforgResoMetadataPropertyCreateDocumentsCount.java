package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDocumentsCount
*/
public interface AnyOforgResoMetadataPropertyCreateDocumentsCount {

}
