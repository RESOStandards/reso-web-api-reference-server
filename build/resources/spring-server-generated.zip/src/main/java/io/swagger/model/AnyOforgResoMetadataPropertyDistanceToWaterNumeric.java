package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToWaterNumeric
*/
public interface AnyOforgResoMetadataPropertyDistanceToWaterNumeric {

}
