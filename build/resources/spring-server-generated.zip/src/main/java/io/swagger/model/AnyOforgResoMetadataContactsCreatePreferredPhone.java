package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreatePreferredPhone
*/
public interface AnyOforgResoMetadataContactsCreatePreferredPhone {

}
