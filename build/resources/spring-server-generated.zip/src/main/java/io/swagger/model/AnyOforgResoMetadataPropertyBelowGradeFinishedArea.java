package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBelowGradeFinishedArea
*/
public interface AnyOforgResoMetadataPropertyBelowGradeFinishedArea {

}
