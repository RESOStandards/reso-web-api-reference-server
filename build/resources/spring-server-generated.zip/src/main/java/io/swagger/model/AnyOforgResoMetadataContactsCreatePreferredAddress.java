package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreatePreferredAddress
*/
public interface AnyOforgResoMetadataContactsCreatePreferredAddress {

}
