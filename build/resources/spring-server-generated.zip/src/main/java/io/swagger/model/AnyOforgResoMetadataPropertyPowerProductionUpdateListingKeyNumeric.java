package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionUpdateListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyPowerProductionUpdateListingKeyNumeric {

}
