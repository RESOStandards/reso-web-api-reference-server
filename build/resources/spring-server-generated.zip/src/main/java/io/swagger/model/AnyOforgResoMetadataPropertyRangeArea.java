package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRangeArea
*/
public interface AnyOforgResoMetadataPropertyRangeArea {

}
