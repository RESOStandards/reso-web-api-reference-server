package io.swagger.model;


/**
* AnyOforgResoMetadataMemberUpdateMemberCountry
*/
public interface AnyOforgResoMetadataMemberUpdateMemberCountry {

}
