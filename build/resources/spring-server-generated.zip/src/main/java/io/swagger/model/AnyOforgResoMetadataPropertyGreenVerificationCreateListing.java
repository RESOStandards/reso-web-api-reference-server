package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationCreateListing
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationCreateListing {

}
