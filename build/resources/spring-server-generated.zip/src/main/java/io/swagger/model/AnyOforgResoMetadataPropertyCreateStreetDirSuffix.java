package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateStreetDirSuffix
*/
public interface AnyOforgResoMetadataPropertyCreateStreetDirSuffix {

}
