package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Count;
import io.swagger.model.OrgResoMetadataPropertyGreenVerification;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CollectionOfPropertyGreenVerification
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class CollectionOfPropertyGreenVerification   {
  @JsonProperty("@odata.count")
  private Count _atOdataCount = null;

  @JsonProperty("value")
  @Valid
  private List<OrgResoMetadataPropertyGreenVerification> value = null;

  public CollectionOfPropertyGreenVerification _atOdataCount(Count _atOdataCount) {
    this._atOdataCount = _atOdataCount;
    return this;
  }

  /**
   * Get _atOdataCount
   * @return _atOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getAtOdataCount() {
    return _atOdataCount;
  }

  public void setAtOdataCount(Count _atOdataCount) {
    this._atOdataCount = _atOdataCount;
  }

  public CollectionOfPropertyGreenVerification value(List<OrgResoMetadataPropertyGreenVerification> value) {
    this.value = value;
    return this;
  }

  public CollectionOfPropertyGreenVerification addValueItem(OrgResoMetadataPropertyGreenVerification valueItem) {
    if (this.value == null) {
      this.value = new ArrayList<OrgResoMetadataPropertyGreenVerification>();
    }
    this.value.add(valueItem);
    return this;
  }

  /**
   * Get value
   * @return value
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataPropertyGreenVerification> getValue() {
    return value;
  }

  public void setValue(List<OrgResoMetadataPropertyGreenVerification> value) {
    this.value = value;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CollectionOfPropertyGreenVerification collectionOfPropertyGreenVerification = (CollectionOfPropertyGreenVerification) o;
    return Objects.equals(this._atOdataCount, collectionOfPropertyGreenVerification._atOdataCount) &&
        Objects.equals(this.value, collectionOfPropertyGreenVerification.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_atOdataCount, value);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CollectionOfPropertyGreenVerification {\n");
    
    sb.append("    _atOdataCount: ").append(toIndentedString(_atOdataCount)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
