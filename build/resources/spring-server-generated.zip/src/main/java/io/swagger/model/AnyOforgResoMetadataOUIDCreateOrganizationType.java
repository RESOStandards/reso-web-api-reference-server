package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationType
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationType {

}
