package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyOccupantType
*/
public interface AnyOforgResoMetadataPropertyOccupantType {

}
