package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBuildingAreaSource
*/
public interface AnyOforgResoMetadataPropertyCreateBuildingAreaSource {

}
