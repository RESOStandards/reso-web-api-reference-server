package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency
*/
public interface AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency {

}
