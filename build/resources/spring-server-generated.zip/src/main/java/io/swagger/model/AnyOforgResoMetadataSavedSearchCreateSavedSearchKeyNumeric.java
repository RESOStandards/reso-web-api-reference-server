package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchCreateSavedSearchKeyNumeric
*/
public interface AnyOforgResoMetadataSavedSearchCreateSavedSearchKeyNumeric {

}
