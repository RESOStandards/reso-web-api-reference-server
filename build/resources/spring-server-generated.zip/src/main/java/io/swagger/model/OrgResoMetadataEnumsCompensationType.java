package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.CompensationType
 */
public enum OrgResoMetadataEnumsCompensationType {
  DOLLARS("Dollars"),
    OTHER("Other"),
    PERCENT("Percent"),
    SEEREMARKS("SeeRemarks");

  private String value;

  OrgResoMetadataEnumsCompensationType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsCompensationType fromValue(String text) {
    for (OrgResoMetadataEnumsCompensationType b : OrgResoMetadataEnumsCompensationType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
