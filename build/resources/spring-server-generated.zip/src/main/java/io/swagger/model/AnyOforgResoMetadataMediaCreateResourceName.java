package io.swagger.model;


/**
* AnyOforgResoMetadataMediaCreateResourceName
*/
public interface AnyOforgResoMetadataMediaCreateResourceName {

}
