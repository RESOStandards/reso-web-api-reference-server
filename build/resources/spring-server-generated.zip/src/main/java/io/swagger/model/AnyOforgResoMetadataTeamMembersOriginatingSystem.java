package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersOriginatingSystem
*/
public interface AnyOforgResoMetadataTeamMembersOriginatingSystem {

}
