package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateTrashExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateTrashExpense {

}
