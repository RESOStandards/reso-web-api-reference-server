package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.model.OrgResoMetadataSocialMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOpenHouseCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOpenHouseCreate   {
  @JsonProperty("AppointmentRequiredYN")
  private Boolean appointmentRequiredYN = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OpenHouseAttendedBy")
  private AnyOforgResoMetadataOpenHouseCreateOpenHouseAttendedBy openHouseAttendedBy = null;

  @JsonProperty("OpenHouseDate")
  private LocalDate openHouseDate = null;

  @JsonProperty("OpenHouseEndTime")
  private OffsetDateTime openHouseEndTime = null;

  @JsonProperty("OpenHouseId")
  private String openHouseId = null;

  @JsonProperty("OpenHouseKey")
  private String openHouseKey = null;

  @JsonProperty("OpenHouseKeyNumeric")
  private AnyOforgResoMetadataOpenHouseCreateOpenHouseKeyNumeric openHouseKeyNumeric = null;

  @JsonProperty("OpenHouseRemarks")
  private String openHouseRemarks = null;

  @JsonProperty("OpenHouseStartTime")
  private OffsetDateTime openHouseStartTime = null;

  @JsonProperty("OpenHouseStatus")
  private AnyOforgResoMetadataOpenHouseCreateOpenHouseStatus openHouseStatus = null;

  @JsonProperty("OpenHouseType")
  private AnyOforgResoMetadataOpenHouseCreateOpenHouseType openHouseType = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("Refreshments")
  private String refreshments = null;

  @JsonProperty("ShowingAgentFirstName")
  private String showingAgentFirstName = null;

  @JsonProperty("ShowingAgentKey")
  private String showingAgentKey = null;

  @JsonProperty("ShowingAgentKeyNumeric")
  private AnyOforgResoMetadataOpenHouseCreateShowingAgentKeyNumeric showingAgentKeyNumeric = null;

  @JsonProperty("ShowingAgentLastName")
  private String showingAgentLastName = null;

  @JsonProperty("ShowingAgentMlsID")
  private String showingAgentMlsID = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("Listing")
  private AnyOforgResoMetadataOpenHouseCreateListing listing = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataOpenHouseCreateOriginatingSystem originatingSystem = null;

  @JsonProperty("ShowingAgent")
  private AnyOforgResoMetadataOpenHouseCreateShowingAgent showingAgent = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataOpenHouseCreateSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMediaCreate> socialMedia = null;

  public OrgResoMetadataOpenHouseCreate appointmentRequiredYN(Boolean appointmentRequiredYN) {
    this.appointmentRequiredYN = appointmentRequiredYN;
    return this;
  }

  /**
   * Get appointmentRequiredYN
   * @return appointmentRequiredYN
   **/
  @Schema(description = "")
  
    public Boolean isAppointmentRequiredYN() {
    return appointmentRequiredYN;
  }

  public void setAppointmentRequiredYN(Boolean appointmentRequiredYN) {
    this.appointmentRequiredYN = appointmentRequiredYN;
  }

  public OrgResoMetadataOpenHouseCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataOpenHouseCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataOpenHouseCreate listingKeyNumeric(AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataOpenHouseCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOpenHouseCreate openHouseAttendedBy(AnyOforgResoMetadataOpenHouseCreateOpenHouseAttendedBy openHouseAttendedBy) {
    this.openHouseAttendedBy = openHouseAttendedBy;
    return this;
  }

  /**
   * Get openHouseAttendedBy
   * @return openHouseAttendedBy
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateOpenHouseAttendedBy getOpenHouseAttendedBy() {
    return openHouseAttendedBy;
  }

  public void setOpenHouseAttendedBy(AnyOforgResoMetadataOpenHouseCreateOpenHouseAttendedBy openHouseAttendedBy) {
    this.openHouseAttendedBy = openHouseAttendedBy;
  }

  public OrgResoMetadataOpenHouseCreate openHouseDate(LocalDate openHouseDate) {
    this.openHouseDate = openHouseDate;
    return this;
  }

  /**
   * Get openHouseDate
   * @return openHouseDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOpenHouseDate() {
    return openHouseDate;
  }

  public void setOpenHouseDate(LocalDate openHouseDate) {
    this.openHouseDate = openHouseDate;
  }

  public OrgResoMetadataOpenHouseCreate openHouseEndTime(OffsetDateTime openHouseEndTime) {
    this.openHouseEndTime = openHouseEndTime;
    return this;
  }

  /**
   * Get openHouseEndTime
   * @return openHouseEndTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOpenHouseEndTime() {
    return openHouseEndTime;
  }

  public void setOpenHouseEndTime(OffsetDateTime openHouseEndTime) {
    this.openHouseEndTime = openHouseEndTime;
  }

  public OrgResoMetadataOpenHouseCreate openHouseId(String openHouseId) {
    this.openHouseId = openHouseId;
    return this;
  }

  /**
   * Get openHouseId
   * @return openHouseId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOpenHouseId() {
    return openHouseId;
  }

  public void setOpenHouseId(String openHouseId) {
    this.openHouseId = openHouseId;
  }

  public OrgResoMetadataOpenHouseCreate openHouseKey(String openHouseKey) {
    this.openHouseKey = openHouseKey;
    return this;
  }

  /**
   * Get openHouseKey
   * @return openHouseKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getOpenHouseKey() {
    return openHouseKey;
  }

  public void setOpenHouseKey(String openHouseKey) {
    this.openHouseKey = openHouseKey;
  }

  public OrgResoMetadataOpenHouseCreate openHouseKeyNumeric(AnyOforgResoMetadataOpenHouseCreateOpenHouseKeyNumeric openHouseKeyNumeric) {
    this.openHouseKeyNumeric = openHouseKeyNumeric;
    return this;
  }

  /**
   * Get openHouseKeyNumeric
   * @return openHouseKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateOpenHouseKeyNumeric getOpenHouseKeyNumeric() {
    return openHouseKeyNumeric;
  }

  public void setOpenHouseKeyNumeric(AnyOforgResoMetadataOpenHouseCreateOpenHouseKeyNumeric openHouseKeyNumeric) {
    this.openHouseKeyNumeric = openHouseKeyNumeric;
  }

  public OrgResoMetadataOpenHouseCreate openHouseRemarks(String openHouseRemarks) {
    this.openHouseRemarks = openHouseRemarks;
    return this;
  }

  /**
   * Get openHouseRemarks
   * @return openHouseRemarks
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getOpenHouseRemarks() {
    return openHouseRemarks;
  }

  public void setOpenHouseRemarks(String openHouseRemarks) {
    this.openHouseRemarks = openHouseRemarks;
  }

  public OrgResoMetadataOpenHouseCreate openHouseStartTime(OffsetDateTime openHouseStartTime) {
    this.openHouseStartTime = openHouseStartTime;
    return this;
  }

  /**
   * Get openHouseStartTime
   * @return openHouseStartTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOpenHouseStartTime() {
    return openHouseStartTime;
  }

  public void setOpenHouseStartTime(OffsetDateTime openHouseStartTime) {
    this.openHouseStartTime = openHouseStartTime;
  }

  public OrgResoMetadataOpenHouseCreate openHouseStatus(AnyOforgResoMetadataOpenHouseCreateOpenHouseStatus openHouseStatus) {
    this.openHouseStatus = openHouseStatus;
    return this;
  }

  /**
   * Get openHouseStatus
   * @return openHouseStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateOpenHouseStatus getOpenHouseStatus() {
    return openHouseStatus;
  }

  public void setOpenHouseStatus(AnyOforgResoMetadataOpenHouseCreateOpenHouseStatus openHouseStatus) {
    this.openHouseStatus = openHouseStatus;
  }

  public OrgResoMetadataOpenHouseCreate openHouseType(AnyOforgResoMetadataOpenHouseCreateOpenHouseType openHouseType) {
    this.openHouseType = openHouseType;
    return this;
  }

  /**
   * Get openHouseType
   * @return openHouseType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateOpenHouseType getOpenHouseType() {
    return openHouseType;
  }

  public void setOpenHouseType(AnyOforgResoMetadataOpenHouseCreateOpenHouseType openHouseType) {
    this.openHouseType = openHouseType;
  }

  public OrgResoMetadataOpenHouseCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataOpenHouseCreate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataOpenHouseCreate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataOpenHouseCreate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataOpenHouseCreate refreshments(String refreshments) {
    this.refreshments = refreshments;
    return this;
  }

  /**
   * Get refreshments
   * @return refreshments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getRefreshments() {
    return refreshments;
  }

  public void setRefreshments(String refreshments) {
    this.refreshments = refreshments;
  }

  public OrgResoMetadataOpenHouseCreate showingAgentFirstName(String showingAgentFirstName) {
    this.showingAgentFirstName = showingAgentFirstName;
    return this;
  }

  /**
   * Get showingAgentFirstName
   * @return showingAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getShowingAgentFirstName() {
    return showingAgentFirstName;
  }

  public void setShowingAgentFirstName(String showingAgentFirstName) {
    this.showingAgentFirstName = showingAgentFirstName;
  }

  public OrgResoMetadataOpenHouseCreate showingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
    return this;
  }

  /**
   * Get showingAgentKey
   * @return showingAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingAgentKey() {
    return showingAgentKey;
  }

  public void setShowingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
  }

  public OrgResoMetadataOpenHouseCreate showingAgentKeyNumeric(AnyOforgResoMetadataOpenHouseCreateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
    return this;
  }

  /**
   * Get showingAgentKeyNumeric
   * @return showingAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateShowingAgentKeyNumeric getShowingAgentKeyNumeric() {
    return showingAgentKeyNumeric;
  }

  public void setShowingAgentKeyNumeric(AnyOforgResoMetadataOpenHouseCreateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
  }

  public OrgResoMetadataOpenHouseCreate showingAgentLastName(String showingAgentLastName) {
    this.showingAgentLastName = showingAgentLastName;
    return this;
  }

  /**
   * Get showingAgentLastName
   * @return showingAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getShowingAgentLastName() {
    return showingAgentLastName;
  }

  public void setShowingAgentLastName(String showingAgentLastName) {
    this.showingAgentLastName = showingAgentLastName;
  }

  public OrgResoMetadataOpenHouseCreate showingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
    return this;
  }

  /**
   * Get showingAgentMlsID
   * @return showingAgentMlsID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getShowingAgentMlsID() {
    return showingAgentMlsID;
  }

  public void setShowingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
  }

  public OrgResoMetadataOpenHouseCreate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataOpenHouseCreate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataOpenHouseCreate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataOpenHouseCreate listing(AnyOforgResoMetadataOpenHouseCreateListing listing) {
    this.listing = listing;
    return this;
  }

  /**
   * Get listing
   * @return listing
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateListing getListing() {
    return listing;
  }

  public void setListing(AnyOforgResoMetadataOpenHouseCreateListing listing) {
    this.listing = listing;
  }

  public OrgResoMetadataOpenHouseCreate originatingSystem(AnyOforgResoMetadataOpenHouseCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataOpenHouseCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataOpenHouseCreate showingAgent(AnyOforgResoMetadataOpenHouseCreateShowingAgent showingAgent) {
    this.showingAgent = showingAgent;
    return this;
  }

  /**
   * Get showingAgent
   * @return showingAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateShowingAgent getShowingAgent() {
    return showingAgent;
  }

  public void setShowingAgent(AnyOforgResoMetadataOpenHouseCreateShowingAgent showingAgent) {
    this.showingAgent = showingAgent;
  }

  public OrgResoMetadataOpenHouseCreate sourceSystem(AnyOforgResoMetadataOpenHouseCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseCreateSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataOpenHouseCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataOpenHouseCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataOpenHouseCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataOpenHouseCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataOpenHouseCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }

  public OrgResoMetadataOpenHouseCreate socialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataOpenHouseCreate addSocialMediaItem(OrgResoMetadataSocialMediaCreate socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMediaCreate>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMediaCreate> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOpenHouseCreate orgResoMetadataOpenHouseCreate = (OrgResoMetadataOpenHouseCreate) o;
    return Objects.equals(this.appointmentRequiredYN, orgResoMetadataOpenHouseCreate.appointmentRequiredYN) &&
        Objects.equals(this.listingId, orgResoMetadataOpenHouseCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataOpenHouseCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataOpenHouseCreate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOpenHouseCreate.modificationTimestamp) &&
        Objects.equals(this.openHouseAttendedBy, orgResoMetadataOpenHouseCreate.openHouseAttendedBy) &&
        Objects.equals(this.openHouseDate, orgResoMetadataOpenHouseCreate.openHouseDate) &&
        Objects.equals(this.openHouseEndTime, orgResoMetadataOpenHouseCreate.openHouseEndTime) &&
        Objects.equals(this.openHouseId, orgResoMetadataOpenHouseCreate.openHouseId) &&
        Objects.equals(this.openHouseKey, orgResoMetadataOpenHouseCreate.openHouseKey) &&
        Objects.equals(this.openHouseKeyNumeric, orgResoMetadataOpenHouseCreate.openHouseKeyNumeric) &&
        Objects.equals(this.openHouseRemarks, orgResoMetadataOpenHouseCreate.openHouseRemarks) &&
        Objects.equals(this.openHouseStartTime, orgResoMetadataOpenHouseCreate.openHouseStartTime) &&
        Objects.equals(this.openHouseStatus, orgResoMetadataOpenHouseCreate.openHouseStatus) &&
        Objects.equals(this.openHouseType, orgResoMetadataOpenHouseCreate.openHouseType) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataOpenHouseCreate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataOpenHouseCreate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataOpenHouseCreate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataOpenHouseCreate.originatingSystemName) &&
        Objects.equals(this.refreshments, orgResoMetadataOpenHouseCreate.refreshments) &&
        Objects.equals(this.showingAgentFirstName, orgResoMetadataOpenHouseCreate.showingAgentFirstName) &&
        Objects.equals(this.showingAgentKey, orgResoMetadataOpenHouseCreate.showingAgentKey) &&
        Objects.equals(this.showingAgentKeyNumeric, orgResoMetadataOpenHouseCreate.showingAgentKeyNumeric) &&
        Objects.equals(this.showingAgentLastName, orgResoMetadataOpenHouseCreate.showingAgentLastName) &&
        Objects.equals(this.showingAgentMlsID, orgResoMetadataOpenHouseCreate.showingAgentMlsID) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataOpenHouseCreate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataOpenHouseCreate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataOpenHouseCreate.sourceSystemName) &&
        Objects.equals(this.listing, orgResoMetadataOpenHouseCreate.listing) &&
        Objects.equals(this.originatingSystem, orgResoMetadataOpenHouseCreate.originatingSystem) &&
        Objects.equals(this.showingAgent, orgResoMetadataOpenHouseCreate.showingAgent) &&
        Objects.equals(this.sourceSystem, orgResoMetadataOpenHouseCreate.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataOpenHouseCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataOpenHouseCreate.media) &&
        Objects.equals(this.socialMedia, orgResoMetadataOpenHouseCreate.socialMedia);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentRequiredYN, listingId, listingKey, listingKeyNumeric, modificationTimestamp, openHouseAttendedBy, openHouseDate, openHouseEndTime, openHouseId, openHouseKey, openHouseKeyNumeric, openHouseRemarks, openHouseStartTime, openHouseStatus, openHouseType, originalEntryTimestamp, originatingSystemID, originatingSystemKey, originatingSystemName, refreshments, showingAgentFirstName, showingAgentKey, showingAgentKeyNumeric, showingAgentLastName, showingAgentMlsID, sourceSystemID, sourceSystemKey, sourceSystemName, listing, originatingSystem, showingAgent, sourceSystem, historyTransactional, media, socialMedia);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOpenHouseCreate {\n");
    
    sb.append("    appointmentRequiredYN: ").append(toIndentedString(appointmentRequiredYN)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    openHouseAttendedBy: ").append(toIndentedString(openHouseAttendedBy)).append("\n");
    sb.append("    openHouseDate: ").append(toIndentedString(openHouseDate)).append("\n");
    sb.append("    openHouseEndTime: ").append(toIndentedString(openHouseEndTime)).append("\n");
    sb.append("    openHouseId: ").append(toIndentedString(openHouseId)).append("\n");
    sb.append("    openHouseKey: ").append(toIndentedString(openHouseKey)).append("\n");
    sb.append("    openHouseKeyNumeric: ").append(toIndentedString(openHouseKeyNumeric)).append("\n");
    sb.append("    openHouseRemarks: ").append(toIndentedString(openHouseRemarks)).append("\n");
    sb.append("    openHouseStartTime: ").append(toIndentedString(openHouseStartTime)).append("\n");
    sb.append("    openHouseStatus: ").append(toIndentedString(openHouseStatus)).append("\n");
    sb.append("    openHouseType: ").append(toIndentedString(openHouseType)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    refreshments: ").append(toIndentedString(refreshments)).append("\n");
    sb.append("    showingAgentFirstName: ").append(toIndentedString(showingAgentFirstName)).append("\n");
    sb.append("    showingAgentKey: ").append(toIndentedString(showingAgentKey)).append("\n");
    sb.append("    showingAgentKeyNumeric: ").append(toIndentedString(showingAgentKeyNumeric)).append("\n");
    sb.append("    showingAgentLastName: ").append(toIndentedString(showingAgentLastName)).append("\n");
    sb.append("    showingAgentMlsID: ").append(toIndentedString(showingAgentMlsID)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    listing: ").append(toIndentedString(listing)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    showingAgent: ").append(toIndentedString(showingAgent)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
