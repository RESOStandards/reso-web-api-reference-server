package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsUpdateRoomAreaUnits
*/
public interface AnyOforgResoMetadataPropertyRoomsUpdateRoomAreaUnits {

}
