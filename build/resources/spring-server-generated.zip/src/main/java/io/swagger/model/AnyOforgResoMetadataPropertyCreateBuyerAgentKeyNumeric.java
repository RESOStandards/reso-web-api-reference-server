package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric {

}
