package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus
*/
public interface AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus {

}
