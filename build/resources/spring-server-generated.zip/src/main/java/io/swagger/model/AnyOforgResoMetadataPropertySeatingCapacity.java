package io.swagger.model;


/**
* AnyOforgResoMetadataPropertySeatingCapacity
*/
public interface AnyOforgResoMetadataPropertySeatingCapacity {

}
