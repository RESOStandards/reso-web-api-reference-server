package io.swagger.model;


/**
* AnyOforgResoMetadataRulesUpdateRuleFormat
*/
public interface AnyOforgResoMetadataRulesUpdateRuleFormat {

}
