package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits
*/
public interface AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits {

}
