package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateStandardStatus
*/
public interface AnyOforgResoMetadataPropertyUpdateStandardStatus {

}
