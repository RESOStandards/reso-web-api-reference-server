package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR
*/
public interface AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR {

}
