package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyTaxAssessedValue
*/
public interface AnyOforgResoMetadataPropertyTaxAssessedValue {

}
