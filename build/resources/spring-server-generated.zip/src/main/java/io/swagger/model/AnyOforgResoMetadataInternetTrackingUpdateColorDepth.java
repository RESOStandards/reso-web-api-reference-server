package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateColorDepth
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateColorDepth {

}
