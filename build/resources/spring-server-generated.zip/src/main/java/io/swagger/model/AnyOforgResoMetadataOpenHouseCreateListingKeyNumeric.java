package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataOpenHouseCreateListingKeyNumeric {

}
