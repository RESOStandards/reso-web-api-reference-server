package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.AssociationAmenities
 */
public enum OrgResoMetadataEnumsAssociationAmenities {
  AIRPORTRUNWAY("AirportRunway"),
    BARBECUE("Barbecue"),
    BASKETBALLCOURT("BasketballCourt"),
    BEACHACCESS("BeachAccess"),
    BEACHRIGHTS("BeachRights"),
    BILLIARDROOM("BilliardRoom"),
    BOATDOCK("BoatDock"),
    BOATING("Boating"),
    BOATSLIP("BoatSlip"),
    CABANA("Cabana"),
    CABLETV("CableTv"),
    CARWASHAREA("CarWashArea"),
    CLUBHOUSE("Clubhouse"),
    COINLAUNDRY("CoinLaundry"),
    CONCIERGE("Concierge"),
    DAYCARE("DayCare"),
    DOGPARK("DogPark"),
    DRYDOCK("DryDock"),
    ELECTRICITY("Electricity"),
    ELEVATORS("Elevators"),
    EXERCISECOURSE("ExerciseCourse"),
    FITNESSCENTER("FitnessCenter"),
    GAMECOURTEXTERIOR("GameCourtExterior"),
    GAMECOURTINTERIOR("GameCourtInterior"),
    GAMEROOM("GameRoom"),
    GAS("Gas"),
    GATED("Gated"),
    GOLFCOURSE("GolfCourse"),
    HOTWATER("HotWater"),
    INDOORPOOL("IndoorPool"),
    INSURANCE("Insurance"),
    JOGGINGPATH("JoggingPath"),
    LANDSCAPING("Landscaping"),
    LAUNDRY("Laundry"),
    MAIDSERVICE("MaidService"),
    MAINTENANCE("Maintenance"),
    MAINTENANCEGROUNDS("MaintenanceGrounds"),
    MAINTENANCESTRUCTURE("MaintenanceStructure"),
    MANAGEMENT("Management"),
    MARINA("Marina"),
    MEETINGROOM("MeetingRoom"),
    NONE("None"),
    OTHER("Other"),
    PARK("Park"),
    PARKING("Parking"),
    PARTYROOM("PartyRoom"),
    PICNICAREA("PicnicArea"),
    PLAYGROUND("Playground"),
    PONDSEASONAL("PondSeasonal"),
    PONDYEARROUND("PondYearRound"),
    POOL("Pool"),
    POWEREDBOATSALLOWED("PoweredBoatsAllowed"),
    RACQUETBALL("Racquetball"),
    RECREATIONFACILITIES("RecreationFacilities"),
    RECREATIONROOM("RecreationRoom"),
    ROOFDECK("RoofDeck"),
    RVBOATSTORAGE("RvBoatStorage"),
    RVPARKING("RvParking"),
    SAUNA("Sauna"),
    SECURITY("Security"),
    SERVICEELEVATORS("ServiceElevators"),
    SHUFFLEBOARDCOURT("ShuffleboardCourt"),
    SKIACCESSIBLE("SkiAccessible"),
    SNOWREMOVAL("SnowRemoval"),
    SPAHOTTUB("SpaHotTub"),
    SPORTCOURT("SportCourt"),
    STABLES("Stables"),
    STORAGE("Storage"),
    STREAMSEASONAL("StreamSeasonal"),
    STREAMYEARROUND("StreamYearRound"),
    TAXES("Taxes"),
    TENNISCOURTS("TennisCourts"),
    TRAILS("Trails"),
    TRASH("Trash"),
    WATER("Water"),
    WORKSHOPAREA("WorkshopArea");

  private String value;

  OrgResoMetadataEnumsAssociationAmenities(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsAssociationAmenities fromValue(String text) {
    for (OrgResoMetadataEnumsAssociationAmenities b : OrgResoMetadataEnumsAssociationAmenities.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
