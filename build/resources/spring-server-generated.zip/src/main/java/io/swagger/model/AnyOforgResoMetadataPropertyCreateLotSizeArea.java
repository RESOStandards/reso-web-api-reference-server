package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLotSizeArea
*/
public interface AnyOforgResoMetadataPropertyCreateLotSizeArea {

}
