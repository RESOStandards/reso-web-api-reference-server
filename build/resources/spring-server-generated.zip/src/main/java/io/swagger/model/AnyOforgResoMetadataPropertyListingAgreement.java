package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListingAgreement
*/
public interface AnyOforgResoMetadataPropertyListingAgreement {

}
