package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateTeamCountry
*/
public interface AnyOforgResoMetadataTeamsCreateTeamCountry {

}
