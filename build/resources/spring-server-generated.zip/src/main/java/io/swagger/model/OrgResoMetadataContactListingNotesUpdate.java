package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataContactListingNotesUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataContactListingNotesUpdate   {
  @JsonProperty("ContactKeyNumeric")
  private AnyOforgResoMetadataContactListingNotesUpdateContactKeyNumeric contactKeyNumeric = null;

  @JsonProperty("ContactListingNotesKey")
  private String contactListingNotesKey = null;

  @JsonProperty("ContactListingNotesKeyNumeric")
  private AnyOforgResoMetadataContactListingNotesUpdateContactListingNotesKeyNumeric contactListingNotesKeyNumeric = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataContactListingNotesUpdateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NoteContents")
  private String noteContents = null;

  @JsonProperty("NotedBy")
  private AnyOforgResoMetadataContactListingNotesUpdateNotedBy notedBy = null;

  public OrgResoMetadataContactListingNotesUpdate contactKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
    return this;
  }

  /**
   * Get contactKeyNumeric
   * @return contactKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingNotesUpdateContactKeyNumeric getContactKeyNumeric() {
    return contactKeyNumeric;
  }

  public void setContactKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
  }

  public OrgResoMetadataContactListingNotesUpdate contactListingNotesKey(String contactListingNotesKey) {
    this.contactListingNotesKey = contactListingNotesKey;
    return this;
  }

  /**
   * Get contactListingNotesKey
   * @return contactListingNotesKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getContactListingNotesKey() {
    return contactListingNotesKey;
  }

  public void setContactListingNotesKey(String contactListingNotesKey) {
    this.contactListingNotesKey = contactListingNotesKey;
  }

  public OrgResoMetadataContactListingNotesUpdate contactListingNotesKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateContactListingNotesKeyNumeric contactListingNotesKeyNumeric) {
    this.contactListingNotesKeyNumeric = contactListingNotesKeyNumeric;
    return this;
  }

  /**
   * Get contactListingNotesKeyNumeric
   * @return contactListingNotesKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingNotesUpdateContactListingNotesKeyNumeric getContactListingNotesKeyNumeric() {
    return contactListingNotesKeyNumeric;
  }

  public void setContactListingNotesKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateContactListingNotesKeyNumeric contactListingNotesKeyNumeric) {
    this.contactListingNotesKeyNumeric = contactListingNotesKeyNumeric;
  }

  public OrgResoMetadataContactListingNotesUpdate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataContactListingNotesUpdate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataContactListingNotesUpdate listingKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingNotesUpdateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataContactListingNotesUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataContactListingNotesUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataContactListingNotesUpdate noteContents(String noteContents) {
    this.noteContents = noteContents;
    return this;
  }

  /**
   * Get noteContents
   * @return noteContents
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getNoteContents() {
    return noteContents;
  }

  public void setNoteContents(String noteContents) {
    this.noteContents = noteContents;
  }

  public OrgResoMetadataContactListingNotesUpdate notedBy(AnyOforgResoMetadataContactListingNotesUpdateNotedBy notedBy) {
    this.notedBy = notedBy;
    return this;
  }

  /**
   * Get notedBy
   * @return notedBy
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingNotesUpdateNotedBy getNotedBy() {
    return notedBy;
  }

  public void setNotedBy(AnyOforgResoMetadataContactListingNotesUpdateNotedBy notedBy) {
    this.notedBy = notedBy;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataContactListingNotesUpdate orgResoMetadataContactListingNotesUpdate = (OrgResoMetadataContactListingNotesUpdate) o;
    return Objects.equals(this.contactKeyNumeric, orgResoMetadataContactListingNotesUpdate.contactKeyNumeric) &&
        Objects.equals(this.contactListingNotesKey, orgResoMetadataContactListingNotesUpdate.contactListingNotesKey) &&
        Objects.equals(this.contactListingNotesKeyNumeric, orgResoMetadataContactListingNotesUpdate.contactListingNotesKeyNumeric) &&
        Objects.equals(this.listingId, orgResoMetadataContactListingNotesUpdate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataContactListingNotesUpdate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataContactListingNotesUpdate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataContactListingNotesUpdate.modificationTimestamp) &&
        Objects.equals(this.noteContents, orgResoMetadataContactListingNotesUpdate.noteContents) &&
        Objects.equals(this.notedBy, orgResoMetadataContactListingNotesUpdate.notedBy);
  }

  @Override
  public int hashCode() {
    return Objects.hash(contactKeyNumeric, contactListingNotesKey, contactListingNotesKeyNumeric, listingId, listingKey, listingKeyNumeric, modificationTimestamp, noteContents, notedBy);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataContactListingNotesUpdate {\n");
    
    sb.append("    contactKeyNumeric: ").append(toIndentedString(contactKeyNumeric)).append("\n");
    sb.append("    contactListingNotesKey: ").append(toIndentedString(contactListingNotesKey)).append("\n");
    sb.append("    contactListingNotesKeyNumeric: ").append(toIndentedString(contactListingNotesKeyNumeric)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    noteContents: ").append(toIndentedString(noteContents)).append("\n");
    sb.append("    notedBy: ").append(toIndentedString(notedBy)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
