package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateVacancyAllowance
*/
public interface AnyOforgResoMetadataPropertyCreateVacancyAllowance {

}
