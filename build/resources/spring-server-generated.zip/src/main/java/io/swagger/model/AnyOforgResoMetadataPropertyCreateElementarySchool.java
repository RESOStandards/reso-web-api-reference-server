package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateElementarySchool
*/
public interface AnyOforgResoMetadataPropertyCreateElementarySchool {

}
