package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric {

}
