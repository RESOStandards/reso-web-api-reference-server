package io.swagger.model;


/**
* AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric
*/
public interface AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric {

}
