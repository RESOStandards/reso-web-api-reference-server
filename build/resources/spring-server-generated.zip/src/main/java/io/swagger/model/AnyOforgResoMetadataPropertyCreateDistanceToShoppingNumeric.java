package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric {

}
