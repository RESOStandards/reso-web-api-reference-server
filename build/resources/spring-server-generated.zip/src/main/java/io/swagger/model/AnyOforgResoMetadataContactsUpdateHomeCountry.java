package io.swagger.model;


/**
* AnyOforgResoMetadataContactsUpdateHomeCountry
*/
public interface AnyOforgResoMetadataContactsUpdateHomeCountry {

}
