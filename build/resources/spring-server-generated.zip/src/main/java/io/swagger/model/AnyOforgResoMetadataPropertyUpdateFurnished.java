package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateFurnished
*/
public interface AnyOforgResoMetadataPropertyUpdateFurnished {

}
