package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsDailySchedule;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataProspectingCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataProspectingCreate   {
  @JsonProperty("ActiveYN")
  private Boolean activeYN = null;

  @JsonProperty("BccEmailList")
  private String bccEmailList = null;

  @JsonProperty("BccMeYN")
  private Boolean bccMeYN = null;

  @JsonProperty("CcEmailList")
  private String ccEmailList = null;

  @JsonProperty("ClientActivatedYN")
  private Boolean clientActivatedYN = null;

  @JsonProperty("ConciergeNotificationsYN")
  private Boolean conciergeNotificationsYN = null;

  @JsonProperty("ConciergeYN")
  private Boolean conciergeYN = null;

  @JsonProperty("ContactKey")
  private String contactKey = null;

  @JsonProperty("ContactKeyNumeric")
  private AnyOforgResoMetadataProspectingCreateContactKeyNumeric contactKeyNumeric = null;

  @JsonProperty("DailySchedule")
  @Valid
  private List<OrgResoMetadataEnumsDailySchedule> dailySchedule = null;

  @JsonProperty("DisplayTemplateID")
  private String displayTemplateID = null;

  @JsonProperty("Language")
  private AnyOforgResoMetadataProspectingCreateLanguage language = null;

  @JsonProperty("LastNewChangedTimestamp")
  private OffsetDateTime lastNewChangedTimestamp = null;

  @JsonProperty("LastViewedTimestamp")
  private OffsetDateTime lastViewedTimestamp = null;

  @JsonProperty("MessageNew")
  private String messageNew = null;

  @JsonProperty("MessageRevise")
  private String messageRevise = null;

  @JsonProperty("MessageUpdate")
  private String messageUpdate = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NextSendTimestamp")
  private OffsetDateTime nextSendTimestamp = null;

  @JsonProperty("OwnerMemberID")
  private String ownerMemberID = null;

  @JsonProperty("OwnerMemberKey")
  private String ownerMemberKey = null;

  @JsonProperty("OwnerMemberKeyNumeric")
  private AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric = null;

  @JsonProperty("ProspectingKey")
  private String prospectingKey = null;

  @JsonProperty("ProspectingKeyNumeric")
  private AnyOforgResoMetadataProspectingCreateProspectingKeyNumeric prospectingKeyNumeric = null;

  @JsonProperty("ReasonActiveOrDisabled")
  private AnyOforgResoMetadataProspectingCreateReasonActiveOrDisabled reasonActiveOrDisabled = null;

  @JsonProperty("SavedSearchKey")
  private String savedSearchKey = null;

  @JsonProperty("SavedSearchKeyNumeric")
  private AnyOforgResoMetadataProspectingCreateSavedSearchKeyNumeric savedSearchKeyNumeric = null;

  @JsonProperty("ScheduleType")
  private AnyOforgResoMetadataProspectingCreateScheduleType scheduleType = null;

  @JsonProperty("Subject")
  private String subject = null;

  @JsonProperty("ToEmailList")
  private String toEmailList = null;

  @JsonProperty("Contact")
  private AnyOforgResoMetadataProspectingCreateContact contact = null;

  @JsonProperty("OwnerMember")
  private AnyOforgResoMetadataProspectingCreateOwnerMember ownerMember = null;

  @JsonProperty("SavedSearch")
  private AnyOforgResoMetadataProspectingCreateSavedSearch savedSearch = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  public OrgResoMetadataProspectingCreate activeYN(Boolean activeYN) {
    this.activeYN = activeYN;
    return this;
  }

  /**
   * Get activeYN
   * @return activeYN
   **/
  @Schema(description = "")
  
    public Boolean isActiveYN() {
    return activeYN;
  }

  public void setActiveYN(Boolean activeYN) {
    this.activeYN = activeYN;
  }

  public OrgResoMetadataProspectingCreate bccEmailList(String bccEmailList) {
    this.bccEmailList = bccEmailList;
    return this;
  }

  /**
   * Get bccEmailList
   * @return bccEmailList
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getBccEmailList() {
    return bccEmailList;
  }

  public void setBccEmailList(String bccEmailList) {
    this.bccEmailList = bccEmailList;
  }

  public OrgResoMetadataProspectingCreate bccMeYN(Boolean bccMeYN) {
    this.bccMeYN = bccMeYN;
    return this;
  }

  /**
   * Get bccMeYN
   * @return bccMeYN
   **/
  @Schema(description = "")
  
    public Boolean isBccMeYN() {
    return bccMeYN;
  }

  public void setBccMeYN(Boolean bccMeYN) {
    this.bccMeYN = bccMeYN;
  }

  public OrgResoMetadataProspectingCreate ccEmailList(String ccEmailList) {
    this.ccEmailList = ccEmailList;
    return this;
  }

  /**
   * Get ccEmailList
   * @return ccEmailList
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getCcEmailList() {
    return ccEmailList;
  }

  public void setCcEmailList(String ccEmailList) {
    this.ccEmailList = ccEmailList;
  }

  public OrgResoMetadataProspectingCreate clientActivatedYN(Boolean clientActivatedYN) {
    this.clientActivatedYN = clientActivatedYN;
    return this;
  }

  /**
   * Get clientActivatedYN
   * @return clientActivatedYN
   **/
  @Schema(description = "")
  
    public Boolean isClientActivatedYN() {
    return clientActivatedYN;
  }

  public void setClientActivatedYN(Boolean clientActivatedYN) {
    this.clientActivatedYN = clientActivatedYN;
  }

  public OrgResoMetadataProspectingCreate conciergeNotificationsYN(Boolean conciergeNotificationsYN) {
    this.conciergeNotificationsYN = conciergeNotificationsYN;
    return this;
  }

  /**
   * Get conciergeNotificationsYN
   * @return conciergeNotificationsYN
   **/
  @Schema(description = "")
  
    public Boolean isConciergeNotificationsYN() {
    return conciergeNotificationsYN;
  }

  public void setConciergeNotificationsYN(Boolean conciergeNotificationsYN) {
    this.conciergeNotificationsYN = conciergeNotificationsYN;
  }

  public OrgResoMetadataProspectingCreate conciergeYN(Boolean conciergeYN) {
    this.conciergeYN = conciergeYN;
    return this;
  }

  /**
   * Get conciergeYN
   * @return conciergeYN
   **/
  @Schema(description = "")
  
    public Boolean isConciergeYN() {
    return conciergeYN;
  }

  public void setConciergeYN(Boolean conciergeYN) {
    this.conciergeYN = conciergeYN;
  }

  public OrgResoMetadataProspectingCreate contactKey(String contactKey) {
    this.contactKey = contactKey;
    return this;
  }

  /**
   * Get contactKey
   * @return contactKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getContactKey() {
    return contactKey;
  }

  public void setContactKey(String contactKey) {
    this.contactKey = contactKey;
  }

  public OrgResoMetadataProspectingCreate contactKeyNumeric(AnyOforgResoMetadataProspectingCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
    return this;
  }

  /**
   * Get contactKeyNumeric
   * @return contactKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataProspectingCreateContactKeyNumeric getContactKeyNumeric() {
    return contactKeyNumeric;
  }

  public void setContactKeyNumeric(AnyOforgResoMetadataProspectingCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
  }

  public OrgResoMetadataProspectingCreate dailySchedule(List<OrgResoMetadataEnumsDailySchedule> dailySchedule) {
    this.dailySchedule = dailySchedule;
    return this;
  }

  public OrgResoMetadataProspectingCreate addDailyScheduleItem(OrgResoMetadataEnumsDailySchedule dailyScheduleItem) {
    if (this.dailySchedule == null) {
      this.dailySchedule = new ArrayList<OrgResoMetadataEnumsDailySchedule>();
    }
    this.dailySchedule.add(dailyScheduleItem);
    return this;
  }

  /**
   * Get dailySchedule
   * @return dailySchedule
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDailySchedule> getDailySchedule() {
    return dailySchedule;
  }

  public void setDailySchedule(List<OrgResoMetadataEnumsDailySchedule> dailySchedule) {
    this.dailySchedule = dailySchedule;
  }

  public OrgResoMetadataProspectingCreate displayTemplateID(String displayTemplateID) {
    this.displayTemplateID = displayTemplateID;
    return this;
  }

  /**
   * Get displayTemplateID
   * @return displayTemplateID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDisplayTemplateID() {
    return displayTemplateID;
  }

  public void setDisplayTemplateID(String displayTemplateID) {
    this.displayTemplateID = displayTemplateID;
  }

  public OrgResoMetadataProspectingCreate language(AnyOforgResoMetadataProspectingCreateLanguage language) {
    this.language = language;
    return this;
  }

  /**
   * Get language
   * @return language
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateLanguage getLanguage() {
    return language;
  }

  public void setLanguage(AnyOforgResoMetadataProspectingCreateLanguage language) {
    this.language = language;
  }

  public OrgResoMetadataProspectingCreate lastNewChangedTimestamp(OffsetDateTime lastNewChangedTimestamp) {
    this.lastNewChangedTimestamp = lastNewChangedTimestamp;
    return this;
  }

  /**
   * Get lastNewChangedTimestamp
   * @return lastNewChangedTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastNewChangedTimestamp() {
    return lastNewChangedTimestamp;
  }

  public void setLastNewChangedTimestamp(OffsetDateTime lastNewChangedTimestamp) {
    this.lastNewChangedTimestamp = lastNewChangedTimestamp;
  }

  public OrgResoMetadataProspectingCreate lastViewedTimestamp(OffsetDateTime lastViewedTimestamp) {
    this.lastViewedTimestamp = lastViewedTimestamp;
    return this;
  }

  /**
   * Get lastViewedTimestamp
   * @return lastViewedTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastViewedTimestamp() {
    return lastViewedTimestamp;
  }

  public void setLastViewedTimestamp(OffsetDateTime lastViewedTimestamp) {
    this.lastViewedTimestamp = lastViewedTimestamp;
  }

  public OrgResoMetadataProspectingCreate messageNew(String messageNew) {
    this.messageNew = messageNew;
    return this;
  }

  /**
   * Get messageNew
   * @return messageNew
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getMessageNew() {
    return messageNew;
  }

  public void setMessageNew(String messageNew) {
    this.messageNew = messageNew;
  }

  public OrgResoMetadataProspectingCreate messageRevise(String messageRevise) {
    this.messageRevise = messageRevise;
    return this;
  }

  /**
   * Get messageRevise
   * @return messageRevise
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getMessageRevise() {
    return messageRevise;
  }

  public void setMessageRevise(String messageRevise) {
    this.messageRevise = messageRevise;
  }

  public OrgResoMetadataProspectingCreate messageUpdate(String messageUpdate) {
    this.messageUpdate = messageUpdate;
    return this;
  }

  /**
   * Get messageUpdate
   * @return messageUpdate
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getMessageUpdate() {
    return messageUpdate;
  }

  public void setMessageUpdate(String messageUpdate) {
    this.messageUpdate = messageUpdate;
  }

  public OrgResoMetadataProspectingCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataProspectingCreate nextSendTimestamp(OffsetDateTime nextSendTimestamp) {
    this.nextSendTimestamp = nextSendTimestamp;
    return this;
  }

  /**
   * Get nextSendTimestamp
   * @return nextSendTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getNextSendTimestamp() {
    return nextSendTimestamp;
  }

  public void setNextSendTimestamp(OffsetDateTime nextSendTimestamp) {
    this.nextSendTimestamp = nextSendTimestamp;
  }

  public OrgResoMetadataProspectingCreate ownerMemberID(String ownerMemberID) {
    this.ownerMemberID = ownerMemberID;
    return this;
  }

  /**
   * Get ownerMemberID
   * @return ownerMemberID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOwnerMemberID() {
    return ownerMemberID;
  }

  public void setOwnerMemberID(String ownerMemberID) {
    this.ownerMemberID = ownerMemberID;
  }

  public OrgResoMetadataProspectingCreate ownerMemberKey(String ownerMemberKey) {
    this.ownerMemberKey = ownerMemberKey;
    return this;
  }

  /**
   * Get ownerMemberKey
   * @return ownerMemberKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOwnerMemberKey() {
    return ownerMemberKey;
  }

  public void setOwnerMemberKey(String ownerMemberKey) {
    this.ownerMemberKey = ownerMemberKey;
  }

  public OrgResoMetadataProspectingCreate ownerMemberKeyNumeric(AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric) {
    this.ownerMemberKeyNumeric = ownerMemberKeyNumeric;
    return this;
  }

  /**
   * Get ownerMemberKeyNumeric
   * @return ownerMemberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric getOwnerMemberKeyNumeric() {
    return ownerMemberKeyNumeric;
  }

  public void setOwnerMemberKeyNumeric(AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric) {
    this.ownerMemberKeyNumeric = ownerMemberKeyNumeric;
  }

  public OrgResoMetadataProspectingCreate prospectingKey(String prospectingKey) {
    this.prospectingKey = prospectingKey;
    return this;
  }

  /**
   * Get prospectingKey
   * @return prospectingKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getProspectingKey() {
    return prospectingKey;
  }

  public void setProspectingKey(String prospectingKey) {
    this.prospectingKey = prospectingKey;
  }

  public OrgResoMetadataProspectingCreate prospectingKeyNumeric(AnyOforgResoMetadataProspectingCreateProspectingKeyNumeric prospectingKeyNumeric) {
    this.prospectingKeyNumeric = prospectingKeyNumeric;
    return this;
  }

  /**
   * Get prospectingKeyNumeric
   * @return prospectingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataProspectingCreateProspectingKeyNumeric getProspectingKeyNumeric() {
    return prospectingKeyNumeric;
  }

  public void setProspectingKeyNumeric(AnyOforgResoMetadataProspectingCreateProspectingKeyNumeric prospectingKeyNumeric) {
    this.prospectingKeyNumeric = prospectingKeyNumeric;
  }

  public OrgResoMetadataProspectingCreate reasonActiveOrDisabled(AnyOforgResoMetadataProspectingCreateReasonActiveOrDisabled reasonActiveOrDisabled) {
    this.reasonActiveOrDisabled = reasonActiveOrDisabled;
    return this;
  }

  /**
   * Get reasonActiveOrDisabled
   * @return reasonActiveOrDisabled
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateReasonActiveOrDisabled getReasonActiveOrDisabled() {
    return reasonActiveOrDisabled;
  }

  public void setReasonActiveOrDisabled(AnyOforgResoMetadataProspectingCreateReasonActiveOrDisabled reasonActiveOrDisabled) {
    this.reasonActiveOrDisabled = reasonActiveOrDisabled;
  }

  public OrgResoMetadataProspectingCreate savedSearchKey(String savedSearchKey) {
    this.savedSearchKey = savedSearchKey;
    return this;
  }

  /**
   * Get savedSearchKey
   * @return savedSearchKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSavedSearchKey() {
    return savedSearchKey;
  }

  public void setSavedSearchKey(String savedSearchKey) {
    this.savedSearchKey = savedSearchKey;
  }

  public OrgResoMetadataProspectingCreate savedSearchKeyNumeric(AnyOforgResoMetadataProspectingCreateSavedSearchKeyNumeric savedSearchKeyNumeric) {
    this.savedSearchKeyNumeric = savedSearchKeyNumeric;
    return this;
  }

  /**
   * Get savedSearchKeyNumeric
   * @return savedSearchKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataProspectingCreateSavedSearchKeyNumeric getSavedSearchKeyNumeric() {
    return savedSearchKeyNumeric;
  }

  public void setSavedSearchKeyNumeric(AnyOforgResoMetadataProspectingCreateSavedSearchKeyNumeric savedSearchKeyNumeric) {
    this.savedSearchKeyNumeric = savedSearchKeyNumeric;
  }

  public OrgResoMetadataProspectingCreate scheduleType(AnyOforgResoMetadataProspectingCreateScheduleType scheduleType) {
    this.scheduleType = scheduleType;
    return this;
  }

  /**
   * Get scheduleType
   * @return scheduleType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateScheduleType getScheduleType() {
    return scheduleType;
  }

  public void setScheduleType(AnyOforgResoMetadataProspectingCreateScheduleType scheduleType) {
    this.scheduleType = scheduleType;
  }

  public OrgResoMetadataProspectingCreate subject(String subject) {
    this.subject = subject;
    return this;
  }

  /**
   * Get subject
   * @return subject
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public OrgResoMetadataProspectingCreate toEmailList(String toEmailList) {
    this.toEmailList = toEmailList;
    return this;
  }

  /**
   * Get toEmailList
   * @return toEmailList
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getToEmailList() {
    return toEmailList;
  }

  public void setToEmailList(String toEmailList) {
    this.toEmailList = toEmailList;
  }

  public OrgResoMetadataProspectingCreate contact(AnyOforgResoMetadataProspectingCreateContact contact) {
    this.contact = contact;
    return this;
  }

  /**
   * Get contact
   * @return contact
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateContact getContact() {
    return contact;
  }

  public void setContact(AnyOforgResoMetadataProspectingCreateContact contact) {
    this.contact = contact;
  }

  public OrgResoMetadataProspectingCreate ownerMember(AnyOforgResoMetadataProspectingCreateOwnerMember ownerMember) {
    this.ownerMember = ownerMember;
    return this;
  }

  /**
   * Get ownerMember
   * @return ownerMember
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateOwnerMember getOwnerMember() {
    return ownerMember;
  }

  public void setOwnerMember(AnyOforgResoMetadataProspectingCreateOwnerMember ownerMember) {
    this.ownerMember = ownerMember;
  }

  public OrgResoMetadataProspectingCreate savedSearch(AnyOforgResoMetadataProspectingCreateSavedSearch savedSearch) {
    this.savedSearch = savedSearch;
    return this;
  }

  /**
   * Get savedSearch
   * @return savedSearch
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataProspectingCreateSavedSearch getSavedSearch() {
    return savedSearch;
  }

  public void setSavedSearch(AnyOforgResoMetadataProspectingCreateSavedSearch savedSearch) {
    this.savedSearch = savedSearch;
  }

  public OrgResoMetadataProspectingCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataProspectingCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataProspectingCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataProspectingCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataProspectingCreate orgResoMetadataProspectingCreate = (OrgResoMetadataProspectingCreate) o;
    return Objects.equals(this.activeYN, orgResoMetadataProspectingCreate.activeYN) &&
        Objects.equals(this.bccEmailList, orgResoMetadataProspectingCreate.bccEmailList) &&
        Objects.equals(this.bccMeYN, orgResoMetadataProspectingCreate.bccMeYN) &&
        Objects.equals(this.ccEmailList, orgResoMetadataProspectingCreate.ccEmailList) &&
        Objects.equals(this.clientActivatedYN, orgResoMetadataProspectingCreate.clientActivatedYN) &&
        Objects.equals(this.conciergeNotificationsYN, orgResoMetadataProspectingCreate.conciergeNotificationsYN) &&
        Objects.equals(this.conciergeYN, orgResoMetadataProspectingCreate.conciergeYN) &&
        Objects.equals(this.contactKey, orgResoMetadataProspectingCreate.contactKey) &&
        Objects.equals(this.contactKeyNumeric, orgResoMetadataProspectingCreate.contactKeyNumeric) &&
        Objects.equals(this.dailySchedule, orgResoMetadataProspectingCreate.dailySchedule) &&
        Objects.equals(this.displayTemplateID, orgResoMetadataProspectingCreate.displayTemplateID) &&
        Objects.equals(this.language, orgResoMetadataProspectingCreate.language) &&
        Objects.equals(this.lastNewChangedTimestamp, orgResoMetadataProspectingCreate.lastNewChangedTimestamp) &&
        Objects.equals(this.lastViewedTimestamp, orgResoMetadataProspectingCreate.lastViewedTimestamp) &&
        Objects.equals(this.messageNew, orgResoMetadataProspectingCreate.messageNew) &&
        Objects.equals(this.messageRevise, orgResoMetadataProspectingCreate.messageRevise) &&
        Objects.equals(this.messageUpdate, orgResoMetadataProspectingCreate.messageUpdate) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataProspectingCreate.modificationTimestamp) &&
        Objects.equals(this.nextSendTimestamp, orgResoMetadataProspectingCreate.nextSendTimestamp) &&
        Objects.equals(this.ownerMemberID, orgResoMetadataProspectingCreate.ownerMemberID) &&
        Objects.equals(this.ownerMemberKey, orgResoMetadataProspectingCreate.ownerMemberKey) &&
        Objects.equals(this.ownerMemberKeyNumeric, orgResoMetadataProspectingCreate.ownerMemberKeyNumeric) &&
        Objects.equals(this.prospectingKey, orgResoMetadataProspectingCreate.prospectingKey) &&
        Objects.equals(this.prospectingKeyNumeric, orgResoMetadataProspectingCreate.prospectingKeyNumeric) &&
        Objects.equals(this.reasonActiveOrDisabled, orgResoMetadataProspectingCreate.reasonActiveOrDisabled) &&
        Objects.equals(this.savedSearchKey, orgResoMetadataProspectingCreate.savedSearchKey) &&
        Objects.equals(this.savedSearchKeyNumeric, orgResoMetadataProspectingCreate.savedSearchKeyNumeric) &&
        Objects.equals(this.scheduleType, orgResoMetadataProspectingCreate.scheduleType) &&
        Objects.equals(this.subject, orgResoMetadataProspectingCreate.subject) &&
        Objects.equals(this.toEmailList, orgResoMetadataProspectingCreate.toEmailList) &&
        Objects.equals(this.contact, orgResoMetadataProspectingCreate.contact) &&
        Objects.equals(this.ownerMember, orgResoMetadataProspectingCreate.ownerMember) &&
        Objects.equals(this.savedSearch, orgResoMetadataProspectingCreate.savedSearch) &&
        Objects.equals(this.historyTransactional, orgResoMetadataProspectingCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataProspectingCreate.media);
  }

  @Override
  public int hashCode() {
    return Objects.hash(activeYN, bccEmailList, bccMeYN, ccEmailList, clientActivatedYN, conciergeNotificationsYN, conciergeYN, contactKey, contactKeyNumeric, dailySchedule, displayTemplateID, language, lastNewChangedTimestamp, lastViewedTimestamp, messageNew, messageRevise, messageUpdate, modificationTimestamp, nextSendTimestamp, ownerMemberID, ownerMemberKey, ownerMemberKeyNumeric, prospectingKey, prospectingKeyNumeric, reasonActiveOrDisabled, savedSearchKey, savedSearchKeyNumeric, scheduleType, subject, toEmailList, contact, ownerMember, savedSearch, historyTransactional, media);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataProspectingCreate {\n");
    
    sb.append("    activeYN: ").append(toIndentedString(activeYN)).append("\n");
    sb.append("    bccEmailList: ").append(toIndentedString(bccEmailList)).append("\n");
    sb.append("    bccMeYN: ").append(toIndentedString(bccMeYN)).append("\n");
    sb.append("    ccEmailList: ").append(toIndentedString(ccEmailList)).append("\n");
    sb.append("    clientActivatedYN: ").append(toIndentedString(clientActivatedYN)).append("\n");
    sb.append("    conciergeNotificationsYN: ").append(toIndentedString(conciergeNotificationsYN)).append("\n");
    sb.append("    conciergeYN: ").append(toIndentedString(conciergeYN)).append("\n");
    sb.append("    contactKey: ").append(toIndentedString(contactKey)).append("\n");
    sb.append("    contactKeyNumeric: ").append(toIndentedString(contactKeyNumeric)).append("\n");
    sb.append("    dailySchedule: ").append(toIndentedString(dailySchedule)).append("\n");
    sb.append("    displayTemplateID: ").append(toIndentedString(displayTemplateID)).append("\n");
    sb.append("    language: ").append(toIndentedString(language)).append("\n");
    sb.append("    lastNewChangedTimestamp: ").append(toIndentedString(lastNewChangedTimestamp)).append("\n");
    sb.append("    lastViewedTimestamp: ").append(toIndentedString(lastViewedTimestamp)).append("\n");
    sb.append("    messageNew: ").append(toIndentedString(messageNew)).append("\n");
    sb.append("    messageRevise: ").append(toIndentedString(messageRevise)).append("\n");
    sb.append("    messageUpdate: ").append(toIndentedString(messageUpdate)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    nextSendTimestamp: ").append(toIndentedString(nextSendTimestamp)).append("\n");
    sb.append("    ownerMemberID: ").append(toIndentedString(ownerMemberID)).append("\n");
    sb.append("    ownerMemberKey: ").append(toIndentedString(ownerMemberKey)).append("\n");
    sb.append("    ownerMemberKeyNumeric: ").append(toIndentedString(ownerMemberKeyNumeric)).append("\n");
    sb.append("    prospectingKey: ").append(toIndentedString(prospectingKey)).append("\n");
    sb.append("    prospectingKeyNumeric: ").append(toIndentedString(prospectingKeyNumeric)).append("\n");
    sb.append("    reasonActiveOrDisabled: ").append(toIndentedString(reasonActiveOrDisabled)).append("\n");
    sb.append("    savedSearchKey: ").append(toIndentedString(savedSearchKey)).append("\n");
    sb.append("    savedSearchKeyNumeric: ").append(toIndentedString(savedSearchKeyNumeric)).append("\n");
    sb.append("    scheduleType: ").append(toIndentedString(scheduleType)).append("\n");
    sb.append("    subject: ").append(toIndentedString(subject)).append("\n");
    sb.append("    toEmailList: ").append(toIndentedString(toEmailList)).append("\n");
    sb.append("    contact: ").append(toIndentedString(contact)).append("\n");
    sb.append("    ownerMember: ").append(toIndentedString(ownerMember)).append("\n");
    sb.append("    savedSearch: ").append(toIndentedString(savedSearch)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
