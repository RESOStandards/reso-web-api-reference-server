package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric {

}
