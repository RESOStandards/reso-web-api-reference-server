package io.swagger.model;


/**
* AnyOforgResoMetadataContactsSourceSystem
*/
public interface AnyOforgResoMetadataContactsSourceSystem {

}
