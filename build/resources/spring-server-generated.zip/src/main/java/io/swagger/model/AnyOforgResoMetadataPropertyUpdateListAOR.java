package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateListAOR
*/
public interface AnyOforgResoMetadataPropertyUpdateListAOR {

}
