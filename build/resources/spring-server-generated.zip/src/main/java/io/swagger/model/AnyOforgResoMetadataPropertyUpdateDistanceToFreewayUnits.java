package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits {

}
