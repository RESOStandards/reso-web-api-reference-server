package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateActorKeyNumeric
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateActorKeyNumeric {

}
