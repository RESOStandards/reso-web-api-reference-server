package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionPowerProductionAnnual
*/
public interface AnyOforgResoMetadataPropertyPowerProductionPowerProductionAnnual {

}
