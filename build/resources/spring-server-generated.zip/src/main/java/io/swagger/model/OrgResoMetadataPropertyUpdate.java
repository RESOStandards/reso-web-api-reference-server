package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsAccessibilityFeatures;
import io.swagger.model.OrgResoMetadataEnumsAppliances;
import io.swagger.model.OrgResoMetadataEnumsArchitecturalStyle;
import io.swagger.model.OrgResoMetadataEnumsAssociationAmenities;
import io.swagger.model.OrgResoMetadataEnumsAssociationFeeIncludes;
import io.swagger.model.OrgResoMetadataEnumsBasement;
import io.swagger.model.OrgResoMetadataEnumsBodyType;
import io.swagger.model.OrgResoMetadataEnumsBuildingFeatures;
import io.swagger.model.OrgResoMetadataEnumsBusinessType;
import io.swagger.model.OrgResoMetadataEnumsBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsBuyerFinancing;
import io.swagger.model.OrgResoMetadataEnumsCoBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCoListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCommonWalls;
import io.swagger.model.OrgResoMetadataEnumsCommunityFeatures;
import io.swagger.model.OrgResoMetadataEnumsConstructionMaterials;
import io.swagger.model.OrgResoMetadataEnumsCooling;
import io.swagger.model.OrgResoMetadataEnumsCurrentFinancing;
import io.swagger.model.OrgResoMetadataEnumsCurrentUse;
import io.swagger.model.OrgResoMetadataEnumsDevelopmentStatus;
import io.swagger.model.OrgResoMetadataEnumsDisclosures;
import io.swagger.model.OrgResoMetadataEnumsDocumentsAvailable;
import io.swagger.model.OrgResoMetadataEnumsDoorFeatures;
import io.swagger.model.OrgResoMetadataEnumsElectric;
import io.swagger.model.OrgResoMetadataEnumsExistingLeaseType;
import io.swagger.model.OrgResoMetadataEnumsExteriorFeatures;
import io.swagger.model.OrgResoMetadataEnumsFencing;
import io.swagger.model.OrgResoMetadataEnumsFinancialDataSource;
import io.swagger.model.OrgResoMetadataEnumsFireplaceFeatures;
import io.swagger.model.OrgResoMetadataEnumsFlooring;
import io.swagger.model.OrgResoMetadataEnumsFoundationDetails;
import io.swagger.model.OrgResoMetadataEnumsFrontageType;
import io.swagger.model.OrgResoMetadataEnumsGreenBuildingVerificationType;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyEfficient;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyGeneration;
import io.swagger.model.OrgResoMetadataEnumsGreenIndoorAirQuality;
import io.swagger.model.OrgResoMetadataEnumsGreenLocation;
import io.swagger.model.OrgResoMetadataEnumsGreenSustainability;
import io.swagger.model.OrgResoMetadataEnumsGreenWaterConservation;
import io.swagger.model.OrgResoMetadataEnumsHeating;
import io.swagger.model.OrgResoMetadataEnumsHorseAmenities;
import io.swagger.model.OrgResoMetadataEnumsHoursDaysOfOperation;
import io.swagger.model.OrgResoMetadataEnumsIncomeIncludes;
import io.swagger.model.OrgResoMetadataEnumsInteriorOrRoomFeatures;
import io.swagger.model.OrgResoMetadataEnumsIrrigationSource;
import io.swagger.model.OrgResoMetadataEnumsLaborInformation;
import io.swagger.model.OrgResoMetadataEnumsLaundryFeatures;
import io.swagger.model.OrgResoMetadataEnumsLeaseRenewalCompensation;
import io.swagger.model.OrgResoMetadataEnumsLevels;
import io.swagger.model.OrgResoMetadataEnumsListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsListingTerms;
import io.swagger.model.OrgResoMetadataEnumsLockBoxType;
import io.swagger.model.OrgResoMetadataEnumsLotFeatures;
import io.swagger.model.OrgResoMetadataEnumsOperatingExpenseIncludes;
import io.swagger.model.OrgResoMetadataEnumsOtherEquipment;
import io.swagger.model.OrgResoMetadataEnumsOtherStructures;
import io.swagger.model.OrgResoMetadataEnumsOwnerPays;
import io.swagger.model.OrgResoMetadataEnumsParkingFeatures;
import io.swagger.model.OrgResoMetadataEnumsPatioAndPorchFeatures;
import io.swagger.model.OrgResoMetadataEnumsPetsAllowed;
import io.swagger.model.OrgResoMetadataEnumsPoolFeatures;
import io.swagger.model.OrgResoMetadataEnumsPossession;
import io.swagger.model.OrgResoMetadataEnumsPossibleUse;
import io.swagger.model.OrgResoMetadataEnumsPowerProductionType;
import io.swagger.model.OrgResoMetadataEnumsPropertyCondition;
import io.swagger.model.OrgResoMetadataEnumsRentIncludes;
import io.swagger.model.OrgResoMetadataEnumsRoadFrontageType;
import io.swagger.model.OrgResoMetadataEnumsRoadResponsibility;
import io.swagger.model.OrgResoMetadataEnumsRoadSurfaceType;
import io.swagger.model.OrgResoMetadataEnumsRoof;
import io.swagger.model.OrgResoMetadataEnumsRoomType;
import io.swagger.model.OrgResoMetadataEnumsSecurityFeatures;
import io.swagger.model.OrgResoMetadataEnumsSewer;
import io.swagger.model.OrgResoMetadataEnumsShowingContactType;
import io.swagger.model.OrgResoMetadataEnumsShowingDays;
import io.swagger.model.OrgResoMetadataEnumsShowingRequirements;
import io.swagger.model.OrgResoMetadataEnumsSkirt;
import io.swagger.model.OrgResoMetadataEnumsSpaFeatures;
import io.swagger.model.OrgResoMetadataEnumsSpecialLicenses;
import io.swagger.model.OrgResoMetadataEnumsSpecialListingConditions;
import io.swagger.model.OrgResoMetadataEnumsStructureType;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.model.OrgResoMetadataEnumsTaxStatusCurrent;
import io.swagger.model.OrgResoMetadataEnumsTenantPays;
import io.swagger.model.OrgResoMetadataEnumsUnitTypeType;
import io.swagger.model.OrgResoMetadataEnumsUtilities;
import io.swagger.model.OrgResoMetadataEnumsVegetation;
import io.swagger.model.OrgResoMetadataEnumsView;
import io.swagger.model.OrgResoMetadataEnumsWaterSource;
import io.swagger.model.OrgResoMetadataEnumsWaterfrontFeatures;
import io.swagger.model.OrgResoMetadataEnumsWindowFeatures;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataPropertyUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataPropertyUpdate   {
  @JsonProperty("AboveGradeFinishedArea")
  private AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedArea aboveGradeFinishedArea = null;

  @JsonProperty("AboveGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource = null;

  @JsonProperty("AboveGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits = null;

  @JsonProperty("AccessCode")
  private String accessCode = null;

  @JsonProperty("AccessibilityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures = null;

  @JsonProperty("AdditionalParcelsDescription")
  private String additionalParcelsDescription = null;

  @JsonProperty("AdditionalParcelsYN")
  private Boolean additionalParcelsYN = null;

  @JsonProperty("AnchorsCoTenants")
  private String anchorsCoTenants = null;

  @JsonProperty("Appliances")
  @Valid
  private List<OrgResoMetadataEnumsAppliances> appliances = null;

  @JsonProperty("ArchitecturalStyle")
  @Valid
  private List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle = null;

  @JsonProperty("AssociationAmenities")
  @Valid
  private List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities = null;

  @JsonProperty("AssociationFee")
  private AnyOforgResoMetadataPropertyUpdateAssociationFee associationFee = null;

  @JsonProperty("AssociationFee2")
  private AnyOforgResoMetadataPropertyUpdateAssociationFee2 associationFee2 = null;

  @JsonProperty("AssociationFee2Frequency")
  private AnyOforgResoMetadataPropertyUpdateAssociationFee2Frequency associationFee2Frequency = null;

  @JsonProperty("AssociationFeeFrequency")
  private AnyOforgResoMetadataPropertyUpdateAssociationFeeFrequency associationFeeFrequency = null;

  @JsonProperty("AssociationFeeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes = null;

  @JsonProperty("AssociationName")
  private String associationName = null;

  @JsonProperty("AssociationName2")
  private String associationName2 = null;

  @JsonProperty("AssociationPhone")
  private String associationPhone = null;

  @JsonProperty("AssociationPhone2")
  private String associationPhone2 = null;

  @JsonProperty("AssociationYN")
  private Boolean associationYN = null;

  @JsonProperty("AttachedGarageYN")
  private Boolean attachedGarageYN = null;

  @JsonProperty("AvailabilityDate")
  private LocalDate availabilityDate = null;

  @JsonProperty("Basement")
  @Valid
  private List<OrgResoMetadataEnumsBasement> basement = null;

  @JsonProperty("BasementYN")
  private Boolean basementYN = null;

  @JsonProperty("BathroomsFull")
  private AnyOforgResoMetadataPropertyUpdateBathroomsFull bathroomsFull = null;

  @JsonProperty("BathroomsHalf")
  private AnyOforgResoMetadataPropertyUpdateBathroomsHalf bathroomsHalf = null;

  @JsonProperty("BathroomsOneQuarter")
  private AnyOforgResoMetadataPropertyUpdateBathroomsOneQuarter bathroomsOneQuarter = null;

  @JsonProperty("BathroomsPartial")
  private AnyOforgResoMetadataPropertyUpdateBathroomsPartial bathroomsPartial = null;

  @JsonProperty("BathroomsThreeQuarter")
  private AnyOforgResoMetadataPropertyUpdateBathroomsThreeQuarter bathroomsThreeQuarter = null;

  @JsonProperty("BathroomsTotalInteger")
  private AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger bathroomsTotalInteger = null;

  @JsonProperty("BedroomsPossible")
  private AnyOforgResoMetadataPropertyUpdateBedroomsPossible bedroomsPossible = null;

  @JsonProperty("BedroomsTotal")
  private AnyOforgResoMetadataPropertyUpdateBedroomsTotal bedroomsTotal = null;

  @JsonProperty("BelowGradeFinishedArea")
  private AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedArea belowGradeFinishedArea = null;

  @JsonProperty("BelowGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource = null;

  @JsonProperty("BelowGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits = null;

  @JsonProperty("BodyType")
  @Valid
  private List<OrgResoMetadataEnumsBodyType> bodyType = null;

  @JsonProperty("BuilderModel")
  private String builderModel = null;

  @JsonProperty("BuilderName")
  private String builderName = null;

  @JsonProperty("BuildingAreaSource")
  private AnyOforgResoMetadataPropertyUpdateBuildingAreaSource buildingAreaSource = null;

  @JsonProperty("BuildingAreaTotal")
  private AnyOforgResoMetadataPropertyUpdateBuildingAreaTotal buildingAreaTotal = null;

  @JsonProperty("BuildingAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateBuildingAreaUnits buildingAreaUnits = null;

  @JsonProperty("BuildingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures = null;

  @JsonProperty("BuildingName")
  private String buildingName = null;

  @JsonProperty("BusinessName")
  private String businessName = null;

  @JsonProperty("BusinessType")
  @Valid
  private List<OrgResoMetadataEnumsBusinessType> businessType = null;

  @JsonProperty("BuyerAgencyCompensation")
  private String buyerAgencyCompensation = null;

  @JsonProperty("BuyerAgencyCompensationType")
  private AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType buyerAgencyCompensationType = null;

  @JsonProperty("BuyerAgentAOR")
  private AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR buyerAgentAOR = null;

  @JsonProperty("BuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation = null;

  @JsonProperty("BuyerAgentDirectPhone")
  private String buyerAgentDirectPhone = null;

  @JsonProperty("BuyerAgentEmail")
  private String buyerAgentEmail = null;

  @JsonProperty("BuyerAgentFax")
  private String buyerAgentFax = null;

  @JsonProperty("BuyerAgentFirstName")
  private String buyerAgentFirstName = null;

  @JsonProperty("BuyerAgentFullName")
  private String buyerAgentFullName = null;

  @JsonProperty("BuyerAgentHomePhone")
  private String buyerAgentHomePhone = null;

  @JsonProperty("BuyerAgentKey")
  private String buyerAgentKey = null;

  @JsonProperty("BuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric buyerAgentKeyNumeric = null;

  @JsonProperty("BuyerAgentLastName")
  private String buyerAgentLastName = null;

  @JsonProperty("BuyerAgentMiddleName")
  private String buyerAgentMiddleName = null;

  @JsonProperty("BuyerAgentMlsId")
  private String buyerAgentMlsId = null;

  @JsonProperty("BuyerAgentMobilePhone")
  private String buyerAgentMobilePhone = null;

  @JsonProperty("BuyerAgentNamePrefix")
  private String buyerAgentNamePrefix = null;

  @JsonProperty("BuyerAgentNameSuffix")
  private String buyerAgentNameSuffix = null;

  @JsonProperty("BuyerAgentOfficePhone")
  private String buyerAgentOfficePhone = null;

  @JsonProperty("BuyerAgentOfficePhoneExt")
  private String buyerAgentOfficePhoneExt = null;

  @JsonProperty("BuyerAgentPager")
  private String buyerAgentPager = null;

  @JsonProperty("BuyerAgentPreferredPhone")
  private String buyerAgentPreferredPhone = null;

  @JsonProperty("BuyerAgentPreferredPhoneExt")
  private String buyerAgentPreferredPhoneExt = null;

  @JsonProperty("BuyerAgentStateLicense")
  private String buyerAgentStateLicense = null;

  @JsonProperty("BuyerAgentTollFreePhone")
  private String buyerAgentTollFreePhone = null;

  @JsonProperty("BuyerAgentURL")
  private String buyerAgentURL = null;

  @JsonProperty("BuyerAgentVoiceMail")
  private String buyerAgentVoiceMail = null;

  @JsonProperty("BuyerAgentVoiceMailExt")
  private String buyerAgentVoiceMailExt = null;

  @JsonProperty("BuyerFinancing")
  @Valid
  private List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing = null;

  @JsonProperty("BuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyUpdateBuyerOfficeAOR buyerOfficeAOR = null;

  @JsonProperty("BuyerOfficeEmail")
  private String buyerOfficeEmail = null;

  @JsonProperty("BuyerOfficeFax")
  private String buyerOfficeFax = null;

  @JsonProperty("BuyerOfficeKey")
  private String buyerOfficeKey = null;

  @JsonProperty("BuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric = null;

  @JsonProperty("BuyerOfficeMlsId")
  private String buyerOfficeMlsId = null;

  @JsonProperty("BuyerOfficeName")
  private String buyerOfficeName = null;

  @JsonProperty("BuyerOfficePhone")
  private String buyerOfficePhone = null;

  @JsonProperty("BuyerOfficePhoneExt")
  private String buyerOfficePhoneExt = null;

  @JsonProperty("BuyerOfficeURL")
  private String buyerOfficeURL = null;

  @JsonProperty("BuyerTeamKey")
  private String buyerTeamKey = null;

  @JsonProperty("BuyerTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric buyerTeamKeyNumeric = null;

  @JsonProperty("BuyerTeamName")
  private String buyerTeamName = null;

  @JsonProperty("CableTvExpense")
  private AnyOforgResoMetadataPropertyUpdateCableTvExpense cableTvExpense = null;

  @JsonProperty("CancellationDate")
  private LocalDate cancellationDate = null;

  @JsonProperty("CapRate")
  private AnyOforgResoMetadataPropertyUpdateCapRate capRate = null;

  @JsonProperty("CarportSpaces")
  private AnyOforgResoMetadataPropertyUpdateCarportSpaces carportSpaces = null;

  @JsonProperty("CarportYN")
  private Boolean carportYN = null;

  @JsonProperty("CarrierRoute")
  private String carrierRoute = null;

  @JsonProperty("City")
  private AnyOforgResoMetadataPropertyUpdateCity city = null;

  @JsonProperty("CityRegion")
  private String cityRegion = null;

  @JsonProperty("CloseDate")
  private LocalDate closeDate = null;

  @JsonProperty("ClosePrice")
  private AnyOforgResoMetadataPropertyUpdateClosePrice closePrice = null;

  @JsonProperty("CoBuyerAgentAOR")
  private AnyOforgResoMetadataPropertyUpdateCoBuyerAgentAOR coBuyerAgentAOR = null;

  @JsonProperty("CoBuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation = null;

  @JsonProperty("CoBuyerAgentDirectPhone")
  private String coBuyerAgentDirectPhone = null;

  @JsonProperty("CoBuyerAgentEmail")
  private String coBuyerAgentEmail = null;

  @JsonProperty("CoBuyerAgentFax")
  private String coBuyerAgentFax = null;

  @JsonProperty("CoBuyerAgentFirstName")
  private String coBuyerAgentFirstName = null;

  @JsonProperty("CoBuyerAgentFullName")
  private String coBuyerAgentFullName = null;

  @JsonProperty("CoBuyerAgentHomePhone")
  private String coBuyerAgentHomePhone = null;

  @JsonProperty("CoBuyerAgentKey")
  private String coBuyerAgentKey = null;

  @JsonProperty("CoBuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric = null;

  @JsonProperty("CoBuyerAgentLastName")
  private String coBuyerAgentLastName = null;

  @JsonProperty("CoBuyerAgentMiddleName")
  private String coBuyerAgentMiddleName = null;

  @JsonProperty("CoBuyerAgentMlsId")
  private String coBuyerAgentMlsId = null;

  @JsonProperty("CoBuyerAgentMobilePhone")
  private String coBuyerAgentMobilePhone = null;

  @JsonProperty("CoBuyerAgentNamePrefix")
  private String coBuyerAgentNamePrefix = null;

  @JsonProperty("CoBuyerAgentNameSuffix")
  private String coBuyerAgentNameSuffix = null;

  @JsonProperty("CoBuyerAgentOfficePhone")
  private String coBuyerAgentOfficePhone = null;

  @JsonProperty("CoBuyerAgentOfficePhoneExt")
  private String coBuyerAgentOfficePhoneExt = null;

  @JsonProperty("CoBuyerAgentPager")
  private String coBuyerAgentPager = null;

  @JsonProperty("CoBuyerAgentPreferredPhone")
  private String coBuyerAgentPreferredPhone = null;

  @JsonProperty("CoBuyerAgentPreferredPhoneExt")
  private String coBuyerAgentPreferredPhoneExt = null;

  @JsonProperty("CoBuyerAgentStateLicense")
  private String coBuyerAgentStateLicense = null;

  @JsonProperty("CoBuyerAgentTollFreePhone")
  private String coBuyerAgentTollFreePhone = null;

  @JsonProperty("CoBuyerAgentURL")
  private String coBuyerAgentURL = null;

  @JsonProperty("CoBuyerAgentVoiceMail")
  private String coBuyerAgentVoiceMail = null;

  @JsonProperty("CoBuyerAgentVoiceMailExt")
  private String coBuyerAgentVoiceMailExt = null;

  @JsonProperty("CoBuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeAOR coBuyerOfficeAOR = null;

  @JsonProperty("CoBuyerOfficeEmail")
  private String coBuyerOfficeEmail = null;

  @JsonProperty("CoBuyerOfficeFax")
  private String coBuyerOfficeFax = null;

  @JsonProperty("CoBuyerOfficeKey")
  private String coBuyerOfficeKey = null;

  @JsonProperty("CoBuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric = null;

  @JsonProperty("CoBuyerOfficeMlsId")
  private String coBuyerOfficeMlsId = null;

  @JsonProperty("CoBuyerOfficeName")
  private String coBuyerOfficeName = null;

  @JsonProperty("CoBuyerOfficePhone")
  private String coBuyerOfficePhone = null;

  @JsonProperty("CoBuyerOfficePhoneExt")
  private String coBuyerOfficePhoneExt = null;

  @JsonProperty("CoBuyerOfficeURL")
  private String coBuyerOfficeURL = null;

  @JsonProperty("CoListAgentAOR")
  private AnyOforgResoMetadataPropertyUpdateCoListAgentAOR coListAgentAOR = null;

  @JsonProperty("CoListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation = null;

  @JsonProperty("CoListAgentDirectPhone")
  private String coListAgentDirectPhone = null;

  @JsonProperty("CoListAgentEmail")
  private String coListAgentEmail = null;

  @JsonProperty("CoListAgentFax")
  private String coListAgentFax = null;

  @JsonProperty("CoListAgentFirstName")
  private String coListAgentFirstName = null;

  @JsonProperty("CoListAgentFullName")
  private String coListAgentFullName = null;

  @JsonProperty("CoListAgentHomePhone")
  private String coListAgentHomePhone = null;

  @JsonProperty("CoListAgentKey")
  private String coListAgentKey = null;

  @JsonProperty("CoListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric coListAgentKeyNumeric = null;

  @JsonProperty("CoListAgentLastName")
  private String coListAgentLastName = null;

  @JsonProperty("CoListAgentMiddleName")
  private String coListAgentMiddleName = null;

  @JsonProperty("CoListAgentMlsId")
  private String coListAgentMlsId = null;

  @JsonProperty("CoListAgentMobilePhone")
  private String coListAgentMobilePhone = null;

  @JsonProperty("CoListAgentNamePrefix")
  private String coListAgentNamePrefix = null;

  @JsonProperty("CoListAgentNameSuffix")
  private String coListAgentNameSuffix = null;

  @JsonProperty("CoListAgentOfficePhone")
  private String coListAgentOfficePhone = null;

  @JsonProperty("CoListAgentOfficePhoneExt")
  private String coListAgentOfficePhoneExt = null;

  @JsonProperty("CoListAgentPager")
  private String coListAgentPager = null;

  @JsonProperty("CoListAgentPreferredPhone")
  private String coListAgentPreferredPhone = null;

  @JsonProperty("CoListAgentPreferredPhoneExt")
  private String coListAgentPreferredPhoneExt = null;

  @JsonProperty("CoListAgentStateLicense")
  private String coListAgentStateLicense = null;

  @JsonProperty("CoListAgentTollFreePhone")
  private String coListAgentTollFreePhone = null;

  @JsonProperty("CoListAgentURL")
  private String coListAgentURL = null;

  @JsonProperty("CoListAgentVoiceMail")
  private String coListAgentVoiceMail = null;

  @JsonProperty("CoListAgentVoiceMailExt")
  private String coListAgentVoiceMailExt = null;

  @JsonProperty("CoListOfficeAOR")
  private AnyOforgResoMetadataPropertyUpdateCoListOfficeAOR coListOfficeAOR = null;

  @JsonProperty("CoListOfficeEmail")
  private String coListOfficeEmail = null;

  @JsonProperty("CoListOfficeFax")
  private String coListOfficeFax = null;

  @JsonProperty("CoListOfficeKey")
  private String coListOfficeKey = null;

  @JsonProperty("CoListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateCoListOfficeKeyNumeric coListOfficeKeyNumeric = null;

  @JsonProperty("CoListOfficeMlsId")
  private String coListOfficeMlsId = null;

  @JsonProperty("CoListOfficeName")
  private String coListOfficeName = null;

  @JsonProperty("CoListOfficePhone")
  private String coListOfficePhone = null;

  @JsonProperty("CoListOfficePhoneExt")
  private String coListOfficePhoneExt = null;

  @JsonProperty("CoListOfficeURL")
  private String coListOfficeURL = null;

  @JsonProperty("CommonInterest")
  private AnyOforgResoMetadataPropertyUpdateCommonInterest commonInterest = null;

  @JsonProperty("CommonWalls")
  @Valid
  private List<OrgResoMetadataEnumsCommonWalls> commonWalls = null;

  @JsonProperty("CommunityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures = null;

  @JsonProperty("Concessions")
  private AnyOforgResoMetadataPropertyUpdateConcessions concessions = null;

  @JsonProperty("ConcessionsAmount")
  private AnyOforgResoMetadataPropertyUpdateConcessionsAmount concessionsAmount = null;

  @JsonProperty("ConcessionsComments")
  private String concessionsComments = null;

  @JsonProperty("ConstructionMaterials")
  @Valid
  private List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials = null;

  @JsonProperty("ContinentRegion")
  private String continentRegion = null;

  @JsonProperty("Contingency")
  private String contingency = null;

  @JsonProperty("ContingentDate")
  private LocalDate contingentDate = null;

  @JsonProperty("ContractStatusChangeDate")
  private LocalDate contractStatusChangeDate = null;

  @JsonProperty("Cooling")
  @Valid
  private List<OrgResoMetadataEnumsCooling> cooling = null;

  @JsonProperty("CoolingYN")
  private Boolean coolingYN = null;

  @JsonProperty("CopyrightNotice")
  private String copyrightNotice = null;

  @JsonProperty("Country")
  private AnyOforgResoMetadataPropertyUpdateCountry country = null;

  @JsonProperty("CountryRegion")
  private String countryRegion = null;

  @JsonProperty("CountyOrParish")
  private AnyOforgResoMetadataPropertyUpdateCountyOrParish countyOrParish = null;

  @JsonProperty("CoveredSpaces")
  private AnyOforgResoMetadataPropertyUpdateCoveredSpaces coveredSpaces = null;

  @JsonProperty("CropsIncludedYN")
  private Boolean cropsIncludedYN = null;

  @JsonProperty("CrossStreet")
  private String crossStreet = null;

  @JsonProperty("CultivatedArea")
  private AnyOforgResoMetadataPropertyUpdateCultivatedArea cultivatedArea = null;

  @JsonProperty("CumulativeDaysOnMarket")
  private AnyOforgResoMetadataPropertyUpdateCumulativeDaysOnMarket cumulativeDaysOnMarket = null;

  @JsonProperty("CurrentFinancing")
  @Valid
  private List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing = null;

  @JsonProperty("CurrentUse")
  @Valid
  private List<OrgResoMetadataEnumsCurrentUse> currentUse = null;

  @JsonProperty("DOH1")
  private String doH1 = null;

  @JsonProperty("DOH2")
  private String doH2 = null;

  @JsonProperty("DOH3")
  private String doH3 = null;

  @JsonProperty("DaysOnMarket")
  private AnyOforgResoMetadataPropertyUpdateDaysOnMarket daysOnMarket = null;

  @JsonProperty("DevelopmentStatus")
  @Valid
  private List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus = null;

  @JsonProperty("DirectionFaces")
  private AnyOforgResoMetadataPropertyUpdateDirectionFaces directionFaces = null;

  @JsonProperty("Directions")
  private String directions = null;

  @JsonProperty("Disclaimer")
  private String disclaimer = null;

  @JsonProperty("Disclosures")
  @Valid
  private List<OrgResoMetadataEnumsDisclosures> disclosures = null;

  @JsonProperty("DistanceToBusComments")
  private String distanceToBusComments = null;

  @JsonProperty("DistanceToBusNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric distanceToBusNumeric = null;

  @JsonProperty("DistanceToBusUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits distanceToBusUnits = null;

  @JsonProperty("DistanceToElectricComments")
  private String distanceToElectricComments = null;

  @JsonProperty("DistanceToElectricNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric distanceToElectricNumeric = null;

  @JsonProperty("DistanceToElectricUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToElectricUnits distanceToElectricUnits = null;

  @JsonProperty("DistanceToFreewayComments")
  private String distanceToFreewayComments = null;

  @JsonProperty("DistanceToFreewayNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToFreewayNumeric distanceToFreewayNumeric = null;

  @JsonProperty("DistanceToFreewayUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits distanceToFreewayUnits = null;

  @JsonProperty("DistanceToGasComments")
  private String distanceToGasComments = null;

  @JsonProperty("DistanceToGasNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToGasNumeric distanceToGasNumeric = null;

  @JsonProperty("DistanceToGasUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits distanceToGasUnits = null;

  @JsonProperty("DistanceToPhoneServiceComments")
  private String distanceToPhoneServiceComments = null;

  @JsonProperty("DistanceToPhoneServiceNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric = null;

  @JsonProperty("DistanceToPhoneServiceUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits = null;

  @JsonProperty("DistanceToPlaceofWorshipComments")
  private String distanceToPlaceofWorshipComments = null;

  @JsonProperty("DistanceToPlaceofWorshipNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric = null;

  @JsonProperty("DistanceToPlaceofWorshipUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits = null;

  @JsonProperty("DistanceToSchoolBusComments")
  private String distanceToSchoolBusComments = null;

  @JsonProperty("DistanceToSchoolBusNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric = null;

  @JsonProperty("DistanceToSchoolBusUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits distanceToSchoolBusUnits = null;

  @JsonProperty("DistanceToSchoolsComments")
  private String distanceToSchoolsComments = null;

  @JsonProperty("DistanceToSchoolsNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsNumeric distanceToSchoolsNumeric = null;

  @JsonProperty("DistanceToSchoolsUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsUnits distanceToSchoolsUnits = null;

  @JsonProperty("DistanceToSewerComments")
  private String distanceToSewerComments = null;

  @JsonProperty("DistanceToSewerNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric distanceToSewerNumeric = null;

  @JsonProperty("DistanceToSewerUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToSewerUnits distanceToSewerUnits = null;

  @JsonProperty("DistanceToShoppingComments")
  private String distanceToShoppingComments = null;

  @JsonProperty("DistanceToShoppingNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToShoppingNumeric distanceToShoppingNumeric = null;

  @JsonProperty("DistanceToShoppingUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToShoppingUnits distanceToShoppingUnits = null;

  @JsonProperty("DistanceToStreetComments")
  private String distanceToStreetComments = null;

  @JsonProperty("DistanceToStreetNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToStreetNumeric distanceToStreetNumeric = null;

  @JsonProperty("DistanceToStreetUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToStreetUnits distanceToStreetUnits = null;

  @JsonProperty("DistanceToWaterComments")
  private String distanceToWaterComments = null;

  @JsonProperty("DistanceToWaterNumeric")
  private AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric distanceToWaterNumeric = null;

  @JsonProperty("DistanceToWaterUnits")
  private AnyOforgResoMetadataPropertyUpdateDistanceToWaterUnits distanceToWaterUnits = null;

  @JsonProperty("DocumentsAvailable")
  @Valid
  private List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable = null;

  @JsonProperty("DocumentsChangeTimestamp")
  private OffsetDateTime documentsChangeTimestamp = null;

  @JsonProperty("DocumentsCount")
  private AnyOforgResoMetadataPropertyUpdateDocumentsCount documentsCount = null;

  @JsonProperty("DoorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsDoorFeatures> doorFeatures = null;

  @JsonProperty("DualVariableCompensationYN")
  private Boolean dualVariableCompensationYN = null;

  @JsonProperty("Electric")
  @Valid
  private List<OrgResoMetadataEnumsElectric> electric = null;

  @JsonProperty("ElectricExpense")
  private AnyOforgResoMetadataPropertyUpdateElectricExpense electricExpense = null;

  @JsonProperty("ElectricOnPropertyYN")
  private Boolean electricOnPropertyYN = null;

  @JsonProperty("ElementarySchool")
  private AnyOforgResoMetadataPropertyUpdateElementarySchool elementarySchool = null;

  @JsonProperty("ElementarySchoolDistrict")
  private AnyOforgResoMetadataPropertyUpdateElementarySchoolDistrict elementarySchoolDistrict = null;

  @JsonProperty("Elevation")
  private AnyOforgResoMetadataPropertyUpdateElevation elevation = null;

  @JsonProperty("ElevationUnits")
  private AnyOforgResoMetadataPropertyUpdateElevationUnits elevationUnits = null;

  @JsonProperty("EntryLevel")
  private AnyOforgResoMetadataPropertyUpdateEntryLevel entryLevel = null;

  @JsonProperty("EntryLocation")
  private String entryLocation = null;

  @JsonProperty("Exclusions")
  private String exclusions = null;

  @JsonProperty("ExistingLeaseType")
  @Valid
  private List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType = null;

  @JsonProperty("ExpirationDate")
  private LocalDate expirationDate = null;

  @JsonProperty("ExteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures = null;

  @JsonProperty("FarmCreditServiceInclYN")
  private Boolean farmCreditServiceInclYN = null;

  @JsonProperty("FarmLandAreaSource")
  private AnyOforgResoMetadataPropertyUpdateFarmLandAreaSource farmLandAreaSource = null;

  @JsonProperty("FarmLandAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateFarmLandAreaUnits farmLandAreaUnits = null;

  @JsonProperty("Fencing")
  @Valid
  private List<OrgResoMetadataEnumsFencing> fencing = null;

  @JsonProperty("FinancialDataSource")
  @Valid
  private List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource = null;

  @JsonProperty("FireplaceFeatures")
  @Valid
  private List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures = null;

  @JsonProperty("FireplaceYN")
  private Boolean fireplaceYN = null;

  @JsonProperty("FireplacesTotal")
  private AnyOforgResoMetadataPropertyUpdateFireplacesTotal fireplacesTotal = null;

  @JsonProperty("Flooring")
  @Valid
  private List<OrgResoMetadataEnumsFlooring> flooring = null;

  @JsonProperty("FoundationArea")
  private AnyOforgResoMetadataPropertyUpdateFoundationArea foundationArea = null;

  @JsonProperty("FoundationDetails")
  @Valid
  private List<OrgResoMetadataEnumsFoundationDetails> foundationDetails = null;

  @JsonProperty("FrontageLength")
  private String frontageLength = null;

  @JsonProperty("FrontageType")
  @Valid
  private List<OrgResoMetadataEnumsFrontageType> frontageType = null;

  @JsonProperty("FuelExpense")
  private AnyOforgResoMetadataPropertyUpdateFuelExpense fuelExpense = null;

  @JsonProperty("Furnished")
  private AnyOforgResoMetadataPropertyUpdateFurnished furnished = null;

  @JsonProperty("FurnitureReplacementExpense")
  private AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense furnitureReplacementExpense = null;

  @JsonProperty("GarageSpaces")
  private AnyOforgResoMetadataPropertyUpdateGarageSpaces garageSpaces = null;

  @JsonProperty("GarageYN")
  private Boolean garageYN = null;

  @JsonProperty("GardenerExpense")
  private AnyOforgResoMetadataPropertyUpdateGardenerExpense gardenerExpense = null;

  @JsonProperty("GrazingPermitsBlmYN")
  private Boolean grazingPermitsBlmYN = null;

  @JsonProperty("GrazingPermitsForestServiceYN")
  private Boolean grazingPermitsForestServiceYN = null;

  @JsonProperty("GrazingPermitsPrivateYN")
  private Boolean grazingPermitsPrivateYN = null;

  @JsonProperty("GreenBuildingVerificationType")
  @Valid
  private List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType = null;

  @JsonProperty("GreenEnergyEfficient")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient = null;

  @JsonProperty("GreenEnergyGeneration")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration = null;

  @JsonProperty("GreenIndoorAirQuality")
  @Valid
  private List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality = null;

  @JsonProperty("GreenLocation")
  @Valid
  private List<OrgResoMetadataEnumsGreenLocation> greenLocation = null;

  @JsonProperty("GreenSustainability")
  @Valid
  private List<OrgResoMetadataEnumsGreenSustainability> greenSustainability = null;

  @JsonProperty("GreenWaterConservation")
  @Valid
  private List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation = null;

  @JsonProperty("GrossIncome")
  private AnyOforgResoMetadataPropertyUpdateGrossIncome grossIncome = null;

  @JsonProperty("GrossScheduledIncome")
  private AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome grossScheduledIncome = null;

  @JsonProperty("HabitableResidenceYN")
  private Boolean habitableResidenceYN = null;

  @JsonProperty("Heating")
  @Valid
  private List<OrgResoMetadataEnumsHeating> heating = null;

  @JsonProperty("HeatingYN")
  private Boolean heatingYN = null;

  @JsonProperty("HighSchool")
  private AnyOforgResoMetadataPropertyUpdateHighSchool highSchool = null;

  @JsonProperty("HighSchoolDistrict")
  private AnyOforgResoMetadataPropertyUpdateHighSchoolDistrict highSchoolDistrict = null;

  @JsonProperty("HomeWarrantyYN")
  private Boolean homeWarrantyYN = null;

  @JsonProperty("HorseAmenities")
  @Valid
  private List<OrgResoMetadataEnumsHorseAmenities> horseAmenities = null;

  @JsonProperty("HorseYN")
  private Boolean horseYN = null;

  @JsonProperty("HoursDaysOfOperation")
  @Valid
  private List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation = null;

  @JsonProperty("HoursDaysOfOperationDescription")
  private String hoursDaysOfOperationDescription = null;

  @JsonProperty("Inclusions")
  private String inclusions = null;

  @JsonProperty("IncomeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes = null;

  @JsonProperty("InsuranceExpense")
  private AnyOforgResoMetadataPropertyUpdateInsuranceExpense insuranceExpense = null;

  @JsonProperty("InteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures = null;

  @JsonProperty("InternetAddressDisplayYN")
  private Boolean internetAddressDisplayYN = null;

  @JsonProperty("InternetAutomatedValuationDisplayYN")
  private Boolean internetAutomatedValuationDisplayYN = null;

  @JsonProperty("InternetConsumerCommentYN")
  private Boolean internetConsumerCommentYN = null;

  @JsonProperty("InternetEntireListingDisplayYN")
  private Boolean internetEntireListingDisplayYN = null;

  @JsonProperty("IrrigationSource")
  @Valid
  private List<OrgResoMetadataEnumsIrrigationSource> irrigationSource = null;

  @JsonProperty("IrrigationWaterRightsAcres")
  private AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres irrigationWaterRightsAcres = null;

  @JsonProperty("IrrigationWaterRightsYN")
  private Boolean irrigationWaterRightsYN = null;

  @JsonProperty("LaborInformation")
  @Valid
  private List<OrgResoMetadataEnumsLaborInformation> laborInformation = null;

  @JsonProperty("LandLeaseAmount")
  private AnyOforgResoMetadataPropertyUpdateLandLeaseAmount landLeaseAmount = null;

  @JsonProperty("LandLeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyUpdateLandLeaseAmountFrequency landLeaseAmountFrequency = null;

  @JsonProperty("LandLeaseExpirationDate")
  private LocalDate landLeaseExpirationDate = null;

  @JsonProperty("LandLeaseYN")
  private Boolean landLeaseYN = null;

  @JsonProperty("Latitude")
  private AnyOforgResoMetadataPropertyUpdateLatitude latitude = null;

  @JsonProperty("LaundryFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures = null;

  @JsonProperty("LeasableArea")
  private AnyOforgResoMetadataPropertyUpdateLeasableArea leasableArea = null;

  @JsonProperty("LeasableAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateLeasableAreaUnits leasableAreaUnits = null;

  @JsonProperty("LeaseAmount")
  private AnyOforgResoMetadataPropertyUpdateLeaseAmount leaseAmount = null;

  @JsonProperty("LeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyUpdateLeaseAmountFrequency leaseAmountFrequency = null;

  @JsonProperty("LeaseAssignableYN")
  private Boolean leaseAssignableYN = null;

  @JsonProperty("LeaseConsideredYN")
  private Boolean leaseConsideredYN = null;

  @JsonProperty("LeaseExpiration")
  private LocalDate leaseExpiration = null;

  @JsonProperty("LeaseRenewalCompensation")
  @Valid
  private List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation = null;

  @JsonProperty("LeaseRenewalOptionYN")
  private Boolean leaseRenewalOptionYN = null;

  @JsonProperty("LeaseTerm")
  private AnyOforgResoMetadataPropertyUpdateLeaseTerm leaseTerm = null;

  @JsonProperty("Levels")
  @Valid
  private List<OrgResoMetadataEnumsLevels> levels = null;

  @JsonProperty("License1")
  private String license1 = null;

  @JsonProperty("License2")
  private String license2 = null;

  @JsonProperty("License3")
  private String license3 = null;

  @JsonProperty("LicensesExpense")
  private AnyOforgResoMetadataPropertyUpdateLicensesExpense licensesExpense = null;

  @JsonProperty("ListAOR")
  private AnyOforgResoMetadataPropertyUpdateListAOR listAOR = null;

  @JsonProperty("ListAgentAOR")
  private AnyOforgResoMetadataPropertyUpdateListAgentAOR listAgentAOR = null;

  @JsonProperty("ListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation = null;

  @JsonProperty("ListAgentDirectPhone")
  private String listAgentDirectPhone = null;

  @JsonProperty("ListAgentEmail")
  private String listAgentEmail = null;

  @JsonProperty("ListAgentFax")
  private String listAgentFax = null;

  @JsonProperty("ListAgentFirstName")
  private String listAgentFirstName = null;

  @JsonProperty("ListAgentFullName")
  private String listAgentFullName = null;

  @JsonProperty("ListAgentHomePhone")
  private String listAgentHomePhone = null;

  @JsonProperty("ListAgentKey")
  private String listAgentKey = null;

  @JsonProperty("ListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric listAgentKeyNumeric = null;

  @JsonProperty("ListAgentLastName")
  private String listAgentLastName = null;

  @JsonProperty("ListAgentMiddleName")
  private String listAgentMiddleName = null;

  @JsonProperty("ListAgentMlsId")
  private String listAgentMlsId = null;

  @JsonProperty("ListAgentMobilePhone")
  private String listAgentMobilePhone = null;

  @JsonProperty("ListAgentNamePrefix")
  private String listAgentNamePrefix = null;

  @JsonProperty("ListAgentNameSuffix")
  private String listAgentNameSuffix = null;

  @JsonProperty("ListAgentOfficePhone")
  private String listAgentOfficePhone = null;

  @JsonProperty("ListAgentOfficePhoneExt")
  private String listAgentOfficePhoneExt = null;

  @JsonProperty("ListAgentPager")
  private String listAgentPager = null;

  @JsonProperty("ListAgentPreferredPhone")
  private String listAgentPreferredPhone = null;

  @JsonProperty("ListAgentPreferredPhoneExt")
  private String listAgentPreferredPhoneExt = null;

  @JsonProperty("ListAgentStateLicense")
  private String listAgentStateLicense = null;

  @JsonProperty("ListAgentTollFreePhone")
  private String listAgentTollFreePhone = null;

  @JsonProperty("ListAgentURL")
  private String listAgentURL = null;

  @JsonProperty("ListAgentVoiceMail")
  private String listAgentVoiceMail = null;

  @JsonProperty("ListAgentVoiceMailExt")
  private String listAgentVoiceMailExt = null;

  @JsonProperty("ListOfficeAOR")
  private AnyOforgResoMetadataPropertyUpdateListOfficeAOR listOfficeAOR = null;

  @JsonProperty("ListOfficeEmail")
  private String listOfficeEmail = null;

  @JsonProperty("ListOfficeFax")
  private String listOfficeFax = null;

  @JsonProperty("ListOfficeKey")
  private String listOfficeKey = null;

  @JsonProperty("ListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateListOfficeKeyNumeric listOfficeKeyNumeric = null;

  @JsonProperty("ListOfficeMlsId")
  private String listOfficeMlsId = null;

  @JsonProperty("ListOfficeName")
  private String listOfficeName = null;

  @JsonProperty("ListOfficePhone")
  private String listOfficePhone = null;

  @JsonProperty("ListOfficePhoneExt")
  private String listOfficePhoneExt = null;

  @JsonProperty("ListOfficeURL")
  private String listOfficeURL = null;

  @JsonProperty("ListPrice")
  private AnyOforgResoMetadataPropertyUpdateListPrice listPrice = null;

  @JsonProperty("ListPriceLow")
  private AnyOforgResoMetadataPropertyUpdateListPriceLow listPriceLow = null;

  @JsonProperty("ListTeamKey")
  private String listTeamKey = null;

  @JsonProperty("ListTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric listTeamKeyNumeric = null;

  @JsonProperty("ListTeamName")
  private String listTeamName = null;

  @JsonProperty("ListingAgreement")
  private AnyOforgResoMetadataPropertyUpdateListingAgreement listingAgreement = null;

  @JsonProperty("ListingContractDate")
  private LocalDate listingContractDate = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyUpdateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ListingService")
  private AnyOforgResoMetadataPropertyUpdateListingService listingService = null;

  @JsonProperty("ListingTerms")
  @Valid
  private List<OrgResoMetadataEnumsListingTerms> listingTerms = null;

  @JsonProperty("LivingArea")
  private AnyOforgResoMetadataPropertyUpdateLivingArea livingArea = null;

  @JsonProperty("LivingAreaSource")
  private AnyOforgResoMetadataPropertyUpdateLivingAreaSource livingAreaSource = null;

  @JsonProperty("LivingAreaUnits")
  private AnyOforgResoMetadataPropertyUpdateLivingAreaUnits livingAreaUnits = null;

  @JsonProperty("LockBoxLocation")
  private String lockBoxLocation = null;

  @JsonProperty("LockBoxSerialNumber")
  private String lockBoxSerialNumber = null;

  @JsonProperty("LockBoxType")
  @Valid
  private List<OrgResoMetadataEnumsLockBoxType> lockBoxType = null;

  @JsonProperty("Longitude")
  private AnyOforgResoMetadataPropertyUpdateLongitude longitude = null;

  @JsonProperty("LotDimensionsSource")
  private AnyOforgResoMetadataPropertyUpdateLotDimensionsSource lotDimensionsSource = null;

  @JsonProperty("LotFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLotFeatures> lotFeatures = null;

  @JsonProperty("LotSizeAcres")
  private AnyOforgResoMetadataPropertyUpdateLotSizeAcres lotSizeAcres = null;

  @JsonProperty("LotSizeArea")
  private AnyOforgResoMetadataPropertyUpdateLotSizeArea lotSizeArea = null;

  @JsonProperty("LotSizeDimensions")
  private String lotSizeDimensions = null;

  @JsonProperty("LotSizeSource")
  private AnyOforgResoMetadataPropertyUpdateLotSizeSource lotSizeSource = null;

  @JsonProperty("LotSizeSquareFeet")
  private AnyOforgResoMetadataPropertyUpdateLotSizeSquareFeet lotSizeSquareFeet = null;

  @JsonProperty("LotSizeUnits")
  private AnyOforgResoMetadataPropertyUpdateLotSizeUnits lotSizeUnits = null;

  @JsonProperty("MLSAreaMajor")
  private AnyOforgResoMetadataPropertyUpdateMlSAreaMajor mlSAreaMajor = null;

  @JsonProperty("MLSAreaMinor")
  private AnyOforgResoMetadataPropertyUpdateMlSAreaMinor mlSAreaMinor = null;

  @JsonProperty("MainLevelBathrooms")
  private AnyOforgResoMetadataPropertyUpdateMainLevelBathrooms mainLevelBathrooms = null;

  @JsonProperty("MainLevelBedrooms")
  private AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms mainLevelBedrooms = null;

  @JsonProperty("MaintenanceExpense")
  private AnyOforgResoMetadataPropertyUpdateMaintenanceExpense maintenanceExpense = null;

  @JsonProperty("MajorChangeTimestamp")
  private OffsetDateTime majorChangeTimestamp = null;

  @JsonProperty("MajorChangeType")
  private AnyOforgResoMetadataPropertyUpdateMajorChangeType majorChangeType = null;

  @JsonProperty("Make")
  private String make = null;

  @JsonProperty("ManagerExpense")
  private AnyOforgResoMetadataPropertyUpdateManagerExpense managerExpense = null;

  @JsonProperty("MapCoordinate")
  private String mapCoordinate = null;

  @JsonProperty("MapCoordinateSource")
  private String mapCoordinateSource = null;

  @JsonProperty("MapURL")
  private String mapURL = null;

  @JsonProperty("MiddleOrJuniorSchool")
  private AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchool middleOrJuniorSchool = null;

  @JsonProperty("MiddleOrJuniorSchoolDistrict")
  private AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict = null;

  @JsonProperty("MlsStatus")
  private AnyOforgResoMetadataPropertyUpdateMlsStatus mlsStatus = null;

  @JsonProperty("MobileDimUnits")
  private AnyOforgResoMetadataPropertyUpdateMobileDimUnits mobileDimUnits = null;

  @JsonProperty("MobileHomeRemainsYN")
  private Boolean mobileHomeRemainsYN = null;

  @JsonProperty("MobileLength")
  private AnyOforgResoMetadataPropertyUpdateMobileLength mobileLength = null;

  @JsonProperty("MobileWidth")
  private AnyOforgResoMetadataPropertyUpdateMobileWidth mobileWidth = null;

  @JsonProperty("Model")
  private String model = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NetOperatingIncome")
  private AnyOforgResoMetadataPropertyUpdateNetOperatingIncome netOperatingIncome = null;

  @JsonProperty("NewConstructionYN")
  private Boolean newConstructionYN = null;

  @JsonProperty("NewTaxesExpense")
  private AnyOforgResoMetadataPropertyUpdateNewTaxesExpense newTaxesExpense = null;

  @JsonProperty("NumberOfBuildings")
  private AnyOforgResoMetadataPropertyUpdateNumberOfBuildings numberOfBuildings = null;

  @JsonProperty("NumberOfFullTimeEmployees")
  private AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees numberOfFullTimeEmployees = null;

  @JsonProperty("NumberOfLots")
  private AnyOforgResoMetadataPropertyUpdateNumberOfLots numberOfLots = null;

  @JsonProperty("NumberOfPads")
  private AnyOforgResoMetadataPropertyUpdateNumberOfPads numberOfPads = null;

  @JsonProperty("NumberOfPartTimeEmployees")
  private AnyOforgResoMetadataPropertyUpdateNumberOfPartTimeEmployees numberOfPartTimeEmployees = null;

  @JsonProperty("NumberOfSeparateElectricMeters")
  private AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters = null;

  @JsonProperty("NumberOfSeparateGasMeters")
  private AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters numberOfSeparateGasMeters = null;

  @JsonProperty("NumberOfSeparateWaterMeters")
  private AnyOforgResoMetadataPropertyUpdateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters = null;

  @JsonProperty("NumberOfUnitsInCommunity")
  private AnyOforgResoMetadataPropertyUpdateNumberOfUnitsInCommunity numberOfUnitsInCommunity = null;

  @JsonProperty("NumberOfUnitsLeased")
  private AnyOforgResoMetadataPropertyUpdateNumberOfUnitsLeased numberOfUnitsLeased = null;

  @JsonProperty("NumberOfUnitsMoMo")
  private AnyOforgResoMetadataPropertyUpdateNumberOfUnitsMoMo numberOfUnitsMoMo = null;

  @JsonProperty("NumberOfUnitsTotal")
  private AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal numberOfUnitsTotal = null;

  @JsonProperty("NumberOfUnitsVacant")
  private AnyOforgResoMetadataPropertyUpdateNumberOfUnitsVacant numberOfUnitsVacant = null;

  @JsonProperty("OccupantName")
  private String occupantName = null;

  @JsonProperty("OccupantPhone")
  private String occupantPhone = null;

  @JsonProperty("OccupantType")
  private AnyOforgResoMetadataPropertyUpdateOccupantType occupantType = null;

  @JsonProperty("OffMarketDate")
  private LocalDate offMarketDate = null;

  @JsonProperty("OffMarketTimestamp")
  private OffsetDateTime offMarketTimestamp = null;

  @JsonProperty("OnMarketDate")
  private LocalDate onMarketDate = null;

  @JsonProperty("OnMarketTimestamp")
  private OffsetDateTime onMarketTimestamp = null;

  @JsonProperty("OpenParkingSpaces")
  private AnyOforgResoMetadataPropertyUpdateOpenParkingSpaces openParkingSpaces = null;

  @JsonProperty("OpenParkingYN")
  private Boolean openParkingYN = null;

  @JsonProperty("OperatingExpense")
  private AnyOforgResoMetadataPropertyUpdateOperatingExpense operatingExpense = null;

  @JsonProperty("OperatingExpenseIncludes")
  @Valid
  private List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginalListPrice")
  private AnyOforgResoMetadataPropertyUpdateOriginalListPrice originalListPrice = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OtherEquipment")
  @Valid
  private List<OrgResoMetadataEnumsOtherEquipment> otherEquipment = null;

  @JsonProperty("OtherExpense")
  private AnyOforgResoMetadataPropertyUpdateOtherExpense otherExpense = null;

  @JsonProperty("OtherParking")
  private String otherParking = null;

  @JsonProperty("OtherStructures")
  @Valid
  private List<OrgResoMetadataEnumsOtherStructures> otherStructures = null;

  @JsonProperty("OwnerName")
  private String ownerName = null;

  @JsonProperty("OwnerPays")
  @Valid
  private List<OrgResoMetadataEnumsOwnerPays> ownerPays = null;

  @JsonProperty("OwnerPhone")
  private String ownerPhone = null;

  @JsonProperty("Ownership")
  private String ownership = null;

  @JsonProperty("OwnershipType")
  private AnyOforgResoMetadataPropertyUpdateOwnershipType ownershipType = null;

  @JsonProperty("ParcelNumber")
  private String parcelNumber = null;

  @JsonProperty("ParkManagerName")
  private String parkManagerName = null;

  @JsonProperty("ParkManagerPhone")
  private String parkManagerPhone = null;

  @JsonProperty("ParkName")
  private String parkName = null;

  @JsonProperty("ParkingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures = null;

  @JsonProperty("ParkingTotal")
  private AnyOforgResoMetadataPropertyUpdateParkingTotal parkingTotal = null;

  @JsonProperty("PastureArea")
  private AnyOforgResoMetadataPropertyUpdatePastureArea pastureArea = null;

  @JsonProperty("PatioAndPorchFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures = null;

  @JsonProperty("PendingTimestamp")
  private OffsetDateTime pendingTimestamp = null;

  @JsonProperty("PestControlExpense")
  private AnyOforgResoMetadataPropertyUpdatePestControlExpense pestControlExpense = null;

  @JsonProperty("PetsAllowed")
  @Valid
  private List<OrgResoMetadataEnumsPetsAllowed> petsAllowed = null;

  @JsonProperty("PhotosChangeTimestamp")
  private OffsetDateTime photosChangeTimestamp = null;

  @JsonProperty("PhotosCount")
  private AnyOforgResoMetadataPropertyUpdatePhotosCount photosCount = null;

  @JsonProperty("PoolExpense")
  private AnyOforgResoMetadataPropertyUpdatePoolExpense poolExpense = null;

  @JsonProperty("PoolFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPoolFeatures> poolFeatures = null;

  @JsonProperty("PoolPrivateYN")
  private Boolean poolPrivateYN = null;

  @JsonProperty("Possession")
  @Valid
  private List<OrgResoMetadataEnumsPossession> possession = null;

  @JsonProperty("PossibleUse")
  @Valid
  private List<OrgResoMetadataEnumsPossibleUse> possibleUse = null;

  @JsonProperty("PostalCity")
  private AnyOforgResoMetadataPropertyUpdatePostalCity postalCity = null;

  @JsonProperty("PostalCode")
  private String postalCode = null;

  @JsonProperty("PostalCodePlus4")
  private String postalCodePlus4 = null;

  @JsonProperty("PowerProductionType")
  @Valid
  private List<OrgResoMetadataEnumsPowerProductionType> powerProductionType = null;

  @JsonProperty("PreviousListPrice")
  private AnyOforgResoMetadataPropertyUpdatePreviousListPrice previousListPrice = null;

  @JsonProperty("PriceChangeTimestamp")
  private OffsetDateTime priceChangeTimestamp = null;

  @JsonProperty("PrivateOfficeRemarks")
  private String privateOfficeRemarks = null;

  @JsonProperty("PrivateRemarks")
  private String privateRemarks = null;

  @JsonProperty("ProfessionalManagementExpense")
  private AnyOforgResoMetadataPropertyUpdateProfessionalManagementExpense professionalManagementExpense = null;

  @JsonProperty("PropertyAttachedYN")
  private Boolean propertyAttachedYN = null;

  @JsonProperty("PropertyCondition")
  @Valid
  private List<OrgResoMetadataEnumsPropertyCondition> propertyCondition = null;

  @JsonProperty("PropertySubType")
  private AnyOforgResoMetadataPropertyUpdatePropertySubType propertySubType = null;

  @JsonProperty("PropertyType")
  private AnyOforgResoMetadataPropertyUpdatePropertyType propertyType = null;

  @JsonProperty("PublicRemarks")
  private String publicRemarks = null;

  @JsonProperty("PublicSurveyRange")
  private String publicSurveyRange = null;

  @JsonProperty("PublicSurveySection")
  private String publicSurveySection = null;

  @JsonProperty("PublicSurveyTownship")
  private String publicSurveyTownship = null;

  @JsonProperty("PurchaseContractDate")
  private LocalDate purchaseContractDate = null;

  @JsonProperty("RVParkingDimensions")
  private String rvParkingDimensions = null;

  @JsonProperty("RangeArea")
  private AnyOforgResoMetadataPropertyUpdateRangeArea rangeArea = null;

  @JsonProperty("RentControlYN")
  private Boolean rentControlYN = null;

  @JsonProperty("RentIncludes")
  @Valid
  private List<OrgResoMetadataEnumsRentIncludes> rentIncludes = null;

  @JsonProperty("RoadFrontageType")
  @Valid
  private List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType = null;

  @JsonProperty("RoadResponsibility")
  @Valid
  private List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility = null;

  @JsonProperty("RoadSurfaceType")
  @Valid
  private List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType = null;

  @JsonProperty("Roof")
  @Valid
  private List<OrgResoMetadataEnumsRoof> roof = null;

  @JsonProperty("RoomType")
  @Valid
  private List<OrgResoMetadataEnumsRoomType> roomType = null;

  @JsonProperty("RoomsTotal")
  private AnyOforgResoMetadataPropertyUpdateRoomsTotal roomsTotal = null;

  @JsonProperty("SeatingCapacity")
  private AnyOforgResoMetadataPropertyUpdateSeatingCapacity seatingCapacity = null;

  @JsonProperty("SecurityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures = null;

  @JsonProperty("SeniorCommunityYN")
  private Boolean seniorCommunityYN = null;

  @JsonProperty("SerialU")
  private String serialU = null;

  @JsonProperty("SerialX")
  private String serialX = null;

  @JsonProperty("SerialXX")
  private String serialXX = null;

  @JsonProperty("Sewer")
  @Valid
  private List<OrgResoMetadataEnumsSewer> sewer = null;

  @JsonProperty("ShowingAdvanceNotice")
  private AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice showingAdvanceNotice = null;

  @JsonProperty("ShowingAttendedYN")
  private Boolean showingAttendedYN = null;

  @JsonProperty("ShowingContactName")
  private String showingContactName = null;

  @JsonProperty("ShowingContactPhone")
  private String showingContactPhone = null;

  @JsonProperty("ShowingContactPhoneExt")
  private String showingContactPhoneExt = null;

  @JsonProperty("ShowingContactType")
  @Valid
  private List<OrgResoMetadataEnumsShowingContactType> showingContactType = null;

  @JsonProperty("ShowingDays")
  @Valid
  private List<OrgResoMetadataEnumsShowingDays> showingDays = null;

  @JsonProperty("ShowingEndTime")
  private OffsetDateTime showingEndTime = null;

  @JsonProperty("ShowingInstructions")
  private String showingInstructions = null;

  @JsonProperty("ShowingRequirements")
  @Valid
  private List<OrgResoMetadataEnumsShowingRequirements> showingRequirements = null;

  @JsonProperty("ShowingStartTime")
  private OffsetDateTime showingStartTime = null;

  @JsonProperty("SignOnPropertyYN")
  private Boolean signOnPropertyYN = null;

  @JsonProperty("Skirt")
  @Valid
  private List<OrgResoMetadataEnumsSkirt> skirt = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SpaFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSpaFeatures> spaFeatures = null;

  @JsonProperty("SpaYN")
  private Boolean spaYN = null;

  @JsonProperty("SpecialLicenses")
  @Valid
  private List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses = null;

  @JsonProperty("SpecialListingConditions")
  @Valid
  private List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions = null;

  @JsonProperty("StandardStatus")
  private AnyOforgResoMetadataPropertyUpdateStandardStatus standardStatus = null;

  @JsonProperty("StateOrProvince")
  private AnyOforgResoMetadataPropertyUpdateStateOrProvince stateOrProvince = null;

  @JsonProperty("StateRegion")
  private String stateRegion = null;

  @JsonProperty("StatusChangeTimestamp")
  private OffsetDateTime statusChangeTimestamp = null;

  @JsonProperty("Stories")
  private AnyOforgResoMetadataPropertyUpdateStories stories = null;

  @JsonProperty("StoriesTotal")
  private AnyOforgResoMetadataPropertyUpdateStoriesTotal storiesTotal = null;

  @JsonProperty("StreetAdditionalInfo")
  private String streetAdditionalInfo = null;

  @JsonProperty("StreetDirPrefix")
  private AnyOforgResoMetadataPropertyUpdateStreetDirPrefix streetDirPrefix = null;

  @JsonProperty("StreetDirSuffix")
  private AnyOforgResoMetadataPropertyUpdateStreetDirSuffix streetDirSuffix = null;

  @JsonProperty("StreetName")
  private String streetName = null;

  @JsonProperty("StreetNumber")
  private String streetNumber = null;

  @JsonProperty("StreetNumberNumeric")
  private AnyOforgResoMetadataPropertyUpdateStreetNumberNumeric streetNumberNumeric = null;

  @JsonProperty("StreetSuffix")
  private AnyOforgResoMetadataPropertyUpdateStreetSuffix streetSuffix = null;

  @JsonProperty("StreetSuffixModifier")
  private String streetSuffixModifier = null;

  @JsonProperty("StructureType")
  @Valid
  private List<OrgResoMetadataEnumsStructureType> structureType = null;

  @JsonProperty("SubAgencyCompensation")
  private String subAgencyCompensation = null;

  @JsonProperty("SubAgencyCompensationType")
  private AnyOforgResoMetadataPropertyUpdateSubAgencyCompensationType subAgencyCompensationType = null;

  @JsonProperty("SubdivisionName")
  private String subdivisionName = null;

  @JsonProperty("SuppliesExpense")
  private AnyOforgResoMetadataPropertyUpdateSuppliesExpense suppliesExpense = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  @JsonProperty("SyndicationRemarks")
  private String syndicationRemarks = null;

  @JsonProperty("TaxAnnualAmount")
  private AnyOforgResoMetadataPropertyUpdateTaxAnnualAmount taxAnnualAmount = null;

  @JsonProperty("TaxAssessedValue")
  private AnyOforgResoMetadataPropertyUpdateTaxAssessedValue taxAssessedValue = null;

  @JsonProperty("TaxBlock")
  private String taxBlock = null;

  @JsonProperty("TaxBookNumber")
  private String taxBookNumber = null;

  @JsonProperty("TaxLegalDescription")
  private String taxLegalDescription = null;

  @JsonProperty("TaxLot")
  private String taxLot = null;

  @JsonProperty("TaxMapNumber")
  private String taxMapNumber = null;

  @JsonProperty("TaxOtherAnnualAssessmentAmount")
  private AnyOforgResoMetadataPropertyUpdateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount = null;

  @JsonProperty("TaxParcelLetter")
  private String taxParcelLetter = null;

  @JsonProperty("TaxStatusCurrent")
  @Valid
  private List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent = null;

  @JsonProperty("TaxTract")
  private String taxTract = null;

  @JsonProperty("TaxYear")
  private AnyOforgResoMetadataPropertyUpdateTaxYear taxYear = null;

  @JsonProperty("TenantPays")
  @Valid
  private List<OrgResoMetadataEnumsTenantPays> tenantPays = null;

  @JsonProperty("Topography")
  private String topography = null;

  @JsonProperty("TotalActualRent")
  private AnyOforgResoMetadataPropertyUpdateTotalActualRent totalActualRent = null;

  @JsonProperty("Township")
  private String township = null;

  @JsonProperty("TransactionBrokerCompensation")
  private String transactionBrokerCompensation = null;

  @JsonProperty("TransactionBrokerCompensationType")
  private AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType transactionBrokerCompensationType = null;

  @JsonProperty("TrashExpense")
  private AnyOforgResoMetadataPropertyUpdateTrashExpense trashExpense = null;

  @JsonProperty("UnitNumber")
  private String unitNumber = null;

  @JsonProperty("UnitTypeType")
  @Valid
  private List<OrgResoMetadataEnumsUnitTypeType> unitTypeType = null;

  @JsonProperty("UnitsFurnished")
  private AnyOforgResoMetadataPropertyUpdateUnitsFurnished unitsFurnished = null;

  @JsonProperty("UniversalPropertyId")
  private String universalPropertyId = null;

  @JsonProperty("UniversalPropertySubId")
  private String universalPropertySubId = null;

  @JsonProperty("UnparsedAddress")
  private String unparsedAddress = null;

  @JsonProperty("Utilities")
  @Valid
  private List<OrgResoMetadataEnumsUtilities> utilities = null;

  @JsonProperty("VacancyAllowance")
  private AnyOforgResoMetadataPropertyUpdateVacancyAllowance vacancyAllowance = null;

  @JsonProperty("VacancyAllowanceRate")
  private AnyOforgResoMetadataPropertyUpdateVacancyAllowanceRate vacancyAllowanceRate = null;

  @JsonProperty("Vegetation")
  @Valid
  private List<OrgResoMetadataEnumsVegetation> vegetation = null;

  @JsonProperty("VideosChangeTimestamp")
  private OffsetDateTime videosChangeTimestamp = null;

  @JsonProperty("VideosCount")
  private AnyOforgResoMetadataPropertyUpdateVideosCount videosCount = null;

  @JsonProperty("View")
  @Valid
  private List<OrgResoMetadataEnumsView> view = null;

  @JsonProperty("ViewYN")
  private Boolean viewYN = null;

  @JsonProperty("VirtualTourURLBranded")
  private String virtualTourURLBranded = null;

  @JsonProperty("VirtualTourURLUnbranded")
  private String virtualTourURLUnbranded = null;

  @JsonProperty("WalkScore")
  private AnyOforgResoMetadataPropertyUpdateWalkScore walkScore = null;

  @JsonProperty("WaterBodyName")
  private String waterBodyName = null;

  @JsonProperty("WaterSewerExpense")
  private AnyOforgResoMetadataPropertyUpdateWaterSewerExpense waterSewerExpense = null;

  @JsonProperty("WaterSource")
  @Valid
  private List<OrgResoMetadataEnumsWaterSource> waterSource = null;

  @JsonProperty("WaterfrontFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures = null;

  @JsonProperty("WaterfrontYN")
  private Boolean waterfrontYN = null;

  @JsonProperty("WindowFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWindowFeatures> windowFeatures = null;

  @JsonProperty("WithdrawnDate")
  private LocalDate withdrawnDate = null;

  @JsonProperty("WoodedArea")
  private AnyOforgResoMetadataPropertyUpdateWoodedArea woodedArea = null;

  @JsonProperty("WorkmansCompensationExpense")
  private AnyOforgResoMetadataPropertyUpdateWorkmansCompensationExpense workmansCompensationExpense = null;

  @JsonProperty("YearBuilt")
  private AnyOforgResoMetadataPropertyUpdateYearBuilt yearBuilt = null;

  @JsonProperty("YearBuiltDetails")
  private String yearBuiltDetails = null;

  @JsonProperty("YearBuiltEffective")
  private AnyOforgResoMetadataPropertyUpdateYearBuiltEffective yearBuiltEffective = null;

  @JsonProperty("YearBuiltSource")
  private AnyOforgResoMetadataPropertyUpdateYearBuiltSource yearBuiltSource = null;

  @JsonProperty("YearEstablished")
  private AnyOforgResoMetadataPropertyUpdateYearEstablished yearEstablished = null;

  @JsonProperty("YearsCurrentOwner")
  private AnyOforgResoMetadataPropertyUpdateYearsCurrentOwner yearsCurrentOwner = null;

  @JsonProperty("Zoning")
  private String zoning = null;

  @JsonProperty("ZoningDescription")
  private String zoningDescription = null;

  public OrgResoMetadataPropertyUpdate aboveGradeFinishedArea(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
    return this;
  }

  /**
   * Get aboveGradeFinishedArea
   * @return aboveGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedArea getAboveGradeFinishedArea() {
    return aboveGradeFinishedArea;
  }

  public void setAboveGradeFinishedArea(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
  }

  public OrgResoMetadataPropertyUpdate aboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaSource
   * @return aboveGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource getAboveGradeFinishedAreaSource() {
    return aboveGradeFinishedAreaSource;
  }

  public void setAboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
  }

  public OrgResoMetadataPropertyUpdate aboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaUnits
   * @return aboveGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaUnits getAboveGradeFinishedAreaUnits() {
    return aboveGradeFinishedAreaUnits;
  }

  public void setAboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate accessCode(String accessCode) {
    this.accessCode = accessCode;
    return this;
  }

  /**
   * Get accessCode
   * @return accessCode
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getAccessCode() {
    return accessCode;
  }

  public void setAccessCode(String accessCode) {
    this.accessCode = accessCode;
  }

  public OrgResoMetadataPropertyUpdate accessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addAccessibilityFeaturesItem(OrgResoMetadataEnumsAccessibilityFeatures accessibilityFeaturesItem) {
    if (this.accessibilityFeatures == null) {
      this.accessibilityFeatures = new ArrayList<OrgResoMetadataEnumsAccessibilityFeatures>();
    }
    this.accessibilityFeatures.add(accessibilityFeaturesItem);
    return this;
  }

  /**
   * Get accessibilityFeatures
   * @return accessibilityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAccessibilityFeatures> getAccessibilityFeatures() {
    return accessibilityFeatures;
  }

  public void setAccessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
  }

  public OrgResoMetadataPropertyUpdate additionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
    return this;
  }

  /**
   * Get additionalParcelsDescription
   * @return additionalParcelsDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getAdditionalParcelsDescription() {
    return additionalParcelsDescription;
  }

  public void setAdditionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
  }

  public OrgResoMetadataPropertyUpdate additionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
    return this;
  }

  /**
   * Get additionalParcelsYN
   * @return additionalParcelsYN
   **/
  @Schema(description = "")
  
    public Boolean isAdditionalParcelsYN() {
    return additionalParcelsYN;
  }

  public void setAdditionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
  }

  public OrgResoMetadataPropertyUpdate anchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
    return this;
  }

  /**
   * Get anchorsCoTenants
   * @return anchorsCoTenants
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getAnchorsCoTenants() {
    return anchorsCoTenants;
  }

  public void setAnchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
  }

  public OrgResoMetadataPropertyUpdate appliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addAppliancesItem(OrgResoMetadataEnumsAppliances appliancesItem) {
    if (this.appliances == null) {
      this.appliances = new ArrayList<OrgResoMetadataEnumsAppliances>();
    }
    this.appliances.add(appliancesItem);
    return this;
  }

  /**
   * Get appliances
   * @return appliances
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAppliances> getAppliances() {
    return appliances;
  }

  public void setAppliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
  }

  public OrgResoMetadataPropertyUpdate architecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addArchitecturalStyleItem(OrgResoMetadataEnumsArchitecturalStyle architecturalStyleItem) {
    if (this.architecturalStyle == null) {
      this.architecturalStyle = new ArrayList<OrgResoMetadataEnumsArchitecturalStyle>();
    }
    this.architecturalStyle.add(architecturalStyleItem);
    return this;
  }

  /**
   * Get architecturalStyle
   * @return architecturalStyle
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsArchitecturalStyle> getArchitecturalStyle() {
    return architecturalStyle;
  }

  public void setArchitecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
  }

  public OrgResoMetadataPropertyUpdate associationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addAssociationAmenitiesItem(OrgResoMetadataEnumsAssociationAmenities associationAmenitiesItem) {
    if (this.associationAmenities == null) {
      this.associationAmenities = new ArrayList<OrgResoMetadataEnumsAssociationAmenities>();
    }
    this.associationAmenities.add(associationAmenitiesItem);
    return this;
  }

  /**
   * Get associationAmenities
   * @return associationAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationAmenities> getAssociationAmenities() {
    return associationAmenities;
  }

  public void setAssociationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
  }

  public OrgResoMetadataPropertyUpdate associationFee(AnyOforgResoMetadataPropertyUpdateAssociationFee associationFee) {
    this.associationFee = associationFee;
    return this;
  }

  /**
   * Get associationFee
   * @return associationFee
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAssociationFee getAssociationFee() {
    return associationFee;
  }

  public void setAssociationFee(AnyOforgResoMetadataPropertyUpdateAssociationFee associationFee) {
    this.associationFee = associationFee;
  }

  public OrgResoMetadataPropertyUpdate associationFee2(AnyOforgResoMetadataPropertyUpdateAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
    return this;
  }

  /**
   * Get associationFee2
   * @return associationFee2
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAssociationFee2 getAssociationFee2() {
    return associationFee2;
  }

  public void setAssociationFee2(AnyOforgResoMetadataPropertyUpdateAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
  }

  public OrgResoMetadataPropertyUpdate associationFee2Frequency(AnyOforgResoMetadataPropertyUpdateAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
    return this;
  }

  /**
   * Get associationFee2Frequency
   * @return associationFee2Frequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAssociationFee2Frequency getAssociationFee2Frequency() {
    return associationFee2Frequency;
  }

  public void setAssociationFee2Frequency(AnyOforgResoMetadataPropertyUpdateAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
  }

  public OrgResoMetadataPropertyUpdate associationFeeFrequency(AnyOforgResoMetadataPropertyUpdateAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
    return this;
  }

  /**
   * Get associationFeeFrequency
   * @return associationFeeFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateAssociationFeeFrequency getAssociationFeeFrequency() {
    return associationFeeFrequency;
  }

  public void setAssociationFeeFrequency(AnyOforgResoMetadataPropertyUpdateAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
  }

  public OrgResoMetadataPropertyUpdate associationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addAssociationFeeIncludesItem(OrgResoMetadataEnumsAssociationFeeIncludes associationFeeIncludesItem) {
    if (this.associationFeeIncludes == null) {
      this.associationFeeIncludes = new ArrayList<OrgResoMetadataEnumsAssociationFeeIncludes>();
    }
    this.associationFeeIncludes.add(associationFeeIncludesItem);
    return this;
  }

  /**
   * Get associationFeeIncludes
   * @return associationFeeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationFeeIncludes> getAssociationFeeIncludes() {
    return associationFeeIncludes;
  }

  public void setAssociationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
  }

  public OrgResoMetadataPropertyUpdate associationName(String associationName) {
    this.associationName = associationName;
    return this;
  }

  /**
   * Get associationName
   * @return associationName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName() {
    return associationName;
  }

  public void setAssociationName(String associationName) {
    this.associationName = associationName;
  }

  public OrgResoMetadataPropertyUpdate associationName2(String associationName2) {
    this.associationName2 = associationName2;
    return this;
  }

  /**
   * Get associationName2
   * @return associationName2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName2() {
    return associationName2;
  }

  public void setAssociationName2(String associationName2) {
    this.associationName2 = associationName2;
  }

  public OrgResoMetadataPropertyUpdate associationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
    return this;
  }

  /**
   * Get associationPhone
   * @return associationPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone() {
    return associationPhone;
  }

  public void setAssociationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
  }

  public OrgResoMetadataPropertyUpdate associationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
    return this;
  }

  /**
   * Get associationPhone2
   * @return associationPhone2
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone2() {
    return associationPhone2;
  }

  public void setAssociationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
  }

  public OrgResoMetadataPropertyUpdate associationYN(Boolean associationYN) {
    this.associationYN = associationYN;
    return this;
  }

  /**
   * Get associationYN
   * @return associationYN
   **/
  @Schema(description = "")
  
    public Boolean isAssociationYN() {
    return associationYN;
  }

  public void setAssociationYN(Boolean associationYN) {
    this.associationYN = associationYN;
  }

  public OrgResoMetadataPropertyUpdate attachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
    return this;
  }

  /**
   * Get attachedGarageYN
   * @return attachedGarageYN
   **/
  @Schema(description = "")
  
    public Boolean isAttachedGarageYN() {
    return attachedGarageYN;
  }

  public void setAttachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
  }

  public OrgResoMetadataPropertyUpdate availabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
    return this;
  }

  /**
   * Get availabilityDate
   * @return availabilityDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getAvailabilityDate() {
    return availabilityDate;
  }

  public void setAvailabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
  }

  public OrgResoMetadataPropertyUpdate basement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBasementItem(OrgResoMetadataEnumsBasement basementItem) {
    if (this.basement == null) {
      this.basement = new ArrayList<OrgResoMetadataEnumsBasement>();
    }
    this.basement.add(basementItem);
    return this;
  }

  /**
   * Get basement
   * @return basement
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBasement> getBasement() {
    return basement;
  }

  public void setBasement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
  }

  public OrgResoMetadataPropertyUpdate basementYN(Boolean basementYN) {
    this.basementYN = basementYN;
    return this;
  }

  /**
   * Get basementYN
   * @return basementYN
   **/
  @Schema(description = "")
  
    public Boolean isBasementYN() {
    return basementYN;
  }

  public void setBasementYN(Boolean basementYN) {
    this.basementYN = basementYN;
  }

  public OrgResoMetadataPropertyUpdate bathroomsFull(AnyOforgResoMetadataPropertyUpdateBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
    return this;
  }

  /**
   * Get bathroomsFull
   * @return bathroomsFull
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsFull getBathroomsFull() {
    return bathroomsFull;
  }

  public void setBathroomsFull(AnyOforgResoMetadataPropertyUpdateBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
  }

  public OrgResoMetadataPropertyUpdate bathroomsHalf(AnyOforgResoMetadataPropertyUpdateBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
    return this;
  }

  /**
   * Get bathroomsHalf
   * @return bathroomsHalf
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsHalf getBathroomsHalf() {
    return bathroomsHalf;
  }

  public void setBathroomsHalf(AnyOforgResoMetadataPropertyUpdateBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
  }

  public OrgResoMetadataPropertyUpdate bathroomsOneQuarter(AnyOforgResoMetadataPropertyUpdateBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
    return this;
  }

  /**
   * Get bathroomsOneQuarter
   * @return bathroomsOneQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsOneQuarter getBathroomsOneQuarter() {
    return bathroomsOneQuarter;
  }

  public void setBathroomsOneQuarter(AnyOforgResoMetadataPropertyUpdateBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
  }

  public OrgResoMetadataPropertyUpdate bathroomsPartial(AnyOforgResoMetadataPropertyUpdateBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
    return this;
  }

  /**
   * Get bathroomsPartial
   * @return bathroomsPartial
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsPartial getBathroomsPartial() {
    return bathroomsPartial;
  }

  public void setBathroomsPartial(AnyOforgResoMetadataPropertyUpdateBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
  }

  public OrgResoMetadataPropertyUpdate bathroomsThreeQuarter(AnyOforgResoMetadataPropertyUpdateBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
    return this;
  }

  /**
   * Get bathroomsThreeQuarter
   * @return bathroomsThreeQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsThreeQuarter getBathroomsThreeQuarter() {
    return bathroomsThreeQuarter;
  }

  public void setBathroomsThreeQuarter(AnyOforgResoMetadataPropertyUpdateBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
  }

  public OrgResoMetadataPropertyUpdate bathroomsTotalInteger(AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
    return this;
  }

  /**
   * Get bathroomsTotalInteger
   * @return bathroomsTotalInteger
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger getBathroomsTotalInteger() {
    return bathroomsTotalInteger;
  }

  public void setBathroomsTotalInteger(AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
  }

  public OrgResoMetadataPropertyUpdate bedroomsPossible(AnyOforgResoMetadataPropertyUpdateBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
    return this;
  }

  /**
   * Get bedroomsPossible
   * @return bedroomsPossible
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBedroomsPossible getBedroomsPossible() {
    return bedroomsPossible;
  }

  public void setBedroomsPossible(AnyOforgResoMetadataPropertyUpdateBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
  }

  public OrgResoMetadataPropertyUpdate bedroomsTotal(AnyOforgResoMetadataPropertyUpdateBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
    return this;
  }

  /**
   * Get bedroomsTotal
   * @return bedroomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBedroomsTotal getBedroomsTotal() {
    return bedroomsTotal;
  }

  public void setBedroomsTotal(AnyOforgResoMetadataPropertyUpdateBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
  }

  public OrgResoMetadataPropertyUpdate belowGradeFinishedArea(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
    return this;
  }

  /**
   * Get belowGradeFinishedArea
   * @return belowGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedArea getBelowGradeFinishedArea() {
    return belowGradeFinishedArea;
  }

  public void setBelowGradeFinishedArea(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
  }

  public OrgResoMetadataPropertyUpdate belowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaSource
   * @return belowGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource getBelowGradeFinishedAreaSource() {
    return belowGradeFinishedAreaSource;
  }

  public void setBelowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
  }

  public OrgResoMetadataPropertyUpdate belowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaUnits
   * @return belowGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaUnits getBelowGradeFinishedAreaUnits() {
    return belowGradeFinishedAreaUnits;
  }

  public void setBelowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate bodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBodyTypeItem(OrgResoMetadataEnumsBodyType bodyTypeItem) {
    if (this.bodyType == null) {
      this.bodyType = new ArrayList<OrgResoMetadataEnumsBodyType>();
    }
    this.bodyType.add(bodyTypeItem);
    return this;
  }

  /**
   * Get bodyType
   * @return bodyType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBodyType> getBodyType() {
    return bodyType;
  }

  public void setBodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
  }

  public OrgResoMetadataPropertyUpdate builderModel(String builderModel) {
    this.builderModel = builderModel;
    return this;
  }

  /**
   * Get builderModel
   * @return builderModel
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderModel() {
    return builderModel;
  }

  public void setBuilderModel(String builderModel) {
    this.builderModel = builderModel;
  }

  public OrgResoMetadataPropertyUpdate builderName(String builderName) {
    this.builderName = builderName;
    return this;
  }

  /**
   * Get builderName
   * @return builderName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderName() {
    return builderName;
  }

  public void setBuilderName(String builderName) {
    this.builderName = builderName;
  }

  public OrgResoMetadataPropertyUpdate buildingAreaSource(AnyOforgResoMetadataPropertyUpdateBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
    return this;
  }

  /**
   * Get buildingAreaSource
   * @return buildingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuildingAreaSource getBuildingAreaSource() {
    return buildingAreaSource;
  }

  public void setBuildingAreaSource(AnyOforgResoMetadataPropertyUpdateBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
  }

  public OrgResoMetadataPropertyUpdate buildingAreaTotal(AnyOforgResoMetadataPropertyUpdateBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
    return this;
  }

  /**
   * Get buildingAreaTotal
   * @return buildingAreaTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuildingAreaTotal getBuildingAreaTotal() {
    return buildingAreaTotal;
  }

  public void setBuildingAreaTotal(AnyOforgResoMetadataPropertyUpdateBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
  }

  public OrgResoMetadataPropertyUpdate buildingAreaUnits(AnyOforgResoMetadataPropertyUpdateBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
    return this;
  }

  /**
   * Get buildingAreaUnits
   * @return buildingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuildingAreaUnits getBuildingAreaUnits() {
    return buildingAreaUnits;
  }

  public void setBuildingAreaUnits(AnyOforgResoMetadataPropertyUpdateBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate buildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBuildingFeaturesItem(OrgResoMetadataEnumsBuildingFeatures buildingFeaturesItem) {
    if (this.buildingFeatures == null) {
      this.buildingFeatures = new ArrayList<OrgResoMetadataEnumsBuildingFeatures>();
    }
    this.buildingFeatures.add(buildingFeaturesItem);
    return this;
  }

  /**
   * Get buildingFeatures
   * @return buildingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuildingFeatures> getBuildingFeatures() {
    return buildingFeatures;
  }

  public void setBuildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
  }

  public OrgResoMetadataPropertyUpdate buildingName(String buildingName) {
    this.buildingName = buildingName;
    return this;
  }

  /**
   * Get buildingName
   * @return buildingName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuildingName() {
    return buildingName;
  }

  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  public OrgResoMetadataPropertyUpdate businessName(String businessName) {
    this.businessName = businessName;
    return this;
  }

  /**
   * Get businessName
   * @return businessName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBusinessName() {
    return businessName;
  }

  public void setBusinessName(String businessName) {
    this.businessName = businessName;
  }

  public OrgResoMetadataPropertyUpdate businessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBusinessTypeItem(OrgResoMetadataEnumsBusinessType businessTypeItem) {
    if (this.businessType == null) {
      this.businessType = new ArrayList<OrgResoMetadataEnumsBusinessType>();
    }
    this.businessType.add(businessTypeItem);
    return this;
  }

  /**
   * Get businessType
   * @return businessType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBusinessType> getBusinessType() {
    return businessType;
  }

  public void setBusinessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
  }

  public OrgResoMetadataPropertyUpdate buyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
    return this;
  }

  /**
   * Get buyerAgencyCompensation
   * @return buyerAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgencyCompensation() {
    return buyerAgencyCompensation;
  }

  public void setBuyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
  }

  public OrgResoMetadataPropertyUpdate buyerAgencyCompensationType(AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
    return this;
  }

  /**
   * Get buyerAgencyCompensationType
   * @return buyerAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType getBuyerAgencyCompensationType() {
    return buyerAgencyCompensationType;
  }

  public void setBuyerAgencyCompensationType(AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentAOR(AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
    return this;
  }

  /**
   * Get buyerAgentAOR
   * @return buyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR getBuyerAgentAOR() {
    return buyerAgentAOR;
  }

  public void setBuyerAgentAOR(AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBuyerAgentDesignationItem(OrgResoMetadataEnumsBuyerAgentDesignation buyerAgentDesignationItem) {
    if (this.buyerAgentDesignation == null) {
      this.buyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsBuyerAgentDesignation>();
    }
    this.buyerAgentDesignation.add(buyerAgentDesignationItem);
    return this;
  }

  /**
   * Get buyerAgentDesignation
   * @return buyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerAgentDesignation> getBuyerAgentDesignation() {
    return buyerAgentDesignation;
  }

  public void setBuyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
    return this;
  }

  /**
   * Get buyerAgentDirectPhone
   * @return buyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentDirectPhone() {
    return buyerAgentDirectPhone;
  }

  public void setBuyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
    return this;
  }

  /**
   * Get buyerAgentEmail
   * @return buyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerAgentEmail() {
    return buyerAgentEmail;
  }

  public void setBuyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
    return this;
  }

  /**
   * Get buyerAgentFax
   * @return buyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentFax() {
    return buyerAgentFax;
  }

  public void setBuyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
    return this;
  }

  /**
   * Get buyerAgentFirstName
   * @return buyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentFirstName() {
    return buyerAgentFirstName;
  }

  public void setBuyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
    return this;
  }

  /**
   * Get buyerAgentFullName
   * @return buyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getBuyerAgentFullName() {
    return buyerAgentFullName;
  }

  public void setBuyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
    return this;
  }

  /**
   * Get buyerAgentHomePhone
   * @return buyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentHomePhone() {
    return buyerAgentHomePhone;
  }

  public void setBuyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
    return this;
  }

  /**
   * Get buyerAgentKey
   * @return buyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerAgentKey() {
    return buyerAgentKey;
  }

  public void setBuyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get buyerAgentKeyNumeric
   * @return buyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric getBuyerAgentKeyNumeric() {
    return buyerAgentKeyNumeric;
  }

  public void setBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
    return this;
  }

  /**
   * Get buyerAgentLastName
   * @return buyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentLastName() {
    return buyerAgentLastName;
  }

  public void setBuyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
    return this;
  }

  /**
   * Get buyerAgentMiddleName
   * @return buyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentMiddleName() {
    return buyerAgentMiddleName;
  }

  public void setBuyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
    return this;
  }

  /**
   * Get buyerAgentMlsId
   * @return buyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgentMlsId() {
    return buyerAgentMlsId;
  }

  public void setBuyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
    return this;
  }

  /**
   * Get buyerAgentMobilePhone
   * @return buyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentMobilePhone() {
    return buyerAgentMobilePhone;
  }

  public void setBuyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
    return this;
  }

  /**
   * Get buyerAgentNamePrefix
   * @return buyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNamePrefix() {
    return buyerAgentNamePrefix;
  }

  public void setBuyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
    return this;
  }

  /**
   * Get buyerAgentNameSuffix
   * @return buyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNameSuffix() {
    return buyerAgentNameSuffix;
  }

  public void setBuyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
    return this;
  }

  /**
   * Get buyerAgentOfficePhone
   * @return buyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentOfficePhone() {
    return buyerAgentOfficePhone;
  }

  public void setBuyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerAgentOfficePhoneExt
   * @return buyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentOfficePhoneExt() {
    return buyerAgentOfficePhoneExt;
  }

  public void setBuyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
    return this;
  }

  /**
   * Get buyerAgentPager
   * @return buyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPager() {
    return buyerAgentPager;
  }

  public void setBuyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhone
   * @return buyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPreferredPhone() {
    return buyerAgentPreferredPhone;
  }

  public void setBuyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhoneExt
   * @return buyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentPreferredPhoneExt() {
    return buyerAgentPreferredPhoneExt;
  }

  public void setBuyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
    return this;
  }

  /**
   * Get buyerAgentStateLicense
   * @return buyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentStateLicense() {
    return buyerAgentStateLicense;
  }

  public void setBuyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get buyerAgentTollFreePhone
   * @return buyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentTollFreePhone() {
    return buyerAgentTollFreePhone;
  }

  public void setBuyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
    return this;
  }

  /**
   * Get buyerAgentURL
   * @return buyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerAgentURL() {
    return buyerAgentURL;
  }

  public void setBuyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
    return this;
  }

  /**
   * Get buyerAgentVoiceMail
   * @return buyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentVoiceMail() {
    return buyerAgentVoiceMail;
  }

  public void setBuyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
  }

  public OrgResoMetadataPropertyUpdate buyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get buyerAgentVoiceMailExt
   * @return buyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentVoiceMailExt() {
    return buyerAgentVoiceMailExt;
  }

  public void setBuyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyUpdate buyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addBuyerFinancingItem(OrgResoMetadataEnumsBuyerFinancing buyerFinancingItem) {
    if (this.buyerFinancing == null) {
      this.buyerFinancing = new ArrayList<OrgResoMetadataEnumsBuyerFinancing>();
    }
    this.buyerFinancing.add(buyerFinancingItem);
    return this;
  }

  /**
   * Get buyerFinancing
   * @return buyerFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerFinancing> getBuyerFinancing() {
    return buyerFinancing;
  }

  public void setBuyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeAOR(AnyOforgResoMetadataPropertyUpdateBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
    return this;
  }

  /**
   * Get buyerOfficeAOR
   * @return buyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerOfficeAOR getBuyerOfficeAOR() {
    return buyerOfficeAOR;
  }

  public void setBuyerOfficeAOR(AnyOforgResoMetadataPropertyUpdateBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
    return this;
  }

  /**
   * Get buyerOfficeEmail
   * @return buyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerOfficeEmail() {
    return buyerOfficeEmail;
  }

  public void setBuyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
    return this;
  }

  /**
   * Get buyerOfficeFax
   * @return buyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficeFax() {
    return buyerOfficeFax;
  }

  public void setBuyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
    return this;
  }

  /**
   * Get buyerOfficeKey
   * @return buyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeKey() {
    return buyerOfficeKey;
  }

  public void setBuyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get buyerOfficeKeyNumeric
   * @return buyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerOfficeKeyNumeric getBuyerOfficeKeyNumeric() {
    return buyerOfficeKeyNumeric;
  }

  public void setBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
    return this;
  }

  /**
   * Get buyerOfficeMlsId
   * @return buyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerOfficeMlsId() {
    return buyerOfficeMlsId;
  }

  public void setBuyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
    return this;
  }

  /**
   * Get buyerOfficeName
   * @return buyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeName() {
    return buyerOfficeName;
  }

  public void setBuyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
    return this;
  }

  /**
   * Get buyerOfficePhone
   * @return buyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficePhone() {
    return buyerOfficePhone;
  }

  public void setBuyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerOfficePhoneExt
   * @return buyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerOfficePhoneExt() {
    return buyerOfficePhoneExt;
  }

  public void setBuyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate buyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
    return this;
  }

  /**
   * Get buyerOfficeURL
   * @return buyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerOfficeURL() {
    return buyerOfficeURL;
  }

  public void setBuyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
  }

  public OrgResoMetadataPropertyUpdate buyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
    return this;
  }

  /**
   * Get buyerTeamKey
   * @return buyerTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerTeamKey() {
    return buyerTeamKey;
  }

  public void setBuyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
  }

  public OrgResoMetadataPropertyUpdate buyerTeamKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
    return this;
  }

  /**
   * Get buyerTeamKeyNumeric
   * @return buyerTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric getBuyerTeamKeyNumeric() {
    return buyerTeamKeyNumeric;
  }

  public void setBuyerTeamKeyNumeric(AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate buyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
    return this;
  }

  /**
   * Get buyerTeamName
   * @return buyerTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerTeamName() {
    return buyerTeamName;
  }

  public void setBuyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
  }

  public OrgResoMetadataPropertyUpdate cableTvExpense(AnyOforgResoMetadataPropertyUpdateCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
    return this;
  }

  /**
   * Get cableTvExpense
   * @return cableTvExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCableTvExpense getCableTvExpense() {
    return cableTvExpense;
  }

  public void setCableTvExpense(AnyOforgResoMetadataPropertyUpdateCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
  }

  public OrgResoMetadataPropertyUpdate cancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
    return this;
  }

  /**
   * Get cancellationDate
   * @return cancellationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCancellationDate() {
    return cancellationDate;
  }

  public void setCancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
  }

  public OrgResoMetadataPropertyUpdate capRate(AnyOforgResoMetadataPropertyUpdateCapRate capRate) {
    this.capRate = capRate;
    return this;
  }

  /**
   * Get capRate
   * @return capRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCapRate getCapRate() {
    return capRate;
  }

  public void setCapRate(AnyOforgResoMetadataPropertyUpdateCapRate capRate) {
    this.capRate = capRate;
  }

  public OrgResoMetadataPropertyUpdate carportSpaces(AnyOforgResoMetadataPropertyUpdateCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
    return this;
  }

  /**
   * Get carportSpaces
   * @return carportSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCarportSpaces getCarportSpaces() {
    return carportSpaces;
  }

  public void setCarportSpaces(AnyOforgResoMetadataPropertyUpdateCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
  }

  public OrgResoMetadataPropertyUpdate carportYN(Boolean carportYN) {
    this.carportYN = carportYN;
    return this;
  }

  /**
   * Get carportYN
   * @return carportYN
   **/
  @Schema(description = "")
  
    public Boolean isCarportYN() {
    return carportYN;
  }

  public void setCarportYN(Boolean carportYN) {
    this.carportYN = carportYN;
  }

  public OrgResoMetadataPropertyUpdate carrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
    return this;
  }

  /**
   * Get carrierRoute
   * @return carrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getCarrierRoute() {
    return carrierRoute;
  }

  public void setCarrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
  }

  public OrgResoMetadataPropertyUpdate city(AnyOforgResoMetadataPropertyUpdateCity city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCity getCity() {
    return city;
  }

  public void setCity(AnyOforgResoMetadataPropertyUpdateCity city) {
    this.city = city;
  }

  public OrgResoMetadataPropertyUpdate cityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
    return this;
  }

  /**
   * Get cityRegion
   * @return cityRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCityRegion() {
    return cityRegion;
  }

  public void setCityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
  }

  public OrgResoMetadataPropertyUpdate closeDate(LocalDate closeDate) {
    this.closeDate = closeDate;
    return this;
  }

  /**
   * Get closeDate
   * @return closeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(LocalDate closeDate) {
    this.closeDate = closeDate;
  }

  public OrgResoMetadataPropertyUpdate closePrice(AnyOforgResoMetadataPropertyUpdateClosePrice closePrice) {
    this.closePrice = closePrice;
    return this;
  }

  /**
   * Get closePrice
   * @return closePrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateClosePrice getClosePrice() {
    return closePrice;
  }

  public void setClosePrice(AnyOforgResoMetadataPropertyUpdateClosePrice closePrice) {
    this.closePrice = closePrice;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentAOR(AnyOforgResoMetadataPropertyUpdateCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
    return this;
  }

  /**
   * Get coBuyerAgentAOR
   * @return coBuyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoBuyerAgentAOR getCoBuyerAgentAOR() {
    return coBuyerAgentAOR;
  }

  public void setCoBuyerAgentAOR(AnyOforgResoMetadataPropertyUpdateCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCoBuyerAgentDesignationItem(OrgResoMetadataEnumsCoBuyerAgentDesignation coBuyerAgentDesignationItem) {
    if (this.coBuyerAgentDesignation == null) {
      this.coBuyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoBuyerAgentDesignation>();
    }
    this.coBuyerAgentDesignation.add(coBuyerAgentDesignationItem);
    return this;
  }

  /**
   * Get coBuyerAgentDesignation
   * @return coBuyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoBuyerAgentDesignation> getCoBuyerAgentDesignation() {
    return coBuyerAgentDesignation;
  }

  public void setCoBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
    return this;
  }

  /**
   * Get coBuyerAgentDirectPhone
   * @return coBuyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentDirectPhone() {
    return coBuyerAgentDirectPhone;
  }

  public void setCoBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
    return this;
  }

  /**
   * Get coBuyerAgentEmail
   * @return coBuyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerAgentEmail() {
    return coBuyerAgentEmail;
  }

  public void setCoBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
    return this;
  }

  /**
   * Get coBuyerAgentFax
   * @return coBuyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentFax() {
    return coBuyerAgentFax;
  }

  public void setCoBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
    return this;
  }

  /**
   * Get coBuyerAgentFirstName
   * @return coBuyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentFirstName() {
    return coBuyerAgentFirstName;
  }

  public void setCoBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
    return this;
  }

  /**
   * Get coBuyerAgentFullName
   * @return coBuyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoBuyerAgentFullName() {
    return coBuyerAgentFullName;
  }

  public void setCoBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
    return this;
  }

  /**
   * Get coBuyerAgentHomePhone
   * @return coBuyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentHomePhone() {
    return coBuyerAgentHomePhone;
  }

  public void setCoBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
    return this;
  }

  /**
   * Get coBuyerAgentKey
   * @return coBuyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerAgentKey() {
    return coBuyerAgentKey;
  }

  public void setCoBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerAgentKeyNumeric
   * @return coBuyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoBuyerAgentKeyNumeric getCoBuyerAgentKeyNumeric() {
    return coBuyerAgentKeyNumeric;
  }

  public void setCoBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
    return this;
  }

  /**
   * Get coBuyerAgentLastName
   * @return coBuyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentLastName() {
    return coBuyerAgentLastName;
  }

  public void setCoBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
    return this;
  }

  /**
   * Get coBuyerAgentMiddleName
   * @return coBuyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentMiddleName() {
    return coBuyerAgentMiddleName;
  }

  public void setCoBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
    return this;
  }

  /**
   * Get coBuyerAgentMlsId
   * @return coBuyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerAgentMlsId() {
    return coBuyerAgentMlsId;
  }

  public void setCoBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
    return this;
  }

  /**
   * Get coBuyerAgentMobilePhone
   * @return coBuyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentMobilePhone() {
    return coBuyerAgentMobilePhone;
  }

  public void setCoBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
    return this;
  }

  /**
   * Get coBuyerAgentNamePrefix
   * @return coBuyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNamePrefix() {
    return coBuyerAgentNamePrefix;
  }

  public void setCoBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
    return this;
  }

  /**
   * Get coBuyerAgentNameSuffix
   * @return coBuyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNameSuffix() {
    return coBuyerAgentNameSuffix;
  }

  public void setCoBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhone
   * @return coBuyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentOfficePhone() {
    return coBuyerAgentOfficePhone;
  }

  public void setCoBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhoneExt
   * @return coBuyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentOfficePhoneExt() {
    return coBuyerAgentOfficePhoneExt;
  }

  public void setCoBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
    return this;
  }

  /**
   * Get coBuyerAgentPager
   * @return coBuyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPager() {
    return coBuyerAgentPager;
  }

  public void setCoBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhone
   * @return coBuyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPreferredPhone() {
    return coBuyerAgentPreferredPhone;
  }

  public void setCoBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhoneExt
   * @return coBuyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentPreferredPhoneExt() {
    return coBuyerAgentPreferredPhoneExt;
  }

  public void setCoBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
    return this;
  }

  /**
   * Get coBuyerAgentStateLicense
   * @return coBuyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentStateLicense() {
    return coBuyerAgentStateLicense;
  }

  public void setCoBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get coBuyerAgentTollFreePhone
   * @return coBuyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentTollFreePhone() {
    return coBuyerAgentTollFreePhone;
  }

  public void setCoBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
    return this;
  }

  /**
   * Get coBuyerAgentURL
   * @return coBuyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerAgentURL() {
    return coBuyerAgentURL;
  }

  public void setCoBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMail
   * @return coBuyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentVoiceMail() {
    return coBuyerAgentVoiceMail;
  }

  public void setCoBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
  }

  public OrgResoMetadataPropertyUpdate coBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMailExt
   * @return coBuyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentVoiceMailExt() {
    return coBuyerAgentVoiceMailExt;
  }

  public void setCoBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeAOR(AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
    return this;
  }

  /**
   * Get coBuyerOfficeAOR
   * @return coBuyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeAOR getCoBuyerOfficeAOR() {
    return coBuyerOfficeAOR;
  }

  public void setCoBuyerOfficeAOR(AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
    return this;
  }

  /**
   * Get coBuyerOfficeEmail
   * @return coBuyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerOfficeEmail() {
    return coBuyerOfficeEmail;
  }

  public void setCoBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
    return this;
  }

  /**
   * Get coBuyerOfficeFax
   * @return coBuyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficeFax() {
    return coBuyerOfficeFax;
  }

  public void setCoBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
    return this;
  }

  /**
   * Get coBuyerOfficeKey
   * @return coBuyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeKey() {
    return coBuyerOfficeKey;
  }

  public void setCoBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerOfficeKeyNumeric
   * @return coBuyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeKeyNumeric getCoBuyerOfficeKeyNumeric() {
    return coBuyerOfficeKeyNumeric;
  }

  public void setCoBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
    return this;
  }

  /**
   * Get coBuyerOfficeMlsId
   * @return coBuyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerOfficeMlsId() {
    return coBuyerOfficeMlsId;
  }

  public void setCoBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
    return this;
  }

  /**
   * Get coBuyerOfficeName
   * @return coBuyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeName() {
    return coBuyerOfficeName;
  }

  public void setCoBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
    return this;
  }

  /**
   * Get coBuyerOfficePhone
   * @return coBuyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficePhone() {
    return coBuyerOfficePhone;
  }

  public void setCoBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerOfficePhoneExt
   * @return coBuyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerOfficePhoneExt() {
    return coBuyerOfficePhoneExt;
  }

  public void setCoBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
    return this;
  }

  /**
   * Get coBuyerOfficeURL
   * @return coBuyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerOfficeURL() {
    return coBuyerOfficeURL;
  }

  public void setCoBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
  }

  public OrgResoMetadataPropertyUpdate coListAgentAOR(AnyOforgResoMetadataPropertyUpdateCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
    return this;
  }

  /**
   * Get coListAgentAOR
   * @return coListAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoListAgentAOR getCoListAgentAOR() {
    return coListAgentAOR;
  }

  public void setCoListAgentAOR(AnyOforgResoMetadataPropertyUpdateCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
  }

  public OrgResoMetadataPropertyUpdate coListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCoListAgentDesignationItem(OrgResoMetadataEnumsCoListAgentDesignation coListAgentDesignationItem) {
    if (this.coListAgentDesignation == null) {
      this.coListAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoListAgentDesignation>();
    }
    this.coListAgentDesignation.add(coListAgentDesignationItem);
    return this;
  }

  /**
   * Get coListAgentDesignation
   * @return coListAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoListAgentDesignation> getCoListAgentDesignation() {
    return coListAgentDesignation;
  }

  public void setCoListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
  }

  public OrgResoMetadataPropertyUpdate coListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
    return this;
  }

  /**
   * Get coListAgentDirectPhone
   * @return coListAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentDirectPhone() {
    return coListAgentDirectPhone;
  }

  public void setCoListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
    return this;
  }

  /**
   * Get coListAgentEmail
   * @return coListAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListAgentEmail() {
    return coListAgentEmail;
  }

  public void setCoListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
  }

  public OrgResoMetadataPropertyUpdate coListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
    return this;
  }

  /**
   * Get coListAgentFax
   * @return coListAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentFax() {
    return coListAgentFax;
  }

  public void setCoListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
  }

  public OrgResoMetadataPropertyUpdate coListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
    return this;
  }

  /**
   * Get coListAgentFirstName
   * @return coListAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentFirstName() {
    return coListAgentFirstName;
  }

  public void setCoListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
  }

  public OrgResoMetadataPropertyUpdate coListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
    return this;
  }

  /**
   * Get coListAgentFullName
   * @return coListAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoListAgentFullName() {
    return coListAgentFullName;
  }

  public void setCoListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
  }

  public OrgResoMetadataPropertyUpdate coListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
    return this;
  }

  /**
   * Get coListAgentHomePhone
   * @return coListAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentHomePhone() {
    return coListAgentHomePhone;
  }

  public void setCoListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
    return this;
  }

  /**
   * Get coListAgentKey
   * @return coListAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListAgentKey() {
    return coListAgentKey;
  }

  public void setCoListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
  }

  public OrgResoMetadataPropertyUpdate coListAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
    return this;
  }

  /**
   * Get coListAgentKeyNumeric
   * @return coListAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric getCoListAgentKeyNumeric() {
    return coListAgentKeyNumeric;
  }

  public void setCoListAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate coListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
    return this;
  }

  /**
   * Get coListAgentLastName
   * @return coListAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentLastName() {
    return coListAgentLastName;
  }

  public void setCoListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
  }

  public OrgResoMetadataPropertyUpdate coListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
    return this;
  }

  /**
   * Get coListAgentMiddleName
   * @return coListAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentMiddleName() {
    return coListAgentMiddleName;
  }

  public void setCoListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
  }

  public OrgResoMetadataPropertyUpdate coListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
    return this;
  }

  /**
   * Get coListAgentMlsId
   * @return coListAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListAgentMlsId() {
    return coListAgentMlsId;
  }

  public void setCoListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
  }

  public OrgResoMetadataPropertyUpdate coListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
    return this;
  }

  /**
   * Get coListAgentMobilePhone
   * @return coListAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentMobilePhone() {
    return coListAgentMobilePhone;
  }

  public void setCoListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
    return this;
  }

  /**
   * Get coListAgentNamePrefix
   * @return coListAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNamePrefix() {
    return coListAgentNamePrefix;
  }

  public void setCoListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
  }

  public OrgResoMetadataPropertyUpdate coListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
    return this;
  }

  /**
   * Get coListAgentNameSuffix
   * @return coListAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNameSuffix() {
    return coListAgentNameSuffix;
  }

  public void setCoListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
  }

  public OrgResoMetadataPropertyUpdate coListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
    return this;
  }

  /**
   * Get coListAgentOfficePhone
   * @return coListAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentOfficePhone() {
    return coListAgentOfficePhone;
  }

  public void setCoListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coListAgentOfficePhoneExt
   * @return coListAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentOfficePhoneExt() {
    return coListAgentOfficePhoneExt;
  }

  public void setCoListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
    return this;
  }

  /**
   * Get coListAgentPager
   * @return coListAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPager() {
    return coListAgentPager;
  }

  public void setCoListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
  }

  public OrgResoMetadataPropertyUpdate coListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
    return this;
  }

  /**
   * Get coListAgentPreferredPhone
   * @return coListAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPreferredPhone() {
    return coListAgentPreferredPhone;
  }

  public void setCoListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coListAgentPreferredPhoneExt
   * @return coListAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentPreferredPhoneExt() {
    return coListAgentPreferredPhoneExt;
  }

  public void setCoListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
    return this;
  }

  /**
   * Get coListAgentStateLicense
   * @return coListAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentStateLicense() {
    return coListAgentStateLicense;
  }

  public void setCoListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
  }

  public OrgResoMetadataPropertyUpdate coListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
    return this;
  }

  /**
   * Get coListAgentTollFreePhone
   * @return coListAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentTollFreePhone() {
    return coListAgentTollFreePhone;
  }

  public void setCoListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyUpdate coListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
    return this;
  }

  /**
   * Get coListAgentURL
   * @return coListAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListAgentURL() {
    return coListAgentURL;
  }

  public void setCoListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
  }

  public OrgResoMetadataPropertyUpdate coListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
    return this;
  }

  /**
   * Get coListAgentVoiceMail
   * @return coListAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentVoiceMail() {
    return coListAgentVoiceMail;
  }

  public void setCoListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
  }

  public OrgResoMetadataPropertyUpdate coListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coListAgentVoiceMailExt
   * @return coListAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentVoiceMailExt() {
    return coListAgentVoiceMailExt;
  }

  public void setCoListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeAOR(AnyOforgResoMetadataPropertyUpdateCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
    return this;
  }

  /**
   * Get coListOfficeAOR
   * @return coListOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoListOfficeAOR getCoListOfficeAOR() {
    return coListOfficeAOR;
  }

  public void setCoListOfficeAOR(AnyOforgResoMetadataPropertyUpdateCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
    return this;
  }

  /**
   * Get coListOfficeEmail
   * @return coListOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListOfficeEmail() {
    return coListOfficeEmail;
  }

  public void setCoListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
    return this;
  }

  /**
   * Get coListOfficeFax
   * @return coListOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficeFax() {
    return coListOfficeFax;
  }

  public void setCoListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
    return this;
  }

  /**
   * Get coListOfficeKey
   * @return coListOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeKey() {
    return coListOfficeKey;
  }

  public void setCoListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coListOfficeKeyNumeric
   * @return coListOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoListOfficeKeyNumeric getCoListOfficeKeyNumeric() {
    return coListOfficeKeyNumeric;
  }

  public void setCoListOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
    return this;
  }

  /**
   * Get coListOfficeMlsId
   * @return coListOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListOfficeMlsId() {
    return coListOfficeMlsId;
  }

  public void setCoListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
    return this;
  }

  /**
   * Get coListOfficeName
   * @return coListOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeName() {
    return coListOfficeName;
  }

  public void setCoListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
  }

  public OrgResoMetadataPropertyUpdate coListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
    return this;
  }

  /**
   * Get coListOfficePhone
   * @return coListOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficePhone() {
    return coListOfficePhone;
  }

  public void setCoListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate coListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
    return this;
  }

  /**
   * Get coListOfficePhoneExt
   * @return coListOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListOfficePhoneExt() {
    return coListOfficePhoneExt;
  }

  public void setCoListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate coListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
    return this;
  }

  /**
   * Get coListOfficeURL
   * @return coListOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListOfficeURL() {
    return coListOfficeURL;
  }

  public void setCoListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
  }

  public OrgResoMetadataPropertyUpdate commonInterest(AnyOforgResoMetadataPropertyUpdateCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
    return this;
  }

  /**
   * Get commonInterest
   * @return commonInterest
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCommonInterest getCommonInterest() {
    return commonInterest;
  }

  public void setCommonInterest(AnyOforgResoMetadataPropertyUpdateCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
  }

  public OrgResoMetadataPropertyUpdate commonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCommonWallsItem(OrgResoMetadataEnumsCommonWalls commonWallsItem) {
    if (this.commonWalls == null) {
      this.commonWalls = new ArrayList<OrgResoMetadataEnumsCommonWalls>();
    }
    this.commonWalls.add(commonWallsItem);
    return this;
  }

  /**
   * Get commonWalls
   * @return commonWalls
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommonWalls> getCommonWalls() {
    return commonWalls;
  }

  public void setCommonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
  }

  public OrgResoMetadataPropertyUpdate communityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCommunityFeaturesItem(OrgResoMetadataEnumsCommunityFeatures communityFeaturesItem) {
    if (this.communityFeatures == null) {
      this.communityFeatures = new ArrayList<OrgResoMetadataEnumsCommunityFeatures>();
    }
    this.communityFeatures.add(communityFeaturesItem);
    return this;
  }

  /**
   * Get communityFeatures
   * @return communityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommunityFeatures> getCommunityFeatures() {
    return communityFeatures;
  }

  public void setCommunityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
  }

  public OrgResoMetadataPropertyUpdate concessions(AnyOforgResoMetadataPropertyUpdateConcessions concessions) {
    this.concessions = concessions;
    return this;
  }

  /**
   * Get concessions
   * @return concessions
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateConcessions getConcessions() {
    return concessions;
  }

  public void setConcessions(AnyOforgResoMetadataPropertyUpdateConcessions concessions) {
    this.concessions = concessions;
  }

  public OrgResoMetadataPropertyUpdate concessionsAmount(AnyOforgResoMetadataPropertyUpdateConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
    return this;
  }

  /**
   * Get concessionsAmount
   * @return concessionsAmount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateConcessionsAmount getConcessionsAmount() {
    return concessionsAmount;
  }

  public void setConcessionsAmount(AnyOforgResoMetadataPropertyUpdateConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
  }

  public OrgResoMetadataPropertyUpdate concessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
    return this;
  }

  /**
   * Get concessionsComments
   * @return concessionsComments
   **/
  @Schema(description = "")
  
  @Size(max=200)   public String getConcessionsComments() {
    return concessionsComments;
  }

  public void setConcessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
  }

  public OrgResoMetadataPropertyUpdate constructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addConstructionMaterialsItem(OrgResoMetadataEnumsConstructionMaterials constructionMaterialsItem) {
    if (this.constructionMaterials == null) {
      this.constructionMaterials = new ArrayList<OrgResoMetadataEnumsConstructionMaterials>();
    }
    this.constructionMaterials.add(constructionMaterialsItem);
    return this;
  }

  /**
   * Get constructionMaterials
   * @return constructionMaterials
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsConstructionMaterials> getConstructionMaterials() {
    return constructionMaterials;
  }

  public void setConstructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
  }

  public OrgResoMetadataPropertyUpdate continentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
    return this;
  }

  /**
   * Get continentRegion
   * @return continentRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getContinentRegion() {
    return continentRegion;
  }

  public void setContinentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
  }

  public OrgResoMetadataPropertyUpdate contingency(String contingency) {
    this.contingency = contingency;
    return this;
  }

  /**
   * Get contingency
   * @return contingency
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getContingency() {
    return contingency;
  }

  public void setContingency(String contingency) {
    this.contingency = contingency;
  }

  public OrgResoMetadataPropertyUpdate contingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
    return this;
  }

  /**
   * Get contingentDate
   * @return contingentDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContingentDate() {
    return contingentDate;
  }

  public void setContingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
  }

  public OrgResoMetadataPropertyUpdate contractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
    return this;
  }

  /**
   * Get contractStatusChangeDate
   * @return contractStatusChangeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContractStatusChangeDate() {
    return contractStatusChangeDate;
  }

  public void setContractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
  }

  public OrgResoMetadataPropertyUpdate cooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCoolingItem(OrgResoMetadataEnumsCooling coolingItem) {
    if (this.cooling == null) {
      this.cooling = new ArrayList<OrgResoMetadataEnumsCooling>();
    }
    this.cooling.add(coolingItem);
    return this;
  }

  /**
   * Get cooling
   * @return cooling
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCooling> getCooling() {
    return cooling;
  }

  public void setCooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
  }

  public OrgResoMetadataPropertyUpdate coolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
    return this;
  }

  /**
   * Get coolingYN
   * @return coolingYN
   **/
  @Schema(description = "")
  
    public Boolean isCoolingYN() {
    return coolingYN;
  }

  public void setCoolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
  }

  public OrgResoMetadataPropertyUpdate copyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
    return this;
  }

  /**
   * Get copyrightNotice
   * @return copyrightNotice
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getCopyrightNotice() {
    return copyrightNotice;
  }

  public void setCopyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
  }

  public OrgResoMetadataPropertyUpdate country(AnyOforgResoMetadataPropertyUpdateCountry country) {
    this.country = country;
    return this;
  }

  /**
   * Get country
   * @return country
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCountry getCountry() {
    return country;
  }

  public void setCountry(AnyOforgResoMetadataPropertyUpdateCountry country) {
    this.country = country;
  }

  public OrgResoMetadataPropertyUpdate countryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
    return this;
  }

  /**
   * Get countryRegion
   * @return countryRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCountryRegion() {
    return countryRegion;
  }

  public void setCountryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
  }

  public OrgResoMetadataPropertyUpdate countyOrParish(AnyOforgResoMetadataPropertyUpdateCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
    return this;
  }

  /**
   * Get countyOrParish
   * @return countyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCountyOrParish getCountyOrParish() {
    return countyOrParish;
  }

  public void setCountyOrParish(AnyOforgResoMetadataPropertyUpdateCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
  }

  public OrgResoMetadataPropertyUpdate coveredSpaces(AnyOforgResoMetadataPropertyUpdateCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
    return this;
  }

  /**
   * Get coveredSpaces
   * @return coveredSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCoveredSpaces getCoveredSpaces() {
    return coveredSpaces;
  }

  public void setCoveredSpaces(AnyOforgResoMetadataPropertyUpdateCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
  }

  public OrgResoMetadataPropertyUpdate cropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
    return this;
  }

  /**
   * Get cropsIncludedYN
   * @return cropsIncludedYN
   **/
  @Schema(description = "")
  
    public Boolean isCropsIncludedYN() {
    return cropsIncludedYN;
  }

  public void setCropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
  }

  public OrgResoMetadataPropertyUpdate crossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
    return this;
  }

  /**
   * Get crossStreet
   * @return crossStreet
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCrossStreet() {
    return crossStreet;
  }

  public void setCrossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
  }

  public OrgResoMetadataPropertyUpdate cultivatedArea(AnyOforgResoMetadataPropertyUpdateCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
    return this;
  }

  /**
   * Get cultivatedArea
   * @return cultivatedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCultivatedArea getCultivatedArea() {
    return cultivatedArea;
  }

  public void setCultivatedArea(AnyOforgResoMetadataPropertyUpdateCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
  }

  public OrgResoMetadataPropertyUpdate cumulativeDaysOnMarket(AnyOforgResoMetadataPropertyUpdateCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
    return this;
  }

  /**
   * Get cumulativeDaysOnMarket
   * @return cumulativeDaysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateCumulativeDaysOnMarket getCumulativeDaysOnMarket() {
    return cumulativeDaysOnMarket;
  }

  public void setCumulativeDaysOnMarket(AnyOforgResoMetadataPropertyUpdateCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
  }

  public OrgResoMetadataPropertyUpdate currentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCurrentFinancingItem(OrgResoMetadataEnumsCurrentFinancing currentFinancingItem) {
    if (this.currentFinancing == null) {
      this.currentFinancing = new ArrayList<OrgResoMetadataEnumsCurrentFinancing>();
    }
    this.currentFinancing.add(currentFinancingItem);
    return this;
  }

  /**
   * Get currentFinancing
   * @return currentFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentFinancing> getCurrentFinancing() {
    return currentFinancing;
  }

  public void setCurrentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
  }

  public OrgResoMetadataPropertyUpdate currentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addCurrentUseItem(OrgResoMetadataEnumsCurrentUse currentUseItem) {
    if (this.currentUse == null) {
      this.currentUse = new ArrayList<OrgResoMetadataEnumsCurrentUse>();
    }
    this.currentUse.add(currentUseItem);
    return this;
  }

  /**
   * Get currentUse
   * @return currentUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentUse> getCurrentUse() {
    return currentUse;
  }

  public void setCurrentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
  }

  public OrgResoMetadataPropertyUpdate doH1(String doH1) {
    this.doH1 = doH1;
    return this;
  }

  /**
   * Get doH1
   * @return doH1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH1() {
    return doH1;
  }

  public void setDoH1(String doH1) {
    this.doH1 = doH1;
  }

  public OrgResoMetadataPropertyUpdate doH2(String doH2) {
    this.doH2 = doH2;
    return this;
  }

  /**
   * Get doH2
   * @return doH2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH2() {
    return doH2;
  }

  public void setDoH2(String doH2) {
    this.doH2 = doH2;
  }

  public OrgResoMetadataPropertyUpdate doH3(String doH3) {
    this.doH3 = doH3;
    return this;
  }

  /**
   * Get doH3
   * @return doH3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH3() {
    return doH3;
  }

  public void setDoH3(String doH3) {
    this.doH3 = doH3;
  }

  public OrgResoMetadataPropertyUpdate daysOnMarket(AnyOforgResoMetadataPropertyUpdateDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
    return this;
  }

  /**
   * Get daysOnMarket
   * @return daysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDaysOnMarket getDaysOnMarket() {
    return daysOnMarket;
  }

  public void setDaysOnMarket(AnyOforgResoMetadataPropertyUpdateDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
  }

  public OrgResoMetadataPropertyUpdate developmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addDevelopmentStatusItem(OrgResoMetadataEnumsDevelopmentStatus developmentStatusItem) {
    if (this.developmentStatus == null) {
      this.developmentStatus = new ArrayList<OrgResoMetadataEnumsDevelopmentStatus>();
    }
    this.developmentStatus.add(developmentStatusItem);
    return this;
  }

  /**
   * Get developmentStatus
   * @return developmentStatus
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDevelopmentStatus> getDevelopmentStatus() {
    return developmentStatus;
  }

  public void setDevelopmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
  }

  public OrgResoMetadataPropertyUpdate directionFaces(AnyOforgResoMetadataPropertyUpdateDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
    return this;
  }

  /**
   * Get directionFaces
   * @return directionFaces
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDirectionFaces getDirectionFaces() {
    return directionFaces;
  }

  public void setDirectionFaces(AnyOforgResoMetadataPropertyUpdateDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
  }

  public OrgResoMetadataPropertyUpdate directions(String directions) {
    this.directions = directions;
    return this;
  }

  /**
   * Get directions
   * @return directions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getDirections() {
    return directions;
  }

  public void setDirections(String directions) {
    this.directions = directions;
  }

  public OrgResoMetadataPropertyUpdate disclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
    return this;
  }

  /**
   * Get disclaimer
   * @return disclaimer
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getDisclaimer() {
    return disclaimer;
  }

  public void setDisclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
  }

  public OrgResoMetadataPropertyUpdate disclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addDisclosuresItem(OrgResoMetadataEnumsDisclosures disclosuresItem) {
    if (this.disclosures == null) {
      this.disclosures = new ArrayList<OrgResoMetadataEnumsDisclosures>();
    }
    this.disclosures.add(disclosuresItem);
    return this;
  }

  /**
   * Get disclosures
   * @return disclosures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDisclosures> getDisclosures() {
    return disclosures;
  }

  public void setDisclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
  }

  public OrgResoMetadataPropertyUpdate distanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
    return this;
  }

  /**
   * Get distanceToBusComments
   * @return distanceToBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToBusComments() {
    return distanceToBusComments;
  }

  public void setDistanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToBusNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
    return this;
  }

  /**
   * Get distanceToBusNumeric
   * @return distanceToBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric getDistanceToBusNumeric() {
    return distanceToBusNumeric;
  }

  public void setDistanceToBusNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToBusUnits(AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
    return this;
  }

  /**
   * Get distanceToBusUnits
   * @return distanceToBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits getDistanceToBusUnits() {
    return distanceToBusUnits;
  }

  public void setDistanceToBusUnits(AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
    return this;
  }

  /**
   * Get distanceToElectricComments
   * @return distanceToElectricComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToElectricComments() {
    return distanceToElectricComments;
  }

  public void setDistanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToElectricNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
    return this;
  }

  /**
   * Get distanceToElectricNumeric
   * @return distanceToElectricNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric getDistanceToElectricNumeric() {
    return distanceToElectricNumeric;
  }

  public void setDistanceToElectricNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToElectricUnits(AnyOforgResoMetadataPropertyUpdateDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
    return this;
  }

  /**
   * Get distanceToElectricUnits
   * @return distanceToElectricUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToElectricUnits getDistanceToElectricUnits() {
    return distanceToElectricUnits;
  }

  public void setDistanceToElectricUnits(AnyOforgResoMetadataPropertyUpdateDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
    return this;
  }

  /**
   * Get distanceToFreewayComments
   * @return distanceToFreewayComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToFreewayComments() {
    return distanceToFreewayComments;
  }

  public void setDistanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToFreewayNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
    return this;
  }

  /**
   * Get distanceToFreewayNumeric
   * @return distanceToFreewayNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToFreewayNumeric getDistanceToFreewayNumeric() {
    return distanceToFreewayNumeric;
  }

  public void setDistanceToFreewayNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToFreewayUnits(AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
    return this;
  }

  /**
   * Get distanceToFreewayUnits
   * @return distanceToFreewayUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits getDistanceToFreewayUnits() {
    return distanceToFreewayUnits;
  }

  public void setDistanceToFreewayUnits(AnyOforgResoMetadataPropertyUpdateDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
    return this;
  }

  /**
   * Get distanceToGasComments
   * @return distanceToGasComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToGasComments() {
    return distanceToGasComments;
  }

  public void setDistanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToGasNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
    return this;
  }

  /**
   * Get distanceToGasNumeric
   * @return distanceToGasNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToGasNumeric getDistanceToGasNumeric() {
    return distanceToGasNumeric;
  }

  public void setDistanceToGasNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToGasUnits(AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
    return this;
  }

  /**
   * Get distanceToGasUnits
   * @return distanceToGasUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits getDistanceToGasUnits() {
    return distanceToGasUnits;
  }

  public void setDistanceToGasUnits(AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
    return this;
  }

  /**
   * Get distanceToPhoneServiceComments
   * @return distanceToPhoneServiceComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPhoneServiceComments() {
    return distanceToPhoneServiceComments;
  }

  public void setDistanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
    return this;
  }

  /**
   * Get distanceToPhoneServiceNumeric
   * @return distanceToPhoneServiceNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric getDistanceToPhoneServiceNumeric() {
    return distanceToPhoneServiceNumeric;
  }

  public void setDistanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
    return this;
  }

  /**
   * Get distanceToPhoneServiceUnits
   * @return distanceToPhoneServiceUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits getDistanceToPhoneServiceUnits() {
    return distanceToPhoneServiceUnits;
  }

  public void setDistanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipComments
   * @return distanceToPlaceofWorshipComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPlaceofWorshipComments() {
    return distanceToPlaceofWorshipComments;
  }

  public void setDistanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipNumeric
   * @return distanceToPlaceofWorshipNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipNumeric getDistanceToPlaceofWorshipNumeric() {
    return distanceToPlaceofWorshipNumeric;
  }

  public void setDistanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipUnits
   * @return distanceToPlaceofWorshipUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipUnits getDistanceToPlaceofWorshipUnits() {
    return distanceToPlaceofWorshipUnits;
  }

  public void setDistanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyUpdateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
    return this;
  }

  /**
   * Get distanceToSchoolBusComments
   * @return distanceToSchoolBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolBusComments() {
    return distanceToSchoolBusComments;
  }

  public void setDistanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolBusNumeric
   * @return distanceToSchoolBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric getDistanceToSchoolBusNumeric() {
    return distanceToSchoolBusNumeric;
  }

  public void setDistanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolBusUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
    return this;
  }

  /**
   * Get distanceToSchoolBusUnits
   * @return distanceToSchoolBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits getDistanceToSchoolBusUnits() {
    return distanceToSchoolBusUnits;
  }

  public void setDistanceToSchoolBusUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
    return this;
  }

  /**
   * Get distanceToSchoolsComments
   * @return distanceToSchoolsComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolsComments() {
    return distanceToSchoolsComments;
  }

  public void setDistanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolsNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolsNumeric
   * @return distanceToSchoolsNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsNumeric getDistanceToSchoolsNumeric() {
    return distanceToSchoolsNumeric;
  }

  public void setDistanceToSchoolsNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToSchoolsUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
    return this;
  }

  /**
   * Get distanceToSchoolsUnits
   * @return distanceToSchoolsUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsUnits getDistanceToSchoolsUnits() {
    return distanceToSchoolsUnits;
  }

  public void setDistanceToSchoolsUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
    return this;
  }

  /**
   * Get distanceToSewerComments
   * @return distanceToSewerComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSewerComments() {
    return distanceToSewerComments;
  }

  public void setDistanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToSewerNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
    return this;
  }

  /**
   * Get distanceToSewerNumeric
   * @return distanceToSewerNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric getDistanceToSewerNumeric() {
    return distanceToSewerNumeric;
  }

  public void setDistanceToSewerNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToSewerUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
    return this;
  }

  /**
   * Get distanceToSewerUnits
   * @return distanceToSewerUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToSewerUnits getDistanceToSewerUnits() {
    return distanceToSewerUnits;
  }

  public void setDistanceToSewerUnits(AnyOforgResoMetadataPropertyUpdateDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
    return this;
  }

  /**
   * Get distanceToShoppingComments
   * @return distanceToShoppingComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToShoppingComments() {
    return distanceToShoppingComments;
  }

  public void setDistanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToShoppingNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
    return this;
  }

  /**
   * Get distanceToShoppingNumeric
   * @return distanceToShoppingNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToShoppingNumeric getDistanceToShoppingNumeric() {
    return distanceToShoppingNumeric;
  }

  public void setDistanceToShoppingNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToShoppingUnits(AnyOforgResoMetadataPropertyUpdateDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
    return this;
  }

  /**
   * Get distanceToShoppingUnits
   * @return distanceToShoppingUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToShoppingUnits getDistanceToShoppingUnits() {
    return distanceToShoppingUnits;
  }

  public void setDistanceToShoppingUnits(AnyOforgResoMetadataPropertyUpdateDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
    return this;
  }

  /**
   * Get distanceToStreetComments
   * @return distanceToStreetComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToStreetComments() {
    return distanceToStreetComments;
  }

  public void setDistanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToStreetNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
    return this;
  }

  /**
   * Get distanceToStreetNumeric
   * @return distanceToStreetNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToStreetNumeric getDistanceToStreetNumeric() {
    return distanceToStreetNumeric;
  }

  public void setDistanceToStreetNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToStreetUnits(AnyOforgResoMetadataPropertyUpdateDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
    return this;
  }

  /**
   * Get distanceToStreetUnits
   * @return distanceToStreetUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToStreetUnits getDistanceToStreetUnits() {
    return distanceToStreetUnits;
  }

  public void setDistanceToStreetUnits(AnyOforgResoMetadataPropertyUpdateDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
  }

  public OrgResoMetadataPropertyUpdate distanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
    return this;
  }

  /**
   * Get distanceToWaterComments
   * @return distanceToWaterComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToWaterComments() {
    return distanceToWaterComments;
  }

  public void setDistanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
  }

  public OrgResoMetadataPropertyUpdate distanceToWaterNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
    return this;
  }

  /**
   * Get distanceToWaterNumeric
   * @return distanceToWaterNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric getDistanceToWaterNumeric() {
    return distanceToWaterNumeric;
  }

  public void setDistanceToWaterNumeric(AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
  }

  public OrgResoMetadataPropertyUpdate distanceToWaterUnits(AnyOforgResoMetadataPropertyUpdateDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
    return this;
  }

  /**
   * Get distanceToWaterUnits
   * @return distanceToWaterUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDistanceToWaterUnits getDistanceToWaterUnits() {
    return distanceToWaterUnits;
  }

  public void setDistanceToWaterUnits(AnyOforgResoMetadataPropertyUpdateDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
  }

  public OrgResoMetadataPropertyUpdate documentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addDocumentsAvailableItem(OrgResoMetadataEnumsDocumentsAvailable documentsAvailableItem) {
    if (this.documentsAvailable == null) {
      this.documentsAvailable = new ArrayList<OrgResoMetadataEnumsDocumentsAvailable>();
    }
    this.documentsAvailable.add(documentsAvailableItem);
    return this;
  }

  /**
   * Get documentsAvailable
   * @return documentsAvailable
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDocumentsAvailable> getDocumentsAvailable() {
    return documentsAvailable;
  }

  public void setDocumentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
  }

  public OrgResoMetadataPropertyUpdate documentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
    return this;
  }

  /**
   * Get documentsChangeTimestamp
   * @return documentsChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDocumentsChangeTimestamp() {
    return documentsChangeTimestamp;
  }

  public void setDocumentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate documentsCount(AnyOforgResoMetadataPropertyUpdateDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
    return this;
  }

  /**
   * Get documentsCount
   * @return documentsCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateDocumentsCount getDocumentsCount() {
    return documentsCount;
  }

  public void setDocumentsCount(AnyOforgResoMetadataPropertyUpdateDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
  }

  public OrgResoMetadataPropertyUpdate doorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addDoorFeaturesItem(OrgResoMetadataEnumsDoorFeatures doorFeaturesItem) {
    if (this.doorFeatures == null) {
      this.doorFeatures = new ArrayList<OrgResoMetadataEnumsDoorFeatures>();
    }
    this.doorFeatures.add(doorFeaturesItem);
    return this;
  }

  /**
   * Get doorFeatures
   * @return doorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDoorFeatures> getDoorFeatures() {
    return doorFeatures;
  }

  public void setDoorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
  }

  public OrgResoMetadataPropertyUpdate dualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
    return this;
  }

  /**
   * Get dualVariableCompensationYN
   * @return dualVariableCompensationYN
   **/
  @Schema(description = "")
  
    public Boolean isDualVariableCompensationYN() {
    return dualVariableCompensationYN;
  }

  public void setDualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
  }

  public OrgResoMetadataPropertyUpdate electric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addElectricItem(OrgResoMetadataEnumsElectric electricItem) {
    if (this.electric == null) {
      this.electric = new ArrayList<OrgResoMetadataEnumsElectric>();
    }
    this.electric.add(electricItem);
    return this;
  }

  /**
   * Get electric
   * @return electric
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsElectric> getElectric() {
    return electric;
  }

  public void setElectric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
  }

  public OrgResoMetadataPropertyUpdate electricExpense(AnyOforgResoMetadataPropertyUpdateElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
    return this;
  }

  /**
   * Get electricExpense
   * @return electricExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateElectricExpense getElectricExpense() {
    return electricExpense;
  }

  public void setElectricExpense(AnyOforgResoMetadataPropertyUpdateElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
  }

  public OrgResoMetadataPropertyUpdate electricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
    return this;
  }

  /**
   * Get electricOnPropertyYN
   * @return electricOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isElectricOnPropertyYN() {
    return electricOnPropertyYN;
  }

  public void setElectricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
  }

  public OrgResoMetadataPropertyUpdate elementarySchool(AnyOforgResoMetadataPropertyUpdateElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
    return this;
  }

  /**
   * Get elementarySchool
   * @return elementarySchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateElementarySchool getElementarySchool() {
    return elementarySchool;
  }

  public void setElementarySchool(AnyOforgResoMetadataPropertyUpdateElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
  }

  public OrgResoMetadataPropertyUpdate elementarySchoolDistrict(AnyOforgResoMetadataPropertyUpdateElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
    return this;
  }

  /**
   * Get elementarySchoolDistrict
   * @return elementarySchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateElementarySchoolDistrict getElementarySchoolDistrict() {
    return elementarySchoolDistrict;
  }

  public void setElementarySchoolDistrict(AnyOforgResoMetadataPropertyUpdateElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
  }

  public OrgResoMetadataPropertyUpdate elevation(AnyOforgResoMetadataPropertyUpdateElevation elevation) {
    this.elevation = elevation;
    return this;
  }

  /**
   * Get elevation
   * @return elevation
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateElevation getElevation() {
    return elevation;
  }

  public void setElevation(AnyOforgResoMetadataPropertyUpdateElevation elevation) {
    this.elevation = elevation;
  }

  public OrgResoMetadataPropertyUpdate elevationUnits(AnyOforgResoMetadataPropertyUpdateElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
    return this;
  }

  /**
   * Get elevationUnits
   * @return elevationUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateElevationUnits getElevationUnits() {
    return elevationUnits;
  }

  public void setElevationUnits(AnyOforgResoMetadataPropertyUpdateElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
  }

  public OrgResoMetadataPropertyUpdate entryLevel(AnyOforgResoMetadataPropertyUpdateEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
    return this;
  }

  /**
   * Get entryLevel
   * @return entryLevel
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateEntryLevel getEntryLevel() {
    return entryLevel;
  }

  public void setEntryLevel(AnyOforgResoMetadataPropertyUpdateEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
  }

  public OrgResoMetadataPropertyUpdate entryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
    return this;
  }

  /**
   * Get entryLocation
   * @return entryLocation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getEntryLocation() {
    return entryLocation;
  }

  public void setEntryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
  }

  public OrgResoMetadataPropertyUpdate exclusions(String exclusions) {
    this.exclusions = exclusions;
    return this;
  }

  /**
   * Get exclusions
   * @return exclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getExclusions() {
    return exclusions;
  }

  public void setExclusions(String exclusions) {
    this.exclusions = exclusions;
  }

  public OrgResoMetadataPropertyUpdate existingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addExistingLeaseTypeItem(OrgResoMetadataEnumsExistingLeaseType existingLeaseTypeItem) {
    if (this.existingLeaseType == null) {
      this.existingLeaseType = new ArrayList<OrgResoMetadataEnumsExistingLeaseType>();
    }
    this.existingLeaseType.add(existingLeaseTypeItem);
    return this;
  }

  /**
   * Get existingLeaseType
   * @return existingLeaseType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExistingLeaseType> getExistingLeaseType() {
    return existingLeaseType;
  }

  public void setExistingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
  }

  public OrgResoMetadataPropertyUpdate expirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
    return this;
  }

  /**
   * Get expirationDate
   * @return expirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
  }

  public OrgResoMetadataPropertyUpdate exteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addExteriorFeaturesItem(OrgResoMetadataEnumsExteriorFeatures exteriorFeaturesItem) {
    if (this.exteriorFeatures == null) {
      this.exteriorFeatures = new ArrayList<OrgResoMetadataEnumsExteriorFeatures>();
    }
    this.exteriorFeatures.add(exteriorFeaturesItem);
    return this;
  }

  /**
   * Get exteriorFeatures
   * @return exteriorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExteriorFeatures> getExteriorFeatures() {
    return exteriorFeatures;
  }

  public void setExteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
  }

  public OrgResoMetadataPropertyUpdate farmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
    return this;
  }

  /**
   * Get farmCreditServiceInclYN
   * @return farmCreditServiceInclYN
   **/
  @Schema(description = "")
  
    public Boolean isFarmCreditServiceInclYN() {
    return farmCreditServiceInclYN;
  }

  public void setFarmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
  }

  public OrgResoMetadataPropertyUpdate farmLandAreaSource(AnyOforgResoMetadataPropertyUpdateFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
    return this;
  }

  /**
   * Get farmLandAreaSource
   * @return farmLandAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFarmLandAreaSource getFarmLandAreaSource() {
    return farmLandAreaSource;
  }

  public void setFarmLandAreaSource(AnyOforgResoMetadataPropertyUpdateFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
  }

  public OrgResoMetadataPropertyUpdate farmLandAreaUnits(AnyOforgResoMetadataPropertyUpdateFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
    return this;
  }

  /**
   * Get farmLandAreaUnits
   * @return farmLandAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFarmLandAreaUnits getFarmLandAreaUnits() {
    return farmLandAreaUnits;
  }

  public void setFarmLandAreaUnits(AnyOforgResoMetadataPropertyUpdateFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate fencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFencingItem(OrgResoMetadataEnumsFencing fencingItem) {
    if (this.fencing == null) {
      this.fencing = new ArrayList<OrgResoMetadataEnumsFencing>();
    }
    this.fencing.add(fencingItem);
    return this;
  }

  /**
   * Get fencing
   * @return fencing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFencing> getFencing() {
    return fencing;
  }

  public void setFencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
  }

  public OrgResoMetadataPropertyUpdate financialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFinancialDataSourceItem(OrgResoMetadataEnumsFinancialDataSource financialDataSourceItem) {
    if (this.financialDataSource == null) {
      this.financialDataSource = new ArrayList<OrgResoMetadataEnumsFinancialDataSource>();
    }
    this.financialDataSource.add(financialDataSourceItem);
    return this;
  }

  /**
   * Get financialDataSource
   * @return financialDataSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFinancialDataSource> getFinancialDataSource() {
    return financialDataSource;
  }

  public void setFinancialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
  }

  public OrgResoMetadataPropertyUpdate fireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFireplaceFeaturesItem(OrgResoMetadataEnumsFireplaceFeatures fireplaceFeaturesItem) {
    if (this.fireplaceFeatures == null) {
      this.fireplaceFeatures = new ArrayList<OrgResoMetadataEnumsFireplaceFeatures>();
    }
    this.fireplaceFeatures.add(fireplaceFeaturesItem);
    return this;
  }

  /**
   * Get fireplaceFeatures
   * @return fireplaceFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFireplaceFeatures> getFireplaceFeatures() {
    return fireplaceFeatures;
  }

  public void setFireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
  }

  public OrgResoMetadataPropertyUpdate fireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
    return this;
  }

  /**
   * Get fireplaceYN
   * @return fireplaceYN
   **/
  @Schema(description = "")
  
    public Boolean isFireplaceYN() {
    return fireplaceYN;
  }

  public void setFireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
  }

  public OrgResoMetadataPropertyUpdate fireplacesTotal(AnyOforgResoMetadataPropertyUpdateFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
    return this;
  }

  /**
   * Get fireplacesTotal
   * @return fireplacesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFireplacesTotal getFireplacesTotal() {
    return fireplacesTotal;
  }

  public void setFireplacesTotal(AnyOforgResoMetadataPropertyUpdateFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
  }

  public OrgResoMetadataPropertyUpdate flooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFlooringItem(OrgResoMetadataEnumsFlooring flooringItem) {
    if (this.flooring == null) {
      this.flooring = new ArrayList<OrgResoMetadataEnumsFlooring>();
    }
    this.flooring.add(flooringItem);
    return this;
  }

  /**
   * Get flooring
   * @return flooring
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFlooring> getFlooring() {
    return flooring;
  }

  public void setFlooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
  }

  public OrgResoMetadataPropertyUpdate foundationArea(AnyOforgResoMetadataPropertyUpdateFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
    return this;
  }

  /**
   * Get foundationArea
   * @return foundationArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFoundationArea getFoundationArea() {
    return foundationArea;
  }

  public void setFoundationArea(AnyOforgResoMetadataPropertyUpdateFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
  }

  public OrgResoMetadataPropertyUpdate foundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFoundationDetailsItem(OrgResoMetadataEnumsFoundationDetails foundationDetailsItem) {
    if (this.foundationDetails == null) {
      this.foundationDetails = new ArrayList<OrgResoMetadataEnumsFoundationDetails>();
    }
    this.foundationDetails.add(foundationDetailsItem);
    return this;
  }

  /**
   * Get foundationDetails
   * @return foundationDetails
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFoundationDetails> getFoundationDetails() {
    return foundationDetails;
  }

  public void setFoundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
  }

  public OrgResoMetadataPropertyUpdate frontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
    return this;
  }

  /**
   * Get frontageLength
   * @return frontageLength
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getFrontageLength() {
    return frontageLength;
  }

  public void setFrontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
  }

  public OrgResoMetadataPropertyUpdate frontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addFrontageTypeItem(OrgResoMetadataEnumsFrontageType frontageTypeItem) {
    if (this.frontageType == null) {
      this.frontageType = new ArrayList<OrgResoMetadataEnumsFrontageType>();
    }
    this.frontageType.add(frontageTypeItem);
    return this;
  }

  /**
   * Get frontageType
   * @return frontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFrontageType> getFrontageType() {
    return frontageType;
  }

  public void setFrontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
  }

  public OrgResoMetadataPropertyUpdate fuelExpense(AnyOforgResoMetadataPropertyUpdateFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
    return this;
  }

  /**
   * Get fuelExpense
   * @return fuelExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFuelExpense getFuelExpense() {
    return fuelExpense;
  }

  public void setFuelExpense(AnyOforgResoMetadataPropertyUpdateFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
  }

  public OrgResoMetadataPropertyUpdate furnished(AnyOforgResoMetadataPropertyUpdateFurnished furnished) {
    this.furnished = furnished;
    return this;
  }

  /**
   * Get furnished
   * @return furnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFurnished getFurnished() {
    return furnished;
  }

  public void setFurnished(AnyOforgResoMetadataPropertyUpdateFurnished furnished) {
    this.furnished = furnished;
  }

  public OrgResoMetadataPropertyUpdate furnitureReplacementExpense(AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
    return this;
  }

  /**
   * Get furnitureReplacementExpense
   * @return furnitureReplacementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense getFurnitureReplacementExpense() {
    return furnitureReplacementExpense;
  }

  public void setFurnitureReplacementExpense(AnyOforgResoMetadataPropertyUpdateFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
  }

  public OrgResoMetadataPropertyUpdate garageSpaces(AnyOforgResoMetadataPropertyUpdateGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
    return this;
  }

  /**
   * Get garageSpaces
   * @return garageSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateGarageSpaces getGarageSpaces() {
    return garageSpaces;
  }

  public void setGarageSpaces(AnyOforgResoMetadataPropertyUpdateGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
  }

  public OrgResoMetadataPropertyUpdate garageYN(Boolean garageYN) {
    this.garageYN = garageYN;
    return this;
  }

  /**
   * Get garageYN
   * @return garageYN
   **/
  @Schema(description = "")
  
    public Boolean isGarageYN() {
    return garageYN;
  }

  public void setGarageYN(Boolean garageYN) {
    this.garageYN = garageYN;
  }

  public OrgResoMetadataPropertyUpdate gardenerExpense(AnyOforgResoMetadataPropertyUpdateGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
    return this;
  }

  /**
   * Get gardenerExpense
   * @return gardenerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateGardenerExpense getGardenerExpense() {
    return gardenerExpense;
  }

  public void setGardenerExpense(AnyOforgResoMetadataPropertyUpdateGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
  }

  public OrgResoMetadataPropertyUpdate grazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
    return this;
  }

  /**
   * Get grazingPermitsBlmYN
   * @return grazingPermitsBlmYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsBlmYN() {
    return grazingPermitsBlmYN;
  }

  public void setGrazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
  }

  public OrgResoMetadataPropertyUpdate grazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
    return this;
  }

  /**
   * Get grazingPermitsForestServiceYN
   * @return grazingPermitsForestServiceYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsForestServiceYN() {
    return grazingPermitsForestServiceYN;
  }

  public void setGrazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
  }

  public OrgResoMetadataPropertyUpdate grazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
    return this;
  }

  /**
   * Get grazingPermitsPrivateYN
   * @return grazingPermitsPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsPrivateYN() {
    return grazingPermitsPrivateYN;
  }

  public void setGrazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
  }

  public OrgResoMetadataPropertyUpdate greenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenBuildingVerificationTypeItem(OrgResoMetadataEnumsGreenBuildingVerificationType greenBuildingVerificationTypeItem) {
    if (this.greenBuildingVerificationType == null) {
      this.greenBuildingVerificationType = new ArrayList<OrgResoMetadataEnumsGreenBuildingVerificationType>();
    }
    this.greenBuildingVerificationType.add(greenBuildingVerificationTypeItem);
    return this;
  }

  /**
   * Get greenBuildingVerificationType
   * @return greenBuildingVerificationType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenBuildingVerificationType> getGreenBuildingVerificationType() {
    return greenBuildingVerificationType;
  }

  public void setGreenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
  }

  public OrgResoMetadataPropertyUpdate greenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenEnergyEfficientItem(OrgResoMetadataEnumsGreenEnergyEfficient greenEnergyEfficientItem) {
    if (this.greenEnergyEfficient == null) {
      this.greenEnergyEfficient = new ArrayList<OrgResoMetadataEnumsGreenEnergyEfficient>();
    }
    this.greenEnergyEfficient.add(greenEnergyEfficientItem);
    return this;
  }

  /**
   * Get greenEnergyEfficient
   * @return greenEnergyEfficient
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyEfficient> getGreenEnergyEfficient() {
    return greenEnergyEfficient;
  }

  public void setGreenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
  }

  public OrgResoMetadataPropertyUpdate greenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenEnergyGenerationItem(OrgResoMetadataEnumsGreenEnergyGeneration greenEnergyGenerationItem) {
    if (this.greenEnergyGeneration == null) {
      this.greenEnergyGeneration = new ArrayList<OrgResoMetadataEnumsGreenEnergyGeneration>();
    }
    this.greenEnergyGeneration.add(greenEnergyGenerationItem);
    return this;
  }

  /**
   * Get greenEnergyGeneration
   * @return greenEnergyGeneration
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyGeneration> getGreenEnergyGeneration() {
    return greenEnergyGeneration;
  }

  public void setGreenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
  }

  public OrgResoMetadataPropertyUpdate greenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenIndoorAirQualityItem(OrgResoMetadataEnumsGreenIndoorAirQuality greenIndoorAirQualityItem) {
    if (this.greenIndoorAirQuality == null) {
      this.greenIndoorAirQuality = new ArrayList<OrgResoMetadataEnumsGreenIndoorAirQuality>();
    }
    this.greenIndoorAirQuality.add(greenIndoorAirQualityItem);
    return this;
  }

  /**
   * Get greenIndoorAirQuality
   * @return greenIndoorAirQuality
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenIndoorAirQuality> getGreenIndoorAirQuality() {
    return greenIndoorAirQuality;
  }

  public void setGreenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
  }

  public OrgResoMetadataPropertyUpdate greenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenLocationItem(OrgResoMetadataEnumsGreenLocation greenLocationItem) {
    if (this.greenLocation == null) {
      this.greenLocation = new ArrayList<OrgResoMetadataEnumsGreenLocation>();
    }
    this.greenLocation.add(greenLocationItem);
    return this;
  }

  /**
   * Get greenLocation
   * @return greenLocation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenLocation> getGreenLocation() {
    return greenLocation;
  }

  public void setGreenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
  }

  public OrgResoMetadataPropertyUpdate greenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenSustainabilityItem(OrgResoMetadataEnumsGreenSustainability greenSustainabilityItem) {
    if (this.greenSustainability == null) {
      this.greenSustainability = new ArrayList<OrgResoMetadataEnumsGreenSustainability>();
    }
    this.greenSustainability.add(greenSustainabilityItem);
    return this;
  }

  /**
   * Get greenSustainability
   * @return greenSustainability
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenSustainability> getGreenSustainability() {
    return greenSustainability;
  }

  public void setGreenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
  }

  public OrgResoMetadataPropertyUpdate greenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addGreenWaterConservationItem(OrgResoMetadataEnumsGreenWaterConservation greenWaterConservationItem) {
    if (this.greenWaterConservation == null) {
      this.greenWaterConservation = new ArrayList<OrgResoMetadataEnumsGreenWaterConservation>();
    }
    this.greenWaterConservation.add(greenWaterConservationItem);
    return this;
  }

  /**
   * Get greenWaterConservation
   * @return greenWaterConservation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenWaterConservation> getGreenWaterConservation() {
    return greenWaterConservation;
  }

  public void setGreenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
  }

  public OrgResoMetadataPropertyUpdate grossIncome(AnyOforgResoMetadataPropertyUpdateGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
    return this;
  }

  /**
   * Get grossIncome
   * @return grossIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateGrossIncome getGrossIncome() {
    return grossIncome;
  }

  public void setGrossIncome(AnyOforgResoMetadataPropertyUpdateGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
  }

  public OrgResoMetadataPropertyUpdate grossScheduledIncome(AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
    return this;
  }

  /**
   * Get grossScheduledIncome
   * @return grossScheduledIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome getGrossScheduledIncome() {
    return grossScheduledIncome;
  }

  public void setGrossScheduledIncome(AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
  }

  public OrgResoMetadataPropertyUpdate habitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
    return this;
  }

  /**
   * Get habitableResidenceYN
   * @return habitableResidenceYN
   **/
  @Schema(description = "")
  
    public Boolean isHabitableResidenceYN() {
    return habitableResidenceYN;
  }

  public void setHabitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
  }

  public OrgResoMetadataPropertyUpdate heating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addHeatingItem(OrgResoMetadataEnumsHeating heatingItem) {
    if (this.heating == null) {
      this.heating = new ArrayList<OrgResoMetadataEnumsHeating>();
    }
    this.heating.add(heatingItem);
    return this;
  }

  /**
   * Get heating
   * @return heating
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHeating> getHeating() {
    return heating;
  }

  public void setHeating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
  }

  public OrgResoMetadataPropertyUpdate heatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
    return this;
  }

  /**
   * Get heatingYN
   * @return heatingYN
   **/
  @Schema(description = "")
  
    public Boolean isHeatingYN() {
    return heatingYN;
  }

  public void setHeatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
  }

  public OrgResoMetadataPropertyUpdate highSchool(AnyOforgResoMetadataPropertyUpdateHighSchool highSchool) {
    this.highSchool = highSchool;
    return this;
  }

  /**
   * Get highSchool
   * @return highSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateHighSchool getHighSchool() {
    return highSchool;
  }

  public void setHighSchool(AnyOforgResoMetadataPropertyUpdateHighSchool highSchool) {
    this.highSchool = highSchool;
  }

  public OrgResoMetadataPropertyUpdate highSchoolDistrict(AnyOforgResoMetadataPropertyUpdateHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
    return this;
  }

  /**
   * Get highSchoolDistrict
   * @return highSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateHighSchoolDistrict getHighSchoolDistrict() {
    return highSchoolDistrict;
  }

  public void setHighSchoolDistrict(AnyOforgResoMetadataPropertyUpdateHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
  }

  public OrgResoMetadataPropertyUpdate homeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
    return this;
  }

  /**
   * Get homeWarrantyYN
   * @return homeWarrantyYN
   **/
  @Schema(description = "")
  
    public Boolean isHomeWarrantyYN() {
    return homeWarrantyYN;
  }

  public void setHomeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
  }

  public OrgResoMetadataPropertyUpdate horseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addHorseAmenitiesItem(OrgResoMetadataEnumsHorseAmenities horseAmenitiesItem) {
    if (this.horseAmenities == null) {
      this.horseAmenities = new ArrayList<OrgResoMetadataEnumsHorseAmenities>();
    }
    this.horseAmenities.add(horseAmenitiesItem);
    return this;
  }

  /**
   * Get horseAmenities
   * @return horseAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHorseAmenities> getHorseAmenities() {
    return horseAmenities;
  }

  public void setHorseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
  }

  public OrgResoMetadataPropertyUpdate horseYN(Boolean horseYN) {
    this.horseYN = horseYN;
    return this;
  }

  /**
   * Get horseYN
   * @return horseYN
   **/
  @Schema(description = "")
  
    public Boolean isHorseYN() {
    return horseYN;
  }

  public void setHorseYN(Boolean horseYN) {
    this.horseYN = horseYN;
  }

  public OrgResoMetadataPropertyUpdate hoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addHoursDaysOfOperationItem(OrgResoMetadataEnumsHoursDaysOfOperation hoursDaysOfOperationItem) {
    if (this.hoursDaysOfOperation == null) {
      this.hoursDaysOfOperation = new ArrayList<OrgResoMetadataEnumsHoursDaysOfOperation>();
    }
    this.hoursDaysOfOperation.add(hoursDaysOfOperationItem);
    return this;
  }

  /**
   * Get hoursDaysOfOperation
   * @return hoursDaysOfOperation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHoursDaysOfOperation> getHoursDaysOfOperation() {
    return hoursDaysOfOperation;
  }

  public void setHoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
  }

  public OrgResoMetadataPropertyUpdate hoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
    return this;
  }

  /**
   * Get hoursDaysOfOperationDescription
   * @return hoursDaysOfOperationDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getHoursDaysOfOperationDescription() {
    return hoursDaysOfOperationDescription;
  }

  public void setHoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
  }

  public OrgResoMetadataPropertyUpdate inclusions(String inclusions) {
    this.inclusions = inclusions;
    return this;
  }

  /**
   * Get inclusions
   * @return inclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getInclusions() {
    return inclusions;
  }

  public void setInclusions(String inclusions) {
    this.inclusions = inclusions;
  }

  public OrgResoMetadataPropertyUpdate incomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addIncomeIncludesItem(OrgResoMetadataEnumsIncomeIncludes incomeIncludesItem) {
    if (this.incomeIncludes == null) {
      this.incomeIncludes = new ArrayList<OrgResoMetadataEnumsIncomeIncludes>();
    }
    this.incomeIncludes.add(incomeIncludesItem);
    return this;
  }

  /**
   * Get incomeIncludes
   * @return incomeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIncomeIncludes> getIncomeIncludes() {
    return incomeIncludes;
  }

  public void setIncomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
  }

  public OrgResoMetadataPropertyUpdate insuranceExpense(AnyOforgResoMetadataPropertyUpdateInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
    return this;
  }

  /**
   * Get insuranceExpense
   * @return insuranceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateInsuranceExpense getInsuranceExpense() {
    return insuranceExpense;
  }

  public void setInsuranceExpense(AnyOforgResoMetadataPropertyUpdateInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
  }

  public OrgResoMetadataPropertyUpdate interiorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addInteriorFeaturesItem(OrgResoMetadataEnumsInteriorOrRoomFeatures interiorFeaturesItem) {
    if (this.interiorFeatures == null) {
      this.interiorFeatures = new ArrayList<OrgResoMetadataEnumsInteriorOrRoomFeatures>();
    }
    this.interiorFeatures.add(interiorFeaturesItem);
    return this;
  }

  /**
   * Get interiorFeatures
   * @return interiorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsInteriorOrRoomFeatures> getInteriorFeatures() {
    return interiorFeatures;
  }

  public void setInteriorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
  }

  public OrgResoMetadataPropertyUpdate internetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
    return this;
  }

  /**
   * Get internetAddressDisplayYN
   * @return internetAddressDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAddressDisplayYN() {
    return internetAddressDisplayYN;
  }

  public void setInternetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
  }

  public OrgResoMetadataPropertyUpdate internetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
    return this;
  }

  /**
   * Get internetAutomatedValuationDisplayYN
   * @return internetAutomatedValuationDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAutomatedValuationDisplayYN() {
    return internetAutomatedValuationDisplayYN;
  }

  public void setInternetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
  }

  public OrgResoMetadataPropertyUpdate internetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
    return this;
  }

  /**
   * Get internetConsumerCommentYN
   * @return internetConsumerCommentYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetConsumerCommentYN() {
    return internetConsumerCommentYN;
  }

  public void setInternetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
  }

  public OrgResoMetadataPropertyUpdate internetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
    return this;
  }

  /**
   * Get internetEntireListingDisplayYN
   * @return internetEntireListingDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetEntireListingDisplayYN() {
    return internetEntireListingDisplayYN;
  }

  public void setInternetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
  }

  public OrgResoMetadataPropertyUpdate irrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addIrrigationSourceItem(OrgResoMetadataEnumsIrrigationSource irrigationSourceItem) {
    if (this.irrigationSource == null) {
      this.irrigationSource = new ArrayList<OrgResoMetadataEnumsIrrigationSource>();
    }
    this.irrigationSource.add(irrigationSourceItem);
    return this;
  }

  /**
   * Get irrigationSource
   * @return irrigationSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIrrigationSource> getIrrigationSource() {
    return irrigationSource;
  }

  public void setIrrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
  }

  public OrgResoMetadataPropertyUpdate irrigationWaterRightsAcres(AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
    return this;
  }

  /**
   * Get irrigationWaterRightsAcres
   * @return irrigationWaterRightsAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres getIrrigationWaterRightsAcres() {
    return irrigationWaterRightsAcres;
  }

  public void setIrrigationWaterRightsAcres(AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
  }

  public OrgResoMetadataPropertyUpdate irrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
    return this;
  }

  /**
   * Get irrigationWaterRightsYN
   * @return irrigationWaterRightsYN
   **/
  @Schema(description = "")
  
    public Boolean isIrrigationWaterRightsYN() {
    return irrigationWaterRightsYN;
  }

  public void setIrrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
  }

  public OrgResoMetadataPropertyUpdate laborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLaborInformationItem(OrgResoMetadataEnumsLaborInformation laborInformationItem) {
    if (this.laborInformation == null) {
      this.laborInformation = new ArrayList<OrgResoMetadataEnumsLaborInformation>();
    }
    this.laborInformation.add(laborInformationItem);
    return this;
  }

  /**
   * Get laborInformation
   * @return laborInformation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaborInformation> getLaborInformation() {
    return laborInformation;
  }

  public void setLaborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
  }

  public OrgResoMetadataPropertyUpdate landLeaseAmount(AnyOforgResoMetadataPropertyUpdateLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
    return this;
  }

  /**
   * Get landLeaseAmount
   * @return landLeaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLandLeaseAmount getLandLeaseAmount() {
    return landLeaseAmount;
  }

  public void setLandLeaseAmount(AnyOforgResoMetadataPropertyUpdateLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
  }

  public OrgResoMetadataPropertyUpdate landLeaseAmountFrequency(AnyOforgResoMetadataPropertyUpdateLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
    return this;
  }

  /**
   * Get landLeaseAmountFrequency
   * @return landLeaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLandLeaseAmountFrequency getLandLeaseAmountFrequency() {
    return landLeaseAmountFrequency;
  }

  public void setLandLeaseAmountFrequency(AnyOforgResoMetadataPropertyUpdateLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
  }

  public OrgResoMetadataPropertyUpdate landLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
    return this;
  }

  /**
   * Get landLeaseExpirationDate
   * @return landLeaseExpirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLandLeaseExpirationDate() {
    return landLeaseExpirationDate;
  }

  public void setLandLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
  }

  public OrgResoMetadataPropertyUpdate landLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
    return this;
  }

  /**
   * Get landLeaseYN
   * @return landLeaseYN
   **/
  @Schema(description = "")
  
    public Boolean isLandLeaseYN() {
    return landLeaseYN;
  }

  public void setLandLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
  }

  public OrgResoMetadataPropertyUpdate latitude(AnyOforgResoMetadataPropertyUpdateLatitude latitude) {
    this.latitude = latitude;
    return this;
  }

  /**
   * Get latitude
   * @return latitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLatitude getLatitude() {
    return latitude;
  }

  public void setLatitude(AnyOforgResoMetadataPropertyUpdateLatitude latitude) {
    this.latitude = latitude;
  }

  public OrgResoMetadataPropertyUpdate laundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLaundryFeaturesItem(OrgResoMetadataEnumsLaundryFeatures laundryFeaturesItem) {
    if (this.laundryFeatures == null) {
      this.laundryFeatures = new ArrayList<OrgResoMetadataEnumsLaundryFeatures>();
    }
    this.laundryFeatures.add(laundryFeaturesItem);
    return this;
  }

  /**
   * Get laundryFeatures
   * @return laundryFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaundryFeatures> getLaundryFeatures() {
    return laundryFeatures;
  }

  public void setLaundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
  }

  public OrgResoMetadataPropertyUpdate leasableArea(AnyOforgResoMetadataPropertyUpdateLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
    return this;
  }

  /**
   * Get leasableArea
   * @return leasableArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLeasableArea getLeasableArea() {
    return leasableArea;
  }

  public void setLeasableArea(AnyOforgResoMetadataPropertyUpdateLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
  }

  public OrgResoMetadataPropertyUpdate leasableAreaUnits(AnyOforgResoMetadataPropertyUpdateLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
    return this;
  }

  /**
   * Get leasableAreaUnits
   * @return leasableAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLeasableAreaUnits getLeasableAreaUnits() {
    return leasableAreaUnits;
  }

  public void setLeasableAreaUnits(AnyOforgResoMetadataPropertyUpdateLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate leaseAmount(AnyOforgResoMetadataPropertyUpdateLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
    return this;
  }

  /**
   * Get leaseAmount
   * @return leaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLeaseAmount getLeaseAmount() {
    return leaseAmount;
  }

  public void setLeaseAmount(AnyOforgResoMetadataPropertyUpdateLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
  }

  public OrgResoMetadataPropertyUpdate leaseAmountFrequency(AnyOforgResoMetadataPropertyUpdateLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
    return this;
  }

  /**
   * Get leaseAmountFrequency
   * @return leaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLeaseAmountFrequency getLeaseAmountFrequency() {
    return leaseAmountFrequency;
  }

  public void setLeaseAmountFrequency(AnyOforgResoMetadataPropertyUpdateLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
  }

  public OrgResoMetadataPropertyUpdate leaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
    return this;
  }

  /**
   * Get leaseAssignableYN
   * @return leaseAssignableYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseAssignableYN() {
    return leaseAssignableYN;
  }

  public void setLeaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
  }

  public OrgResoMetadataPropertyUpdate leaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
    return this;
  }

  /**
   * Get leaseConsideredYN
   * @return leaseConsideredYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseConsideredYN() {
    return leaseConsideredYN;
  }

  public void setLeaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
  }

  public OrgResoMetadataPropertyUpdate leaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
    return this;
  }

  /**
   * Get leaseExpiration
   * @return leaseExpiration
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLeaseExpiration() {
    return leaseExpiration;
  }

  public void setLeaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
  }

  public OrgResoMetadataPropertyUpdate leaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLeaseRenewalCompensationItem(OrgResoMetadataEnumsLeaseRenewalCompensation leaseRenewalCompensationItem) {
    if (this.leaseRenewalCompensation == null) {
      this.leaseRenewalCompensation = new ArrayList<OrgResoMetadataEnumsLeaseRenewalCompensation>();
    }
    this.leaseRenewalCompensation.add(leaseRenewalCompensationItem);
    return this;
  }

  /**
   * Get leaseRenewalCompensation
   * @return leaseRenewalCompensation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLeaseRenewalCompensation> getLeaseRenewalCompensation() {
    return leaseRenewalCompensation;
  }

  public void setLeaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
  }

  public OrgResoMetadataPropertyUpdate leaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
    return this;
  }

  /**
   * Get leaseRenewalOptionYN
   * @return leaseRenewalOptionYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseRenewalOptionYN() {
    return leaseRenewalOptionYN;
  }

  public void setLeaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
  }

  public OrgResoMetadataPropertyUpdate leaseTerm(AnyOforgResoMetadataPropertyUpdateLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
    return this;
  }

  /**
   * Get leaseTerm
   * @return leaseTerm
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLeaseTerm getLeaseTerm() {
    return leaseTerm;
  }

  public void setLeaseTerm(AnyOforgResoMetadataPropertyUpdateLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
  }

  public OrgResoMetadataPropertyUpdate levels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLevelsItem(OrgResoMetadataEnumsLevels levelsItem) {
    if (this.levels == null) {
      this.levels = new ArrayList<OrgResoMetadataEnumsLevels>();
    }
    this.levels.add(levelsItem);
    return this;
  }

  /**
   * Get levels
   * @return levels
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLevels> getLevels() {
    return levels;
  }

  public void setLevels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
  }

  public OrgResoMetadataPropertyUpdate license1(String license1) {
    this.license1 = license1;
    return this;
  }

  /**
   * Get license1
   * @return license1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense1() {
    return license1;
  }

  public void setLicense1(String license1) {
    this.license1 = license1;
  }

  public OrgResoMetadataPropertyUpdate license2(String license2) {
    this.license2 = license2;
    return this;
  }

  /**
   * Get license2
   * @return license2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense2() {
    return license2;
  }

  public void setLicense2(String license2) {
    this.license2 = license2;
  }

  public OrgResoMetadataPropertyUpdate license3(String license3) {
    this.license3 = license3;
    return this;
  }

  /**
   * Get license3
   * @return license3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense3() {
    return license3;
  }

  public void setLicense3(String license3) {
    this.license3 = license3;
  }

  public OrgResoMetadataPropertyUpdate licensesExpense(AnyOforgResoMetadataPropertyUpdateLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
    return this;
  }

  /**
   * Get licensesExpense
   * @return licensesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLicensesExpense getLicensesExpense() {
    return licensesExpense;
  }

  public void setLicensesExpense(AnyOforgResoMetadataPropertyUpdateLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
  }

  public OrgResoMetadataPropertyUpdate listAOR(AnyOforgResoMetadataPropertyUpdateListAOR listAOR) {
    this.listAOR = listAOR;
    return this;
  }

  /**
   * Get listAOR
   * @return listAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListAOR getListAOR() {
    return listAOR;
  }

  public void setListAOR(AnyOforgResoMetadataPropertyUpdateListAOR listAOR) {
    this.listAOR = listAOR;
  }

  public OrgResoMetadataPropertyUpdate listAgentAOR(AnyOforgResoMetadataPropertyUpdateListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
    return this;
  }

  /**
   * Get listAgentAOR
   * @return listAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListAgentAOR getListAgentAOR() {
    return listAgentAOR;
  }

  public void setListAgentAOR(AnyOforgResoMetadataPropertyUpdateListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
  }

  public OrgResoMetadataPropertyUpdate listAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addListAgentDesignationItem(OrgResoMetadataEnumsListAgentDesignation listAgentDesignationItem) {
    if (this.listAgentDesignation == null) {
      this.listAgentDesignation = new ArrayList<OrgResoMetadataEnumsListAgentDesignation>();
    }
    this.listAgentDesignation.add(listAgentDesignationItem);
    return this;
  }

  /**
   * Get listAgentDesignation
   * @return listAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListAgentDesignation> getListAgentDesignation() {
    return listAgentDesignation;
  }

  public void setListAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
  }

  public OrgResoMetadataPropertyUpdate listAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
    return this;
  }

  /**
   * Get listAgentDirectPhone
   * @return listAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentDirectPhone() {
    return listAgentDirectPhone;
  }

  public void setListAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
    return this;
  }

  /**
   * Get listAgentEmail
   * @return listAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListAgentEmail() {
    return listAgentEmail;
  }

  public void setListAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
  }

  public OrgResoMetadataPropertyUpdate listAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
    return this;
  }

  /**
   * Get listAgentFax
   * @return listAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentFax() {
    return listAgentFax;
  }

  public void setListAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
  }

  public OrgResoMetadataPropertyUpdate listAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
    return this;
  }

  /**
   * Get listAgentFirstName
   * @return listAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentFirstName() {
    return listAgentFirstName;
  }

  public void setListAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
  }

  public OrgResoMetadataPropertyUpdate listAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
    return this;
  }

  /**
   * Get listAgentFullName
   * @return listAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getListAgentFullName() {
    return listAgentFullName;
  }

  public void setListAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
  }

  public OrgResoMetadataPropertyUpdate listAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
    return this;
  }

  /**
   * Get listAgentHomePhone
   * @return listAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentHomePhone() {
    return listAgentHomePhone;
  }

  public void setListAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
    return this;
  }

  /**
   * Get listAgentKey
   * @return listAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListAgentKey() {
    return listAgentKey;
  }

  public void setListAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
  }

  public OrgResoMetadataPropertyUpdate listAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
    return this;
  }

  /**
   * Get listAgentKeyNumeric
   * @return listAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric getListAgentKeyNumeric() {
    return listAgentKeyNumeric;
  }

  public void setListAgentKeyNumeric(AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate listAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
    return this;
  }

  /**
   * Get listAgentLastName
   * @return listAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentLastName() {
    return listAgentLastName;
  }

  public void setListAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
  }

  public OrgResoMetadataPropertyUpdate listAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
    return this;
  }

  /**
   * Get listAgentMiddleName
   * @return listAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentMiddleName() {
    return listAgentMiddleName;
  }

  public void setListAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
  }

  public OrgResoMetadataPropertyUpdate listAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
    return this;
  }

  /**
   * Get listAgentMlsId
   * @return listAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListAgentMlsId() {
    return listAgentMlsId;
  }

  public void setListAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
  }

  public OrgResoMetadataPropertyUpdate listAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
    return this;
  }

  /**
   * Get listAgentMobilePhone
   * @return listAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentMobilePhone() {
    return listAgentMobilePhone;
  }

  public void setListAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
    return this;
  }

  /**
   * Get listAgentNamePrefix
   * @return listAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNamePrefix() {
    return listAgentNamePrefix;
  }

  public void setListAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
  }

  public OrgResoMetadataPropertyUpdate listAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
    return this;
  }

  /**
   * Get listAgentNameSuffix
   * @return listAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNameSuffix() {
    return listAgentNameSuffix;
  }

  public void setListAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
  }

  public OrgResoMetadataPropertyUpdate listAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
    return this;
  }

  /**
   * Get listAgentOfficePhone
   * @return listAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentOfficePhone() {
    return listAgentOfficePhone;
  }

  public void setListAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get listAgentOfficePhoneExt
   * @return listAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentOfficePhoneExt() {
    return listAgentOfficePhoneExt;
  }

  public void setListAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate listAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
    return this;
  }

  /**
   * Get listAgentPager
   * @return listAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPager() {
    return listAgentPager;
  }

  public void setListAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
  }

  public OrgResoMetadataPropertyUpdate listAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
    return this;
  }

  /**
   * Get listAgentPreferredPhone
   * @return listAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPreferredPhone() {
    return listAgentPreferredPhone;
  }

  public void setListAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get listAgentPreferredPhoneExt
   * @return listAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentPreferredPhoneExt() {
    return listAgentPreferredPhoneExt;
  }

  public void setListAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyUpdate listAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
    return this;
  }

  /**
   * Get listAgentStateLicense
   * @return listAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentStateLicense() {
    return listAgentStateLicense;
  }

  public void setListAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
  }

  public OrgResoMetadataPropertyUpdate listAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
    return this;
  }

  /**
   * Get listAgentTollFreePhone
   * @return listAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentTollFreePhone() {
    return listAgentTollFreePhone;
  }

  public void setListAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyUpdate listAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
    return this;
  }

  /**
   * Get listAgentURL
   * @return listAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListAgentURL() {
    return listAgentURL;
  }

  public void setListAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
  }

  public OrgResoMetadataPropertyUpdate listAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
    return this;
  }

  /**
   * Get listAgentVoiceMail
   * @return listAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentVoiceMail() {
    return listAgentVoiceMail;
  }

  public void setListAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
  }

  public OrgResoMetadataPropertyUpdate listAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
    return this;
  }

  /**
   * Get listAgentVoiceMailExt
   * @return listAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentVoiceMailExt() {
    return listAgentVoiceMailExt;
  }

  public void setListAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyUpdate listOfficeAOR(AnyOforgResoMetadataPropertyUpdateListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
    return this;
  }

  /**
   * Get listOfficeAOR
   * @return listOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListOfficeAOR getListOfficeAOR() {
    return listOfficeAOR;
  }

  public void setListOfficeAOR(AnyOforgResoMetadataPropertyUpdateListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
  }

  public OrgResoMetadataPropertyUpdate listOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
    return this;
  }

  /**
   * Get listOfficeEmail
   * @return listOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListOfficeEmail() {
    return listOfficeEmail;
  }

  public void setListOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
  }

  public OrgResoMetadataPropertyUpdate listOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
    return this;
  }

  /**
   * Get listOfficeFax
   * @return listOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficeFax() {
    return listOfficeFax;
  }

  public void setListOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
  }

  public OrgResoMetadataPropertyUpdate listOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
    return this;
  }

  /**
   * Get listOfficeKey
   * @return listOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeKey() {
    return listOfficeKey;
  }

  public void setListOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
  }

  public OrgResoMetadataPropertyUpdate listOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
    return this;
  }

  /**
   * Get listOfficeKeyNumeric
   * @return listOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListOfficeKeyNumeric getListOfficeKeyNumeric() {
    return listOfficeKeyNumeric;
  }

  public void setListOfficeKeyNumeric(AnyOforgResoMetadataPropertyUpdateListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate listOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
    return this;
  }

  /**
   * Get listOfficeMlsId
   * @return listOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListOfficeMlsId() {
    return listOfficeMlsId;
  }

  public void setListOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
  }

  public OrgResoMetadataPropertyUpdate listOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
    return this;
  }

  /**
   * Get listOfficeName
   * @return listOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeName() {
    return listOfficeName;
  }

  public void setListOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
  }

  public OrgResoMetadataPropertyUpdate listOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
    return this;
  }

  /**
   * Get listOfficePhone
   * @return listOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficePhone() {
    return listOfficePhone;
  }

  public void setListOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
  }

  public OrgResoMetadataPropertyUpdate listOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
    return this;
  }

  /**
   * Get listOfficePhoneExt
   * @return listOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListOfficePhoneExt() {
    return listOfficePhoneExt;
  }

  public void setListOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
  }

  public OrgResoMetadataPropertyUpdate listOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
    return this;
  }

  /**
   * Get listOfficeURL
   * @return listOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListOfficeURL() {
    return listOfficeURL;
  }

  public void setListOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
  }

  public OrgResoMetadataPropertyUpdate listPrice(AnyOforgResoMetadataPropertyUpdateListPrice listPrice) {
    this.listPrice = listPrice;
    return this;
  }

  /**
   * Get listPrice
   * @return listPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListPrice getListPrice() {
    return listPrice;
  }

  public void setListPrice(AnyOforgResoMetadataPropertyUpdateListPrice listPrice) {
    this.listPrice = listPrice;
  }

  public OrgResoMetadataPropertyUpdate listPriceLow(AnyOforgResoMetadataPropertyUpdateListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
    return this;
  }

  /**
   * Get listPriceLow
   * @return listPriceLow
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListPriceLow getListPriceLow() {
    return listPriceLow;
  }

  public void setListPriceLow(AnyOforgResoMetadataPropertyUpdateListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
  }

  public OrgResoMetadataPropertyUpdate listTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
    return this;
  }

  /**
   * Get listTeamKey
   * @return listTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListTeamKey() {
    return listTeamKey;
  }

  public void setListTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
  }

  public OrgResoMetadataPropertyUpdate listTeamKeyNumeric(AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
    return this;
  }

  /**
   * Get listTeamKeyNumeric
   * @return listTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric getListTeamKeyNumeric() {
    return listTeamKeyNumeric;
  }

  public void setListTeamKeyNumeric(AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate listTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
    return this;
  }

  /**
   * Get listTeamName
   * @return listTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListTeamName() {
    return listTeamName;
  }

  public void setListTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
  }

  public OrgResoMetadataPropertyUpdate listingAgreement(AnyOforgResoMetadataPropertyUpdateListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
    return this;
  }

  /**
   * Get listingAgreement
   * @return listingAgreement
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListingAgreement getListingAgreement() {
    return listingAgreement;
  }

  public void setListingAgreement(AnyOforgResoMetadataPropertyUpdateListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
  }

  public OrgResoMetadataPropertyUpdate listingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
    return this;
  }

  /**
   * Get listingContractDate
   * @return listingContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getListingContractDate() {
    return listingContractDate;
  }

  public void setListingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
  }

  public OrgResoMetadataPropertyUpdate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataPropertyUpdate listingKeyNumeric(AnyOforgResoMetadataPropertyUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataPropertyUpdate listingService(AnyOforgResoMetadataPropertyUpdateListingService listingService) {
    this.listingService = listingService;
    return this;
  }

  /**
   * Get listingService
   * @return listingService
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateListingService getListingService() {
    return listingService;
  }

  public void setListingService(AnyOforgResoMetadataPropertyUpdateListingService listingService) {
    this.listingService = listingService;
  }

  public OrgResoMetadataPropertyUpdate listingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addListingTermsItem(OrgResoMetadataEnumsListingTerms listingTermsItem) {
    if (this.listingTerms == null) {
      this.listingTerms = new ArrayList<OrgResoMetadataEnumsListingTerms>();
    }
    this.listingTerms.add(listingTermsItem);
    return this;
  }

  /**
   * Get listingTerms
   * @return listingTerms
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListingTerms> getListingTerms() {
    return listingTerms;
  }

  public void setListingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
  }

  public OrgResoMetadataPropertyUpdate livingArea(AnyOforgResoMetadataPropertyUpdateLivingArea livingArea) {
    this.livingArea = livingArea;
    return this;
  }

  /**
   * Get livingArea
   * @return livingArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLivingArea getLivingArea() {
    return livingArea;
  }

  public void setLivingArea(AnyOforgResoMetadataPropertyUpdateLivingArea livingArea) {
    this.livingArea = livingArea;
  }

  public OrgResoMetadataPropertyUpdate livingAreaSource(AnyOforgResoMetadataPropertyUpdateLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
    return this;
  }

  /**
   * Get livingAreaSource
   * @return livingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLivingAreaSource getLivingAreaSource() {
    return livingAreaSource;
  }

  public void setLivingAreaSource(AnyOforgResoMetadataPropertyUpdateLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
  }

  public OrgResoMetadataPropertyUpdate livingAreaUnits(AnyOforgResoMetadataPropertyUpdateLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
    return this;
  }

  /**
   * Get livingAreaUnits
   * @return livingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLivingAreaUnits getLivingAreaUnits() {
    return livingAreaUnits;
  }

  public void setLivingAreaUnits(AnyOforgResoMetadataPropertyUpdateLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
  }

  public OrgResoMetadataPropertyUpdate lockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
    return this;
  }

  /**
   * Get lockBoxLocation
   * @return lockBoxLocation
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getLockBoxLocation() {
    return lockBoxLocation;
  }

  public void setLockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
  }

  public OrgResoMetadataPropertyUpdate lockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
    return this;
  }

  /**
   * Get lockBoxSerialNumber
   * @return lockBoxSerialNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLockBoxSerialNumber() {
    return lockBoxSerialNumber;
  }

  public void setLockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
  }

  public OrgResoMetadataPropertyUpdate lockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLockBoxTypeItem(OrgResoMetadataEnumsLockBoxType lockBoxTypeItem) {
    if (this.lockBoxType == null) {
      this.lockBoxType = new ArrayList<OrgResoMetadataEnumsLockBoxType>();
    }
    this.lockBoxType.add(lockBoxTypeItem);
    return this;
  }

  /**
   * Get lockBoxType
   * @return lockBoxType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLockBoxType> getLockBoxType() {
    return lockBoxType;
  }

  public void setLockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
  }

  public OrgResoMetadataPropertyUpdate longitude(AnyOforgResoMetadataPropertyUpdateLongitude longitude) {
    this.longitude = longitude;
    return this;
  }

  /**
   * Get longitude
   * @return longitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLongitude getLongitude() {
    return longitude;
  }

  public void setLongitude(AnyOforgResoMetadataPropertyUpdateLongitude longitude) {
    this.longitude = longitude;
  }

  public OrgResoMetadataPropertyUpdate lotDimensionsSource(AnyOforgResoMetadataPropertyUpdateLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
    return this;
  }

  /**
   * Get lotDimensionsSource
   * @return lotDimensionsSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotDimensionsSource getLotDimensionsSource() {
    return lotDimensionsSource;
  }

  public void setLotDimensionsSource(AnyOforgResoMetadataPropertyUpdateLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
  }

  public OrgResoMetadataPropertyUpdate lotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addLotFeaturesItem(OrgResoMetadataEnumsLotFeatures lotFeaturesItem) {
    if (this.lotFeatures == null) {
      this.lotFeatures = new ArrayList<OrgResoMetadataEnumsLotFeatures>();
    }
    this.lotFeatures.add(lotFeaturesItem);
    return this;
  }

  /**
   * Get lotFeatures
   * @return lotFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLotFeatures> getLotFeatures() {
    return lotFeatures;
  }

  public void setLotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
  }

  public OrgResoMetadataPropertyUpdate lotSizeAcres(AnyOforgResoMetadataPropertyUpdateLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
    return this;
  }

  /**
   * Get lotSizeAcres
   * @return lotSizeAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotSizeAcres getLotSizeAcres() {
    return lotSizeAcres;
  }

  public void setLotSizeAcres(AnyOforgResoMetadataPropertyUpdateLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
  }

  public OrgResoMetadataPropertyUpdate lotSizeArea(AnyOforgResoMetadataPropertyUpdateLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
    return this;
  }

  /**
   * Get lotSizeArea
   * @return lotSizeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotSizeArea getLotSizeArea() {
    return lotSizeArea;
  }

  public void setLotSizeArea(AnyOforgResoMetadataPropertyUpdateLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
  }

  public OrgResoMetadataPropertyUpdate lotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
    return this;
  }

  /**
   * Get lotSizeDimensions
   * @return lotSizeDimensions
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getLotSizeDimensions() {
    return lotSizeDimensions;
  }

  public void setLotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
  }

  public OrgResoMetadataPropertyUpdate lotSizeSource(AnyOforgResoMetadataPropertyUpdateLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
    return this;
  }

  /**
   * Get lotSizeSource
   * @return lotSizeSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotSizeSource getLotSizeSource() {
    return lotSizeSource;
  }

  public void setLotSizeSource(AnyOforgResoMetadataPropertyUpdateLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
  }

  public OrgResoMetadataPropertyUpdate lotSizeSquareFeet(AnyOforgResoMetadataPropertyUpdateLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
    return this;
  }

  /**
   * Get lotSizeSquareFeet
   * @return lotSizeSquareFeet
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotSizeSquareFeet getLotSizeSquareFeet() {
    return lotSizeSquareFeet;
  }

  public void setLotSizeSquareFeet(AnyOforgResoMetadataPropertyUpdateLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
  }

  public OrgResoMetadataPropertyUpdate lotSizeUnits(AnyOforgResoMetadataPropertyUpdateLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
    return this;
  }

  /**
   * Get lotSizeUnits
   * @return lotSizeUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateLotSizeUnits getLotSizeUnits() {
    return lotSizeUnits;
  }

  public void setLotSizeUnits(AnyOforgResoMetadataPropertyUpdateLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
  }

  public OrgResoMetadataPropertyUpdate mlSAreaMajor(AnyOforgResoMetadataPropertyUpdateMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
    return this;
  }

  /**
   * Get mlSAreaMajor
   * @return mlSAreaMajor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMlSAreaMajor getMlSAreaMajor() {
    return mlSAreaMajor;
  }

  public void setMlSAreaMajor(AnyOforgResoMetadataPropertyUpdateMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
  }

  public OrgResoMetadataPropertyUpdate mlSAreaMinor(AnyOforgResoMetadataPropertyUpdateMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
    return this;
  }

  /**
   * Get mlSAreaMinor
   * @return mlSAreaMinor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMlSAreaMinor getMlSAreaMinor() {
    return mlSAreaMinor;
  }

  public void setMlSAreaMinor(AnyOforgResoMetadataPropertyUpdateMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
  }

  public OrgResoMetadataPropertyUpdate mainLevelBathrooms(AnyOforgResoMetadataPropertyUpdateMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
    return this;
  }

  /**
   * Get mainLevelBathrooms
   * @return mainLevelBathrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMainLevelBathrooms getMainLevelBathrooms() {
    return mainLevelBathrooms;
  }

  public void setMainLevelBathrooms(AnyOforgResoMetadataPropertyUpdateMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
  }

  public OrgResoMetadataPropertyUpdate mainLevelBedrooms(AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
    return this;
  }

  /**
   * Get mainLevelBedrooms
   * @return mainLevelBedrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms getMainLevelBedrooms() {
    return mainLevelBedrooms;
  }

  public void setMainLevelBedrooms(AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
  }

  public OrgResoMetadataPropertyUpdate maintenanceExpense(AnyOforgResoMetadataPropertyUpdateMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
    return this;
  }

  /**
   * Get maintenanceExpense
   * @return maintenanceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMaintenanceExpense getMaintenanceExpense() {
    return maintenanceExpense;
  }

  public void setMaintenanceExpense(AnyOforgResoMetadataPropertyUpdateMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
  }

  public OrgResoMetadataPropertyUpdate majorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
    return this;
  }

  /**
   * Get majorChangeTimestamp
   * @return majorChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getMajorChangeTimestamp() {
    return majorChangeTimestamp;
  }

  public void setMajorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate majorChangeType(AnyOforgResoMetadataPropertyUpdateMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
    return this;
  }

  /**
   * Get majorChangeType
   * @return majorChangeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMajorChangeType getMajorChangeType() {
    return majorChangeType;
  }

  public void setMajorChangeType(AnyOforgResoMetadataPropertyUpdateMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
  }

  public OrgResoMetadataPropertyUpdate make(String make) {
    this.make = make;
    return this;
  }

  /**
   * Get make
   * @return make
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getMake() {
    return make;
  }

  public void setMake(String make) {
    this.make = make;
  }

  public OrgResoMetadataPropertyUpdate managerExpense(AnyOforgResoMetadataPropertyUpdateManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
    return this;
  }

  /**
   * Get managerExpense
   * @return managerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateManagerExpense getManagerExpense() {
    return managerExpense;
  }

  public void setManagerExpense(AnyOforgResoMetadataPropertyUpdateManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
  }

  public OrgResoMetadataPropertyUpdate mapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
    return this;
  }

  /**
   * Get mapCoordinate
   * @return mapCoordinate
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinate() {
    return mapCoordinate;
  }

  public void setMapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
  }

  public OrgResoMetadataPropertyUpdate mapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
    return this;
  }

  /**
   * Get mapCoordinateSource
   * @return mapCoordinateSource
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinateSource() {
    return mapCoordinateSource;
  }

  public void setMapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
  }

  public OrgResoMetadataPropertyUpdate mapURL(String mapURL) {
    this.mapURL = mapURL;
    return this;
  }

  /**
   * Get mapURL
   * @return mapURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getMapURL() {
    return mapURL;
  }

  public void setMapURL(String mapURL) {
    this.mapURL = mapURL;
  }

  public OrgResoMetadataPropertyUpdate middleOrJuniorSchool(AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
    return this;
  }

  /**
   * Get middleOrJuniorSchool
   * @return middleOrJuniorSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchool getMiddleOrJuniorSchool() {
    return middleOrJuniorSchool;
  }

  public void setMiddleOrJuniorSchool(AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
  }

  public OrgResoMetadataPropertyUpdate middleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
    return this;
  }

  /**
   * Get middleOrJuniorSchoolDistrict
   * @return middleOrJuniorSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchoolDistrict getMiddleOrJuniorSchoolDistrict() {
    return middleOrJuniorSchoolDistrict;
  }

  public void setMiddleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyUpdateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
  }

  public OrgResoMetadataPropertyUpdate mlsStatus(AnyOforgResoMetadataPropertyUpdateMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
    return this;
  }

  /**
   * Get mlsStatus
   * @return mlsStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMlsStatus getMlsStatus() {
    return mlsStatus;
  }

  public void setMlsStatus(AnyOforgResoMetadataPropertyUpdateMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
  }

  public OrgResoMetadataPropertyUpdate mobileDimUnits(AnyOforgResoMetadataPropertyUpdateMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
    return this;
  }

  /**
   * Get mobileDimUnits
   * @return mobileDimUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMobileDimUnits getMobileDimUnits() {
    return mobileDimUnits;
  }

  public void setMobileDimUnits(AnyOforgResoMetadataPropertyUpdateMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
  }

  public OrgResoMetadataPropertyUpdate mobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
    return this;
  }

  /**
   * Get mobileHomeRemainsYN
   * @return mobileHomeRemainsYN
   **/
  @Schema(description = "")
  
    public Boolean isMobileHomeRemainsYN() {
    return mobileHomeRemainsYN;
  }

  public void setMobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
  }

  public OrgResoMetadataPropertyUpdate mobileLength(AnyOforgResoMetadataPropertyUpdateMobileLength mobileLength) {
    this.mobileLength = mobileLength;
    return this;
  }

  /**
   * Get mobileLength
   * @return mobileLength
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMobileLength getMobileLength() {
    return mobileLength;
  }

  public void setMobileLength(AnyOforgResoMetadataPropertyUpdateMobileLength mobileLength) {
    this.mobileLength = mobileLength;
  }

  public OrgResoMetadataPropertyUpdate mobileWidth(AnyOforgResoMetadataPropertyUpdateMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
    return this;
  }

  /**
   * Get mobileWidth
   * @return mobileWidth
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateMobileWidth getMobileWidth() {
    return mobileWidth;
  }

  public void setMobileWidth(AnyOforgResoMetadataPropertyUpdateMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
  }

  public OrgResoMetadataPropertyUpdate model(String model) {
    this.model = model;
    return this;
  }

  /**
   * Get model
   * @return model
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public OrgResoMetadataPropertyUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataPropertyUpdate netOperatingIncome(AnyOforgResoMetadataPropertyUpdateNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
    return this;
  }

  /**
   * Get netOperatingIncome
   * @return netOperatingIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNetOperatingIncome getNetOperatingIncome() {
    return netOperatingIncome;
  }

  public void setNetOperatingIncome(AnyOforgResoMetadataPropertyUpdateNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
  }

  public OrgResoMetadataPropertyUpdate newConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
    return this;
  }

  /**
   * Get newConstructionYN
   * @return newConstructionYN
   **/
  @Schema(description = "")
  
    public Boolean isNewConstructionYN() {
    return newConstructionYN;
  }

  public void setNewConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
  }

  public OrgResoMetadataPropertyUpdate newTaxesExpense(AnyOforgResoMetadataPropertyUpdateNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
    return this;
  }

  /**
   * Get newTaxesExpense
   * @return newTaxesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNewTaxesExpense getNewTaxesExpense() {
    return newTaxesExpense;
  }

  public void setNewTaxesExpense(AnyOforgResoMetadataPropertyUpdateNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
  }

  public OrgResoMetadataPropertyUpdate numberOfBuildings(AnyOforgResoMetadataPropertyUpdateNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
    return this;
  }

  /**
   * Get numberOfBuildings
   * @return numberOfBuildings
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfBuildings getNumberOfBuildings() {
    return numberOfBuildings;
  }

  public void setNumberOfBuildings(AnyOforgResoMetadataPropertyUpdateNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
  }

  public OrgResoMetadataPropertyUpdate numberOfFullTimeEmployees(AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
    return this;
  }

  /**
   * Get numberOfFullTimeEmployees
   * @return numberOfFullTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees getNumberOfFullTimeEmployees() {
    return numberOfFullTimeEmployees;
  }

  public void setNumberOfFullTimeEmployees(AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
  }

  public OrgResoMetadataPropertyUpdate numberOfLots(AnyOforgResoMetadataPropertyUpdateNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
    return this;
  }

  /**
   * Get numberOfLots
   * @return numberOfLots
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfLots getNumberOfLots() {
    return numberOfLots;
  }

  public void setNumberOfLots(AnyOforgResoMetadataPropertyUpdateNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
  }

  public OrgResoMetadataPropertyUpdate numberOfPads(AnyOforgResoMetadataPropertyUpdateNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
    return this;
  }

  /**
   * Get numberOfPads
   * @return numberOfPads
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfPads getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(AnyOforgResoMetadataPropertyUpdateNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public OrgResoMetadataPropertyUpdate numberOfPartTimeEmployees(AnyOforgResoMetadataPropertyUpdateNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
    return this;
  }

  /**
   * Get numberOfPartTimeEmployees
   * @return numberOfPartTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfPartTimeEmployees getNumberOfPartTimeEmployees() {
    return numberOfPartTimeEmployees;
  }

  public void setNumberOfPartTimeEmployees(AnyOforgResoMetadataPropertyUpdateNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
  }

  public OrgResoMetadataPropertyUpdate numberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
    return this;
  }

  /**
   * Get numberOfSeparateElectricMeters
   * @return numberOfSeparateElectricMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters getNumberOfSeparateElectricMeters() {
    return numberOfSeparateElectricMeters;
  }

  public void setNumberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
  }

  public OrgResoMetadataPropertyUpdate numberOfSeparateGasMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
    return this;
  }

  /**
   * Get numberOfSeparateGasMeters
   * @return numberOfSeparateGasMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters getNumberOfSeparateGasMeters() {
    return numberOfSeparateGasMeters;
  }

  public void setNumberOfSeparateGasMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
  }

  public OrgResoMetadataPropertyUpdate numberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
    return this;
  }

  /**
   * Get numberOfSeparateWaterMeters
   * @return numberOfSeparateWaterMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfSeparateWaterMeters getNumberOfSeparateWaterMeters() {
    return numberOfSeparateWaterMeters;
  }

  public void setNumberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyUpdateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
  }

  public OrgResoMetadataPropertyUpdate numberOfUnitsInCommunity(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
    return this;
  }

  /**
   * Get numberOfUnitsInCommunity
   * @return numberOfUnitsInCommunity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfUnitsInCommunity getNumberOfUnitsInCommunity() {
    return numberOfUnitsInCommunity;
  }

  public void setNumberOfUnitsInCommunity(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
  }

  public OrgResoMetadataPropertyUpdate numberOfUnitsLeased(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
    return this;
  }

  /**
   * Get numberOfUnitsLeased
   * @return numberOfUnitsLeased
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfUnitsLeased getNumberOfUnitsLeased() {
    return numberOfUnitsLeased;
  }

  public void setNumberOfUnitsLeased(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
  }

  public OrgResoMetadataPropertyUpdate numberOfUnitsMoMo(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
    return this;
  }

  /**
   * Get numberOfUnitsMoMo
   * @return numberOfUnitsMoMo
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfUnitsMoMo getNumberOfUnitsMoMo() {
    return numberOfUnitsMoMo;
  }

  public void setNumberOfUnitsMoMo(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
  }

  public OrgResoMetadataPropertyUpdate numberOfUnitsTotal(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
    return this;
  }

  /**
   * Get numberOfUnitsTotal
   * @return numberOfUnitsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal getNumberOfUnitsTotal() {
    return numberOfUnitsTotal;
  }

  public void setNumberOfUnitsTotal(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
  }

  public OrgResoMetadataPropertyUpdate numberOfUnitsVacant(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
    return this;
  }

  /**
   * Get numberOfUnitsVacant
   * @return numberOfUnitsVacant
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateNumberOfUnitsVacant getNumberOfUnitsVacant() {
    return numberOfUnitsVacant;
  }

  public void setNumberOfUnitsVacant(AnyOforgResoMetadataPropertyUpdateNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
  }

  public OrgResoMetadataPropertyUpdate occupantName(String occupantName) {
    this.occupantName = occupantName;
    return this;
  }

  /**
   * Get occupantName
   * @return occupantName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOccupantName() {
    return occupantName;
  }

  public void setOccupantName(String occupantName) {
    this.occupantName = occupantName;
  }

  public OrgResoMetadataPropertyUpdate occupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
    return this;
  }

  /**
   * Get occupantPhone
   * @return occupantPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOccupantPhone() {
    return occupantPhone;
  }

  public void setOccupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
  }

  public OrgResoMetadataPropertyUpdate occupantType(AnyOforgResoMetadataPropertyUpdateOccupantType occupantType) {
    this.occupantType = occupantType;
    return this;
  }

  /**
   * Get occupantType
   * @return occupantType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOccupantType getOccupantType() {
    return occupantType;
  }

  public void setOccupantType(AnyOforgResoMetadataPropertyUpdateOccupantType occupantType) {
    this.occupantType = occupantType;
  }

  public OrgResoMetadataPropertyUpdate offMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
    return this;
  }

  /**
   * Get offMarketDate
   * @return offMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOffMarketDate() {
    return offMarketDate;
  }

  public void setOffMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
  }

  public OrgResoMetadataPropertyUpdate offMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
    return this;
  }

  /**
   * Get offMarketTimestamp
   * @return offMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOffMarketTimestamp() {
    return offMarketTimestamp;
  }

  public void setOffMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
  }

  public OrgResoMetadataPropertyUpdate onMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
    return this;
  }

  /**
   * Get onMarketDate
   * @return onMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOnMarketDate() {
    return onMarketDate;
  }

  public void setOnMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
  }

  public OrgResoMetadataPropertyUpdate onMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
    return this;
  }

  /**
   * Get onMarketTimestamp
   * @return onMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOnMarketTimestamp() {
    return onMarketTimestamp;
  }

  public void setOnMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
  }

  public OrgResoMetadataPropertyUpdate openParkingSpaces(AnyOforgResoMetadataPropertyUpdateOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
    return this;
  }

  /**
   * Get openParkingSpaces
   * @return openParkingSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOpenParkingSpaces getOpenParkingSpaces() {
    return openParkingSpaces;
  }

  public void setOpenParkingSpaces(AnyOforgResoMetadataPropertyUpdateOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
  }

  public OrgResoMetadataPropertyUpdate openParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
    return this;
  }

  /**
   * Get openParkingYN
   * @return openParkingYN
   **/
  @Schema(description = "")
  
    public Boolean isOpenParkingYN() {
    return openParkingYN;
  }

  public void setOpenParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
  }

  public OrgResoMetadataPropertyUpdate operatingExpense(AnyOforgResoMetadataPropertyUpdateOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
    return this;
  }

  /**
   * Get operatingExpense
   * @return operatingExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOperatingExpense getOperatingExpense() {
    return operatingExpense;
  }

  public void setOperatingExpense(AnyOforgResoMetadataPropertyUpdateOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
  }

  public OrgResoMetadataPropertyUpdate operatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addOperatingExpenseIncludesItem(OrgResoMetadataEnumsOperatingExpenseIncludes operatingExpenseIncludesItem) {
    if (this.operatingExpenseIncludes == null) {
      this.operatingExpenseIncludes = new ArrayList<OrgResoMetadataEnumsOperatingExpenseIncludes>();
    }
    this.operatingExpenseIncludes.add(operatingExpenseIncludesItem);
    return this;
  }

  /**
   * Get operatingExpenseIncludes
   * @return operatingExpenseIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOperatingExpenseIncludes> getOperatingExpenseIncludes() {
    return operatingExpenseIncludes;
  }

  public void setOperatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
  }

  public OrgResoMetadataPropertyUpdate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataPropertyUpdate originalListPrice(AnyOforgResoMetadataPropertyUpdateOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
    return this;
  }

  /**
   * Get originalListPrice
   * @return originalListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOriginalListPrice getOriginalListPrice() {
    return originalListPrice;
  }

  public void setOriginalListPrice(AnyOforgResoMetadataPropertyUpdateOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
  }

  public OrgResoMetadataPropertyUpdate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataPropertyUpdate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataPropertyUpdate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataPropertyUpdate otherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addOtherEquipmentItem(OrgResoMetadataEnumsOtherEquipment otherEquipmentItem) {
    if (this.otherEquipment == null) {
      this.otherEquipment = new ArrayList<OrgResoMetadataEnumsOtherEquipment>();
    }
    this.otherEquipment.add(otherEquipmentItem);
    return this;
  }

  /**
   * Get otherEquipment
   * @return otherEquipment
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherEquipment> getOtherEquipment() {
    return otherEquipment;
  }

  public void setOtherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
  }

  public OrgResoMetadataPropertyUpdate otherExpense(AnyOforgResoMetadataPropertyUpdateOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
    return this;
  }

  /**
   * Get otherExpense
   * @return otherExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOtherExpense getOtherExpense() {
    return otherExpense;
  }

  public void setOtherExpense(AnyOforgResoMetadataPropertyUpdateOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
  }

  public OrgResoMetadataPropertyUpdate otherParking(String otherParking) {
    this.otherParking = otherParking;
    return this;
  }

  /**
   * Get otherParking
   * @return otherParking
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOtherParking() {
    return otherParking;
  }

  public void setOtherParking(String otherParking) {
    this.otherParking = otherParking;
  }

  public OrgResoMetadataPropertyUpdate otherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addOtherStructuresItem(OrgResoMetadataEnumsOtherStructures otherStructuresItem) {
    if (this.otherStructures == null) {
      this.otherStructures = new ArrayList<OrgResoMetadataEnumsOtherStructures>();
    }
    this.otherStructures.add(otherStructuresItem);
    return this;
  }

  /**
   * Get otherStructures
   * @return otherStructures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherStructures> getOtherStructures() {
    return otherStructures;
  }

  public void setOtherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
  }

  public OrgResoMetadataPropertyUpdate ownerName(String ownerName) {
    this.ownerName = ownerName;
    return this;
  }

  /**
   * Get ownerName
   * @return ownerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOwnerName() {
    return ownerName;
  }

  public void setOwnerName(String ownerName) {
    this.ownerName = ownerName;
  }

  public OrgResoMetadataPropertyUpdate ownerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addOwnerPaysItem(OrgResoMetadataEnumsOwnerPays ownerPaysItem) {
    if (this.ownerPays == null) {
      this.ownerPays = new ArrayList<OrgResoMetadataEnumsOwnerPays>();
    }
    this.ownerPays.add(ownerPaysItem);
    return this;
  }

  /**
   * Get ownerPays
   * @return ownerPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOwnerPays> getOwnerPays() {
    return ownerPays;
  }

  public void setOwnerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
  }

  public OrgResoMetadataPropertyUpdate ownerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
    return this;
  }

  /**
   * Get ownerPhone
   * @return ownerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOwnerPhone() {
    return ownerPhone;
  }

  public void setOwnerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
  }

  public OrgResoMetadataPropertyUpdate ownership(String ownership) {
    this.ownership = ownership;
    return this;
  }

  /**
   * Get ownership
   * @return ownership
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOwnership() {
    return ownership;
  }

  public void setOwnership(String ownership) {
    this.ownership = ownership;
  }

  public OrgResoMetadataPropertyUpdate ownershipType(AnyOforgResoMetadataPropertyUpdateOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
    return this;
  }

  /**
   * Get ownershipType
   * @return ownershipType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateOwnershipType getOwnershipType() {
    return ownershipType;
  }

  public void setOwnershipType(AnyOforgResoMetadataPropertyUpdateOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
  }

  public OrgResoMetadataPropertyUpdate parcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
    return this;
  }

  /**
   * Get parcelNumber
   * @return parcelNumber
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParcelNumber() {
    return parcelNumber;
  }

  public void setParcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
  }

  public OrgResoMetadataPropertyUpdate parkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
    return this;
  }

  /**
   * Get parkManagerName
   * @return parkManagerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkManagerName() {
    return parkManagerName;
  }

  public void setParkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
  }

  public OrgResoMetadataPropertyUpdate parkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
    return this;
  }

  /**
   * Get parkManagerPhone
   * @return parkManagerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getParkManagerPhone() {
    return parkManagerPhone;
  }

  public void setParkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
  }

  public OrgResoMetadataPropertyUpdate parkName(String parkName) {
    this.parkName = parkName;
    return this;
  }

  /**
   * Get parkName
   * @return parkName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkName() {
    return parkName;
  }

  public void setParkName(String parkName) {
    this.parkName = parkName;
  }

  public OrgResoMetadataPropertyUpdate parkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addParkingFeaturesItem(OrgResoMetadataEnumsParkingFeatures parkingFeaturesItem) {
    if (this.parkingFeatures == null) {
      this.parkingFeatures = new ArrayList<OrgResoMetadataEnumsParkingFeatures>();
    }
    this.parkingFeatures.add(parkingFeaturesItem);
    return this;
  }

  /**
   * Get parkingFeatures
   * @return parkingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsParkingFeatures> getParkingFeatures() {
    return parkingFeatures;
  }

  public void setParkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
  }

  public OrgResoMetadataPropertyUpdate parkingTotal(AnyOforgResoMetadataPropertyUpdateParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
    return this;
  }

  /**
   * Get parkingTotal
   * @return parkingTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateParkingTotal getParkingTotal() {
    return parkingTotal;
  }

  public void setParkingTotal(AnyOforgResoMetadataPropertyUpdateParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
  }

  public OrgResoMetadataPropertyUpdate pastureArea(AnyOforgResoMetadataPropertyUpdatePastureArea pastureArea) {
    this.pastureArea = pastureArea;
    return this;
  }

  /**
   * Get pastureArea
   * @return pastureArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePastureArea getPastureArea() {
    return pastureArea;
  }

  public void setPastureArea(AnyOforgResoMetadataPropertyUpdatePastureArea pastureArea) {
    this.pastureArea = pastureArea;
  }

  public OrgResoMetadataPropertyUpdate patioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPatioAndPorchFeaturesItem(OrgResoMetadataEnumsPatioAndPorchFeatures patioAndPorchFeaturesItem) {
    if (this.patioAndPorchFeatures == null) {
      this.patioAndPorchFeatures = new ArrayList<OrgResoMetadataEnumsPatioAndPorchFeatures>();
    }
    this.patioAndPorchFeatures.add(patioAndPorchFeaturesItem);
    return this;
  }

  /**
   * Get patioAndPorchFeatures
   * @return patioAndPorchFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPatioAndPorchFeatures> getPatioAndPorchFeatures() {
    return patioAndPorchFeatures;
  }

  public void setPatioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
  }

  public OrgResoMetadataPropertyUpdate pendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
    return this;
  }

  /**
   * Get pendingTimestamp
   * @return pendingTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPendingTimestamp() {
    return pendingTimestamp;
  }

  public void setPendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
  }

  public OrgResoMetadataPropertyUpdate pestControlExpense(AnyOforgResoMetadataPropertyUpdatePestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
    return this;
  }

  /**
   * Get pestControlExpense
   * @return pestControlExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePestControlExpense getPestControlExpense() {
    return pestControlExpense;
  }

  public void setPestControlExpense(AnyOforgResoMetadataPropertyUpdatePestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
  }

  public OrgResoMetadataPropertyUpdate petsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPetsAllowedItem(OrgResoMetadataEnumsPetsAllowed petsAllowedItem) {
    if (this.petsAllowed == null) {
      this.petsAllowed = new ArrayList<OrgResoMetadataEnumsPetsAllowed>();
    }
    this.petsAllowed.add(petsAllowedItem);
    return this;
  }

  /**
   * Get petsAllowed
   * @return petsAllowed
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPetsAllowed> getPetsAllowed() {
    return petsAllowed;
  }

  public void setPetsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
  }

  public OrgResoMetadataPropertyUpdate photosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
    return this;
  }

  /**
   * Get photosChangeTimestamp
   * @return photosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPhotosChangeTimestamp() {
    return photosChangeTimestamp;
  }

  public void setPhotosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate photosCount(AnyOforgResoMetadataPropertyUpdatePhotosCount photosCount) {
    this.photosCount = photosCount;
    return this;
  }

  /**
   * Get photosCount
   * @return photosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePhotosCount getPhotosCount() {
    return photosCount;
  }

  public void setPhotosCount(AnyOforgResoMetadataPropertyUpdatePhotosCount photosCount) {
    this.photosCount = photosCount;
  }

  public OrgResoMetadataPropertyUpdate poolExpense(AnyOforgResoMetadataPropertyUpdatePoolExpense poolExpense) {
    this.poolExpense = poolExpense;
    return this;
  }

  /**
   * Get poolExpense
   * @return poolExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePoolExpense getPoolExpense() {
    return poolExpense;
  }

  public void setPoolExpense(AnyOforgResoMetadataPropertyUpdatePoolExpense poolExpense) {
    this.poolExpense = poolExpense;
  }

  public OrgResoMetadataPropertyUpdate poolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPoolFeaturesItem(OrgResoMetadataEnumsPoolFeatures poolFeaturesItem) {
    if (this.poolFeatures == null) {
      this.poolFeatures = new ArrayList<OrgResoMetadataEnumsPoolFeatures>();
    }
    this.poolFeatures.add(poolFeaturesItem);
    return this;
  }

  /**
   * Get poolFeatures
   * @return poolFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPoolFeatures> getPoolFeatures() {
    return poolFeatures;
  }

  public void setPoolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
  }

  public OrgResoMetadataPropertyUpdate poolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
    return this;
  }

  /**
   * Get poolPrivateYN
   * @return poolPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isPoolPrivateYN() {
    return poolPrivateYN;
  }

  public void setPoolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
  }

  public OrgResoMetadataPropertyUpdate possession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPossessionItem(OrgResoMetadataEnumsPossession possessionItem) {
    if (this.possession == null) {
      this.possession = new ArrayList<OrgResoMetadataEnumsPossession>();
    }
    this.possession.add(possessionItem);
    return this;
  }

  /**
   * Get possession
   * @return possession
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossession> getPossession() {
    return possession;
  }

  public void setPossession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
  }

  public OrgResoMetadataPropertyUpdate possibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPossibleUseItem(OrgResoMetadataEnumsPossibleUse possibleUseItem) {
    if (this.possibleUse == null) {
      this.possibleUse = new ArrayList<OrgResoMetadataEnumsPossibleUse>();
    }
    this.possibleUse.add(possibleUseItem);
    return this;
  }

  /**
   * Get possibleUse
   * @return possibleUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossibleUse> getPossibleUse() {
    return possibleUse;
  }

  public void setPossibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
  }

  public OrgResoMetadataPropertyUpdate postalCity(AnyOforgResoMetadataPropertyUpdatePostalCity postalCity) {
    this.postalCity = postalCity;
    return this;
  }

  /**
   * Get postalCity
   * @return postalCity
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePostalCity getPostalCity() {
    return postalCity;
  }

  public void setPostalCity(AnyOforgResoMetadataPropertyUpdatePostalCity postalCity) {
    this.postalCity = postalCity;
  }

  public OrgResoMetadataPropertyUpdate postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Get postalCode
   * @return postalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public OrgResoMetadataPropertyUpdate postalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
    return this;
  }

  /**
   * Get postalCodePlus4
   * @return postalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getPostalCodePlus4() {
    return postalCodePlus4;
  }

  public void setPostalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
  }

  public OrgResoMetadataPropertyUpdate powerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPowerProductionTypeItem(OrgResoMetadataEnumsPowerProductionType powerProductionTypeItem) {
    if (this.powerProductionType == null) {
      this.powerProductionType = new ArrayList<OrgResoMetadataEnumsPowerProductionType>();
    }
    this.powerProductionType.add(powerProductionTypeItem);
    return this;
  }

  /**
   * Get powerProductionType
   * @return powerProductionType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPowerProductionType> getPowerProductionType() {
    return powerProductionType;
  }

  public void setPowerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
  }

  public OrgResoMetadataPropertyUpdate previousListPrice(AnyOforgResoMetadataPropertyUpdatePreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
    return this;
  }

  /**
   * Get previousListPrice
   * @return previousListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePreviousListPrice getPreviousListPrice() {
    return previousListPrice;
  }

  public void setPreviousListPrice(AnyOforgResoMetadataPropertyUpdatePreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
  }

  public OrgResoMetadataPropertyUpdate priceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
    return this;
  }

  /**
   * Get priceChangeTimestamp
   * @return priceChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPriceChangeTimestamp() {
    return priceChangeTimestamp;
  }

  public void setPriceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate privateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
    return this;
  }

  /**
   * Get privateOfficeRemarks
   * @return privateOfficeRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateOfficeRemarks() {
    return privateOfficeRemarks;
  }

  public void setPrivateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
  }

  public OrgResoMetadataPropertyUpdate privateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
    return this;
  }

  /**
   * Get privateRemarks
   * @return privateRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateRemarks() {
    return privateRemarks;
  }

  public void setPrivateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
  }

  public OrgResoMetadataPropertyUpdate professionalManagementExpense(AnyOforgResoMetadataPropertyUpdateProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
    return this;
  }

  /**
   * Get professionalManagementExpense
   * @return professionalManagementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateProfessionalManagementExpense getProfessionalManagementExpense() {
    return professionalManagementExpense;
  }

  public void setProfessionalManagementExpense(AnyOforgResoMetadataPropertyUpdateProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
  }

  public OrgResoMetadataPropertyUpdate propertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
    return this;
  }

  /**
   * Get propertyAttachedYN
   * @return propertyAttachedYN
   **/
  @Schema(description = "")
  
    public Boolean isPropertyAttachedYN() {
    return propertyAttachedYN;
  }

  public void setPropertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
  }

  public OrgResoMetadataPropertyUpdate propertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addPropertyConditionItem(OrgResoMetadataEnumsPropertyCondition propertyConditionItem) {
    if (this.propertyCondition == null) {
      this.propertyCondition = new ArrayList<OrgResoMetadataEnumsPropertyCondition>();
    }
    this.propertyCondition.add(propertyConditionItem);
    return this;
  }

  /**
   * Get propertyCondition
   * @return propertyCondition
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPropertyCondition> getPropertyCondition() {
    return propertyCondition;
  }

  public void setPropertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
  }

  public OrgResoMetadataPropertyUpdate propertySubType(AnyOforgResoMetadataPropertyUpdatePropertySubType propertySubType) {
    this.propertySubType = propertySubType;
    return this;
  }

  /**
   * Get propertySubType
   * @return propertySubType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePropertySubType getPropertySubType() {
    return propertySubType;
  }

  public void setPropertySubType(AnyOforgResoMetadataPropertyUpdatePropertySubType propertySubType) {
    this.propertySubType = propertySubType;
  }

  public OrgResoMetadataPropertyUpdate propertyType(AnyOforgResoMetadataPropertyUpdatePropertyType propertyType) {
    this.propertyType = propertyType;
    return this;
  }

  /**
   * Get propertyType
   * @return propertyType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdatePropertyType getPropertyType() {
    return propertyType;
  }

  public void setPropertyType(AnyOforgResoMetadataPropertyUpdatePropertyType propertyType) {
    this.propertyType = propertyType;
  }

  public OrgResoMetadataPropertyUpdate publicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
    return this;
  }

  /**
   * Get publicRemarks
   * @return publicRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPublicRemarks() {
    return publicRemarks;
  }

  public void setPublicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
  }

  public OrgResoMetadataPropertyUpdate publicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
    return this;
  }

  /**
   * Get publicSurveyRange
   * @return publicSurveyRange
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyRange() {
    return publicSurveyRange;
  }

  public void setPublicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
  }

  public OrgResoMetadataPropertyUpdate publicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
    return this;
  }

  /**
   * Get publicSurveySection
   * @return publicSurveySection
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveySection() {
    return publicSurveySection;
  }

  public void setPublicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
  }

  public OrgResoMetadataPropertyUpdate publicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
    return this;
  }

  /**
   * Get publicSurveyTownship
   * @return publicSurveyTownship
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyTownship() {
    return publicSurveyTownship;
  }

  public void setPublicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
  }

  public OrgResoMetadataPropertyUpdate purchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
    return this;
  }

  /**
   * Get purchaseContractDate
   * @return purchaseContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getPurchaseContractDate() {
    return purchaseContractDate;
  }

  public void setPurchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
  }

  public OrgResoMetadataPropertyUpdate rvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
    return this;
  }

  /**
   * Get rvParkingDimensions
   * @return rvParkingDimensions
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getRvParkingDimensions() {
    return rvParkingDimensions;
  }

  public void setRvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
  }

  public OrgResoMetadataPropertyUpdate rangeArea(AnyOforgResoMetadataPropertyUpdateRangeArea rangeArea) {
    this.rangeArea = rangeArea;
    return this;
  }

  /**
   * Get rangeArea
   * @return rangeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateRangeArea getRangeArea() {
    return rangeArea;
  }

  public void setRangeArea(AnyOforgResoMetadataPropertyUpdateRangeArea rangeArea) {
    this.rangeArea = rangeArea;
  }

  public OrgResoMetadataPropertyUpdate rentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
    return this;
  }

  /**
   * Get rentControlYN
   * @return rentControlYN
   **/
  @Schema(description = "")
  
    public Boolean isRentControlYN() {
    return rentControlYN;
  }

  public void setRentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
  }

  public OrgResoMetadataPropertyUpdate rentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRentIncludesItem(OrgResoMetadataEnumsRentIncludes rentIncludesItem) {
    if (this.rentIncludes == null) {
      this.rentIncludes = new ArrayList<OrgResoMetadataEnumsRentIncludes>();
    }
    this.rentIncludes.add(rentIncludesItem);
    return this;
  }

  /**
   * Get rentIncludes
   * @return rentIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRentIncludes> getRentIncludes() {
    return rentIncludes;
  }

  public void setRentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
  }

  public OrgResoMetadataPropertyUpdate roadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRoadFrontageTypeItem(OrgResoMetadataEnumsRoadFrontageType roadFrontageTypeItem) {
    if (this.roadFrontageType == null) {
      this.roadFrontageType = new ArrayList<OrgResoMetadataEnumsRoadFrontageType>();
    }
    this.roadFrontageType.add(roadFrontageTypeItem);
    return this;
  }

  /**
   * Get roadFrontageType
   * @return roadFrontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadFrontageType> getRoadFrontageType() {
    return roadFrontageType;
  }

  public void setRoadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
  }

  public OrgResoMetadataPropertyUpdate roadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRoadResponsibilityItem(OrgResoMetadataEnumsRoadResponsibility roadResponsibilityItem) {
    if (this.roadResponsibility == null) {
      this.roadResponsibility = new ArrayList<OrgResoMetadataEnumsRoadResponsibility>();
    }
    this.roadResponsibility.add(roadResponsibilityItem);
    return this;
  }

  /**
   * Get roadResponsibility
   * @return roadResponsibility
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadResponsibility> getRoadResponsibility() {
    return roadResponsibility;
  }

  public void setRoadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
  }

  public OrgResoMetadataPropertyUpdate roadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRoadSurfaceTypeItem(OrgResoMetadataEnumsRoadSurfaceType roadSurfaceTypeItem) {
    if (this.roadSurfaceType == null) {
      this.roadSurfaceType = new ArrayList<OrgResoMetadataEnumsRoadSurfaceType>();
    }
    this.roadSurfaceType.add(roadSurfaceTypeItem);
    return this;
  }

  /**
   * Get roadSurfaceType
   * @return roadSurfaceType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadSurfaceType> getRoadSurfaceType() {
    return roadSurfaceType;
  }

  public void setRoadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
  }

  public OrgResoMetadataPropertyUpdate roof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRoofItem(OrgResoMetadataEnumsRoof roofItem) {
    if (this.roof == null) {
      this.roof = new ArrayList<OrgResoMetadataEnumsRoof>();
    }
    this.roof.add(roofItem);
    return this;
  }

  /**
   * Get roof
   * @return roof
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoof> getRoof() {
    return roof;
  }

  public void setRoof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
  }

  public OrgResoMetadataPropertyUpdate roomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addRoomTypeItem(OrgResoMetadataEnumsRoomType roomTypeItem) {
    if (this.roomType == null) {
      this.roomType = new ArrayList<OrgResoMetadataEnumsRoomType>();
    }
    this.roomType.add(roomTypeItem);
    return this;
  }

  /**
   * Get roomType
   * @return roomType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoomType> getRoomType() {
    return roomType;
  }

  public void setRoomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
  }

  public OrgResoMetadataPropertyUpdate roomsTotal(AnyOforgResoMetadataPropertyUpdateRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
    return this;
  }

  /**
   * Get roomsTotal
   * @return roomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateRoomsTotal getRoomsTotal() {
    return roomsTotal;
  }

  public void setRoomsTotal(AnyOforgResoMetadataPropertyUpdateRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
  }

  public OrgResoMetadataPropertyUpdate seatingCapacity(AnyOforgResoMetadataPropertyUpdateSeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
    return this;
  }

  /**
   * Get seatingCapacity
   * @return seatingCapacity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateSeatingCapacity getSeatingCapacity() {
    return seatingCapacity;
  }

  public void setSeatingCapacity(AnyOforgResoMetadataPropertyUpdateSeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
  }

  public OrgResoMetadataPropertyUpdate securityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSecurityFeaturesItem(OrgResoMetadataEnumsSecurityFeatures securityFeaturesItem) {
    if (this.securityFeatures == null) {
      this.securityFeatures = new ArrayList<OrgResoMetadataEnumsSecurityFeatures>();
    }
    this.securityFeatures.add(securityFeaturesItem);
    return this;
  }

  /**
   * Get securityFeatures
   * @return securityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSecurityFeatures> getSecurityFeatures() {
    return securityFeatures;
  }

  public void setSecurityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
  }

  public OrgResoMetadataPropertyUpdate seniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
    return this;
  }

  /**
   * Get seniorCommunityYN
   * @return seniorCommunityYN
   **/
  @Schema(description = "")
  
    public Boolean isSeniorCommunityYN() {
    return seniorCommunityYN;
  }

  public void setSeniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
  }

  public OrgResoMetadataPropertyUpdate serialU(String serialU) {
    this.serialU = serialU;
    return this;
  }

  /**
   * Get serialU
   * @return serialU
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialU() {
    return serialU;
  }

  public void setSerialU(String serialU) {
    this.serialU = serialU;
  }

  public OrgResoMetadataPropertyUpdate serialX(String serialX) {
    this.serialX = serialX;
    return this;
  }

  /**
   * Get serialX
   * @return serialX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialX() {
    return serialX;
  }

  public void setSerialX(String serialX) {
    this.serialX = serialX;
  }

  public OrgResoMetadataPropertyUpdate serialXX(String serialXX) {
    this.serialXX = serialXX;
    return this;
  }

  /**
   * Get serialXX
   * @return serialXX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialXX() {
    return serialXX;
  }

  public void setSerialXX(String serialXX) {
    this.serialXX = serialXX;
  }

  public OrgResoMetadataPropertyUpdate sewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSewerItem(OrgResoMetadataEnumsSewer sewerItem) {
    if (this.sewer == null) {
      this.sewer = new ArrayList<OrgResoMetadataEnumsSewer>();
    }
    this.sewer.add(sewerItem);
    return this;
  }

  /**
   * Get sewer
   * @return sewer
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSewer> getSewer() {
    return sewer;
  }

  public void setSewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
  }

  public OrgResoMetadataPropertyUpdate showingAdvanceNotice(AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
    return this;
  }

  /**
   * Get showingAdvanceNotice
   * @return showingAdvanceNotice
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice getShowingAdvanceNotice() {
    return showingAdvanceNotice;
  }

  public void setShowingAdvanceNotice(AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
  }

  public OrgResoMetadataPropertyUpdate showingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
    return this;
  }

  /**
   * Get showingAttendedYN
   * @return showingAttendedYN
   **/
  @Schema(description = "")
  
    public Boolean isShowingAttendedYN() {
    return showingAttendedYN;
  }

  public void setShowingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
  }

  public OrgResoMetadataPropertyUpdate showingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
    return this;
  }

  /**
   * Get showingContactName
   * @return showingContactName
   **/
  @Schema(description = "")
  
  @Size(max=40)   public String getShowingContactName() {
    return showingContactName;
  }

  public void setShowingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
  }

  public OrgResoMetadataPropertyUpdate showingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
    return this;
  }

  /**
   * Get showingContactPhone
   * @return showingContactPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getShowingContactPhone() {
    return showingContactPhone;
  }

  public void setShowingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
  }

  public OrgResoMetadataPropertyUpdate showingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
    return this;
  }

  /**
   * Get showingContactPhoneExt
   * @return showingContactPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getShowingContactPhoneExt() {
    return showingContactPhoneExt;
  }

  public void setShowingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
  }

  public OrgResoMetadataPropertyUpdate showingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addShowingContactTypeItem(OrgResoMetadataEnumsShowingContactType showingContactTypeItem) {
    if (this.showingContactType == null) {
      this.showingContactType = new ArrayList<OrgResoMetadataEnumsShowingContactType>();
    }
    this.showingContactType.add(showingContactTypeItem);
    return this;
  }

  /**
   * Get showingContactType
   * @return showingContactType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingContactType> getShowingContactType() {
    return showingContactType;
  }

  public void setShowingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
  }

  public OrgResoMetadataPropertyUpdate showingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addShowingDaysItem(OrgResoMetadataEnumsShowingDays showingDaysItem) {
    if (this.showingDays == null) {
      this.showingDays = new ArrayList<OrgResoMetadataEnumsShowingDays>();
    }
    this.showingDays.add(showingDaysItem);
    return this;
  }

  /**
   * Get showingDays
   * @return showingDays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingDays> getShowingDays() {
    return showingDays;
  }

  public void setShowingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
  }

  public OrgResoMetadataPropertyUpdate showingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
    return this;
  }

  /**
   * Get showingEndTime
   * @return showingEndTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingEndTime() {
    return showingEndTime;
  }

  public void setShowingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
  }

  public OrgResoMetadataPropertyUpdate showingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
    return this;
  }

  /**
   * Get showingInstructions
   * @return showingInstructions
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getShowingInstructions() {
    return showingInstructions;
  }

  public void setShowingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
  }

  public OrgResoMetadataPropertyUpdate showingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addShowingRequirementsItem(OrgResoMetadataEnumsShowingRequirements showingRequirementsItem) {
    if (this.showingRequirements == null) {
      this.showingRequirements = new ArrayList<OrgResoMetadataEnumsShowingRequirements>();
    }
    this.showingRequirements.add(showingRequirementsItem);
    return this;
  }

  /**
   * Get showingRequirements
   * @return showingRequirements
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingRequirements> getShowingRequirements() {
    return showingRequirements;
  }

  public void setShowingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
  }

  public OrgResoMetadataPropertyUpdate showingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
    return this;
  }

  /**
   * Get showingStartTime
   * @return showingStartTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingStartTime() {
    return showingStartTime;
  }

  public void setShowingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
  }

  public OrgResoMetadataPropertyUpdate signOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
    return this;
  }

  /**
   * Get signOnPropertyYN
   * @return signOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isSignOnPropertyYN() {
    return signOnPropertyYN;
  }

  public void setSignOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
  }

  public OrgResoMetadataPropertyUpdate skirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSkirtItem(OrgResoMetadataEnumsSkirt skirtItem) {
    if (this.skirt == null) {
      this.skirt = new ArrayList<OrgResoMetadataEnumsSkirt>();
    }
    this.skirt.add(skirtItem);
    return this;
  }

  /**
   * Get skirt
   * @return skirt
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSkirt> getSkirt() {
    return skirt;
  }

  public void setSkirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
  }

  public OrgResoMetadataPropertyUpdate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataPropertyUpdate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataPropertyUpdate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataPropertyUpdate spaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSpaFeaturesItem(OrgResoMetadataEnumsSpaFeatures spaFeaturesItem) {
    if (this.spaFeatures == null) {
      this.spaFeatures = new ArrayList<OrgResoMetadataEnumsSpaFeatures>();
    }
    this.spaFeatures.add(spaFeaturesItem);
    return this;
  }

  /**
   * Get spaFeatures
   * @return spaFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpaFeatures> getSpaFeatures() {
    return spaFeatures;
  }

  public void setSpaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
  }

  public OrgResoMetadataPropertyUpdate spaYN(Boolean spaYN) {
    this.spaYN = spaYN;
    return this;
  }

  /**
   * Get spaYN
   * @return spaYN
   **/
  @Schema(description = "")
  
    public Boolean isSpaYN() {
    return spaYN;
  }

  public void setSpaYN(Boolean spaYN) {
    this.spaYN = spaYN;
  }

  public OrgResoMetadataPropertyUpdate specialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSpecialLicensesItem(OrgResoMetadataEnumsSpecialLicenses specialLicensesItem) {
    if (this.specialLicenses == null) {
      this.specialLicenses = new ArrayList<OrgResoMetadataEnumsSpecialLicenses>();
    }
    this.specialLicenses.add(specialLicensesItem);
    return this;
  }

  /**
   * Get specialLicenses
   * @return specialLicenses
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialLicenses> getSpecialLicenses() {
    return specialLicenses;
  }

  public void setSpecialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
  }

  public OrgResoMetadataPropertyUpdate specialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSpecialListingConditionsItem(OrgResoMetadataEnumsSpecialListingConditions specialListingConditionsItem) {
    if (this.specialListingConditions == null) {
      this.specialListingConditions = new ArrayList<OrgResoMetadataEnumsSpecialListingConditions>();
    }
    this.specialListingConditions.add(specialListingConditionsItem);
    return this;
  }

  /**
   * Get specialListingConditions
   * @return specialListingConditions
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialListingConditions> getSpecialListingConditions() {
    return specialListingConditions;
  }

  public void setSpecialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
  }

  public OrgResoMetadataPropertyUpdate standardStatus(AnyOforgResoMetadataPropertyUpdateStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
    return this;
  }

  /**
   * Get standardStatus
   * @return standardStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStandardStatus getStandardStatus() {
    return standardStatus;
  }

  public void setStandardStatus(AnyOforgResoMetadataPropertyUpdateStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
  }

  public OrgResoMetadataPropertyUpdate stateOrProvince(AnyOforgResoMetadataPropertyUpdateStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
    return this;
  }

  /**
   * Get stateOrProvince
   * @return stateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStateOrProvince getStateOrProvince() {
    return stateOrProvince;
  }

  public void setStateOrProvince(AnyOforgResoMetadataPropertyUpdateStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  public OrgResoMetadataPropertyUpdate stateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
    return this;
  }

  /**
   * Get stateRegion
   * @return stateRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getStateRegion() {
    return stateRegion;
  }

  public void setStateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
  }

  public OrgResoMetadataPropertyUpdate statusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
    return this;
  }

  /**
   * Get statusChangeTimestamp
   * @return statusChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStatusChangeTimestamp() {
    return statusChangeTimestamp;
  }

  public void setStatusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate stories(AnyOforgResoMetadataPropertyUpdateStories stories) {
    this.stories = stories;
    return this;
  }

  /**
   * Get stories
   * @return stories
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStories getStories() {
    return stories;
  }

  public void setStories(AnyOforgResoMetadataPropertyUpdateStories stories) {
    this.stories = stories;
  }

  public OrgResoMetadataPropertyUpdate storiesTotal(AnyOforgResoMetadataPropertyUpdateStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
    return this;
  }

  /**
   * Get storiesTotal
   * @return storiesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStoriesTotal getStoriesTotal() {
    return storiesTotal;
  }

  public void setStoriesTotal(AnyOforgResoMetadataPropertyUpdateStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
  }

  public OrgResoMetadataPropertyUpdate streetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
    return this;
  }

  /**
   * Get streetAdditionalInfo
   * @return streetAdditionalInfo
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetAdditionalInfo() {
    return streetAdditionalInfo;
  }

  public void setStreetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
  }

  public OrgResoMetadataPropertyUpdate streetDirPrefix(AnyOforgResoMetadataPropertyUpdateStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
    return this;
  }

  /**
   * Get streetDirPrefix
   * @return streetDirPrefix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStreetDirPrefix getStreetDirPrefix() {
    return streetDirPrefix;
  }

  public void setStreetDirPrefix(AnyOforgResoMetadataPropertyUpdateStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
  }

  public OrgResoMetadataPropertyUpdate streetDirSuffix(AnyOforgResoMetadataPropertyUpdateStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
    return this;
  }

  /**
   * Get streetDirSuffix
   * @return streetDirSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStreetDirSuffix getStreetDirSuffix() {
    return streetDirSuffix;
  }

  public void setStreetDirSuffix(AnyOforgResoMetadataPropertyUpdateStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
  }

  public OrgResoMetadataPropertyUpdate streetName(String streetName) {
    this.streetName = streetName;
    return this;
  }

  /**
   * Get streetName
   * @return streetName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetName() {
    return streetName;
  }

  public void setStreetName(String streetName) {
    this.streetName = streetName;
  }

  public OrgResoMetadataPropertyUpdate streetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
    return this;
  }

  /**
   * Get streetNumber
   * @return streetNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetNumber() {
    return streetNumber;
  }

  public void setStreetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
  }

  public OrgResoMetadataPropertyUpdate streetNumberNumeric(AnyOforgResoMetadataPropertyUpdateStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
    return this;
  }

  /**
   * Get streetNumberNumeric
   * @return streetNumberNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStreetNumberNumeric getStreetNumberNumeric() {
    return streetNumberNumeric;
  }

  public void setStreetNumberNumeric(AnyOforgResoMetadataPropertyUpdateStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
  }

  public OrgResoMetadataPropertyUpdate streetSuffix(AnyOforgResoMetadataPropertyUpdateStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
    return this;
  }

  /**
   * Get streetSuffix
   * @return streetSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateStreetSuffix getStreetSuffix() {
    return streetSuffix;
  }

  public void setStreetSuffix(AnyOforgResoMetadataPropertyUpdateStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
  }

  public OrgResoMetadataPropertyUpdate streetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
    return this;
  }

  /**
   * Get streetSuffixModifier
   * @return streetSuffixModifier
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetSuffixModifier() {
    return streetSuffixModifier;
  }

  public void setStreetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
  }

  public OrgResoMetadataPropertyUpdate structureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addStructureTypeItem(OrgResoMetadataEnumsStructureType structureTypeItem) {
    if (this.structureType == null) {
      this.structureType = new ArrayList<OrgResoMetadataEnumsStructureType>();
    }
    this.structureType.add(structureTypeItem);
    return this;
  }

  /**
   * Get structureType
   * @return structureType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsStructureType> getStructureType() {
    return structureType;
  }

  public void setStructureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
  }

  public OrgResoMetadataPropertyUpdate subAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
    return this;
  }

  /**
   * Get subAgencyCompensation
   * @return subAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSubAgencyCompensation() {
    return subAgencyCompensation;
  }

  public void setSubAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
  }

  public OrgResoMetadataPropertyUpdate subAgencyCompensationType(AnyOforgResoMetadataPropertyUpdateSubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
    return this;
  }

  /**
   * Get subAgencyCompensationType
   * @return subAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateSubAgencyCompensationType getSubAgencyCompensationType() {
    return subAgencyCompensationType;
  }

  public void setSubAgencyCompensationType(AnyOforgResoMetadataPropertyUpdateSubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
  }

  public OrgResoMetadataPropertyUpdate subdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
    return this;
  }

  /**
   * Get subdivisionName
   * @return subdivisionName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getSubdivisionName() {
    return subdivisionName;
  }

  public void setSubdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
  }

  public OrgResoMetadataPropertyUpdate suppliesExpense(AnyOforgResoMetadataPropertyUpdateSuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
    return this;
  }

  /**
   * Get suppliesExpense
   * @return suppliesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateSuppliesExpense getSuppliesExpense() {
    return suppliesExpense;
  }

  public void setSuppliesExpense(AnyOforgResoMetadataPropertyUpdateSuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
  }

  public OrgResoMetadataPropertyUpdate syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }

  public OrgResoMetadataPropertyUpdate syndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
    return this;
  }

  /**
   * Get syndicationRemarks
   * @return syndicationRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getSyndicationRemarks() {
    return syndicationRemarks;
  }

  public void setSyndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
  }

  public OrgResoMetadataPropertyUpdate taxAnnualAmount(AnyOforgResoMetadataPropertyUpdateTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
    return this;
  }

  /**
   * Get taxAnnualAmount
   * @return taxAnnualAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTaxAnnualAmount getTaxAnnualAmount() {
    return taxAnnualAmount;
  }

  public void setTaxAnnualAmount(AnyOforgResoMetadataPropertyUpdateTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
  }

  public OrgResoMetadataPropertyUpdate taxAssessedValue(AnyOforgResoMetadataPropertyUpdateTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
    return this;
  }

  /**
   * Get taxAssessedValue
   * @return taxAssessedValue
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTaxAssessedValue getTaxAssessedValue() {
    return taxAssessedValue;
  }

  public void setTaxAssessedValue(AnyOforgResoMetadataPropertyUpdateTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
  }

  public OrgResoMetadataPropertyUpdate taxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
    return this;
  }

  /**
   * Get taxBlock
   * @return taxBlock
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBlock() {
    return taxBlock;
  }

  public void setTaxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
  }

  public OrgResoMetadataPropertyUpdate taxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
    return this;
  }

  /**
   * Get taxBookNumber
   * @return taxBookNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBookNumber() {
    return taxBookNumber;
  }

  public void setTaxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
  }

  public OrgResoMetadataPropertyUpdate taxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
    return this;
  }

  /**
   * Get taxLegalDescription
   * @return taxLegalDescription
   **/
  @Schema(description = "")
  
  @Size(max=6000)   public String getTaxLegalDescription() {
    return taxLegalDescription;
  }

  public void setTaxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
  }

  public OrgResoMetadataPropertyUpdate taxLot(String taxLot) {
    this.taxLot = taxLot;
    return this;
  }

  /**
   * Get taxLot
   * @return taxLot
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxLot() {
    return taxLot;
  }

  public void setTaxLot(String taxLot) {
    this.taxLot = taxLot;
  }

  public OrgResoMetadataPropertyUpdate taxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
    return this;
  }

  /**
   * Get taxMapNumber
   * @return taxMapNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxMapNumber() {
    return taxMapNumber;
  }

  public void setTaxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
  }

  public OrgResoMetadataPropertyUpdate taxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyUpdateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
    return this;
  }

  /**
   * Get taxOtherAnnualAssessmentAmount
   * @return taxOtherAnnualAssessmentAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTaxOtherAnnualAssessmentAmount getTaxOtherAnnualAssessmentAmount() {
    return taxOtherAnnualAssessmentAmount;
  }

  public void setTaxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyUpdateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
  }

  public OrgResoMetadataPropertyUpdate taxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
    return this;
  }

  /**
   * Get taxParcelLetter
   * @return taxParcelLetter
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxParcelLetter() {
    return taxParcelLetter;
  }

  public void setTaxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
  }

  public OrgResoMetadataPropertyUpdate taxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addTaxStatusCurrentItem(OrgResoMetadataEnumsTaxStatusCurrent taxStatusCurrentItem) {
    if (this.taxStatusCurrent == null) {
      this.taxStatusCurrent = new ArrayList<OrgResoMetadataEnumsTaxStatusCurrent>();
    }
    this.taxStatusCurrent.add(taxStatusCurrentItem);
    return this;
  }

  /**
   * Get taxStatusCurrent
   * @return taxStatusCurrent
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTaxStatusCurrent> getTaxStatusCurrent() {
    return taxStatusCurrent;
  }

  public void setTaxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
  }

  public OrgResoMetadataPropertyUpdate taxTract(String taxTract) {
    this.taxTract = taxTract;
    return this;
  }

  /**
   * Get taxTract
   * @return taxTract
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxTract() {
    return taxTract;
  }

  public void setTaxTract(String taxTract) {
    this.taxTract = taxTract;
  }

  public OrgResoMetadataPropertyUpdate taxYear(AnyOforgResoMetadataPropertyUpdateTaxYear taxYear) {
    this.taxYear = taxYear;
    return this;
  }

  /**
   * Get taxYear
   * @return taxYear
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTaxYear getTaxYear() {
    return taxYear;
  }

  public void setTaxYear(AnyOforgResoMetadataPropertyUpdateTaxYear taxYear) {
    this.taxYear = taxYear;
  }

  public OrgResoMetadataPropertyUpdate tenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addTenantPaysItem(OrgResoMetadataEnumsTenantPays tenantPaysItem) {
    if (this.tenantPays == null) {
      this.tenantPays = new ArrayList<OrgResoMetadataEnumsTenantPays>();
    }
    this.tenantPays.add(tenantPaysItem);
    return this;
  }

  /**
   * Get tenantPays
   * @return tenantPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTenantPays> getTenantPays() {
    return tenantPays;
  }

  public void setTenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
  }

  public OrgResoMetadataPropertyUpdate topography(String topography) {
    this.topography = topography;
    return this;
  }

  /**
   * Get topography
   * @return topography
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTopography() {
    return topography;
  }

  public void setTopography(String topography) {
    this.topography = topography;
  }

  public OrgResoMetadataPropertyUpdate totalActualRent(AnyOforgResoMetadataPropertyUpdateTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
    return this;
  }

  /**
   * Get totalActualRent
   * @return totalActualRent
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTotalActualRent getTotalActualRent() {
    return totalActualRent;
  }

  public void setTotalActualRent(AnyOforgResoMetadataPropertyUpdateTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
  }

  public OrgResoMetadataPropertyUpdate township(String township) {
    this.township = township;
    return this;
  }

  /**
   * Get township
   * @return township
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTownship() {
    return township;
  }

  public void setTownship(String township) {
    this.township = township;
  }

  public OrgResoMetadataPropertyUpdate transactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
    return this;
  }

  /**
   * Get transactionBrokerCompensation
   * @return transactionBrokerCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTransactionBrokerCompensation() {
    return transactionBrokerCompensation;
  }

  public void setTransactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
  }

  public OrgResoMetadataPropertyUpdate transactionBrokerCompensationType(AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
    return this;
  }

  /**
   * Get transactionBrokerCompensationType
   * @return transactionBrokerCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType getTransactionBrokerCompensationType() {
    return transactionBrokerCompensationType;
  }

  public void setTransactionBrokerCompensationType(AnyOforgResoMetadataPropertyUpdateTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
  }

  public OrgResoMetadataPropertyUpdate trashExpense(AnyOforgResoMetadataPropertyUpdateTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
    return this;
  }

  /**
   * Get trashExpense
   * @return trashExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateTrashExpense getTrashExpense() {
    return trashExpense;
  }

  public void setTrashExpense(AnyOforgResoMetadataPropertyUpdateTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
  }

  public OrgResoMetadataPropertyUpdate unitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
    return this;
  }

  /**
   * Get unitNumber
   * @return unitNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getUnitNumber() {
    return unitNumber;
  }

  public void setUnitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
  }

  public OrgResoMetadataPropertyUpdate unitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addUnitTypeTypeItem(OrgResoMetadataEnumsUnitTypeType unitTypeTypeItem) {
    if (this.unitTypeType == null) {
      this.unitTypeType = new ArrayList<OrgResoMetadataEnumsUnitTypeType>();
    }
    this.unitTypeType.add(unitTypeTypeItem);
    return this;
  }

  /**
   * Get unitTypeType
   * @return unitTypeType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUnitTypeType> getUnitTypeType() {
    return unitTypeType;
  }

  public void setUnitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
  }

  public OrgResoMetadataPropertyUpdate unitsFurnished(AnyOforgResoMetadataPropertyUpdateUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
    return this;
  }

  /**
   * Get unitsFurnished
   * @return unitsFurnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateUnitsFurnished getUnitsFurnished() {
    return unitsFurnished;
  }

  public void setUnitsFurnished(AnyOforgResoMetadataPropertyUpdateUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
  }

  public OrgResoMetadataPropertyUpdate universalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
    return this;
  }

  /**
   * Get universalPropertyId
   * @return universalPropertyId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertyId() {
    return universalPropertyId;
  }

  public void setUniversalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
  }

  public OrgResoMetadataPropertyUpdate universalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
    return this;
  }

  /**
   * Get universalPropertySubId
   * @return universalPropertySubId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertySubId() {
    return universalPropertySubId;
  }

  public void setUniversalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
  }

  public OrgResoMetadataPropertyUpdate unparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
    return this;
  }

  /**
   * Get unparsedAddress
   * @return unparsedAddress
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getUnparsedAddress() {
    return unparsedAddress;
  }

  public void setUnparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
  }

  public OrgResoMetadataPropertyUpdate utilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addUtilitiesItem(OrgResoMetadataEnumsUtilities utilitiesItem) {
    if (this.utilities == null) {
      this.utilities = new ArrayList<OrgResoMetadataEnumsUtilities>();
    }
    this.utilities.add(utilitiesItem);
    return this;
  }

  /**
   * Get utilities
   * @return utilities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUtilities> getUtilities() {
    return utilities;
  }

  public void setUtilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
  }

  public OrgResoMetadataPropertyUpdate vacancyAllowance(AnyOforgResoMetadataPropertyUpdateVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
    return this;
  }

  /**
   * Get vacancyAllowance
   * @return vacancyAllowance
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateVacancyAllowance getVacancyAllowance() {
    return vacancyAllowance;
  }

  public void setVacancyAllowance(AnyOforgResoMetadataPropertyUpdateVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
  }

  public OrgResoMetadataPropertyUpdate vacancyAllowanceRate(AnyOforgResoMetadataPropertyUpdateVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
    return this;
  }

  /**
   * Get vacancyAllowanceRate
   * @return vacancyAllowanceRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateVacancyAllowanceRate getVacancyAllowanceRate() {
    return vacancyAllowanceRate;
  }

  public void setVacancyAllowanceRate(AnyOforgResoMetadataPropertyUpdateVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
  }

  public OrgResoMetadataPropertyUpdate vegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addVegetationItem(OrgResoMetadataEnumsVegetation vegetationItem) {
    if (this.vegetation == null) {
      this.vegetation = new ArrayList<OrgResoMetadataEnumsVegetation>();
    }
    this.vegetation.add(vegetationItem);
    return this;
  }

  /**
   * Get vegetation
   * @return vegetation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsVegetation> getVegetation() {
    return vegetation;
  }

  public void setVegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
  }

  public OrgResoMetadataPropertyUpdate videosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
    return this;
  }

  /**
   * Get videosChangeTimestamp
   * @return videosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getVideosChangeTimestamp() {
    return videosChangeTimestamp;
  }

  public void setVideosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
  }

  public OrgResoMetadataPropertyUpdate videosCount(AnyOforgResoMetadataPropertyUpdateVideosCount videosCount) {
    this.videosCount = videosCount;
    return this;
  }

  /**
   * Get videosCount
   * @return videosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateVideosCount getVideosCount() {
    return videosCount;
  }

  public void setVideosCount(AnyOforgResoMetadataPropertyUpdateVideosCount videosCount) {
    this.videosCount = videosCount;
  }

  public OrgResoMetadataPropertyUpdate view(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addViewItem(OrgResoMetadataEnumsView viewItem) {
    if (this.view == null) {
      this.view = new ArrayList<OrgResoMetadataEnumsView>();
    }
    this.view.add(viewItem);
    return this;
  }

  /**
   * Get view
   * @return view
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsView> getView() {
    return view;
  }

  public void setView(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
  }

  public OrgResoMetadataPropertyUpdate viewYN(Boolean viewYN) {
    this.viewYN = viewYN;
    return this;
  }

  /**
   * Get viewYN
   * @return viewYN
   **/
  @Schema(description = "")
  
    public Boolean isViewYN() {
    return viewYN;
  }

  public void setViewYN(Boolean viewYN) {
    this.viewYN = viewYN;
  }

  public OrgResoMetadataPropertyUpdate virtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
    return this;
  }

  /**
   * Get virtualTourURLBranded
   * @return virtualTourURLBranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLBranded() {
    return virtualTourURLBranded;
  }

  public void setVirtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
  }

  public OrgResoMetadataPropertyUpdate virtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
    return this;
  }

  /**
   * Get virtualTourURLUnbranded
   * @return virtualTourURLUnbranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLUnbranded() {
    return virtualTourURLUnbranded;
  }

  public void setVirtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
  }

  public OrgResoMetadataPropertyUpdate walkScore(AnyOforgResoMetadataPropertyUpdateWalkScore walkScore) {
    this.walkScore = walkScore;
    return this;
  }

  /**
   * Get walkScore
   * @return walkScore
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateWalkScore getWalkScore() {
    return walkScore;
  }

  public void setWalkScore(AnyOforgResoMetadataPropertyUpdateWalkScore walkScore) {
    this.walkScore = walkScore;
  }

  public OrgResoMetadataPropertyUpdate waterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
    return this;
  }

  /**
   * Get waterBodyName
   * @return waterBodyName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWaterBodyName() {
    return waterBodyName;
  }

  public void setWaterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
  }

  public OrgResoMetadataPropertyUpdate waterSewerExpense(AnyOforgResoMetadataPropertyUpdateWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
    return this;
  }

  /**
   * Get waterSewerExpense
   * @return waterSewerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateWaterSewerExpense getWaterSewerExpense() {
    return waterSewerExpense;
  }

  public void setWaterSewerExpense(AnyOforgResoMetadataPropertyUpdateWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
  }

  public OrgResoMetadataPropertyUpdate waterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addWaterSourceItem(OrgResoMetadataEnumsWaterSource waterSourceItem) {
    if (this.waterSource == null) {
      this.waterSource = new ArrayList<OrgResoMetadataEnumsWaterSource>();
    }
    this.waterSource.add(waterSourceItem);
    return this;
  }

  /**
   * Get waterSource
   * @return waterSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterSource> getWaterSource() {
    return waterSource;
  }

  public void setWaterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
  }

  public OrgResoMetadataPropertyUpdate waterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addWaterfrontFeaturesItem(OrgResoMetadataEnumsWaterfrontFeatures waterfrontFeaturesItem) {
    if (this.waterfrontFeatures == null) {
      this.waterfrontFeatures = new ArrayList<OrgResoMetadataEnumsWaterfrontFeatures>();
    }
    this.waterfrontFeatures.add(waterfrontFeaturesItem);
    return this;
  }

  /**
   * Get waterfrontFeatures
   * @return waterfrontFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterfrontFeatures> getWaterfrontFeatures() {
    return waterfrontFeatures;
  }

  public void setWaterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
  }

  public OrgResoMetadataPropertyUpdate waterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
    return this;
  }

  /**
   * Get waterfrontYN
   * @return waterfrontYN
   **/
  @Schema(description = "")
  
    public Boolean isWaterfrontYN() {
    return waterfrontYN;
  }

  public void setWaterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
  }

  public OrgResoMetadataPropertyUpdate windowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
    return this;
  }

  public OrgResoMetadataPropertyUpdate addWindowFeaturesItem(OrgResoMetadataEnumsWindowFeatures windowFeaturesItem) {
    if (this.windowFeatures == null) {
      this.windowFeatures = new ArrayList<OrgResoMetadataEnumsWindowFeatures>();
    }
    this.windowFeatures.add(windowFeaturesItem);
    return this;
  }

  /**
   * Get windowFeatures
   * @return windowFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWindowFeatures> getWindowFeatures() {
    return windowFeatures;
  }

  public void setWindowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
  }

  public OrgResoMetadataPropertyUpdate withdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
    return this;
  }

  /**
   * Get withdrawnDate
   * @return withdrawnDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getWithdrawnDate() {
    return withdrawnDate;
  }

  public void setWithdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
  }

  public OrgResoMetadataPropertyUpdate woodedArea(AnyOforgResoMetadataPropertyUpdateWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
    return this;
  }

  /**
   * Get woodedArea
   * @return woodedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateWoodedArea getWoodedArea() {
    return woodedArea;
  }

  public void setWoodedArea(AnyOforgResoMetadataPropertyUpdateWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
  }

  public OrgResoMetadataPropertyUpdate workmansCompensationExpense(AnyOforgResoMetadataPropertyUpdateWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
    return this;
  }

  /**
   * Get workmansCompensationExpense
   * @return workmansCompensationExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateWorkmansCompensationExpense getWorkmansCompensationExpense() {
    return workmansCompensationExpense;
  }

  public void setWorkmansCompensationExpense(AnyOforgResoMetadataPropertyUpdateWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
  }

  public OrgResoMetadataPropertyUpdate yearBuilt(AnyOforgResoMetadataPropertyUpdateYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
    return this;
  }

  /**
   * Get yearBuilt
   * @return yearBuilt
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateYearBuilt getYearBuilt() {
    return yearBuilt;
  }

  public void setYearBuilt(AnyOforgResoMetadataPropertyUpdateYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
  }

  public OrgResoMetadataPropertyUpdate yearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
    return this;
  }

  /**
   * Get yearBuiltDetails
   * @return yearBuiltDetails
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getYearBuiltDetails() {
    return yearBuiltDetails;
  }

  public void setYearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
  }

  public OrgResoMetadataPropertyUpdate yearBuiltEffective(AnyOforgResoMetadataPropertyUpdateYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
    return this;
  }

  /**
   * Get yearBuiltEffective
   * @return yearBuiltEffective
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateYearBuiltEffective getYearBuiltEffective() {
    return yearBuiltEffective;
  }

  public void setYearBuiltEffective(AnyOforgResoMetadataPropertyUpdateYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
  }

  public OrgResoMetadataPropertyUpdate yearBuiltSource(AnyOforgResoMetadataPropertyUpdateYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
    return this;
  }

  /**
   * Get yearBuiltSource
   * @return yearBuiltSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUpdateYearBuiltSource getYearBuiltSource() {
    return yearBuiltSource;
  }

  public void setYearBuiltSource(AnyOforgResoMetadataPropertyUpdateYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
  }

  public OrgResoMetadataPropertyUpdate yearEstablished(AnyOforgResoMetadataPropertyUpdateYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
    return this;
  }

  /**
   * Get yearEstablished
   * @return yearEstablished
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateYearEstablished getYearEstablished() {
    return yearEstablished;
  }

  public void setYearEstablished(AnyOforgResoMetadataPropertyUpdateYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
  }

  public OrgResoMetadataPropertyUpdate yearsCurrentOwner(AnyOforgResoMetadataPropertyUpdateYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
    return this;
  }

  /**
   * Get yearsCurrentOwner
   * @return yearsCurrentOwner
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUpdateYearsCurrentOwner getYearsCurrentOwner() {
    return yearsCurrentOwner;
  }

  public void setYearsCurrentOwner(AnyOforgResoMetadataPropertyUpdateYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
  }

  public OrgResoMetadataPropertyUpdate zoning(String zoning) {
    this.zoning = zoning;
    return this;
  }

  /**
   * Get zoning
   * @return zoning
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getZoning() {
    return zoning;
  }

  public void setZoning(String zoning) {
    this.zoning = zoning;
  }

  public OrgResoMetadataPropertyUpdate zoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
    return this;
  }

  /**
   * Get zoningDescription
   * @return zoningDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getZoningDescription() {
    return zoningDescription;
  }

  public void setZoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataPropertyUpdate orgResoMetadataPropertyUpdate = (OrgResoMetadataPropertyUpdate) o;
    return Objects.equals(this.aboveGradeFinishedArea, orgResoMetadataPropertyUpdate.aboveGradeFinishedArea) &&
        Objects.equals(this.aboveGradeFinishedAreaSource, orgResoMetadataPropertyUpdate.aboveGradeFinishedAreaSource) &&
        Objects.equals(this.aboveGradeFinishedAreaUnits, orgResoMetadataPropertyUpdate.aboveGradeFinishedAreaUnits) &&
        Objects.equals(this.accessCode, orgResoMetadataPropertyUpdate.accessCode) &&
        Objects.equals(this.accessibilityFeatures, orgResoMetadataPropertyUpdate.accessibilityFeatures) &&
        Objects.equals(this.additionalParcelsDescription, orgResoMetadataPropertyUpdate.additionalParcelsDescription) &&
        Objects.equals(this.additionalParcelsYN, orgResoMetadataPropertyUpdate.additionalParcelsYN) &&
        Objects.equals(this.anchorsCoTenants, orgResoMetadataPropertyUpdate.anchorsCoTenants) &&
        Objects.equals(this.appliances, orgResoMetadataPropertyUpdate.appliances) &&
        Objects.equals(this.architecturalStyle, orgResoMetadataPropertyUpdate.architecturalStyle) &&
        Objects.equals(this.associationAmenities, orgResoMetadataPropertyUpdate.associationAmenities) &&
        Objects.equals(this.associationFee, orgResoMetadataPropertyUpdate.associationFee) &&
        Objects.equals(this.associationFee2, orgResoMetadataPropertyUpdate.associationFee2) &&
        Objects.equals(this.associationFee2Frequency, orgResoMetadataPropertyUpdate.associationFee2Frequency) &&
        Objects.equals(this.associationFeeFrequency, orgResoMetadataPropertyUpdate.associationFeeFrequency) &&
        Objects.equals(this.associationFeeIncludes, orgResoMetadataPropertyUpdate.associationFeeIncludes) &&
        Objects.equals(this.associationName, orgResoMetadataPropertyUpdate.associationName) &&
        Objects.equals(this.associationName2, orgResoMetadataPropertyUpdate.associationName2) &&
        Objects.equals(this.associationPhone, orgResoMetadataPropertyUpdate.associationPhone) &&
        Objects.equals(this.associationPhone2, orgResoMetadataPropertyUpdate.associationPhone2) &&
        Objects.equals(this.associationYN, orgResoMetadataPropertyUpdate.associationYN) &&
        Objects.equals(this.attachedGarageYN, orgResoMetadataPropertyUpdate.attachedGarageYN) &&
        Objects.equals(this.availabilityDate, orgResoMetadataPropertyUpdate.availabilityDate) &&
        Objects.equals(this.basement, orgResoMetadataPropertyUpdate.basement) &&
        Objects.equals(this.basementYN, orgResoMetadataPropertyUpdate.basementYN) &&
        Objects.equals(this.bathroomsFull, orgResoMetadataPropertyUpdate.bathroomsFull) &&
        Objects.equals(this.bathroomsHalf, orgResoMetadataPropertyUpdate.bathroomsHalf) &&
        Objects.equals(this.bathroomsOneQuarter, orgResoMetadataPropertyUpdate.bathroomsOneQuarter) &&
        Objects.equals(this.bathroomsPartial, orgResoMetadataPropertyUpdate.bathroomsPartial) &&
        Objects.equals(this.bathroomsThreeQuarter, orgResoMetadataPropertyUpdate.bathroomsThreeQuarter) &&
        Objects.equals(this.bathroomsTotalInteger, orgResoMetadataPropertyUpdate.bathroomsTotalInteger) &&
        Objects.equals(this.bedroomsPossible, orgResoMetadataPropertyUpdate.bedroomsPossible) &&
        Objects.equals(this.bedroomsTotal, orgResoMetadataPropertyUpdate.bedroomsTotal) &&
        Objects.equals(this.belowGradeFinishedArea, orgResoMetadataPropertyUpdate.belowGradeFinishedArea) &&
        Objects.equals(this.belowGradeFinishedAreaSource, orgResoMetadataPropertyUpdate.belowGradeFinishedAreaSource) &&
        Objects.equals(this.belowGradeFinishedAreaUnits, orgResoMetadataPropertyUpdate.belowGradeFinishedAreaUnits) &&
        Objects.equals(this.bodyType, orgResoMetadataPropertyUpdate.bodyType) &&
        Objects.equals(this.builderModel, orgResoMetadataPropertyUpdate.builderModel) &&
        Objects.equals(this.builderName, orgResoMetadataPropertyUpdate.builderName) &&
        Objects.equals(this.buildingAreaSource, orgResoMetadataPropertyUpdate.buildingAreaSource) &&
        Objects.equals(this.buildingAreaTotal, orgResoMetadataPropertyUpdate.buildingAreaTotal) &&
        Objects.equals(this.buildingAreaUnits, orgResoMetadataPropertyUpdate.buildingAreaUnits) &&
        Objects.equals(this.buildingFeatures, orgResoMetadataPropertyUpdate.buildingFeatures) &&
        Objects.equals(this.buildingName, orgResoMetadataPropertyUpdate.buildingName) &&
        Objects.equals(this.businessName, orgResoMetadataPropertyUpdate.businessName) &&
        Objects.equals(this.businessType, orgResoMetadataPropertyUpdate.businessType) &&
        Objects.equals(this.buyerAgencyCompensation, orgResoMetadataPropertyUpdate.buyerAgencyCompensation) &&
        Objects.equals(this.buyerAgencyCompensationType, orgResoMetadataPropertyUpdate.buyerAgencyCompensationType) &&
        Objects.equals(this.buyerAgentAOR, orgResoMetadataPropertyUpdate.buyerAgentAOR) &&
        Objects.equals(this.buyerAgentDesignation, orgResoMetadataPropertyUpdate.buyerAgentDesignation) &&
        Objects.equals(this.buyerAgentDirectPhone, orgResoMetadataPropertyUpdate.buyerAgentDirectPhone) &&
        Objects.equals(this.buyerAgentEmail, orgResoMetadataPropertyUpdate.buyerAgentEmail) &&
        Objects.equals(this.buyerAgentFax, orgResoMetadataPropertyUpdate.buyerAgentFax) &&
        Objects.equals(this.buyerAgentFirstName, orgResoMetadataPropertyUpdate.buyerAgentFirstName) &&
        Objects.equals(this.buyerAgentFullName, orgResoMetadataPropertyUpdate.buyerAgentFullName) &&
        Objects.equals(this.buyerAgentHomePhone, orgResoMetadataPropertyUpdate.buyerAgentHomePhone) &&
        Objects.equals(this.buyerAgentKey, orgResoMetadataPropertyUpdate.buyerAgentKey) &&
        Objects.equals(this.buyerAgentKeyNumeric, orgResoMetadataPropertyUpdate.buyerAgentKeyNumeric) &&
        Objects.equals(this.buyerAgentLastName, orgResoMetadataPropertyUpdate.buyerAgentLastName) &&
        Objects.equals(this.buyerAgentMiddleName, orgResoMetadataPropertyUpdate.buyerAgentMiddleName) &&
        Objects.equals(this.buyerAgentMlsId, orgResoMetadataPropertyUpdate.buyerAgentMlsId) &&
        Objects.equals(this.buyerAgentMobilePhone, orgResoMetadataPropertyUpdate.buyerAgentMobilePhone) &&
        Objects.equals(this.buyerAgentNamePrefix, orgResoMetadataPropertyUpdate.buyerAgentNamePrefix) &&
        Objects.equals(this.buyerAgentNameSuffix, orgResoMetadataPropertyUpdate.buyerAgentNameSuffix) &&
        Objects.equals(this.buyerAgentOfficePhone, orgResoMetadataPropertyUpdate.buyerAgentOfficePhone) &&
        Objects.equals(this.buyerAgentOfficePhoneExt, orgResoMetadataPropertyUpdate.buyerAgentOfficePhoneExt) &&
        Objects.equals(this.buyerAgentPager, orgResoMetadataPropertyUpdate.buyerAgentPager) &&
        Objects.equals(this.buyerAgentPreferredPhone, orgResoMetadataPropertyUpdate.buyerAgentPreferredPhone) &&
        Objects.equals(this.buyerAgentPreferredPhoneExt, orgResoMetadataPropertyUpdate.buyerAgentPreferredPhoneExt) &&
        Objects.equals(this.buyerAgentStateLicense, orgResoMetadataPropertyUpdate.buyerAgentStateLicense) &&
        Objects.equals(this.buyerAgentTollFreePhone, orgResoMetadataPropertyUpdate.buyerAgentTollFreePhone) &&
        Objects.equals(this.buyerAgentURL, orgResoMetadataPropertyUpdate.buyerAgentURL) &&
        Objects.equals(this.buyerAgentVoiceMail, orgResoMetadataPropertyUpdate.buyerAgentVoiceMail) &&
        Objects.equals(this.buyerAgentVoiceMailExt, orgResoMetadataPropertyUpdate.buyerAgentVoiceMailExt) &&
        Objects.equals(this.buyerFinancing, orgResoMetadataPropertyUpdate.buyerFinancing) &&
        Objects.equals(this.buyerOfficeAOR, orgResoMetadataPropertyUpdate.buyerOfficeAOR) &&
        Objects.equals(this.buyerOfficeEmail, orgResoMetadataPropertyUpdate.buyerOfficeEmail) &&
        Objects.equals(this.buyerOfficeFax, orgResoMetadataPropertyUpdate.buyerOfficeFax) &&
        Objects.equals(this.buyerOfficeKey, orgResoMetadataPropertyUpdate.buyerOfficeKey) &&
        Objects.equals(this.buyerOfficeKeyNumeric, orgResoMetadataPropertyUpdate.buyerOfficeKeyNumeric) &&
        Objects.equals(this.buyerOfficeMlsId, orgResoMetadataPropertyUpdate.buyerOfficeMlsId) &&
        Objects.equals(this.buyerOfficeName, orgResoMetadataPropertyUpdate.buyerOfficeName) &&
        Objects.equals(this.buyerOfficePhone, orgResoMetadataPropertyUpdate.buyerOfficePhone) &&
        Objects.equals(this.buyerOfficePhoneExt, orgResoMetadataPropertyUpdate.buyerOfficePhoneExt) &&
        Objects.equals(this.buyerOfficeURL, orgResoMetadataPropertyUpdate.buyerOfficeURL) &&
        Objects.equals(this.buyerTeamKey, orgResoMetadataPropertyUpdate.buyerTeamKey) &&
        Objects.equals(this.buyerTeamKeyNumeric, orgResoMetadataPropertyUpdate.buyerTeamKeyNumeric) &&
        Objects.equals(this.buyerTeamName, orgResoMetadataPropertyUpdate.buyerTeamName) &&
        Objects.equals(this.cableTvExpense, orgResoMetadataPropertyUpdate.cableTvExpense) &&
        Objects.equals(this.cancellationDate, orgResoMetadataPropertyUpdate.cancellationDate) &&
        Objects.equals(this.capRate, orgResoMetadataPropertyUpdate.capRate) &&
        Objects.equals(this.carportSpaces, orgResoMetadataPropertyUpdate.carportSpaces) &&
        Objects.equals(this.carportYN, orgResoMetadataPropertyUpdate.carportYN) &&
        Objects.equals(this.carrierRoute, orgResoMetadataPropertyUpdate.carrierRoute) &&
        Objects.equals(this.city, orgResoMetadataPropertyUpdate.city) &&
        Objects.equals(this.cityRegion, orgResoMetadataPropertyUpdate.cityRegion) &&
        Objects.equals(this.closeDate, orgResoMetadataPropertyUpdate.closeDate) &&
        Objects.equals(this.closePrice, orgResoMetadataPropertyUpdate.closePrice) &&
        Objects.equals(this.coBuyerAgentAOR, orgResoMetadataPropertyUpdate.coBuyerAgentAOR) &&
        Objects.equals(this.coBuyerAgentDesignation, orgResoMetadataPropertyUpdate.coBuyerAgentDesignation) &&
        Objects.equals(this.coBuyerAgentDirectPhone, orgResoMetadataPropertyUpdate.coBuyerAgentDirectPhone) &&
        Objects.equals(this.coBuyerAgentEmail, orgResoMetadataPropertyUpdate.coBuyerAgentEmail) &&
        Objects.equals(this.coBuyerAgentFax, orgResoMetadataPropertyUpdate.coBuyerAgentFax) &&
        Objects.equals(this.coBuyerAgentFirstName, orgResoMetadataPropertyUpdate.coBuyerAgentFirstName) &&
        Objects.equals(this.coBuyerAgentFullName, orgResoMetadataPropertyUpdate.coBuyerAgentFullName) &&
        Objects.equals(this.coBuyerAgentHomePhone, orgResoMetadataPropertyUpdate.coBuyerAgentHomePhone) &&
        Objects.equals(this.coBuyerAgentKey, orgResoMetadataPropertyUpdate.coBuyerAgentKey) &&
        Objects.equals(this.coBuyerAgentKeyNumeric, orgResoMetadataPropertyUpdate.coBuyerAgentKeyNumeric) &&
        Objects.equals(this.coBuyerAgentLastName, orgResoMetadataPropertyUpdate.coBuyerAgentLastName) &&
        Objects.equals(this.coBuyerAgentMiddleName, orgResoMetadataPropertyUpdate.coBuyerAgentMiddleName) &&
        Objects.equals(this.coBuyerAgentMlsId, orgResoMetadataPropertyUpdate.coBuyerAgentMlsId) &&
        Objects.equals(this.coBuyerAgentMobilePhone, orgResoMetadataPropertyUpdate.coBuyerAgentMobilePhone) &&
        Objects.equals(this.coBuyerAgentNamePrefix, orgResoMetadataPropertyUpdate.coBuyerAgentNamePrefix) &&
        Objects.equals(this.coBuyerAgentNameSuffix, orgResoMetadataPropertyUpdate.coBuyerAgentNameSuffix) &&
        Objects.equals(this.coBuyerAgentOfficePhone, orgResoMetadataPropertyUpdate.coBuyerAgentOfficePhone) &&
        Objects.equals(this.coBuyerAgentOfficePhoneExt, orgResoMetadataPropertyUpdate.coBuyerAgentOfficePhoneExt) &&
        Objects.equals(this.coBuyerAgentPager, orgResoMetadataPropertyUpdate.coBuyerAgentPager) &&
        Objects.equals(this.coBuyerAgentPreferredPhone, orgResoMetadataPropertyUpdate.coBuyerAgentPreferredPhone) &&
        Objects.equals(this.coBuyerAgentPreferredPhoneExt, orgResoMetadataPropertyUpdate.coBuyerAgentPreferredPhoneExt) &&
        Objects.equals(this.coBuyerAgentStateLicense, orgResoMetadataPropertyUpdate.coBuyerAgentStateLicense) &&
        Objects.equals(this.coBuyerAgentTollFreePhone, orgResoMetadataPropertyUpdate.coBuyerAgentTollFreePhone) &&
        Objects.equals(this.coBuyerAgentURL, orgResoMetadataPropertyUpdate.coBuyerAgentURL) &&
        Objects.equals(this.coBuyerAgentVoiceMail, orgResoMetadataPropertyUpdate.coBuyerAgentVoiceMail) &&
        Objects.equals(this.coBuyerAgentVoiceMailExt, orgResoMetadataPropertyUpdate.coBuyerAgentVoiceMailExt) &&
        Objects.equals(this.coBuyerOfficeAOR, orgResoMetadataPropertyUpdate.coBuyerOfficeAOR) &&
        Objects.equals(this.coBuyerOfficeEmail, orgResoMetadataPropertyUpdate.coBuyerOfficeEmail) &&
        Objects.equals(this.coBuyerOfficeFax, orgResoMetadataPropertyUpdate.coBuyerOfficeFax) &&
        Objects.equals(this.coBuyerOfficeKey, orgResoMetadataPropertyUpdate.coBuyerOfficeKey) &&
        Objects.equals(this.coBuyerOfficeKeyNumeric, orgResoMetadataPropertyUpdate.coBuyerOfficeKeyNumeric) &&
        Objects.equals(this.coBuyerOfficeMlsId, orgResoMetadataPropertyUpdate.coBuyerOfficeMlsId) &&
        Objects.equals(this.coBuyerOfficeName, orgResoMetadataPropertyUpdate.coBuyerOfficeName) &&
        Objects.equals(this.coBuyerOfficePhone, orgResoMetadataPropertyUpdate.coBuyerOfficePhone) &&
        Objects.equals(this.coBuyerOfficePhoneExt, orgResoMetadataPropertyUpdate.coBuyerOfficePhoneExt) &&
        Objects.equals(this.coBuyerOfficeURL, orgResoMetadataPropertyUpdate.coBuyerOfficeURL) &&
        Objects.equals(this.coListAgentAOR, orgResoMetadataPropertyUpdate.coListAgentAOR) &&
        Objects.equals(this.coListAgentDesignation, orgResoMetadataPropertyUpdate.coListAgentDesignation) &&
        Objects.equals(this.coListAgentDirectPhone, orgResoMetadataPropertyUpdate.coListAgentDirectPhone) &&
        Objects.equals(this.coListAgentEmail, orgResoMetadataPropertyUpdate.coListAgentEmail) &&
        Objects.equals(this.coListAgentFax, orgResoMetadataPropertyUpdate.coListAgentFax) &&
        Objects.equals(this.coListAgentFirstName, orgResoMetadataPropertyUpdate.coListAgentFirstName) &&
        Objects.equals(this.coListAgentFullName, orgResoMetadataPropertyUpdate.coListAgentFullName) &&
        Objects.equals(this.coListAgentHomePhone, orgResoMetadataPropertyUpdate.coListAgentHomePhone) &&
        Objects.equals(this.coListAgentKey, orgResoMetadataPropertyUpdate.coListAgentKey) &&
        Objects.equals(this.coListAgentKeyNumeric, orgResoMetadataPropertyUpdate.coListAgentKeyNumeric) &&
        Objects.equals(this.coListAgentLastName, orgResoMetadataPropertyUpdate.coListAgentLastName) &&
        Objects.equals(this.coListAgentMiddleName, orgResoMetadataPropertyUpdate.coListAgentMiddleName) &&
        Objects.equals(this.coListAgentMlsId, orgResoMetadataPropertyUpdate.coListAgentMlsId) &&
        Objects.equals(this.coListAgentMobilePhone, orgResoMetadataPropertyUpdate.coListAgentMobilePhone) &&
        Objects.equals(this.coListAgentNamePrefix, orgResoMetadataPropertyUpdate.coListAgentNamePrefix) &&
        Objects.equals(this.coListAgentNameSuffix, orgResoMetadataPropertyUpdate.coListAgentNameSuffix) &&
        Objects.equals(this.coListAgentOfficePhone, orgResoMetadataPropertyUpdate.coListAgentOfficePhone) &&
        Objects.equals(this.coListAgentOfficePhoneExt, orgResoMetadataPropertyUpdate.coListAgentOfficePhoneExt) &&
        Objects.equals(this.coListAgentPager, orgResoMetadataPropertyUpdate.coListAgentPager) &&
        Objects.equals(this.coListAgentPreferredPhone, orgResoMetadataPropertyUpdate.coListAgentPreferredPhone) &&
        Objects.equals(this.coListAgentPreferredPhoneExt, orgResoMetadataPropertyUpdate.coListAgentPreferredPhoneExt) &&
        Objects.equals(this.coListAgentStateLicense, orgResoMetadataPropertyUpdate.coListAgentStateLicense) &&
        Objects.equals(this.coListAgentTollFreePhone, orgResoMetadataPropertyUpdate.coListAgentTollFreePhone) &&
        Objects.equals(this.coListAgentURL, orgResoMetadataPropertyUpdate.coListAgentURL) &&
        Objects.equals(this.coListAgentVoiceMail, orgResoMetadataPropertyUpdate.coListAgentVoiceMail) &&
        Objects.equals(this.coListAgentVoiceMailExt, orgResoMetadataPropertyUpdate.coListAgentVoiceMailExt) &&
        Objects.equals(this.coListOfficeAOR, orgResoMetadataPropertyUpdate.coListOfficeAOR) &&
        Objects.equals(this.coListOfficeEmail, orgResoMetadataPropertyUpdate.coListOfficeEmail) &&
        Objects.equals(this.coListOfficeFax, orgResoMetadataPropertyUpdate.coListOfficeFax) &&
        Objects.equals(this.coListOfficeKey, orgResoMetadataPropertyUpdate.coListOfficeKey) &&
        Objects.equals(this.coListOfficeKeyNumeric, orgResoMetadataPropertyUpdate.coListOfficeKeyNumeric) &&
        Objects.equals(this.coListOfficeMlsId, orgResoMetadataPropertyUpdate.coListOfficeMlsId) &&
        Objects.equals(this.coListOfficeName, orgResoMetadataPropertyUpdate.coListOfficeName) &&
        Objects.equals(this.coListOfficePhone, orgResoMetadataPropertyUpdate.coListOfficePhone) &&
        Objects.equals(this.coListOfficePhoneExt, orgResoMetadataPropertyUpdate.coListOfficePhoneExt) &&
        Objects.equals(this.coListOfficeURL, orgResoMetadataPropertyUpdate.coListOfficeURL) &&
        Objects.equals(this.commonInterest, orgResoMetadataPropertyUpdate.commonInterest) &&
        Objects.equals(this.commonWalls, orgResoMetadataPropertyUpdate.commonWalls) &&
        Objects.equals(this.communityFeatures, orgResoMetadataPropertyUpdate.communityFeatures) &&
        Objects.equals(this.concessions, orgResoMetadataPropertyUpdate.concessions) &&
        Objects.equals(this.concessionsAmount, orgResoMetadataPropertyUpdate.concessionsAmount) &&
        Objects.equals(this.concessionsComments, orgResoMetadataPropertyUpdate.concessionsComments) &&
        Objects.equals(this.constructionMaterials, orgResoMetadataPropertyUpdate.constructionMaterials) &&
        Objects.equals(this.continentRegion, orgResoMetadataPropertyUpdate.continentRegion) &&
        Objects.equals(this.contingency, orgResoMetadataPropertyUpdate.contingency) &&
        Objects.equals(this.contingentDate, orgResoMetadataPropertyUpdate.contingentDate) &&
        Objects.equals(this.contractStatusChangeDate, orgResoMetadataPropertyUpdate.contractStatusChangeDate) &&
        Objects.equals(this.cooling, orgResoMetadataPropertyUpdate.cooling) &&
        Objects.equals(this.coolingYN, orgResoMetadataPropertyUpdate.coolingYN) &&
        Objects.equals(this.copyrightNotice, orgResoMetadataPropertyUpdate.copyrightNotice) &&
        Objects.equals(this.country, orgResoMetadataPropertyUpdate.country) &&
        Objects.equals(this.countryRegion, orgResoMetadataPropertyUpdate.countryRegion) &&
        Objects.equals(this.countyOrParish, orgResoMetadataPropertyUpdate.countyOrParish) &&
        Objects.equals(this.coveredSpaces, orgResoMetadataPropertyUpdate.coveredSpaces) &&
        Objects.equals(this.cropsIncludedYN, orgResoMetadataPropertyUpdate.cropsIncludedYN) &&
        Objects.equals(this.crossStreet, orgResoMetadataPropertyUpdate.crossStreet) &&
        Objects.equals(this.cultivatedArea, orgResoMetadataPropertyUpdate.cultivatedArea) &&
        Objects.equals(this.cumulativeDaysOnMarket, orgResoMetadataPropertyUpdate.cumulativeDaysOnMarket) &&
        Objects.equals(this.currentFinancing, orgResoMetadataPropertyUpdate.currentFinancing) &&
        Objects.equals(this.currentUse, orgResoMetadataPropertyUpdate.currentUse) &&
        Objects.equals(this.doH1, orgResoMetadataPropertyUpdate.doH1) &&
        Objects.equals(this.doH2, orgResoMetadataPropertyUpdate.doH2) &&
        Objects.equals(this.doH3, orgResoMetadataPropertyUpdate.doH3) &&
        Objects.equals(this.daysOnMarket, orgResoMetadataPropertyUpdate.daysOnMarket) &&
        Objects.equals(this.developmentStatus, orgResoMetadataPropertyUpdate.developmentStatus) &&
        Objects.equals(this.directionFaces, orgResoMetadataPropertyUpdate.directionFaces) &&
        Objects.equals(this.directions, orgResoMetadataPropertyUpdate.directions) &&
        Objects.equals(this.disclaimer, orgResoMetadataPropertyUpdate.disclaimer) &&
        Objects.equals(this.disclosures, orgResoMetadataPropertyUpdate.disclosures) &&
        Objects.equals(this.distanceToBusComments, orgResoMetadataPropertyUpdate.distanceToBusComments) &&
        Objects.equals(this.distanceToBusNumeric, orgResoMetadataPropertyUpdate.distanceToBusNumeric) &&
        Objects.equals(this.distanceToBusUnits, orgResoMetadataPropertyUpdate.distanceToBusUnits) &&
        Objects.equals(this.distanceToElectricComments, orgResoMetadataPropertyUpdate.distanceToElectricComments) &&
        Objects.equals(this.distanceToElectricNumeric, orgResoMetadataPropertyUpdate.distanceToElectricNumeric) &&
        Objects.equals(this.distanceToElectricUnits, orgResoMetadataPropertyUpdate.distanceToElectricUnits) &&
        Objects.equals(this.distanceToFreewayComments, orgResoMetadataPropertyUpdate.distanceToFreewayComments) &&
        Objects.equals(this.distanceToFreewayNumeric, orgResoMetadataPropertyUpdate.distanceToFreewayNumeric) &&
        Objects.equals(this.distanceToFreewayUnits, orgResoMetadataPropertyUpdate.distanceToFreewayUnits) &&
        Objects.equals(this.distanceToGasComments, orgResoMetadataPropertyUpdate.distanceToGasComments) &&
        Objects.equals(this.distanceToGasNumeric, orgResoMetadataPropertyUpdate.distanceToGasNumeric) &&
        Objects.equals(this.distanceToGasUnits, orgResoMetadataPropertyUpdate.distanceToGasUnits) &&
        Objects.equals(this.distanceToPhoneServiceComments, orgResoMetadataPropertyUpdate.distanceToPhoneServiceComments) &&
        Objects.equals(this.distanceToPhoneServiceNumeric, orgResoMetadataPropertyUpdate.distanceToPhoneServiceNumeric) &&
        Objects.equals(this.distanceToPhoneServiceUnits, orgResoMetadataPropertyUpdate.distanceToPhoneServiceUnits) &&
        Objects.equals(this.distanceToPlaceofWorshipComments, orgResoMetadataPropertyUpdate.distanceToPlaceofWorshipComments) &&
        Objects.equals(this.distanceToPlaceofWorshipNumeric, orgResoMetadataPropertyUpdate.distanceToPlaceofWorshipNumeric) &&
        Objects.equals(this.distanceToPlaceofWorshipUnits, orgResoMetadataPropertyUpdate.distanceToPlaceofWorshipUnits) &&
        Objects.equals(this.distanceToSchoolBusComments, orgResoMetadataPropertyUpdate.distanceToSchoolBusComments) &&
        Objects.equals(this.distanceToSchoolBusNumeric, orgResoMetadataPropertyUpdate.distanceToSchoolBusNumeric) &&
        Objects.equals(this.distanceToSchoolBusUnits, orgResoMetadataPropertyUpdate.distanceToSchoolBusUnits) &&
        Objects.equals(this.distanceToSchoolsComments, orgResoMetadataPropertyUpdate.distanceToSchoolsComments) &&
        Objects.equals(this.distanceToSchoolsNumeric, orgResoMetadataPropertyUpdate.distanceToSchoolsNumeric) &&
        Objects.equals(this.distanceToSchoolsUnits, orgResoMetadataPropertyUpdate.distanceToSchoolsUnits) &&
        Objects.equals(this.distanceToSewerComments, orgResoMetadataPropertyUpdate.distanceToSewerComments) &&
        Objects.equals(this.distanceToSewerNumeric, orgResoMetadataPropertyUpdate.distanceToSewerNumeric) &&
        Objects.equals(this.distanceToSewerUnits, orgResoMetadataPropertyUpdate.distanceToSewerUnits) &&
        Objects.equals(this.distanceToShoppingComments, orgResoMetadataPropertyUpdate.distanceToShoppingComments) &&
        Objects.equals(this.distanceToShoppingNumeric, orgResoMetadataPropertyUpdate.distanceToShoppingNumeric) &&
        Objects.equals(this.distanceToShoppingUnits, orgResoMetadataPropertyUpdate.distanceToShoppingUnits) &&
        Objects.equals(this.distanceToStreetComments, orgResoMetadataPropertyUpdate.distanceToStreetComments) &&
        Objects.equals(this.distanceToStreetNumeric, orgResoMetadataPropertyUpdate.distanceToStreetNumeric) &&
        Objects.equals(this.distanceToStreetUnits, orgResoMetadataPropertyUpdate.distanceToStreetUnits) &&
        Objects.equals(this.distanceToWaterComments, orgResoMetadataPropertyUpdate.distanceToWaterComments) &&
        Objects.equals(this.distanceToWaterNumeric, orgResoMetadataPropertyUpdate.distanceToWaterNumeric) &&
        Objects.equals(this.distanceToWaterUnits, orgResoMetadataPropertyUpdate.distanceToWaterUnits) &&
        Objects.equals(this.documentsAvailable, orgResoMetadataPropertyUpdate.documentsAvailable) &&
        Objects.equals(this.documentsChangeTimestamp, orgResoMetadataPropertyUpdate.documentsChangeTimestamp) &&
        Objects.equals(this.documentsCount, orgResoMetadataPropertyUpdate.documentsCount) &&
        Objects.equals(this.doorFeatures, orgResoMetadataPropertyUpdate.doorFeatures) &&
        Objects.equals(this.dualVariableCompensationYN, orgResoMetadataPropertyUpdate.dualVariableCompensationYN) &&
        Objects.equals(this.electric, orgResoMetadataPropertyUpdate.electric) &&
        Objects.equals(this.electricExpense, orgResoMetadataPropertyUpdate.electricExpense) &&
        Objects.equals(this.electricOnPropertyYN, orgResoMetadataPropertyUpdate.electricOnPropertyYN) &&
        Objects.equals(this.elementarySchool, orgResoMetadataPropertyUpdate.elementarySchool) &&
        Objects.equals(this.elementarySchoolDistrict, orgResoMetadataPropertyUpdate.elementarySchoolDistrict) &&
        Objects.equals(this.elevation, orgResoMetadataPropertyUpdate.elevation) &&
        Objects.equals(this.elevationUnits, orgResoMetadataPropertyUpdate.elevationUnits) &&
        Objects.equals(this.entryLevel, orgResoMetadataPropertyUpdate.entryLevel) &&
        Objects.equals(this.entryLocation, orgResoMetadataPropertyUpdate.entryLocation) &&
        Objects.equals(this.exclusions, orgResoMetadataPropertyUpdate.exclusions) &&
        Objects.equals(this.existingLeaseType, orgResoMetadataPropertyUpdate.existingLeaseType) &&
        Objects.equals(this.expirationDate, orgResoMetadataPropertyUpdate.expirationDate) &&
        Objects.equals(this.exteriorFeatures, orgResoMetadataPropertyUpdate.exteriorFeatures) &&
        Objects.equals(this.farmCreditServiceInclYN, orgResoMetadataPropertyUpdate.farmCreditServiceInclYN) &&
        Objects.equals(this.farmLandAreaSource, orgResoMetadataPropertyUpdate.farmLandAreaSource) &&
        Objects.equals(this.farmLandAreaUnits, orgResoMetadataPropertyUpdate.farmLandAreaUnits) &&
        Objects.equals(this.fencing, orgResoMetadataPropertyUpdate.fencing) &&
        Objects.equals(this.financialDataSource, orgResoMetadataPropertyUpdate.financialDataSource) &&
        Objects.equals(this.fireplaceFeatures, orgResoMetadataPropertyUpdate.fireplaceFeatures) &&
        Objects.equals(this.fireplaceYN, orgResoMetadataPropertyUpdate.fireplaceYN) &&
        Objects.equals(this.fireplacesTotal, orgResoMetadataPropertyUpdate.fireplacesTotal) &&
        Objects.equals(this.flooring, orgResoMetadataPropertyUpdate.flooring) &&
        Objects.equals(this.foundationArea, orgResoMetadataPropertyUpdate.foundationArea) &&
        Objects.equals(this.foundationDetails, orgResoMetadataPropertyUpdate.foundationDetails) &&
        Objects.equals(this.frontageLength, orgResoMetadataPropertyUpdate.frontageLength) &&
        Objects.equals(this.frontageType, orgResoMetadataPropertyUpdate.frontageType) &&
        Objects.equals(this.fuelExpense, orgResoMetadataPropertyUpdate.fuelExpense) &&
        Objects.equals(this.furnished, orgResoMetadataPropertyUpdate.furnished) &&
        Objects.equals(this.furnitureReplacementExpense, orgResoMetadataPropertyUpdate.furnitureReplacementExpense) &&
        Objects.equals(this.garageSpaces, orgResoMetadataPropertyUpdate.garageSpaces) &&
        Objects.equals(this.garageYN, orgResoMetadataPropertyUpdate.garageYN) &&
        Objects.equals(this.gardenerExpense, orgResoMetadataPropertyUpdate.gardenerExpense) &&
        Objects.equals(this.grazingPermitsBlmYN, orgResoMetadataPropertyUpdate.grazingPermitsBlmYN) &&
        Objects.equals(this.grazingPermitsForestServiceYN, orgResoMetadataPropertyUpdate.grazingPermitsForestServiceYN) &&
        Objects.equals(this.grazingPermitsPrivateYN, orgResoMetadataPropertyUpdate.grazingPermitsPrivateYN) &&
        Objects.equals(this.greenBuildingVerificationType, orgResoMetadataPropertyUpdate.greenBuildingVerificationType) &&
        Objects.equals(this.greenEnergyEfficient, orgResoMetadataPropertyUpdate.greenEnergyEfficient) &&
        Objects.equals(this.greenEnergyGeneration, orgResoMetadataPropertyUpdate.greenEnergyGeneration) &&
        Objects.equals(this.greenIndoorAirQuality, orgResoMetadataPropertyUpdate.greenIndoorAirQuality) &&
        Objects.equals(this.greenLocation, orgResoMetadataPropertyUpdate.greenLocation) &&
        Objects.equals(this.greenSustainability, orgResoMetadataPropertyUpdate.greenSustainability) &&
        Objects.equals(this.greenWaterConservation, orgResoMetadataPropertyUpdate.greenWaterConservation) &&
        Objects.equals(this.grossIncome, orgResoMetadataPropertyUpdate.grossIncome) &&
        Objects.equals(this.grossScheduledIncome, orgResoMetadataPropertyUpdate.grossScheduledIncome) &&
        Objects.equals(this.habitableResidenceYN, orgResoMetadataPropertyUpdate.habitableResidenceYN) &&
        Objects.equals(this.heating, orgResoMetadataPropertyUpdate.heating) &&
        Objects.equals(this.heatingYN, orgResoMetadataPropertyUpdate.heatingYN) &&
        Objects.equals(this.highSchool, orgResoMetadataPropertyUpdate.highSchool) &&
        Objects.equals(this.highSchoolDistrict, orgResoMetadataPropertyUpdate.highSchoolDistrict) &&
        Objects.equals(this.homeWarrantyYN, orgResoMetadataPropertyUpdate.homeWarrantyYN) &&
        Objects.equals(this.horseAmenities, orgResoMetadataPropertyUpdate.horseAmenities) &&
        Objects.equals(this.horseYN, orgResoMetadataPropertyUpdate.horseYN) &&
        Objects.equals(this.hoursDaysOfOperation, orgResoMetadataPropertyUpdate.hoursDaysOfOperation) &&
        Objects.equals(this.hoursDaysOfOperationDescription, orgResoMetadataPropertyUpdate.hoursDaysOfOperationDescription) &&
        Objects.equals(this.inclusions, orgResoMetadataPropertyUpdate.inclusions) &&
        Objects.equals(this.incomeIncludes, orgResoMetadataPropertyUpdate.incomeIncludes) &&
        Objects.equals(this.insuranceExpense, orgResoMetadataPropertyUpdate.insuranceExpense) &&
        Objects.equals(this.interiorFeatures, orgResoMetadataPropertyUpdate.interiorFeatures) &&
        Objects.equals(this.internetAddressDisplayYN, orgResoMetadataPropertyUpdate.internetAddressDisplayYN) &&
        Objects.equals(this.internetAutomatedValuationDisplayYN, orgResoMetadataPropertyUpdate.internetAutomatedValuationDisplayYN) &&
        Objects.equals(this.internetConsumerCommentYN, orgResoMetadataPropertyUpdate.internetConsumerCommentYN) &&
        Objects.equals(this.internetEntireListingDisplayYN, orgResoMetadataPropertyUpdate.internetEntireListingDisplayYN) &&
        Objects.equals(this.irrigationSource, orgResoMetadataPropertyUpdate.irrigationSource) &&
        Objects.equals(this.irrigationWaterRightsAcres, orgResoMetadataPropertyUpdate.irrigationWaterRightsAcres) &&
        Objects.equals(this.irrigationWaterRightsYN, orgResoMetadataPropertyUpdate.irrigationWaterRightsYN) &&
        Objects.equals(this.laborInformation, orgResoMetadataPropertyUpdate.laborInformation) &&
        Objects.equals(this.landLeaseAmount, orgResoMetadataPropertyUpdate.landLeaseAmount) &&
        Objects.equals(this.landLeaseAmountFrequency, orgResoMetadataPropertyUpdate.landLeaseAmountFrequency) &&
        Objects.equals(this.landLeaseExpirationDate, orgResoMetadataPropertyUpdate.landLeaseExpirationDate) &&
        Objects.equals(this.landLeaseYN, orgResoMetadataPropertyUpdate.landLeaseYN) &&
        Objects.equals(this.latitude, orgResoMetadataPropertyUpdate.latitude) &&
        Objects.equals(this.laundryFeatures, orgResoMetadataPropertyUpdate.laundryFeatures) &&
        Objects.equals(this.leasableArea, orgResoMetadataPropertyUpdate.leasableArea) &&
        Objects.equals(this.leasableAreaUnits, orgResoMetadataPropertyUpdate.leasableAreaUnits) &&
        Objects.equals(this.leaseAmount, orgResoMetadataPropertyUpdate.leaseAmount) &&
        Objects.equals(this.leaseAmountFrequency, orgResoMetadataPropertyUpdate.leaseAmountFrequency) &&
        Objects.equals(this.leaseAssignableYN, orgResoMetadataPropertyUpdate.leaseAssignableYN) &&
        Objects.equals(this.leaseConsideredYN, orgResoMetadataPropertyUpdate.leaseConsideredYN) &&
        Objects.equals(this.leaseExpiration, orgResoMetadataPropertyUpdate.leaseExpiration) &&
        Objects.equals(this.leaseRenewalCompensation, orgResoMetadataPropertyUpdate.leaseRenewalCompensation) &&
        Objects.equals(this.leaseRenewalOptionYN, orgResoMetadataPropertyUpdate.leaseRenewalOptionYN) &&
        Objects.equals(this.leaseTerm, orgResoMetadataPropertyUpdate.leaseTerm) &&
        Objects.equals(this.levels, orgResoMetadataPropertyUpdate.levels) &&
        Objects.equals(this.license1, orgResoMetadataPropertyUpdate.license1) &&
        Objects.equals(this.license2, orgResoMetadataPropertyUpdate.license2) &&
        Objects.equals(this.license3, orgResoMetadataPropertyUpdate.license3) &&
        Objects.equals(this.licensesExpense, orgResoMetadataPropertyUpdate.licensesExpense) &&
        Objects.equals(this.listAOR, orgResoMetadataPropertyUpdate.listAOR) &&
        Objects.equals(this.listAgentAOR, orgResoMetadataPropertyUpdate.listAgentAOR) &&
        Objects.equals(this.listAgentDesignation, orgResoMetadataPropertyUpdate.listAgentDesignation) &&
        Objects.equals(this.listAgentDirectPhone, orgResoMetadataPropertyUpdate.listAgentDirectPhone) &&
        Objects.equals(this.listAgentEmail, orgResoMetadataPropertyUpdate.listAgentEmail) &&
        Objects.equals(this.listAgentFax, orgResoMetadataPropertyUpdate.listAgentFax) &&
        Objects.equals(this.listAgentFirstName, orgResoMetadataPropertyUpdate.listAgentFirstName) &&
        Objects.equals(this.listAgentFullName, orgResoMetadataPropertyUpdate.listAgentFullName) &&
        Objects.equals(this.listAgentHomePhone, orgResoMetadataPropertyUpdate.listAgentHomePhone) &&
        Objects.equals(this.listAgentKey, orgResoMetadataPropertyUpdate.listAgentKey) &&
        Objects.equals(this.listAgentKeyNumeric, orgResoMetadataPropertyUpdate.listAgentKeyNumeric) &&
        Objects.equals(this.listAgentLastName, orgResoMetadataPropertyUpdate.listAgentLastName) &&
        Objects.equals(this.listAgentMiddleName, orgResoMetadataPropertyUpdate.listAgentMiddleName) &&
        Objects.equals(this.listAgentMlsId, orgResoMetadataPropertyUpdate.listAgentMlsId) &&
        Objects.equals(this.listAgentMobilePhone, orgResoMetadataPropertyUpdate.listAgentMobilePhone) &&
        Objects.equals(this.listAgentNamePrefix, orgResoMetadataPropertyUpdate.listAgentNamePrefix) &&
        Objects.equals(this.listAgentNameSuffix, orgResoMetadataPropertyUpdate.listAgentNameSuffix) &&
        Objects.equals(this.listAgentOfficePhone, orgResoMetadataPropertyUpdate.listAgentOfficePhone) &&
        Objects.equals(this.listAgentOfficePhoneExt, orgResoMetadataPropertyUpdate.listAgentOfficePhoneExt) &&
        Objects.equals(this.listAgentPager, orgResoMetadataPropertyUpdate.listAgentPager) &&
        Objects.equals(this.listAgentPreferredPhone, orgResoMetadataPropertyUpdate.listAgentPreferredPhone) &&
        Objects.equals(this.listAgentPreferredPhoneExt, orgResoMetadataPropertyUpdate.listAgentPreferredPhoneExt) &&
        Objects.equals(this.listAgentStateLicense, orgResoMetadataPropertyUpdate.listAgentStateLicense) &&
        Objects.equals(this.listAgentTollFreePhone, orgResoMetadataPropertyUpdate.listAgentTollFreePhone) &&
        Objects.equals(this.listAgentURL, orgResoMetadataPropertyUpdate.listAgentURL) &&
        Objects.equals(this.listAgentVoiceMail, orgResoMetadataPropertyUpdate.listAgentVoiceMail) &&
        Objects.equals(this.listAgentVoiceMailExt, orgResoMetadataPropertyUpdate.listAgentVoiceMailExt) &&
        Objects.equals(this.listOfficeAOR, orgResoMetadataPropertyUpdate.listOfficeAOR) &&
        Objects.equals(this.listOfficeEmail, orgResoMetadataPropertyUpdate.listOfficeEmail) &&
        Objects.equals(this.listOfficeFax, orgResoMetadataPropertyUpdate.listOfficeFax) &&
        Objects.equals(this.listOfficeKey, orgResoMetadataPropertyUpdate.listOfficeKey) &&
        Objects.equals(this.listOfficeKeyNumeric, orgResoMetadataPropertyUpdate.listOfficeKeyNumeric) &&
        Objects.equals(this.listOfficeMlsId, orgResoMetadataPropertyUpdate.listOfficeMlsId) &&
        Objects.equals(this.listOfficeName, orgResoMetadataPropertyUpdate.listOfficeName) &&
        Objects.equals(this.listOfficePhone, orgResoMetadataPropertyUpdate.listOfficePhone) &&
        Objects.equals(this.listOfficePhoneExt, orgResoMetadataPropertyUpdate.listOfficePhoneExt) &&
        Objects.equals(this.listOfficeURL, orgResoMetadataPropertyUpdate.listOfficeURL) &&
        Objects.equals(this.listPrice, orgResoMetadataPropertyUpdate.listPrice) &&
        Objects.equals(this.listPriceLow, orgResoMetadataPropertyUpdate.listPriceLow) &&
        Objects.equals(this.listTeamKey, orgResoMetadataPropertyUpdate.listTeamKey) &&
        Objects.equals(this.listTeamKeyNumeric, orgResoMetadataPropertyUpdate.listTeamKeyNumeric) &&
        Objects.equals(this.listTeamName, orgResoMetadataPropertyUpdate.listTeamName) &&
        Objects.equals(this.listingAgreement, orgResoMetadataPropertyUpdate.listingAgreement) &&
        Objects.equals(this.listingContractDate, orgResoMetadataPropertyUpdate.listingContractDate) &&
        Objects.equals(this.listingId, orgResoMetadataPropertyUpdate.listingId) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataPropertyUpdate.listingKeyNumeric) &&
        Objects.equals(this.listingService, orgResoMetadataPropertyUpdate.listingService) &&
        Objects.equals(this.listingTerms, orgResoMetadataPropertyUpdate.listingTerms) &&
        Objects.equals(this.livingArea, orgResoMetadataPropertyUpdate.livingArea) &&
        Objects.equals(this.livingAreaSource, orgResoMetadataPropertyUpdate.livingAreaSource) &&
        Objects.equals(this.livingAreaUnits, orgResoMetadataPropertyUpdate.livingAreaUnits) &&
        Objects.equals(this.lockBoxLocation, orgResoMetadataPropertyUpdate.lockBoxLocation) &&
        Objects.equals(this.lockBoxSerialNumber, orgResoMetadataPropertyUpdate.lockBoxSerialNumber) &&
        Objects.equals(this.lockBoxType, orgResoMetadataPropertyUpdate.lockBoxType) &&
        Objects.equals(this.longitude, orgResoMetadataPropertyUpdate.longitude) &&
        Objects.equals(this.lotDimensionsSource, orgResoMetadataPropertyUpdate.lotDimensionsSource) &&
        Objects.equals(this.lotFeatures, orgResoMetadataPropertyUpdate.lotFeatures) &&
        Objects.equals(this.lotSizeAcres, orgResoMetadataPropertyUpdate.lotSizeAcres) &&
        Objects.equals(this.lotSizeArea, orgResoMetadataPropertyUpdate.lotSizeArea) &&
        Objects.equals(this.lotSizeDimensions, orgResoMetadataPropertyUpdate.lotSizeDimensions) &&
        Objects.equals(this.lotSizeSource, orgResoMetadataPropertyUpdate.lotSizeSource) &&
        Objects.equals(this.lotSizeSquareFeet, orgResoMetadataPropertyUpdate.lotSizeSquareFeet) &&
        Objects.equals(this.lotSizeUnits, orgResoMetadataPropertyUpdate.lotSizeUnits) &&
        Objects.equals(this.mlSAreaMajor, orgResoMetadataPropertyUpdate.mlSAreaMajor) &&
        Objects.equals(this.mlSAreaMinor, orgResoMetadataPropertyUpdate.mlSAreaMinor) &&
        Objects.equals(this.mainLevelBathrooms, orgResoMetadataPropertyUpdate.mainLevelBathrooms) &&
        Objects.equals(this.mainLevelBedrooms, orgResoMetadataPropertyUpdate.mainLevelBedrooms) &&
        Objects.equals(this.maintenanceExpense, orgResoMetadataPropertyUpdate.maintenanceExpense) &&
        Objects.equals(this.majorChangeTimestamp, orgResoMetadataPropertyUpdate.majorChangeTimestamp) &&
        Objects.equals(this.majorChangeType, orgResoMetadataPropertyUpdate.majorChangeType) &&
        Objects.equals(this.make, orgResoMetadataPropertyUpdate.make) &&
        Objects.equals(this.managerExpense, orgResoMetadataPropertyUpdate.managerExpense) &&
        Objects.equals(this.mapCoordinate, orgResoMetadataPropertyUpdate.mapCoordinate) &&
        Objects.equals(this.mapCoordinateSource, orgResoMetadataPropertyUpdate.mapCoordinateSource) &&
        Objects.equals(this.mapURL, orgResoMetadataPropertyUpdate.mapURL) &&
        Objects.equals(this.middleOrJuniorSchool, orgResoMetadataPropertyUpdate.middleOrJuniorSchool) &&
        Objects.equals(this.middleOrJuniorSchoolDistrict, orgResoMetadataPropertyUpdate.middleOrJuniorSchoolDistrict) &&
        Objects.equals(this.mlsStatus, orgResoMetadataPropertyUpdate.mlsStatus) &&
        Objects.equals(this.mobileDimUnits, orgResoMetadataPropertyUpdate.mobileDimUnits) &&
        Objects.equals(this.mobileHomeRemainsYN, orgResoMetadataPropertyUpdate.mobileHomeRemainsYN) &&
        Objects.equals(this.mobileLength, orgResoMetadataPropertyUpdate.mobileLength) &&
        Objects.equals(this.mobileWidth, orgResoMetadataPropertyUpdate.mobileWidth) &&
        Objects.equals(this.model, orgResoMetadataPropertyUpdate.model) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataPropertyUpdate.modificationTimestamp) &&
        Objects.equals(this.netOperatingIncome, orgResoMetadataPropertyUpdate.netOperatingIncome) &&
        Objects.equals(this.newConstructionYN, orgResoMetadataPropertyUpdate.newConstructionYN) &&
        Objects.equals(this.newTaxesExpense, orgResoMetadataPropertyUpdate.newTaxesExpense) &&
        Objects.equals(this.numberOfBuildings, orgResoMetadataPropertyUpdate.numberOfBuildings) &&
        Objects.equals(this.numberOfFullTimeEmployees, orgResoMetadataPropertyUpdate.numberOfFullTimeEmployees) &&
        Objects.equals(this.numberOfLots, orgResoMetadataPropertyUpdate.numberOfLots) &&
        Objects.equals(this.numberOfPads, orgResoMetadataPropertyUpdate.numberOfPads) &&
        Objects.equals(this.numberOfPartTimeEmployees, orgResoMetadataPropertyUpdate.numberOfPartTimeEmployees) &&
        Objects.equals(this.numberOfSeparateElectricMeters, orgResoMetadataPropertyUpdate.numberOfSeparateElectricMeters) &&
        Objects.equals(this.numberOfSeparateGasMeters, orgResoMetadataPropertyUpdate.numberOfSeparateGasMeters) &&
        Objects.equals(this.numberOfSeparateWaterMeters, orgResoMetadataPropertyUpdate.numberOfSeparateWaterMeters) &&
        Objects.equals(this.numberOfUnitsInCommunity, orgResoMetadataPropertyUpdate.numberOfUnitsInCommunity) &&
        Objects.equals(this.numberOfUnitsLeased, orgResoMetadataPropertyUpdate.numberOfUnitsLeased) &&
        Objects.equals(this.numberOfUnitsMoMo, orgResoMetadataPropertyUpdate.numberOfUnitsMoMo) &&
        Objects.equals(this.numberOfUnitsTotal, orgResoMetadataPropertyUpdate.numberOfUnitsTotal) &&
        Objects.equals(this.numberOfUnitsVacant, orgResoMetadataPropertyUpdate.numberOfUnitsVacant) &&
        Objects.equals(this.occupantName, orgResoMetadataPropertyUpdate.occupantName) &&
        Objects.equals(this.occupantPhone, orgResoMetadataPropertyUpdate.occupantPhone) &&
        Objects.equals(this.occupantType, orgResoMetadataPropertyUpdate.occupantType) &&
        Objects.equals(this.offMarketDate, orgResoMetadataPropertyUpdate.offMarketDate) &&
        Objects.equals(this.offMarketTimestamp, orgResoMetadataPropertyUpdate.offMarketTimestamp) &&
        Objects.equals(this.onMarketDate, orgResoMetadataPropertyUpdate.onMarketDate) &&
        Objects.equals(this.onMarketTimestamp, orgResoMetadataPropertyUpdate.onMarketTimestamp) &&
        Objects.equals(this.openParkingSpaces, orgResoMetadataPropertyUpdate.openParkingSpaces) &&
        Objects.equals(this.openParkingYN, orgResoMetadataPropertyUpdate.openParkingYN) &&
        Objects.equals(this.operatingExpense, orgResoMetadataPropertyUpdate.operatingExpense) &&
        Objects.equals(this.operatingExpenseIncludes, orgResoMetadataPropertyUpdate.operatingExpenseIncludes) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataPropertyUpdate.originalEntryTimestamp) &&
        Objects.equals(this.originalListPrice, orgResoMetadataPropertyUpdate.originalListPrice) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataPropertyUpdate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataPropertyUpdate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataPropertyUpdate.originatingSystemName) &&
        Objects.equals(this.otherEquipment, orgResoMetadataPropertyUpdate.otherEquipment) &&
        Objects.equals(this.otherExpense, orgResoMetadataPropertyUpdate.otherExpense) &&
        Objects.equals(this.otherParking, orgResoMetadataPropertyUpdate.otherParking) &&
        Objects.equals(this.otherStructures, orgResoMetadataPropertyUpdate.otherStructures) &&
        Objects.equals(this.ownerName, orgResoMetadataPropertyUpdate.ownerName) &&
        Objects.equals(this.ownerPays, orgResoMetadataPropertyUpdate.ownerPays) &&
        Objects.equals(this.ownerPhone, orgResoMetadataPropertyUpdate.ownerPhone) &&
        Objects.equals(this.ownership, orgResoMetadataPropertyUpdate.ownership) &&
        Objects.equals(this.ownershipType, orgResoMetadataPropertyUpdate.ownershipType) &&
        Objects.equals(this.parcelNumber, orgResoMetadataPropertyUpdate.parcelNumber) &&
        Objects.equals(this.parkManagerName, orgResoMetadataPropertyUpdate.parkManagerName) &&
        Objects.equals(this.parkManagerPhone, orgResoMetadataPropertyUpdate.parkManagerPhone) &&
        Objects.equals(this.parkName, orgResoMetadataPropertyUpdate.parkName) &&
        Objects.equals(this.parkingFeatures, orgResoMetadataPropertyUpdate.parkingFeatures) &&
        Objects.equals(this.parkingTotal, orgResoMetadataPropertyUpdate.parkingTotal) &&
        Objects.equals(this.pastureArea, orgResoMetadataPropertyUpdate.pastureArea) &&
        Objects.equals(this.patioAndPorchFeatures, orgResoMetadataPropertyUpdate.patioAndPorchFeatures) &&
        Objects.equals(this.pendingTimestamp, orgResoMetadataPropertyUpdate.pendingTimestamp) &&
        Objects.equals(this.pestControlExpense, orgResoMetadataPropertyUpdate.pestControlExpense) &&
        Objects.equals(this.petsAllowed, orgResoMetadataPropertyUpdate.petsAllowed) &&
        Objects.equals(this.photosChangeTimestamp, orgResoMetadataPropertyUpdate.photosChangeTimestamp) &&
        Objects.equals(this.photosCount, orgResoMetadataPropertyUpdate.photosCount) &&
        Objects.equals(this.poolExpense, orgResoMetadataPropertyUpdate.poolExpense) &&
        Objects.equals(this.poolFeatures, orgResoMetadataPropertyUpdate.poolFeatures) &&
        Objects.equals(this.poolPrivateYN, orgResoMetadataPropertyUpdate.poolPrivateYN) &&
        Objects.equals(this.possession, orgResoMetadataPropertyUpdate.possession) &&
        Objects.equals(this.possibleUse, orgResoMetadataPropertyUpdate.possibleUse) &&
        Objects.equals(this.postalCity, orgResoMetadataPropertyUpdate.postalCity) &&
        Objects.equals(this.postalCode, orgResoMetadataPropertyUpdate.postalCode) &&
        Objects.equals(this.postalCodePlus4, orgResoMetadataPropertyUpdate.postalCodePlus4) &&
        Objects.equals(this.powerProductionType, orgResoMetadataPropertyUpdate.powerProductionType) &&
        Objects.equals(this.previousListPrice, orgResoMetadataPropertyUpdate.previousListPrice) &&
        Objects.equals(this.priceChangeTimestamp, orgResoMetadataPropertyUpdate.priceChangeTimestamp) &&
        Objects.equals(this.privateOfficeRemarks, orgResoMetadataPropertyUpdate.privateOfficeRemarks) &&
        Objects.equals(this.privateRemarks, orgResoMetadataPropertyUpdate.privateRemarks) &&
        Objects.equals(this.professionalManagementExpense, orgResoMetadataPropertyUpdate.professionalManagementExpense) &&
        Objects.equals(this.propertyAttachedYN, orgResoMetadataPropertyUpdate.propertyAttachedYN) &&
        Objects.equals(this.propertyCondition, orgResoMetadataPropertyUpdate.propertyCondition) &&
        Objects.equals(this.propertySubType, orgResoMetadataPropertyUpdate.propertySubType) &&
        Objects.equals(this.propertyType, orgResoMetadataPropertyUpdate.propertyType) &&
        Objects.equals(this.publicRemarks, orgResoMetadataPropertyUpdate.publicRemarks) &&
        Objects.equals(this.publicSurveyRange, orgResoMetadataPropertyUpdate.publicSurveyRange) &&
        Objects.equals(this.publicSurveySection, orgResoMetadataPropertyUpdate.publicSurveySection) &&
        Objects.equals(this.publicSurveyTownship, orgResoMetadataPropertyUpdate.publicSurveyTownship) &&
        Objects.equals(this.purchaseContractDate, orgResoMetadataPropertyUpdate.purchaseContractDate) &&
        Objects.equals(this.rvParkingDimensions, orgResoMetadataPropertyUpdate.rvParkingDimensions) &&
        Objects.equals(this.rangeArea, orgResoMetadataPropertyUpdate.rangeArea) &&
        Objects.equals(this.rentControlYN, orgResoMetadataPropertyUpdate.rentControlYN) &&
        Objects.equals(this.rentIncludes, orgResoMetadataPropertyUpdate.rentIncludes) &&
        Objects.equals(this.roadFrontageType, orgResoMetadataPropertyUpdate.roadFrontageType) &&
        Objects.equals(this.roadResponsibility, orgResoMetadataPropertyUpdate.roadResponsibility) &&
        Objects.equals(this.roadSurfaceType, orgResoMetadataPropertyUpdate.roadSurfaceType) &&
        Objects.equals(this.roof, orgResoMetadataPropertyUpdate.roof) &&
        Objects.equals(this.roomType, orgResoMetadataPropertyUpdate.roomType) &&
        Objects.equals(this.roomsTotal, orgResoMetadataPropertyUpdate.roomsTotal) &&
        Objects.equals(this.seatingCapacity, orgResoMetadataPropertyUpdate.seatingCapacity) &&
        Objects.equals(this.securityFeatures, orgResoMetadataPropertyUpdate.securityFeatures) &&
        Objects.equals(this.seniorCommunityYN, orgResoMetadataPropertyUpdate.seniorCommunityYN) &&
        Objects.equals(this.serialU, orgResoMetadataPropertyUpdate.serialU) &&
        Objects.equals(this.serialX, orgResoMetadataPropertyUpdate.serialX) &&
        Objects.equals(this.serialXX, orgResoMetadataPropertyUpdate.serialXX) &&
        Objects.equals(this.sewer, orgResoMetadataPropertyUpdate.sewer) &&
        Objects.equals(this.showingAdvanceNotice, orgResoMetadataPropertyUpdate.showingAdvanceNotice) &&
        Objects.equals(this.showingAttendedYN, orgResoMetadataPropertyUpdate.showingAttendedYN) &&
        Objects.equals(this.showingContactName, orgResoMetadataPropertyUpdate.showingContactName) &&
        Objects.equals(this.showingContactPhone, orgResoMetadataPropertyUpdate.showingContactPhone) &&
        Objects.equals(this.showingContactPhoneExt, orgResoMetadataPropertyUpdate.showingContactPhoneExt) &&
        Objects.equals(this.showingContactType, orgResoMetadataPropertyUpdate.showingContactType) &&
        Objects.equals(this.showingDays, orgResoMetadataPropertyUpdate.showingDays) &&
        Objects.equals(this.showingEndTime, orgResoMetadataPropertyUpdate.showingEndTime) &&
        Objects.equals(this.showingInstructions, orgResoMetadataPropertyUpdate.showingInstructions) &&
        Objects.equals(this.showingRequirements, orgResoMetadataPropertyUpdate.showingRequirements) &&
        Objects.equals(this.showingStartTime, orgResoMetadataPropertyUpdate.showingStartTime) &&
        Objects.equals(this.signOnPropertyYN, orgResoMetadataPropertyUpdate.signOnPropertyYN) &&
        Objects.equals(this.skirt, orgResoMetadataPropertyUpdate.skirt) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataPropertyUpdate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataPropertyUpdate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataPropertyUpdate.sourceSystemName) &&
        Objects.equals(this.spaFeatures, orgResoMetadataPropertyUpdate.spaFeatures) &&
        Objects.equals(this.spaYN, orgResoMetadataPropertyUpdate.spaYN) &&
        Objects.equals(this.specialLicenses, orgResoMetadataPropertyUpdate.specialLicenses) &&
        Objects.equals(this.specialListingConditions, orgResoMetadataPropertyUpdate.specialListingConditions) &&
        Objects.equals(this.standardStatus, orgResoMetadataPropertyUpdate.standardStatus) &&
        Objects.equals(this.stateOrProvince, orgResoMetadataPropertyUpdate.stateOrProvince) &&
        Objects.equals(this.stateRegion, orgResoMetadataPropertyUpdate.stateRegion) &&
        Objects.equals(this.statusChangeTimestamp, orgResoMetadataPropertyUpdate.statusChangeTimestamp) &&
        Objects.equals(this.stories, orgResoMetadataPropertyUpdate.stories) &&
        Objects.equals(this.storiesTotal, orgResoMetadataPropertyUpdate.storiesTotal) &&
        Objects.equals(this.streetAdditionalInfo, orgResoMetadataPropertyUpdate.streetAdditionalInfo) &&
        Objects.equals(this.streetDirPrefix, orgResoMetadataPropertyUpdate.streetDirPrefix) &&
        Objects.equals(this.streetDirSuffix, orgResoMetadataPropertyUpdate.streetDirSuffix) &&
        Objects.equals(this.streetName, orgResoMetadataPropertyUpdate.streetName) &&
        Objects.equals(this.streetNumber, orgResoMetadataPropertyUpdate.streetNumber) &&
        Objects.equals(this.streetNumberNumeric, orgResoMetadataPropertyUpdate.streetNumberNumeric) &&
        Objects.equals(this.streetSuffix, orgResoMetadataPropertyUpdate.streetSuffix) &&
        Objects.equals(this.streetSuffixModifier, orgResoMetadataPropertyUpdate.streetSuffixModifier) &&
        Objects.equals(this.structureType, orgResoMetadataPropertyUpdate.structureType) &&
        Objects.equals(this.subAgencyCompensation, orgResoMetadataPropertyUpdate.subAgencyCompensation) &&
        Objects.equals(this.subAgencyCompensationType, orgResoMetadataPropertyUpdate.subAgencyCompensationType) &&
        Objects.equals(this.subdivisionName, orgResoMetadataPropertyUpdate.subdivisionName) &&
        Objects.equals(this.suppliesExpense, orgResoMetadataPropertyUpdate.suppliesExpense) &&
        Objects.equals(this.syndicateTo, orgResoMetadataPropertyUpdate.syndicateTo) &&
        Objects.equals(this.syndicationRemarks, orgResoMetadataPropertyUpdate.syndicationRemarks) &&
        Objects.equals(this.taxAnnualAmount, orgResoMetadataPropertyUpdate.taxAnnualAmount) &&
        Objects.equals(this.taxAssessedValue, orgResoMetadataPropertyUpdate.taxAssessedValue) &&
        Objects.equals(this.taxBlock, orgResoMetadataPropertyUpdate.taxBlock) &&
        Objects.equals(this.taxBookNumber, orgResoMetadataPropertyUpdate.taxBookNumber) &&
        Objects.equals(this.taxLegalDescription, orgResoMetadataPropertyUpdate.taxLegalDescription) &&
        Objects.equals(this.taxLot, orgResoMetadataPropertyUpdate.taxLot) &&
        Objects.equals(this.taxMapNumber, orgResoMetadataPropertyUpdate.taxMapNumber) &&
        Objects.equals(this.taxOtherAnnualAssessmentAmount, orgResoMetadataPropertyUpdate.taxOtherAnnualAssessmentAmount) &&
        Objects.equals(this.taxParcelLetter, orgResoMetadataPropertyUpdate.taxParcelLetter) &&
        Objects.equals(this.taxStatusCurrent, orgResoMetadataPropertyUpdate.taxStatusCurrent) &&
        Objects.equals(this.taxTract, orgResoMetadataPropertyUpdate.taxTract) &&
        Objects.equals(this.taxYear, orgResoMetadataPropertyUpdate.taxYear) &&
        Objects.equals(this.tenantPays, orgResoMetadataPropertyUpdate.tenantPays) &&
        Objects.equals(this.topography, orgResoMetadataPropertyUpdate.topography) &&
        Objects.equals(this.totalActualRent, orgResoMetadataPropertyUpdate.totalActualRent) &&
        Objects.equals(this.township, orgResoMetadataPropertyUpdate.township) &&
        Objects.equals(this.transactionBrokerCompensation, orgResoMetadataPropertyUpdate.transactionBrokerCompensation) &&
        Objects.equals(this.transactionBrokerCompensationType, orgResoMetadataPropertyUpdate.transactionBrokerCompensationType) &&
        Objects.equals(this.trashExpense, orgResoMetadataPropertyUpdate.trashExpense) &&
        Objects.equals(this.unitNumber, orgResoMetadataPropertyUpdate.unitNumber) &&
        Objects.equals(this.unitTypeType, orgResoMetadataPropertyUpdate.unitTypeType) &&
        Objects.equals(this.unitsFurnished, orgResoMetadataPropertyUpdate.unitsFurnished) &&
        Objects.equals(this.universalPropertyId, orgResoMetadataPropertyUpdate.universalPropertyId) &&
        Objects.equals(this.universalPropertySubId, orgResoMetadataPropertyUpdate.universalPropertySubId) &&
        Objects.equals(this.unparsedAddress, orgResoMetadataPropertyUpdate.unparsedAddress) &&
        Objects.equals(this.utilities, orgResoMetadataPropertyUpdate.utilities) &&
        Objects.equals(this.vacancyAllowance, orgResoMetadataPropertyUpdate.vacancyAllowance) &&
        Objects.equals(this.vacancyAllowanceRate, orgResoMetadataPropertyUpdate.vacancyAllowanceRate) &&
        Objects.equals(this.vegetation, orgResoMetadataPropertyUpdate.vegetation) &&
        Objects.equals(this.videosChangeTimestamp, orgResoMetadataPropertyUpdate.videosChangeTimestamp) &&
        Objects.equals(this.videosCount, orgResoMetadataPropertyUpdate.videosCount) &&
        Objects.equals(this.view, orgResoMetadataPropertyUpdate.view) &&
        Objects.equals(this.viewYN, orgResoMetadataPropertyUpdate.viewYN) &&
        Objects.equals(this.virtualTourURLBranded, orgResoMetadataPropertyUpdate.virtualTourURLBranded) &&
        Objects.equals(this.virtualTourURLUnbranded, orgResoMetadataPropertyUpdate.virtualTourURLUnbranded) &&
        Objects.equals(this.walkScore, orgResoMetadataPropertyUpdate.walkScore) &&
        Objects.equals(this.waterBodyName, orgResoMetadataPropertyUpdate.waterBodyName) &&
        Objects.equals(this.waterSewerExpense, orgResoMetadataPropertyUpdate.waterSewerExpense) &&
        Objects.equals(this.waterSource, orgResoMetadataPropertyUpdate.waterSource) &&
        Objects.equals(this.waterfrontFeatures, orgResoMetadataPropertyUpdate.waterfrontFeatures) &&
        Objects.equals(this.waterfrontYN, orgResoMetadataPropertyUpdate.waterfrontYN) &&
        Objects.equals(this.windowFeatures, orgResoMetadataPropertyUpdate.windowFeatures) &&
        Objects.equals(this.withdrawnDate, orgResoMetadataPropertyUpdate.withdrawnDate) &&
        Objects.equals(this.woodedArea, orgResoMetadataPropertyUpdate.woodedArea) &&
        Objects.equals(this.workmansCompensationExpense, orgResoMetadataPropertyUpdate.workmansCompensationExpense) &&
        Objects.equals(this.yearBuilt, orgResoMetadataPropertyUpdate.yearBuilt) &&
        Objects.equals(this.yearBuiltDetails, orgResoMetadataPropertyUpdate.yearBuiltDetails) &&
        Objects.equals(this.yearBuiltEffective, orgResoMetadataPropertyUpdate.yearBuiltEffective) &&
        Objects.equals(this.yearBuiltSource, orgResoMetadataPropertyUpdate.yearBuiltSource) &&
        Objects.equals(this.yearEstablished, orgResoMetadataPropertyUpdate.yearEstablished) &&
        Objects.equals(this.yearsCurrentOwner, orgResoMetadataPropertyUpdate.yearsCurrentOwner) &&
        Objects.equals(this.zoning, orgResoMetadataPropertyUpdate.zoning) &&
        Objects.equals(this.zoningDescription, orgResoMetadataPropertyUpdate.zoningDescription);
  }

  @Override
  public int hashCode() {
    return Objects.hash(aboveGradeFinishedArea, aboveGradeFinishedAreaSource, aboveGradeFinishedAreaUnits, accessCode, accessibilityFeatures, additionalParcelsDescription, additionalParcelsYN, anchorsCoTenants, appliances, architecturalStyle, associationAmenities, associationFee, associationFee2, associationFee2Frequency, associationFeeFrequency, associationFeeIncludes, associationName, associationName2, associationPhone, associationPhone2, associationYN, attachedGarageYN, availabilityDate, basement, basementYN, bathroomsFull, bathroomsHalf, bathroomsOneQuarter, bathroomsPartial, bathroomsThreeQuarter, bathroomsTotalInteger, bedroomsPossible, bedroomsTotal, belowGradeFinishedArea, belowGradeFinishedAreaSource, belowGradeFinishedAreaUnits, bodyType, builderModel, builderName, buildingAreaSource, buildingAreaTotal, buildingAreaUnits, buildingFeatures, buildingName, businessName, businessType, buyerAgencyCompensation, buyerAgencyCompensationType, buyerAgentAOR, buyerAgentDesignation, buyerAgentDirectPhone, buyerAgentEmail, buyerAgentFax, buyerAgentFirstName, buyerAgentFullName, buyerAgentHomePhone, buyerAgentKey, buyerAgentKeyNumeric, buyerAgentLastName, buyerAgentMiddleName, buyerAgentMlsId, buyerAgentMobilePhone, buyerAgentNamePrefix, buyerAgentNameSuffix, buyerAgentOfficePhone, buyerAgentOfficePhoneExt, buyerAgentPager, buyerAgentPreferredPhone, buyerAgentPreferredPhoneExt, buyerAgentStateLicense, buyerAgentTollFreePhone, buyerAgentURL, buyerAgentVoiceMail, buyerAgentVoiceMailExt, buyerFinancing, buyerOfficeAOR, buyerOfficeEmail, buyerOfficeFax, buyerOfficeKey, buyerOfficeKeyNumeric, buyerOfficeMlsId, buyerOfficeName, buyerOfficePhone, buyerOfficePhoneExt, buyerOfficeURL, buyerTeamKey, buyerTeamKeyNumeric, buyerTeamName, cableTvExpense, cancellationDate, capRate, carportSpaces, carportYN, carrierRoute, city, cityRegion, closeDate, closePrice, coBuyerAgentAOR, coBuyerAgentDesignation, coBuyerAgentDirectPhone, coBuyerAgentEmail, coBuyerAgentFax, coBuyerAgentFirstName, coBuyerAgentFullName, coBuyerAgentHomePhone, coBuyerAgentKey, coBuyerAgentKeyNumeric, coBuyerAgentLastName, coBuyerAgentMiddleName, coBuyerAgentMlsId, coBuyerAgentMobilePhone, coBuyerAgentNamePrefix, coBuyerAgentNameSuffix, coBuyerAgentOfficePhone, coBuyerAgentOfficePhoneExt, coBuyerAgentPager, coBuyerAgentPreferredPhone, coBuyerAgentPreferredPhoneExt, coBuyerAgentStateLicense, coBuyerAgentTollFreePhone, coBuyerAgentURL, coBuyerAgentVoiceMail, coBuyerAgentVoiceMailExt, coBuyerOfficeAOR, coBuyerOfficeEmail, coBuyerOfficeFax, coBuyerOfficeKey, coBuyerOfficeKeyNumeric, coBuyerOfficeMlsId, coBuyerOfficeName, coBuyerOfficePhone, coBuyerOfficePhoneExt, coBuyerOfficeURL, coListAgentAOR, coListAgentDesignation, coListAgentDirectPhone, coListAgentEmail, coListAgentFax, coListAgentFirstName, coListAgentFullName, coListAgentHomePhone, coListAgentKey, coListAgentKeyNumeric, coListAgentLastName, coListAgentMiddleName, coListAgentMlsId, coListAgentMobilePhone, coListAgentNamePrefix, coListAgentNameSuffix, coListAgentOfficePhone, coListAgentOfficePhoneExt, coListAgentPager, coListAgentPreferredPhone, coListAgentPreferredPhoneExt, coListAgentStateLicense, coListAgentTollFreePhone, coListAgentURL, coListAgentVoiceMail, coListAgentVoiceMailExt, coListOfficeAOR, coListOfficeEmail, coListOfficeFax, coListOfficeKey, coListOfficeKeyNumeric, coListOfficeMlsId, coListOfficeName, coListOfficePhone, coListOfficePhoneExt, coListOfficeURL, commonInterest, commonWalls, communityFeatures, concessions, concessionsAmount, concessionsComments, constructionMaterials, continentRegion, contingency, contingentDate, contractStatusChangeDate, cooling, coolingYN, copyrightNotice, country, countryRegion, countyOrParish, coveredSpaces, cropsIncludedYN, crossStreet, cultivatedArea, cumulativeDaysOnMarket, currentFinancing, currentUse, doH1, doH2, doH3, daysOnMarket, developmentStatus, directionFaces, directions, disclaimer, disclosures, distanceToBusComments, distanceToBusNumeric, distanceToBusUnits, distanceToElectricComments, distanceToElectricNumeric, distanceToElectricUnits, distanceToFreewayComments, distanceToFreewayNumeric, distanceToFreewayUnits, distanceToGasComments, distanceToGasNumeric, distanceToGasUnits, distanceToPhoneServiceComments, distanceToPhoneServiceNumeric, distanceToPhoneServiceUnits, distanceToPlaceofWorshipComments, distanceToPlaceofWorshipNumeric, distanceToPlaceofWorshipUnits, distanceToSchoolBusComments, distanceToSchoolBusNumeric, distanceToSchoolBusUnits, distanceToSchoolsComments, distanceToSchoolsNumeric, distanceToSchoolsUnits, distanceToSewerComments, distanceToSewerNumeric, distanceToSewerUnits, distanceToShoppingComments, distanceToShoppingNumeric, distanceToShoppingUnits, distanceToStreetComments, distanceToStreetNumeric, distanceToStreetUnits, distanceToWaterComments, distanceToWaterNumeric, distanceToWaterUnits, documentsAvailable, documentsChangeTimestamp, documentsCount, doorFeatures, dualVariableCompensationYN, electric, electricExpense, electricOnPropertyYN, elementarySchool, elementarySchoolDistrict, elevation, elevationUnits, entryLevel, entryLocation, exclusions, existingLeaseType, expirationDate, exteriorFeatures, farmCreditServiceInclYN, farmLandAreaSource, farmLandAreaUnits, fencing, financialDataSource, fireplaceFeatures, fireplaceYN, fireplacesTotal, flooring, foundationArea, foundationDetails, frontageLength, frontageType, fuelExpense, furnished, furnitureReplacementExpense, garageSpaces, garageYN, gardenerExpense, grazingPermitsBlmYN, grazingPermitsForestServiceYN, grazingPermitsPrivateYN, greenBuildingVerificationType, greenEnergyEfficient, greenEnergyGeneration, greenIndoorAirQuality, greenLocation, greenSustainability, greenWaterConservation, grossIncome, grossScheduledIncome, habitableResidenceYN, heating, heatingYN, highSchool, highSchoolDistrict, homeWarrantyYN, horseAmenities, horseYN, hoursDaysOfOperation, hoursDaysOfOperationDescription, inclusions, incomeIncludes, insuranceExpense, interiorFeatures, internetAddressDisplayYN, internetAutomatedValuationDisplayYN, internetConsumerCommentYN, internetEntireListingDisplayYN, irrigationSource, irrigationWaterRightsAcres, irrigationWaterRightsYN, laborInformation, landLeaseAmount, landLeaseAmountFrequency, landLeaseExpirationDate, landLeaseYN, latitude, laundryFeatures, leasableArea, leasableAreaUnits, leaseAmount, leaseAmountFrequency, leaseAssignableYN, leaseConsideredYN, leaseExpiration, leaseRenewalCompensation, leaseRenewalOptionYN, leaseTerm, levels, license1, license2, license3, licensesExpense, listAOR, listAgentAOR, listAgentDesignation, listAgentDirectPhone, listAgentEmail, listAgentFax, listAgentFirstName, listAgentFullName, listAgentHomePhone, listAgentKey, listAgentKeyNumeric, listAgentLastName, listAgentMiddleName, listAgentMlsId, listAgentMobilePhone, listAgentNamePrefix, listAgentNameSuffix, listAgentOfficePhone, listAgentOfficePhoneExt, listAgentPager, listAgentPreferredPhone, listAgentPreferredPhoneExt, listAgentStateLicense, listAgentTollFreePhone, listAgentURL, listAgentVoiceMail, listAgentVoiceMailExt, listOfficeAOR, listOfficeEmail, listOfficeFax, listOfficeKey, listOfficeKeyNumeric, listOfficeMlsId, listOfficeName, listOfficePhone, listOfficePhoneExt, listOfficeURL, listPrice, listPriceLow, listTeamKey, listTeamKeyNumeric, listTeamName, listingAgreement, listingContractDate, listingId, listingKeyNumeric, listingService, listingTerms, livingArea, livingAreaSource, livingAreaUnits, lockBoxLocation, lockBoxSerialNumber, lockBoxType, longitude, lotDimensionsSource, lotFeatures, lotSizeAcres, lotSizeArea, lotSizeDimensions, lotSizeSource, lotSizeSquareFeet, lotSizeUnits, mlSAreaMajor, mlSAreaMinor, mainLevelBathrooms, mainLevelBedrooms, maintenanceExpense, majorChangeTimestamp, majorChangeType, make, managerExpense, mapCoordinate, mapCoordinateSource, mapURL, middleOrJuniorSchool, middleOrJuniorSchoolDistrict, mlsStatus, mobileDimUnits, mobileHomeRemainsYN, mobileLength, mobileWidth, model, modificationTimestamp, netOperatingIncome, newConstructionYN, newTaxesExpense, numberOfBuildings, numberOfFullTimeEmployees, numberOfLots, numberOfPads, numberOfPartTimeEmployees, numberOfSeparateElectricMeters, numberOfSeparateGasMeters, numberOfSeparateWaterMeters, numberOfUnitsInCommunity, numberOfUnitsLeased, numberOfUnitsMoMo, numberOfUnitsTotal, numberOfUnitsVacant, occupantName, occupantPhone, occupantType, offMarketDate, offMarketTimestamp, onMarketDate, onMarketTimestamp, openParkingSpaces, openParkingYN, operatingExpense, operatingExpenseIncludes, originalEntryTimestamp, originalListPrice, originatingSystemID, originatingSystemKey, originatingSystemName, otherEquipment, otherExpense, otherParking, otherStructures, ownerName, ownerPays, ownerPhone, ownership, ownershipType, parcelNumber, parkManagerName, parkManagerPhone, parkName, parkingFeatures, parkingTotal, pastureArea, patioAndPorchFeatures, pendingTimestamp, pestControlExpense, petsAllowed, photosChangeTimestamp, photosCount, poolExpense, poolFeatures, poolPrivateYN, possession, possibleUse, postalCity, postalCode, postalCodePlus4, powerProductionType, previousListPrice, priceChangeTimestamp, privateOfficeRemarks, privateRemarks, professionalManagementExpense, propertyAttachedYN, propertyCondition, propertySubType, propertyType, publicRemarks, publicSurveyRange, publicSurveySection, publicSurveyTownship, purchaseContractDate, rvParkingDimensions, rangeArea, rentControlYN, rentIncludes, roadFrontageType, roadResponsibility, roadSurfaceType, roof, roomType, roomsTotal, seatingCapacity, securityFeatures, seniorCommunityYN, serialU, serialX, serialXX, sewer, showingAdvanceNotice, showingAttendedYN, showingContactName, showingContactPhone, showingContactPhoneExt, showingContactType, showingDays, showingEndTime, showingInstructions, showingRequirements, showingStartTime, signOnPropertyYN, skirt, sourceSystemID, sourceSystemKey, sourceSystemName, spaFeatures, spaYN, specialLicenses, specialListingConditions, standardStatus, stateOrProvince, stateRegion, statusChangeTimestamp, stories, storiesTotal, streetAdditionalInfo, streetDirPrefix, streetDirSuffix, streetName, streetNumber, streetNumberNumeric, streetSuffix, streetSuffixModifier, structureType, subAgencyCompensation, subAgencyCompensationType, subdivisionName, suppliesExpense, syndicateTo, syndicationRemarks, taxAnnualAmount, taxAssessedValue, taxBlock, taxBookNumber, taxLegalDescription, taxLot, taxMapNumber, taxOtherAnnualAssessmentAmount, taxParcelLetter, taxStatusCurrent, taxTract, taxYear, tenantPays, topography, totalActualRent, township, transactionBrokerCompensation, transactionBrokerCompensationType, trashExpense, unitNumber, unitTypeType, unitsFurnished, universalPropertyId, universalPropertySubId, unparsedAddress, utilities, vacancyAllowance, vacancyAllowanceRate, vegetation, videosChangeTimestamp, videosCount, view, viewYN, virtualTourURLBranded, virtualTourURLUnbranded, walkScore, waterBodyName, waterSewerExpense, waterSource, waterfrontFeatures, waterfrontYN, windowFeatures, withdrawnDate, woodedArea, workmansCompensationExpense, yearBuilt, yearBuiltDetails, yearBuiltEffective, yearBuiltSource, yearEstablished, yearsCurrentOwner, zoning, zoningDescription);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataPropertyUpdate {\n");
    
    sb.append("    aboveGradeFinishedArea: ").append(toIndentedString(aboveGradeFinishedArea)).append("\n");
    sb.append("    aboveGradeFinishedAreaSource: ").append(toIndentedString(aboveGradeFinishedAreaSource)).append("\n");
    sb.append("    aboveGradeFinishedAreaUnits: ").append(toIndentedString(aboveGradeFinishedAreaUnits)).append("\n");
    sb.append("    accessCode: ").append(toIndentedString(accessCode)).append("\n");
    sb.append("    accessibilityFeatures: ").append(toIndentedString(accessibilityFeatures)).append("\n");
    sb.append("    additionalParcelsDescription: ").append(toIndentedString(additionalParcelsDescription)).append("\n");
    sb.append("    additionalParcelsYN: ").append(toIndentedString(additionalParcelsYN)).append("\n");
    sb.append("    anchorsCoTenants: ").append(toIndentedString(anchorsCoTenants)).append("\n");
    sb.append("    appliances: ").append(toIndentedString(appliances)).append("\n");
    sb.append("    architecturalStyle: ").append(toIndentedString(architecturalStyle)).append("\n");
    sb.append("    associationAmenities: ").append(toIndentedString(associationAmenities)).append("\n");
    sb.append("    associationFee: ").append(toIndentedString(associationFee)).append("\n");
    sb.append("    associationFee2: ").append(toIndentedString(associationFee2)).append("\n");
    sb.append("    associationFee2Frequency: ").append(toIndentedString(associationFee2Frequency)).append("\n");
    sb.append("    associationFeeFrequency: ").append(toIndentedString(associationFeeFrequency)).append("\n");
    sb.append("    associationFeeIncludes: ").append(toIndentedString(associationFeeIncludes)).append("\n");
    sb.append("    associationName: ").append(toIndentedString(associationName)).append("\n");
    sb.append("    associationName2: ").append(toIndentedString(associationName2)).append("\n");
    sb.append("    associationPhone: ").append(toIndentedString(associationPhone)).append("\n");
    sb.append("    associationPhone2: ").append(toIndentedString(associationPhone2)).append("\n");
    sb.append("    associationYN: ").append(toIndentedString(associationYN)).append("\n");
    sb.append("    attachedGarageYN: ").append(toIndentedString(attachedGarageYN)).append("\n");
    sb.append("    availabilityDate: ").append(toIndentedString(availabilityDate)).append("\n");
    sb.append("    basement: ").append(toIndentedString(basement)).append("\n");
    sb.append("    basementYN: ").append(toIndentedString(basementYN)).append("\n");
    sb.append("    bathroomsFull: ").append(toIndentedString(bathroomsFull)).append("\n");
    sb.append("    bathroomsHalf: ").append(toIndentedString(bathroomsHalf)).append("\n");
    sb.append("    bathroomsOneQuarter: ").append(toIndentedString(bathroomsOneQuarter)).append("\n");
    sb.append("    bathroomsPartial: ").append(toIndentedString(bathroomsPartial)).append("\n");
    sb.append("    bathroomsThreeQuarter: ").append(toIndentedString(bathroomsThreeQuarter)).append("\n");
    sb.append("    bathroomsTotalInteger: ").append(toIndentedString(bathroomsTotalInteger)).append("\n");
    sb.append("    bedroomsPossible: ").append(toIndentedString(bedroomsPossible)).append("\n");
    sb.append("    bedroomsTotal: ").append(toIndentedString(bedroomsTotal)).append("\n");
    sb.append("    belowGradeFinishedArea: ").append(toIndentedString(belowGradeFinishedArea)).append("\n");
    sb.append("    belowGradeFinishedAreaSource: ").append(toIndentedString(belowGradeFinishedAreaSource)).append("\n");
    sb.append("    belowGradeFinishedAreaUnits: ").append(toIndentedString(belowGradeFinishedAreaUnits)).append("\n");
    sb.append("    bodyType: ").append(toIndentedString(bodyType)).append("\n");
    sb.append("    builderModel: ").append(toIndentedString(builderModel)).append("\n");
    sb.append("    builderName: ").append(toIndentedString(builderName)).append("\n");
    sb.append("    buildingAreaSource: ").append(toIndentedString(buildingAreaSource)).append("\n");
    sb.append("    buildingAreaTotal: ").append(toIndentedString(buildingAreaTotal)).append("\n");
    sb.append("    buildingAreaUnits: ").append(toIndentedString(buildingAreaUnits)).append("\n");
    sb.append("    buildingFeatures: ").append(toIndentedString(buildingFeatures)).append("\n");
    sb.append("    buildingName: ").append(toIndentedString(buildingName)).append("\n");
    sb.append("    businessName: ").append(toIndentedString(businessName)).append("\n");
    sb.append("    businessType: ").append(toIndentedString(businessType)).append("\n");
    sb.append("    buyerAgencyCompensation: ").append(toIndentedString(buyerAgencyCompensation)).append("\n");
    sb.append("    buyerAgencyCompensationType: ").append(toIndentedString(buyerAgencyCompensationType)).append("\n");
    sb.append("    buyerAgentAOR: ").append(toIndentedString(buyerAgentAOR)).append("\n");
    sb.append("    buyerAgentDesignation: ").append(toIndentedString(buyerAgentDesignation)).append("\n");
    sb.append("    buyerAgentDirectPhone: ").append(toIndentedString(buyerAgentDirectPhone)).append("\n");
    sb.append("    buyerAgentEmail: ").append(toIndentedString(buyerAgentEmail)).append("\n");
    sb.append("    buyerAgentFax: ").append(toIndentedString(buyerAgentFax)).append("\n");
    sb.append("    buyerAgentFirstName: ").append(toIndentedString(buyerAgentFirstName)).append("\n");
    sb.append("    buyerAgentFullName: ").append(toIndentedString(buyerAgentFullName)).append("\n");
    sb.append("    buyerAgentHomePhone: ").append(toIndentedString(buyerAgentHomePhone)).append("\n");
    sb.append("    buyerAgentKey: ").append(toIndentedString(buyerAgentKey)).append("\n");
    sb.append("    buyerAgentKeyNumeric: ").append(toIndentedString(buyerAgentKeyNumeric)).append("\n");
    sb.append("    buyerAgentLastName: ").append(toIndentedString(buyerAgentLastName)).append("\n");
    sb.append("    buyerAgentMiddleName: ").append(toIndentedString(buyerAgentMiddleName)).append("\n");
    sb.append("    buyerAgentMlsId: ").append(toIndentedString(buyerAgentMlsId)).append("\n");
    sb.append("    buyerAgentMobilePhone: ").append(toIndentedString(buyerAgentMobilePhone)).append("\n");
    sb.append("    buyerAgentNamePrefix: ").append(toIndentedString(buyerAgentNamePrefix)).append("\n");
    sb.append("    buyerAgentNameSuffix: ").append(toIndentedString(buyerAgentNameSuffix)).append("\n");
    sb.append("    buyerAgentOfficePhone: ").append(toIndentedString(buyerAgentOfficePhone)).append("\n");
    sb.append("    buyerAgentOfficePhoneExt: ").append(toIndentedString(buyerAgentOfficePhoneExt)).append("\n");
    sb.append("    buyerAgentPager: ").append(toIndentedString(buyerAgentPager)).append("\n");
    sb.append("    buyerAgentPreferredPhone: ").append(toIndentedString(buyerAgentPreferredPhone)).append("\n");
    sb.append("    buyerAgentPreferredPhoneExt: ").append(toIndentedString(buyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    buyerAgentStateLicense: ").append(toIndentedString(buyerAgentStateLicense)).append("\n");
    sb.append("    buyerAgentTollFreePhone: ").append(toIndentedString(buyerAgentTollFreePhone)).append("\n");
    sb.append("    buyerAgentURL: ").append(toIndentedString(buyerAgentURL)).append("\n");
    sb.append("    buyerAgentVoiceMail: ").append(toIndentedString(buyerAgentVoiceMail)).append("\n");
    sb.append("    buyerAgentVoiceMailExt: ").append(toIndentedString(buyerAgentVoiceMailExt)).append("\n");
    sb.append("    buyerFinancing: ").append(toIndentedString(buyerFinancing)).append("\n");
    sb.append("    buyerOfficeAOR: ").append(toIndentedString(buyerOfficeAOR)).append("\n");
    sb.append("    buyerOfficeEmail: ").append(toIndentedString(buyerOfficeEmail)).append("\n");
    sb.append("    buyerOfficeFax: ").append(toIndentedString(buyerOfficeFax)).append("\n");
    sb.append("    buyerOfficeKey: ").append(toIndentedString(buyerOfficeKey)).append("\n");
    sb.append("    buyerOfficeKeyNumeric: ").append(toIndentedString(buyerOfficeKeyNumeric)).append("\n");
    sb.append("    buyerOfficeMlsId: ").append(toIndentedString(buyerOfficeMlsId)).append("\n");
    sb.append("    buyerOfficeName: ").append(toIndentedString(buyerOfficeName)).append("\n");
    sb.append("    buyerOfficePhone: ").append(toIndentedString(buyerOfficePhone)).append("\n");
    sb.append("    buyerOfficePhoneExt: ").append(toIndentedString(buyerOfficePhoneExt)).append("\n");
    sb.append("    buyerOfficeURL: ").append(toIndentedString(buyerOfficeURL)).append("\n");
    sb.append("    buyerTeamKey: ").append(toIndentedString(buyerTeamKey)).append("\n");
    sb.append("    buyerTeamKeyNumeric: ").append(toIndentedString(buyerTeamKeyNumeric)).append("\n");
    sb.append("    buyerTeamName: ").append(toIndentedString(buyerTeamName)).append("\n");
    sb.append("    cableTvExpense: ").append(toIndentedString(cableTvExpense)).append("\n");
    sb.append("    cancellationDate: ").append(toIndentedString(cancellationDate)).append("\n");
    sb.append("    capRate: ").append(toIndentedString(capRate)).append("\n");
    sb.append("    carportSpaces: ").append(toIndentedString(carportSpaces)).append("\n");
    sb.append("    carportYN: ").append(toIndentedString(carportYN)).append("\n");
    sb.append("    carrierRoute: ").append(toIndentedString(carrierRoute)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    cityRegion: ").append(toIndentedString(cityRegion)).append("\n");
    sb.append("    closeDate: ").append(toIndentedString(closeDate)).append("\n");
    sb.append("    closePrice: ").append(toIndentedString(closePrice)).append("\n");
    sb.append("    coBuyerAgentAOR: ").append(toIndentedString(coBuyerAgentAOR)).append("\n");
    sb.append("    coBuyerAgentDesignation: ").append(toIndentedString(coBuyerAgentDesignation)).append("\n");
    sb.append("    coBuyerAgentDirectPhone: ").append(toIndentedString(coBuyerAgentDirectPhone)).append("\n");
    sb.append("    coBuyerAgentEmail: ").append(toIndentedString(coBuyerAgentEmail)).append("\n");
    sb.append("    coBuyerAgentFax: ").append(toIndentedString(coBuyerAgentFax)).append("\n");
    sb.append("    coBuyerAgentFirstName: ").append(toIndentedString(coBuyerAgentFirstName)).append("\n");
    sb.append("    coBuyerAgentFullName: ").append(toIndentedString(coBuyerAgentFullName)).append("\n");
    sb.append("    coBuyerAgentHomePhone: ").append(toIndentedString(coBuyerAgentHomePhone)).append("\n");
    sb.append("    coBuyerAgentKey: ").append(toIndentedString(coBuyerAgentKey)).append("\n");
    sb.append("    coBuyerAgentKeyNumeric: ").append(toIndentedString(coBuyerAgentKeyNumeric)).append("\n");
    sb.append("    coBuyerAgentLastName: ").append(toIndentedString(coBuyerAgentLastName)).append("\n");
    sb.append("    coBuyerAgentMiddleName: ").append(toIndentedString(coBuyerAgentMiddleName)).append("\n");
    sb.append("    coBuyerAgentMlsId: ").append(toIndentedString(coBuyerAgentMlsId)).append("\n");
    sb.append("    coBuyerAgentMobilePhone: ").append(toIndentedString(coBuyerAgentMobilePhone)).append("\n");
    sb.append("    coBuyerAgentNamePrefix: ").append(toIndentedString(coBuyerAgentNamePrefix)).append("\n");
    sb.append("    coBuyerAgentNameSuffix: ").append(toIndentedString(coBuyerAgentNameSuffix)).append("\n");
    sb.append("    coBuyerAgentOfficePhone: ").append(toIndentedString(coBuyerAgentOfficePhone)).append("\n");
    sb.append("    coBuyerAgentOfficePhoneExt: ").append(toIndentedString(coBuyerAgentOfficePhoneExt)).append("\n");
    sb.append("    coBuyerAgentPager: ").append(toIndentedString(coBuyerAgentPager)).append("\n");
    sb.append("    coBuyerAgentPreferredPhone: ").append(toIndentedString(coBuyerAgentPreferredPhone)).append("\n");
    sb.append("    coBuyerAgentPreferredPhoneExt: ").append(toIndentedString(coBuyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    coBuyerAgentStateLicense: ").append(toIndentedString(coBuyerAgentStateLicense)).append("\n");
    sb.append("    coBuyerAgentTollFreePhone: ").append(toIndentedString(coBuyerAgentTollFreePhone)).append("\n");
    sb.append("    coBuyerAgentURL: ").append(toIndentedString(coBuyerAgentURL)).append("\n");
    sb.append("    coBuyerAgentVoiceMail: ").append(toIndentedString(coBuyerAgentVoiceMail)).append("\n");
    sb.append("    coBuyerAgentVoiceMailExt: ").append(toIndentedString(coBuyerAgentVoiceMailExt)).append("\n");
    sb.append("    coBuyerOfficeAOR: ").append(toIndentedString(coBuyerOfficeAOR)).append("\n");
    sb.append("    coBuyerOfficeEmail: ").append(toIndentedString(coBuyerOfficeEmail)).append("\n");
    sb.append("    coBuyerOfficeFax: ").append(toIndentedString(coBuyerOfficeFax)).append("\n");
    sb.append("    coBuyerOfficeKey: ").append(toIndentedString(coBuyerOfficeKey)).append("\n");
    sb.append("    coBuyerOfficeKeyNumeric: ").append(toIndentedString(coBuyerOfficeKeyNumeric)).append("\n");
    sb.append("    coBuyerOfficeMlsId: ").append(toIndentedString(coBuyerOfficeMlsId)).append("\n");
    sb.append("    coBuyerOfficeName: ").append(toIndentedString(coBuyerOfficeName)).append("\n");
    sb.append("    coBuyerOfficePhone: ").append(toIndentedString(coBuyerOfficePhone)).append("\n");
    sb.append("    coBuyerOfficePhoneExt: ").append(toIndentedString(coBuyerOfficePhoneExt)).append("\n");
    sb.append("    coBuyerOfficeURL: ").append(toIndentedString(coBuyerOfficeURL)).append("\n");
    sb.append("    coListAgentAOR: ").append(toIndentedString(coListAgentAOR)).append("\n");
    sb.append("    coListAgentDesignation: ").append(toIndentedString(coListAgentDesignation)).append("\n");
    sb.append("    coListAgentDirectPhone: ").append(toIndentedString(coListAgentDirectPhone)).append("\n");
    sb.append("    coListAgentEmail: ").append(toIndentedString(coListAgentEmail)).append("\n");
    sb.append("    coListAgentFax: ").append(toIndentedString(coListAgentFax)).append("\n");
    sb.append("    coListAgentFirstName: ").append(toIndentedString(coListAgentFirstName)).append("\n");
    sb.append("    coListAgentFullName: ").append(toIndentedString(coListAgentFullName)).append("\n");
    sb.append("    coListAgentHomePhone: ").append(toIndentedString(coListAgentHomePhone)).append("\n");
    sb.append("    coListAgentKey: ").append(toIndentedString(coListAgentKey)).append("\n");
    sb.append("    coListAgentKeyNumeric: ").append(toIndentedString(coListAgentKeyNumeric)).append("\n");
    sb.append("    coListAgentLastName: ").append(toIndentedString(coListAgentLastName)).append("\n");
    sb.append("    coListAgentMiddleName: ").append(toIndentedString(coListAgentMiddleName)).append("\n");
    sb.append("    coListAgentMlsId: ").append(toIndentedString(coListAgentMlsId)).append("\n");
    sb.append("    coListAgentMobilePhone: ").append(toIndentedString(coListAgentMobilePhone)).append("\n");
    sb.append("    coListAgentNamePrefix: ").append(toIndentedString(coListAgentNamePrefix)).append("\n");
    sb.append("    coListAgentNameSuffix: ").append(toIndentedString(coListAgentNameSuffix)).append("\n");
    sb.append("    coListAgentOfficePhone: ").append(toIndentedString(coListAgentOfficePhone)).append("\n");
    sb.append("    coListAgentOfficePhoneExt: ").append(toIndentedString(coListAgentOfficePhoneExt)).append("\n");
    sb.append("    coListAgentPager: ").append(toIndentedString(coListAgentPager)).append("\n");
    sb.append("    coListAgentPreferredPhone: ").append(toIndentedString(coListAgentPreferredPhone)).append("\n");
    sb.append("    coListAgentPreferredPhoneExt: ").append(toIndentedString(coListAgentPreferredPhoneExt)).append("\n");
    sb.append("    coListAgentStateLicense: ").append(toIndentedString(coListAgentStateLicense)).append("\n");
    sb.append("    coListAgentTollFreePhone: ").append(toIndentedString(coListAgentTollFreePhone)).append("\n");
    sb.append("    coListAgentURL: ").append(toIndentedString(coListAgentURL)).append("\n");
    sb.append("    coListAgentVoiceMail: ").append(toIndentedString(coListAgentVoiceMail)).append("\n");
    sb.append("    coListAgentVoiceMailExt: ").append(toIndentedString(coListAgentVoiceMailExt)).append("\n");
    sb.append("    coListOfficeAOR: ").append(toIndentedString(coListOfficeAOR)).append("\n");
    sb.append("    coListOfficeEmail: ").append(toIndentedString(coListOfficeEmail)).append("\n");
    sb.append("    coListOfficeFax: ").append(toIndentedString(coListOfficeFax)).append("\n");
    sb.append("    coListOfficeKey: ").append(toIndentedString(coListOfficeKey)).append("\n");
    sb.append("    coListOfficeKeyNumeric: ").append(toIndentedString(coListOfficeKeyNumeric)).append("\n");
    sb.append("    coListOfficeMlsId: ").append(toIndentedString(coListOfficeMlsId)).append("\n");
    sb.append("    coListOfficeName: ").append(toIndentedString(coListOfficeName)).append("\n");
    sb.append("    coListOfficePhone: ").append(toIndentedString(coListOfficePhone)).append("\n");
    sb.append("    coListOfficePhoneExt: ").append(toIndentedString(coListOfficePhoneExt)).append("\n");
    sb.append("    coListOfficeURL: ").append(toIndentedString(coListOfficeURL)).append("\n");
    sb.append("    commonInterest: ").append(toIndentedString(commonInterest)).append("\n");
    sb.append("    commonWalls: ").append(toIndentedString(commonWalls)).append("\n");
    sb.append("    communityFeatures: ").append(toIndentedString(communityFeatures)).append("\n");
    sb.append("    concessions: ").append(toIndentedString(concessions)).append("\n");
    sb.append("    concessionsAmount: ").append(toIndentedString(concessionsAmount)).append("\n");
    sb.append("    concessionsComments: ").append(toIndentedString(concessionsComments)).append("\n");
    sb.append("    constructionMaterials: ").append(toIndentedString(constructionMaterials)).append("\n");
    sb.append("    continentRegion: ").append(toIndentedString(continentRegion)).append("\n");
    sb.append("    contingency: ").append(toIndentedString(contingency)).append("\n");
    sb.append("    contingentDate: ").append(toIndentedString(contingentDate)).append("\n");
    sb.append("    contractStatusChangeDate: ").append(toIndentedString(contractStatusChangeDate)).append("\n");
    sb.append("    cooling: ").append(toIndentedString(cooling)).append("\n");
    sb.append("    coolingYN: ").append(toIndentedString(coolingYN)).append("\n");
    sb.append("    copyrightNotice: ").append(toIndentedString(copyrightNotice)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    countryRegion: ").append(toIndentedString(countryRegion)).append("\n");
    sb.append("    countyOrParish: ").append(toIndentedString(countyOrParish)).append("\n");
    sb.append("    coveredSpaces: ").append(toIndentedString(coveredSpaces)).append("\n");
    sb.append("    cropsIncludedYN: ").append(toIndentedString(cropsIncludedYN)).append("\n");
    sb.append("    crossStreet: ").append(toIndentedString(crossStreet)).append("\n");
    sb.append("    cultivatedArea: ").append(toIndentedString(cultivatedArea)).append("\n");
    sb.append("    cumulativeDaysOnMarket: ").append(toIndentedString(cumulativeDaysOnMarket)).append("\n");
    sb.append("    currentFinancing: ").append(toIndentedString(currentFinancing)).append("\n");
    sb.append("    currentUse: ").append(toIndentedString(currentUse)).append("\n");
    sb.append("    doH1: ").append(toIndentedString(doH1)).append("\n");
    sb.append("    doH2: ").append(toIndentedString(doH2)).append("\n");
    sb.append("    doH3: ").append(toIndentedString(doH3)).append("\n");
    sb.append("    daysOnMarket: ").append(toIndentedString(daysOnMarket)).append("\n");
    sb.append("    developmentStatus: ").append(toIndentedString(developmentStatus)).append("\n");
    sb.append("    directionFaces: ").append(toIndentedString(directionFaces)).append("\n");
    sb.append("    directions: ").append(toIndentedString(directions)).append("\n");
    sb.append("    disclaimer: ").append(toIndentedString(disclaimer)).append("\n");
    sb.append("    disclosures: ").append(toIndentedString(disclosures)).append("\n");
    sb.append("    distanceToBusComments: ").append(toIndentedString(distanceToBusComments)).append("\n");
    sb.append("    distanceToBusNumeric: ").append(toIndentedString(distanceToBusNumeric)).append("\n");
    sb.append("    distanceToBusUnits: ").append(toIndentedString(distanceToBusUnits)).append("\n");
    sb.append("    distanceToElectricComments: ").append(toIndentedString(distanceToElectricComments)).append("\n");
    sb.append("    distanceToElectricNumeric: ").append(toIndentedString(distanceToElectricNumeric)).append("\n");
    sb.append("    distanceToElectricUnits: ").append(toIndentedString(distanceToElectricUnits)).append("\n");
    sb.append("    distanceToFreewayComments: ").append(toIndentedString(distanceToFreewayComments)).append("\n");
    sb.append("    distanceToFreewayNumeric: ").append(toIndentedString(distanceToFreewayNumeric)).append("\n");
    sb.append("    distanceToFreewayUnits: ").append(toIndentedString(distanceToFreewayUnits)).append("\n");
    sb.append("    distanceToGasComments: ").append(toIndentedString(distanceToGasComments)).append("\n");
    sb.append("    distanceToGasNumeric: ").append(toIndentedString(distanceToGasNumeric)).append("\n");
    sb.append("    distanceToGasUnits: ").append(toIndentedString(distanceToGasUnits)).append("\n");
    sb.append("    distanceToPhoneServiceComments: ").append(toIndentedString(distanceToPhoneServiceComments)).append("\n");
    sb.append("    distanceToPhoneServiceNumeric: ").append(toIndentedString(distanceToPhoneServiceNumeric)).append("\n");
    sb.append("    distanceToPhoneServiceUnits: ").append(toIndentedString(distanceToPhoneServiceUnits)).append("\n");
    sb.append("    distanceToPlaceofWorshipComments: ").append(toIndentedString(distanceToPlaceofWorshipComments)).append("\n");
    sb.append("    distanceToPlaceofWorshipNumeric: ").append(toIndentedString(distanceToPlaceofWorshipNumeric)).append("\n");
    sb.append("    distanceToPlaceofWorshipUnits: ").append(toIndentedString(distanceToPlaceofWorshipUnits)).append("\n");
    sb.append("    distanceToSchoolBusComments: ").append(toIndentedString(distanceToSchoolBusComments)).append("\n");
    sb.append("    distanceToSchoolBusNumeric: ").append(toIndentedString(distanceToSchoolBusNumeric)).append("\n");
    sb.append("    distanceToSchoolBusUnits: ").append(toIndentedString(distanceToSchoolBusUnits)).append("\n");
    sb.append("    distanceToSchoolsComments: ").append(toIndentedString(distanceToSchoolsComments)).append("\n");
    sb.append("    distanceToSchoolsNumeric: ").append(toIndentedString(distanceToSchoolsNumeric)).append("\n");
    sb.append("    distanceToSchoolsUnits: ").append(toIndentedString(distanceToSchoolsUnits)).append("\n");
    sb.append("    distanceToSewerComments: ").append(toIndentedString(distanceToSewerComments)).append("\n");
    sb.append("    distanceToSewerNumeric: ").append(toIndentedString(distanceToSewerNumeric)).append("\n");
    sb.append("    distanceToSewerUnits: ").append(toIndentedString(distanceToSewerUnits)).append("\n");
    sb.append("    distanceToShoppingComments: ").append(toIndentedString(distanceToShoppingComments)).append("\n");
    sb.append("    distanceToShoppingNumeric: ").append(toIndentedString(distanceToShoppingNumeric)).append("\n");
    sb.append("    distanceToShoppingUnits: ").append(toIndentedString(distanceToShoppingUnits)).append("\n");
    sb.append("    distanceToStreetComments: ").append(toIndentedString(distanceToStreetComments)).append("\n");
    sb.append("    distanceToStreetNumeric: ").append(toIndentedString(distanceToStreetNumeric)).append("\n");
    sb.append("    distanceToStreetUnits: ").append(toIndentedString(distanceToStreetUnits)).append("\n");
    sb.append("    distanceToWaterComments: ").append(toIndentedString(distanceToWaterComments)).append("\n");
    sb.append("    distanceToWaterNumeric: ").append(toIndentedString(distanceToWaterNumeric)).append("\n");
    sb.append("    distanceToWaterUnits: ").append(toIndentedString(distanceToWaterUnits)).append("\n");
    sb.append("    documentsAvailable: ").append(toIndentedString(documentsAvailable)).append("\n");
    sb.append("    documentsChangeTimestamp: ").append(toIndentedString(documentsChangeTimestamp)).append("\n");
    sb.append("    documentsCount: ").append(toIndentedString(documentsCount)).append("\n");
    sb.append("    doorFeatures: ").append(toIndentedString(doorFeatures)).append("\n");
    sb.append("    dualVariableCompensationYN: ").append(toIndentedString(dualVariableCompensationYN)).append("\n");
    sb.append("    electric: ").append(toIndentedString(electric)).append("\n");
    sb.append("    electricExpense: ").append(toIndentedString(electricExpense)).append("\n");
    sb.append("    electricOnPropertyYN: ").append(toIndentedString(electricOnPropertyYN)).append("\n");
    sb.append("    elementarySchool: ").append(toIndentedString(elementarySchool)).append("\n");
    sb.append("    elementarySchoolDistrict: ").append(toIndentedString(elementarySchoolDistrict)).append("\n");
    sb.append("    elevation: ").append(toIndentedString(elevation)).append("\n");
    sb.append("    elevationUnits: ").append(toIndentedString(elevationUnits)).append("\n");
    sb.append("    entryLevel: ").append(toIndentedString(entryLevel)).append("\n");
    sb.append("    entryLocation: ").append(toIndentedString(entryLocation)).append("\n");
    sb.append("    exclusions: ").append(toIndentedString(exclusions)).append("\n");
    sb.append("    existingLeaseType: ").append(toIndentedString(existingLeaseType)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    exteriorFeatures: ").append(toIndentedString(exteriorFeatures)).append("\n");
    sb.append("    farmCreditServiceInclYN: ").append(toIndentedString(farmCreditServiceInclYN)).append("\n");
    sb.append("    farmLandAreaSource: ").append(toIndentedString(farmLandAreaSource)).append("\n");
    sb.append("    farmLandAreaUnits: ").append(toIndentedString(farmLandAreaUnits)).append("\n");
    sb.append("    fencing: ").append(toIndentedString(fencing)).append("\n");
    sb.append("    financialDataSource: ").append(toIndentedString(financialDataSource)).append("\n");
    sb.append("    fireplaceFeatures: ").append(toIndentedString(fireplaceFeatures)).append("\n");
    sb.append("    fireplaceYN: ").append(toIndentedString(fireplaceYN)).append("\n");
    sb.append("    fireplacesTotal: ").append(toIndentedString(fireplacesTotal)).append("\n");
    sb.append("    flooring: ").append(toIndentedString(flooring)).append("\n");
    sb.append("    foundationArea: ").append(toIndentedString(foundationArea)).append("\n");
    sb.append("    foundationDetails: ").append(toIndentedString(foundationDetails)).append("\n");
    sb.append("    frontageLength: ").append(toIndentedString(frontageLength)).append("\n");
    sb.append("    frontageType: ").append(toIndentedString(frontageType)).append("\n");
    sb.append("    fuelExpense: ").append(toIndentedString(fuelExpense)).append("\n");
    sb.append("    furnished: ").append(toIndentedString(furnished)).append("\n");
    sb.append("    furnitureReplacementExpense: ").append(toIndentedString(furnitureReplacementExpense)).append("\n");
    sb.append("    garageSpaces: ").append(toIndentedString(garageSpaces)).append("\n");
    sb.append("    garageYN: ").append(toIndentedString(garageYN)).append("\n");
    sb.append("    gardenerExpense: ").append(toIndentedString(gardenerExpense)).append("\n");
    sb.append("    grazingPermitsBlmYN: ").append(toIndentedString(grazingPermitsBlmYN)).append("\n");
    sb.append("    grazingPermitsForestServiceYN: ").append(toIndentedString(grazingPermitsForestServiceYN)).append("\n");
    sb.append("    grazingPermitsPrivateYN: ").append(toIndentedString(grazingPermitsPrivateYN)).append("\n");
    sb.append("    greenBuildingVerificationType: ").append(toIndentedString(greenBuildingVerificationType)).append("\n");
    sb.append("    greenEnergyEfficient: ").append(toIndentedString(greenEnergyEfficient)).append("\n");
    sb.append("    greenEnergyGeneration: ").append(toIndentedString(greenEnergyGeneration)).append("\n");
    sb.append("    greenIndoorAirQuality: ").append(toIndentedString(greenIndoorAirQuality)).append("\n");
    sb.append("    greenLocation: ").append(toIndentedString(greenLocation)).append("\n");
    sb.append("    greenSustainability: ").append(toIndentedString(greenSustainability)).append("\n");
    sb.append("    greenWaterConservation: ").append(toIndentedString(greenWaterConservation)).append("\n");
    sb.append("    grossIncome: ").append(toIndentedString(grossIncome)).append("\n");
    sb.append("    grossScheduledIncome: ").append(toIndentedString(grossScheduledIncome)).append("\n");
    sb.append("    habitableResidenceYN: ").append(toIndentedString(habitableResidenceYN)).append("\n");
    sb.append("    heating: ").append(toIndentedString(heating)).append("\n");
    sb.append("    heatingYN: ").append(toIndentedString(heatingYN)).append("\n");
    sb.append("    highSchool: ").append(toIndentedString(highSchool)).append("\n");
    sb.append("    highSchoolDistrict: ").append(toIndentedString(highSchoolDistrict)).append("\n");
    sb.append("    homeWarrantyYN: ").append(toIndentedString(homeWarrantyYN)).append("\n");
    sb.append("    horseAmenities: ").append(toIndentedString(horseAmenities)).append("\n");
    sb.append("    horseYN: ").append(toIndentedString(horseYN)).append("\n");
    sb.append("    hoursDaysOfOperation: ").append(toIndentedString(hoursDaysOfOperation)).append("\n");
    sb.append("    hoursDaysOfOperationDescription: ").append(toIndentedString(hoursDaysOfOperationDescription)).append("\n");
    sb.append("    inclusions: ").append(toIndentedString(inclusions)).append("\n");
    sb.append("    incomeIncludes: ").append(toIndentedString(incomeIncludes)).append("\n");
    sb.append("    insuranceExpense: ").append(toIndentedString(insuranceExpense)).append("\n");
    sb.append("    interiorFeatures: ").append(toIndentedString(interiorFeatures)).append("\n");
    sb.append("    internetAddressDisplayYN: ").append(toIndentedString(internetAddressDisplayYN)).append("\n");
    sb.append("    internetAutomatedValuationDisplayYN: ").append(toIndentedString(internetAutomatedValuationDisplayYN)).append("\n");
    sb.append("    internetConsumerCommentYN: ").append(toIndentedString(internetConsumerCommentYN)).append("\n");
    sb.append("    internetEntireListingDisplayYN: ").append(toIndentedString(internetEntireListingDisplayYN)).append("\n");
    sb.append("    irrigationSource: ").append(toIndentedString(irrigationSource)).append("\n");
    sb.append("    irrigationWaterRightsAcres: ").append(toIndentedString(irrigationWaterRightsAcres)).append("\n");
    sb.append("    irrigationWaterRightsYN: ").append(toIndentedString(irrigationWaterRightsYN)).append("\n");
    sb.append("    laborInformation: ").append(toIndentedString(laborInformation)).append("\n");
    sb.append("    landLeaseAmount: ").append(toIndentedString(landLeaseAmount)).append("\n");
    sb.append("    landLeaseAmountFrequency: ").append(toIndentedString(landLeaseAmountFrequency)).append("\n");
    sb.append("    landLeaseExpirationDate: ").append(toIndentedString(landLeaseExpirationDate)).append("\n");
    sb.append("    landLeaseYN: ").append(toIndentedString(landLeaseYN)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    laundryFeatures: ").append(toIndentedString(laundryFeatures)).append("\n");
    sb.append("    leasableArea: ").append(toIndentedString(leasableArea)).append("\n");
    sb.append("    leasableAreaUnits: ").append(toIndentedString(leasableAreaUnits)).append("\n");
    sb.append("    leaseAmount: ").append(toIndentedString(leaseAmount)).append("\n");
    sb.append("    leaseAmountFrequency: ").append(toIndentedString(leaseAmountFrequency)).append("\n");
    sb.append("    leaseAssignableYN: ").append(toIndentedString(leaseAssignableYN)).append("\n");
    sb.append("    leaseConsideredYN: ").append(toIndentedString(leaseConsideredYN)).append("\n");
    sb.append("    leaseExpiration: ").append(toIndentedString(leaseExpiration)).append("\n");
    sb.append("    leaseRenewalCompensation: ").append(toIndentedString(leaseRenewalCompensation)).append("\n");
    sb.append("    leaseRenewalOptionYN: ").append(toIndentedString(leaseRenewalOptionYN)).append("\n");
    sb.append("    leaseTerm: ").append(toIndentedString(leaseTerm)).append("\n");
    sb.append("    levels: ").append(toIndentedString(levels)).append("\n");
    sb.append("    license1: ").append(toIndentedString(license1)).append("\n");
    sb.append("    license2: ").append(toIndentedString(license2)).append("\n");
    sb.append("    license3: ").append(toIndentedString(license3)).append("\n");
    sb.append("    licensesExpense: ").append(toIndentedString(licensesExpense)).append("\n");
    sb.append("    listAOR: ").append(toIndentedString(listAOR)).append("\n");
    sb.append("    listAgentAOR: ").append(toIndentedString(listAgentAOR)).append("\n");
    sb.append("    listAgentDesignation: ").append(toIndentedString(listAgentDesignation)).append("\n");
    sb.append("    listAgentDirectPhone: ").append(toIndentedString(listAgentDirectPhone)).append("\n");
    sb.append("    listAgentEmail: ").append(toIndentedString(listAgentEmail)).append("\n");
    sb.append("    listAgentFax: ").append(toIndentedString(listAgentFax)).append("\n");
    sb.append("    listAgentFirstName: ").append(toIndentedString(listAgentFirstName)).append("\n");
    sb.append("    listAgentFullName: ").append(toIndentedString(listAgentFullName)).append("\n");
    sb.append("    listAgentHomePhone: ").append(toIndentedString(listAgentHomePhone)).append("\n");
    sb.append("    listAgentKey: ").append(toIndentedString(listAgentKey)).append("\n");
    sb.append("    listAgentKeyNumeric: ").append(toIndentedString(listAgentKeyNumeric)).append("\n");
    sb.append("    listAgentLastName: ").append(toIndentedString(listAgentLastName)).append("\n");
    sb.append("    listAgentMiddleName: ").append(toIndentedString(listAgentMiddleName)).append("\n");
    sb.append("    listAgentMlsId: ").append(toIndentedString(listAgentMlsId)).append("\n");
    sb.append("    listAgentMobilePhone: ").append(toIndentedString(listAgentMobilePhone)).append("\n");
    sb.append("    listAgentNamePrefix: ").append(toIndentedString(listAgentNamePrefix)).append("\n");
    sb.append("    listAgentNameSuffix: ").append(toIndentedString(listAgentNameSuffix)).append("\n");
    sb.append("    listAgentOfficePhone: ").append(toIndentedString(listAgentOfficePhone)).append("\n");
    sb.append("    listAgentOfficePhoneExt: ").append(toIndentedString(listAgentOfficePhoneExt)).append("\n");
    sb.append("    listAgentPager: ").append(toIndentedString(listAgentPager)).append("\n");
    sb.append("    listAgentPreferredPhone: ").append(toIndentedString(listAgentPreferredPhone)).append("\n");
    sb.append("    listAgentPreferredPhoneExt: ").append(toIndentedString(listAgentPreferredPhoneExt)).append("\n");
    sb.append("    listAgentStateLicense: ").append(toIndentedString(listAgentStateLicense)).append("\n");
    sb.append("    listAgentTollFreePhone: ").append(toIndentedString(listAgentTollFreePhone)).append("\n");
    sb.append("    listAgentURL: ").append(toIndentedString(listAgentURL)).append("\n");
    sb.append("    listAgentVoiceMail: ").append(toIndentedString(listAgentVoiceMail)).append("\n");
    sb.append("    listAgentVoiceMailExt: ").append(toIndentedString(listAgentVoiceMailExt)).append("\n");
    sb.append("    listOfficeAOR: ").append(toIndentedString(listOfficeAOR)).append("\n");
    sb.append("    listOfficeEmail: ").append(toIndentedString(listOfficeEmail)).append("\n");
    sb.append("    listOfficeFax: ").append(toIndentedString(listOfficeFax)).append("\n");
    sb.append("    listOfficeKey: ").append(toIndentedString(listOfficeKey)).append("\n");
    sb.append("    listOfficeKeyNumeric: ").append(toIndentedString(listOfficeKeyNumeric)).append("\n");
    sb.append("    listOfficeMlsId: ").append(toIndentedString(listOfficeMlsId)).append("\n");
    sb.append("    listOfficeName: ").append(toIndentedString(listOfficeName)).append("\n");
    sb.append("    listOfficePhone: ").append(toIndentedString(listOfficePhone)).append("\n");
    sb.append("    listOfficePhoneExt: ").append(toIndentedString(listOfficePhoneExt)).append("\n");
    sb.append("    listOfficeURL: ").append(toIndentedString(listOfficeURL)).append("\n");
    sb.append("    listPrice: ").append(toIndentedString(listPrice)).append("\n");
    sb.append("    listPriceLow: ").append(toIndentedString(listPriceLow)).append("\n");
    sb.append("    listTeamKey: ").append(toIndentedString(listTeamKey)).append("\n");
    sb.append("    listTeamKeyNumeric: ").append(toIndentedString(listTeamKeyNumeric)).append("\n");
    sb.append("    listTeamName: ").append(toIndentedString(listTeamName)).append("\n");
    sb.append("    listingAgreement: ").append(toIndentedString(listingAgreement)).append("\n");
    sb.append("    listingContractDate: ").append(toIndentedString(listingContractDate)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    listingService: ").append(toIndentedString(listingService)).append("\n");
    sb.append("    listingTerms: ").append(toIndentedString(listingTerms)).append("\n");
    sb.append("    livingArea: ").append(toIndentedString(livingArea)).append("\n");
    sb.append("    livingAreaSource: ").append(toIndentedString(livingAreaSource)).append("\n");
    sb.append("    livingAreaUnits: ").append(toIndentedString(livingAreaUnits)).append("\n");
    sb.append("    lockBoxLocation: ").append(toIndentedString(lockBoxLocation)).append("\n");
    sb.append("    lockBoxSerialNumber: ").append(toIndentedString(lockBoxSerialNumber)).append("\n");
    sb.append("    lockBoxType: ").append(toIndentedString(lockBoxType)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    lotDimensionsSource: ").append(toIndentedString(lotDimensionsSource)).append("\n");
    sb.append("    lotFeatures: ").append(toIndentedString(lotFeatures)).append("\n");
    sb.append("    lotSizeAcres: ").append(toIndentedString(lotSizeAcres)).append("\n");
    sb.append("    lotSizeArea: ").append(toIndentedString(lotSizeArea)).append("\n");
    sb.append("    lotSizeDimensions: ").append(toIndentedString(lotSizeDimensions)).append("\n");
    sb.append("    lotSizeSource: ").append(toIndentedString(lotSizeSource)).append("\n");
    sb.append("    lotSizeSquareFeet: ").append(toIndentedString(lotSizeSquareFeet)).append("\n");
    sb.append("    lotSizeUnits: ").append(toIndentedString(lotSizeUnits)).append("\n");
    sb.append("    mlSAreaMajor: ").append(toIndentedString(mlSAreaMajor)).append("\n");
    sb.append("    mlSAreaMinor: ").append(toIndentedString(mlSAreaMinor)).append("\n");
    sb.append("    mainLevelBathrooms: ").append(toIndentedString(mainLevelBathrooms)).append("\n");
    sb.append("    mainLevelBedrooms: ").append(toIndentedString(mainLevelBedrooms)).append("\n");
    sb.append("    maintenanceExpense: ").append(toIndentedString(maintenanceExpense)).append("\n");
    sb.append("    majorChangeTimestamp: ").append(toIndentedString(majorChangeTimestamp)).append("\n");
    sb.append("    majorChangeType: ").append(toIndentedString(majorChangeType)).append("\n");
    sb.append("    make: ").append(toIndentedString(make)).append("\n");
    sb.append("    managerExpense: ").append(toIndentedString(managerExpense)).append("\n");
    sb.append("    mapCoordinate: ").append(toIndentedString(mapCoordinate)).append("\n");
    sb.append("    mapCoordinateSource: ").append(toIndentedString(mapCoordinateSource)).append("\n");
    sb.append("    mapURL: ").append(toIndentedString(mapURL)).append("\n");
    sb.append("    middleOrJuniorSchool: ").append(toIndentedString(middleOrJuniorSchool)).append("\n");
    sb.append("    middleOrJuniorSchoolDistrict: ").append(toIndentedString(middleOrJuniorSchoolDistrict)).append("\n");
    sb.append("    mlsStatus: ").append(toIndentedString(mlsStatus)).append("\n");
    sb.append("    mobileDimUnits: ").append(toIndentedString(mobileDimUnits)).append("\n");
    sb.append("    mobileHomeRemainsYN: ").append(toIndentedString(mobileHomeRemainsYN)).append("\n");
    sb.append("    mobileLength: ").append(toIndentedString(mobileLength)).append("\n");
    sb.append("    mobileWidth: ").append(toIndentedString(mobileWidth)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    netOperatingIncome: ").append(toIndentedString(netOperatingIncome)).append("\n");
    sb.append("    newConstructionYN: ").append(toIndentedString(newConstructionYN)).append("\n");
    sb.append("    newTaxesExpense: ").append(toIndentedString(newTaxesExpense)).append("\n");
    sb.append("    numberOfBuildings: ").append(toIndentedString(numberOfBuildings)).append("\n");
    sb.append("    numberOfFullTimeEmployees: ").append(toIndentedString(numberOfFullTimeEmployees)).append("\n");
    sb.append("    numberOfLots: ").append(toIndentedString(numberOfLots)).append("\n");
    sb.append("    numberOfPads: ").append(toIndentedString(numberOfPads)).append("\n");
    sb.append("    numberOfPartTimeEmployees: ").append(toIndentedString(numberOfPartTimeEmployees)).append("\n");
    sb.append("    numberOfSeparateElectricMeters: ").append(toIndentedString(numberOfSeparateElectricMeters)).append("\n");
    sb.append("    numberOfSeparateGasMeters: ").append(toIndentedString(numberOfSeparateGasMeters)).append("\n");
    sb.append("    numberOfSeparateWaterMeters: ").append(toIndentedString(numberOfSeparateWaterMeters)).append("\n");
    sb.append("    numberOfUnitsInCommunity: ").append(toIndentedString(numberOfUnitsInCommunity)).append("\n");
    sb.append("    numberOfUnitsLeased: ").append(toIndentedString(numberOfUnitsLeased)).append("\n");
    sb.append("    numberOfUnitsMoMo: ").append(toIndentedString(numberOfUnitsMoMo)).append("\n");
    sb.append("    numberOfUnitsTotal: ").append(toIndentedString(numberOfUnitsTotal)).append("\n");
    sb.append("    numberOfUnitsVacant: ").append(toIndentedString(numberOfUnitsVacant)).append("\n");
    sb.append("    occupantName: ").append(toIndentedString(occupantName)).append("\n");
    sb.append("    occupantPhone: ").append(toIndentedString(occupantPhone)).append("\n");
    sb.append("    occupantType: ").append(toIndentedString(occupantType)).append("\n");
    sb.append("    offMarketDate: ").append(toIndentedString(offMarketDate)).append("\n");
    sb.append("    offMarketTimestamp: ").append(toIndentedString(offMarketTimestamp)).append("\n");
    sb.append("    onMarketDate: ").append(toIndentedString(onMarketDate)).append("\n");
    sb.append("    onMarketTimestamp: ").append(toIndentedString(onMarketTimestamp)).append("\n");
    sb.append("    openParkingSpaces: ").append(toIndentedString(openParkingSpaces)).append("\n");
    sb.append("    openParkingYN: ").append(toIndentedString(openParkingYN)).append("\n");
    sb.append("    operatingExpense: ").append(toIndentedString(operatingExpense)).append("\n");
    sb.append("    operatingExpenseIncludes: ").append(toIndentedString(operatingExpenseIncludes)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originalListPrice: ").append(toIndentedString(originalListPrice)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    otherEquipment: ").append(toIndentedString(otherEquipment)).append("\n");
    sb.append("    otherExpense: ").append(toIndentedString(otherExpense)).append("\n");
    sb.append("    otherParking: ").append(toIndentedString(otherParking)).append("\n");
    sb.append("    otherStructures: ").append(toIndentedString(otherStructures)).append("\n");
    sb.append("    ownerName: ").append(toIndentedString(ownerName)).append("\n");
    sb.append("    ownerPays: ").append(toIndentedString(ownerPays)).append("\n");
    sb.append("    ownerPhone: ").append(toIndentedString(ownerPhone)).append("\n");
    sb.append("    ownership: ").append(toIndentedString(ownership)).append("\n");
    sb.append("    ownershipType: ").append(toIndentedString(ownershipType)).append("\n");
    sb.append("    parcelNumber: ").append(toIndentedString(parcelNumber)).append("\n");
    sb.append("    parkManagerName: ").append(toIndentedString(parkManagerName)).append("\n");
    sb.append("    parkManagerPhone: ").append(toIndentedString(parkManagerPhone)).append("\n");
    sb.append("    parkName: ").append(toIndentedString(parkName)).append("\n");
    sb.append("    parkingFeatures: ").append(toIndentedString(parkingFeatures)).append("\n");
    sb.append("    parkingTotal: ").append(toIndentedString(parkingTotal)).append("\n");
    sb.append("    pastureArea: ").append(toIndentedString(pastureArea)).append("\n");
    sb.append("    patioAndPorchFeatures: ").append(toIndentedString(patioAndPorchFeatures)).append("\n");
    sb.append("    pendingTimestamp: ").append(toIndentedString(pendingTimestamp)).append("\n");
    sb.append("    pestControlExpense: ").append(toIndentedString(pestControlExpense)).append("\n");
    sb.append("    petsAllowed: ").append(toIndentedString(petsAllowed)).append("\n");
    sb.append("    photosChangeTimestamp: ").append(toIndentedString(photosChangeTimestamp)).append("\n");
    sb.append("    photosCount: ").append(toIndentedString(photosCount)).append("\n");
    sb.append("    poolExpense: ").append(toIndentedString(poolExpense)).append("\n");
    sb.append("    poolFeatures: ").append(toIndentedString(poolFeatures)).append("\n");
    sb.append("    poolPrivateYN: ").append(toIndentedString(poolPrivateYN)).append("\n");
    sb.append("    possession: ").append(toIndentedString(possession)).append("\n");
    sb.append("    possibleUse: ").append(toIndentedString(possibleUse)).append("\n");
    sb.append("    postalCity: ").append(toIndentedString(postalCity)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    postalCodePlus4: ").append(toIndentedString(postalCodePlus4)).append("\n");
    sb.append("    powerProductionType: ").append(toIndentedString(powerProductionType)).append("\n");
    sb.append("    previousListPrice: ").append(toIndentedString(previousListPrice)).append("\n");
    sb.append("    priceChangeTimestamp: ").append(toIndentedString(priceChangeTimestamp)).append("\n");
    sb.append("    privateOfficeRemarks: ").append(toIndentedString(privateOfficeRemarks)).append("\n");
    sb.append("    privateRemarks: ").append(toIndentedString(privateRemarks)).append("\n");
    sb.append("    professionalManagementExpense: ").append(toIndentedString(professionalManagementExpense)).append("\n");
    sb.append("    propertyAttachedYN: ").append(toIndentedString(propertyAttachedYN)).append("\n");
    sb.append("    propertyCondition: ").append(toIndentedString(propertyCondition)).append("\n");
    sb.append("    propertySubType: ").append(toIndentedString(propertySubType)).append("\n");
    sb.append("    propertyType: ").append(toIndentedString(propertyType)).append("\n");
    sb.append("    publicRemarks: ").append(toIndentedString(publicRemarks)).append("\n");
    sb.append("    publicSurveyRange: ").append(toIndentedString(publicSurveyRange)).append("\n");
    sb.append("    publicSurveySection: ").append(toIndentedString(publicSurveySection)).append("\n");
    sb.append("    publicSurveyTownship: ").append(toIndentedString(publicSurveyTownship)).append("\n");
    sb.append("    purchaseContractDate: ").append(toIndentedString(purchaseContractDate)).append("\n");
    sb.append("    rvParkingDimensions: ").append(toIndentedString(rvParkingDimensions)).append("\n");
    sb.append("    rangeArea: ").append(toIndentedString(rangeArea)).append("\n");
    sb.append("    rentControlYN: ").append(toIndentedString(rentControlYN)).append("\n");
    sb.append("    rentIncludes: ").append(toIndentedString(rentIncludes)).append("\n");
    sb.append("    roadFrontageType: ").append(toIndentedString(roadFrontageType)).append("\n");
    sb.append("    roadResponsibility: ").append(toIndentedString(roadResponsibility)).append("\n");
    sb.append("    roadSurfaceType: ").append(toIndentedString(roadSurfaceType)).append("\n");
    sb.append("    roof: ").append(toIndentedString(roof)).append("\n");
    sb.append("    roomType: ").append(toIndentedString(roomType)).append("\n");
    sb.append("    roomsTotal: ").append(toIndentedString(roomsTotal)).append("\n");
    sb.append("    seatingCapacity: ").append(toIndentedString(seatingCapacity)).append("\n");
    sb.append("    securityFeatures: ").append(toIndentedString(securityFeatures)).append("\n");
    sb.append("    seniorCommunityYN: ").append(toIndentedString(seniorCommunityYN)).append("\n");
    sb.append("    serialU: ").append(toIndentedString(serialU)).append("\n");
    sb.append("    serialX: ").append(toIndentedString(serialX)).append("\n");
    sb.append("    serialXX: ").append(toIndentedString(serialXX)).append("\n");
    sb.append("    sewer: ").append(toIndentedString(sewer)).append("\n");
    sb.append("    showingAdvanceNotice: ").append(toIndentedString(showingAdvanceNotice)).append("\n");
    sb.append("    showingAttendedYN: ").append(toIndentedString(showingAttendedYN)).append("\n");
    sb.append("    showingContactName: ").append(toIndentedString(showingContactName)).append("\n");
    sb.append("    showingContactPhone: ").append(toIndentedString(showingContactPhone)).append("\n");
    sb.append("    showingContactPhoneExt: ").append(toIndentedString(showingContactPhoneExt)).append("\n");
    sb.append("    showingContactType: ").append(toIndentedString(showingContactType)).append("\n");
    sb.append("    showingDays: ").append(toIndentedString(showingDays)).append("\n");
    sb.append("    showingEndTime: ").append(toIndentedString(showingEndTime)).append("\n");
    sb.append("    showingInstructions: ").append(toIndentedString(showingInstructions)).append("\n");
    sb.append("    showingRequirements: ").append(toIndentedString(showingRequirements)).append("\n");
    sb.append("    showingStartTime: ").append(toIndentedString(showingStartTime)).append("\n");
    sb.append("    signOnPropertyYN: ").append(toIndentedString(signOnPropertyYN)).append("\n");
    sb.append("    skirt: ").append(toIndentedString(skirt)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    spaFeatures: ").append(toIndentedString(spaFeatures)).append("\n");
    sb.append("    spaYN: ").append(toIndentedString(spaYN)).append("\n");
    sb.append("    specialLicenses: ").append(toIndentedString(specialLicenses)).append("\n");
    sb.append("    specialListingConditions: ").append(toIndentedString(specialListingConditions)).append("\n");
    sb.append("    standardStatus: ").append(toIndentedString(standardStatus)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    stateRegion: ").append(toIndentedString(stateRegion)).append("\n");
    sb.append("    statusChangeTimestamp: ").append(toIndentedString(statusChangeTimestamp)).append("\n");
    sb.append("    stories: ").append(toIndentedString(stories)).append("\n");
    sb.append("    storiesTotal: ").append(toIndentedString(storiesTotal)).append("\n");
    sb.append("    streetAdditionalInfo: ").append(toIndentedString(streetAdditionalInfo)).append("\n");
    sb.append("    streetDirPrefix: ").append(toIndentedString(streetDirPrefix)).append("\n");
    sb.append("    streetDirSuffix: ").append(toIndentedString(streetDirSuffix)).append("\n");
    sb.append("    streetName: ").append(toIndentedString(streetName)).append("\n");
    sb.append("    streetNumber: ").append(toIndentedString(streetNumber)).append("\n");
    sb.append("    streetNumberNumeric: ").append(toIndentedString(streetNumberNumeric)).append("\n");
    sb.append("    streetSuffix: ").append(toIndentedString(streetSuffix)).append("\n");
    sb.append("    streetSuffixModifier: ").append(toIndentedString(streetSuffixModifier)).append("\n");
    sb.append("    structureType: ").append(toIndentedString(structureType)).append("\n");
    sb.append("    subAgencyCompensation: ").append(toIndentedString(subAgencyCompensation)).append("\n");
    sb.append("    subAgencyCompensationType: ").append(toIndentedString(subAgencyCompensationType)).append("\n");
    sb.append("    subdivisionName: ").append(toIndentedString(subdivisionName)).append("\n");
    sb.append("    suppliesExpense: ").append(toIndentedString(suppliesExpense)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("    syndicationRemarks: ").append(toIndentedString(syndicationRemarks)).append("\n");
    sb.append("    taxAnnualAmount: ").append(toIndentedString(taxAnnualAmount)).append("\n");
    sb.append("    taxAssessedValue: ").append(toIndentedString(taxAssessedValue)).append("\n");
    sb.append("    taxBlock: ").append(toIndentedString(taxBlock)).append("\n");
    sb.append("    taxBookNumber: ").append(toIndentedString(taxBookNumber)).append("\n");
    sb.append("    taxLegalDescription: ").append(toIndentedString(taxLegalDescription)).append("\n");
    sb.append("    taxLot: ").append(toIndentedString(taxLot)).append("\n");
    sb.append("    taxMapNumber: ").append(toIndentedString(taxMapNumber)).append("\n");
    sb.append("    taxOtherAnnualAssessmentAmount: ").append(toIndentedString(taxOtherAnnualAssessmentAmount)).append("\n");
    sb.append("    taxParcelLetter: ").append(toIndentedString(taxParcelLetter)).append("\n");
    sb.append("    taxStatusCurrent: ").append(toIndentedString(taxStatusCurrent)).append("\n");
    sb.append("    taxTract: ").append(toIndentedString(taxTract)).append("\n");
    sb.append("    taxYear: ").append(toIndentedString(taxYear)).append("\n");
    sb.append("    tenantPays: ").append(toIndentedString(tenantPays)).append("\n");
    sb.append("    topography: ").append(toIndentedString(topography)).append("\n");
    sb.append("    totalActualRent: ").append(toIndentedString(totalActualRent)).append("\n");
    sb.append("    township: ").append(toIndentedString(township)).append("\n");
    sb.append("    transactionBrokerCompensation: ").append(toIndentedString(transactionBrokerCompensation)).append("\n");
    sb.append("    transactionBrokerCompensationType: ").append(toIndentedString(transactionBrokerCompensationType)).append("\n");
    sb.append("    trashExpense: ").append(toIndentedString(trashExpense)).append("\n");
    sb.append("    unitNumber: ").append(toIndentedString(unitNumber)).append("\n");
    sb.append("    unitTypeType: ").append(toIndentedString(unitTypeType)).append("\n");
    sb.append("    unitsFurnished: ").append(toIndentedString(unitsFurnished)).append("\n");
    sb.append("    universalPropertyId: ").append(toIndentedString(universalPropertyId)).append("\n");
    sb.append("    universalPropertySubId: ").append(toIndentedString(universalPropertySubId)).append("\n");
    sb.append("    unparsedAddress: ").append(toIndentedString(unparsedAddress)).append("\n");
    sb.append("    utilities: ").append(toIndentedString(utilities)).append("\n");
    sb.append("    vacancyAllowance: ").append(toIndentedString(vacancyAllowance)).append("\n");
    sb.append("    vacancyAllowanceRate: ").append(toIndentedString(vacancyAllowanceRate)).append("\n");
    sb.append("    vegetation: ").append(toIndentedString(vegetation)).append("\n");
    sb.append("    videosChangeTimestamp: ").append(toIndentedString(videosChangeTimestamp)).append("\n");
    sb.append("    videosCount: ").append(toIndentedString(videosCount)).append("\n");
    sb.append("    view: ").append(toIndentedString(view)).append("\n");
    sb.append("    viewYN: ").append(toIndentedString(viewYN)).append("\n");
    sb.append("    virtualTourURLBranded: ").append(toIndentedString(virtualTourURLBranded)).append("\n");
    sb.append("    virtualTourURLUnbranded: ").append(toIndentedString(virtualTourURLUnbranded)).append("\n");
    sb.append("    walkScore: ").append(toIndentedString(walkScore)).append("\n");
    sb.append("    waterBodyName: ").append(toIndentedString(waterBodyName)).append("\n");
    sb.append("    waterSewerExpense: ").append(toIndentedString(waterSewerExpense)).append("\n");
    sb.append("    waterSource: ").append(toIndentedString(waterSource)).append("\n");
    sb.append("    waterfrontFeatures: ").append(toIndentedString(waterfrontFeatures)).append("\n");
    sb.append("    waterfrontYN: ").append(toIndentedString(waterfrontYN)).append("\n");
    sb.append("    windowFeatures: ").append(toIndentedString(windowFeatures)).append("\n");
    sb.append("    withdrawnDate: ").append(toIndentedString(withdrawnDate)).append("\n");
    sb.append("    woodedArea: ").append(toIndentedString(woodedArea)).append("\n");
    sb.append("    workmansCompensationExpense: ").append(toIndentedString(workmansCompensationExpense)).append("\n");
    sb.append("    yearBuilt: ").append(toIndentedString(yearBuilt)).append("\n");
    sb.append("    yearBuiltDetails: ").append(toIndentedString(yearBuiltDetails)).append("\n");
    sb.append("    yearBuiltEffective: ").append(toIndentedString(yearBuiltEffective)).append("\n");
    sb.append("    yearBuiltSource: ").append(toIndentedString(yearBuiltSource)).append("\n");
    sb.append("    yearEstablished: ").append(toIndentedString(yearEstablished)).append("\n");
    sb.append("    yearsCurrentOwner: ").append(toIndentedString(yearsCurrentOwner)).append("\n");
    sb.append("    zoning: ").append(toIndentedString(zoning)).append("\n");
    sb.append("    zoningDescription: ").append(toIndentedString(zoningDescription)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
