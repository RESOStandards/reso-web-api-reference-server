package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric {

}
