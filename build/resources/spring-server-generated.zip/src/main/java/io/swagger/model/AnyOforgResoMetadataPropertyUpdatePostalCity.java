package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdatePostalCity
*/
public interface AnyOforgResoMetadataPropertyUpdatePostalCity {

}
