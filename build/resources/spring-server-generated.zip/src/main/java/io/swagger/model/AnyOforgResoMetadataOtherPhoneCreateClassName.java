package io.swagger.model;


/**
* AnyOforgResoMetadataOtherPhoneCreateClassName
*/
public interface AnyOforgResoMetadataOtherPhoneCreateClassName {

}
