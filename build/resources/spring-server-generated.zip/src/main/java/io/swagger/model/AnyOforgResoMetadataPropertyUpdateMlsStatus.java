package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateMlsStatus
*/
public interface AnyOforgResoMetadataPropertyUpdateMlsStatus {

}
