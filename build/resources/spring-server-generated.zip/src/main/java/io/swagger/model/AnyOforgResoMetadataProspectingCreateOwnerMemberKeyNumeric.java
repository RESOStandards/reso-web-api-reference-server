package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric
*/
public interface AnyOforgResoMetadataProspectingCreateOwnerMemberKeyNumeric {

}
