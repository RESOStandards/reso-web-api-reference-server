package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataQueueUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataQueueUpdate   {
  @JsonProperty("ClassName")
  private AnyOforgResoMetadataQueueUpdateClassName className = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OriginatingSystemQueueKey")
  private String originatingSystemQueueKey = null;

  @JsonProperty("QueueTransactionKeyNumeric")
  private AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric queueTransactionKeyNumeric = null;

  @JsonProperty("QueueTransactionType")
  private AnyOforgResoMetadataQueueUpdateQueueTransactionType queueTransactionType = null;

  @JsonProperty("ResourceName")
  private AnyOforgResoMetadataQueueUpdateResourceName resourceName = null;

  @JsonProperty("ResourceRecordID")
  private String resourceRecordID = null;

  @JsonProperty("ResourceRecordKey")
  private String resourceRecordKey = null;

  @JsonProperty("ResourceRecordKeyNumeric")
  private AnyOforgResoMetadataQueueUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SourceSystemQueueKey")
  private String sourceSystemQueueKey = null;

  public OrgResoMetadataQueueUpdate className(AnyOforgResoMetadataQueueUpdateClassName className) {
    this.className = className;
    return this;
  }

  /**
   * Get className
   * @return className
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataQueueUpdateClassName getClassName() {
    return className;
  }

  public void setClassName(AnyOforgResoMetadataQueueUpdateClassName className) {
    this.className = className;
  }

  public OrgResoMetadataQueueUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataQueueUpdate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataQueueUpdate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataQueueUpdate originatingSystemQueueKey(String originatingSystemQueueKey) {
    this.originatingSystemQueueKey = originatingSystemQueueKey;
    return this;
  }

  /**
   * Get originatingSystemQueueKey
   * @return originatingSystemQueueKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemQueueKey() {
    return originatingSystemQueueKey;
  }

  public void setOriginatingSystemQueueKey(String originatingSystemQueueKey) {
    this.originatingSystemQueueKey = originatingSystemQueueKey;
  }

  public OrgResoMetadataQueueUpdate queueTransactionKeyNumeric(AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric queueTransactionKeyNumeric) {
    this.queueTransactionKeyNumeric = queueTransactionKeyNumeric;
    return this;
  }

  /**
   * Get queueTransactionKeyNumeric
   * @return queueTransactionKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric getQueueTransactionKeyNumeric() {
    return queueTransactionKeyNumeric;
  }

  public void setQueueTransactionKeyNumeric(AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric queueTransactionKeyNumeric) {
    this.queueTransactionKeyNumeric = queueTransactionKeyNumeric;
  }

  public OrgResoMetadataQueueUpdate queueTransactionType(AnyOforgResoMetadataQueueUpdateQueueTransactionType queueTransactionType) {
    this.queueTransactionType = queueTransactionType;
    return this;
  }

  /**
   * Get queueTransactionType
   * @return queueTransactionType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataQueueUpdateQueueTransactionType getQueueTransactionType() {
    return queueTransactionType;
  }

  public void setQueueTransactionType(AnyOforgResoMetadataQueueUpdateQueueTransactionType queueTransactionType) {
    this.queueTransactionType = queueTransactionType;
  }

  public OrgResoMetadataQueueUpdate resourceName(AnyOforgResoMetadataQueueUpdateResourceName resourceName) {
    this.resourceName = resourceName;
    return this;
  }

  /**
   * Get resourceName
   * @return resourceName
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataQueueUpdateResourceName getResourceName() {
    return resourceName;
  }

  public void setResourceName(AnyOforgResoMetadataQueueUpdateResourceName resourceName) {
    this.resourceName = resourceName;
  }

  public OrgResoMetadataQueueUpdate resourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
    return this;
  }

  /**
   * Get resourceRecordID
   * @return resourceRecordID
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordID() {
    return resourceRecordID;
  }

  public void setResourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
  }

  public OrgResoMetadataQueueUpdate resourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
    return this;
  }

  /**
   * Get resourceRecordKey
   * @return resourceRecordKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordKey() {
    return resourceRecordKey;
  }

  public void setResourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
  }

  public OrgResoMetadataQueueUpdate resourceRecordKeyNumeric(AnyOforgResoMetadataQueueUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
    return this;
  }

  /**
   * Get resourceRecordKeyNumeric
   * @return resourceRecordKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataQueueUpdateResourceRecordKeyNumeric getResourceRecordKeyNumeric() {
    return resourceRecordKeyNumeric;
  }

  public void setResourceRecordKeyNumeric(AnyOforgResoMetadataQueueUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
  }

  public OrgResoMetadataQueueUpdate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataQueueUpdate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataQueueUpdate sourceSystemQueueKey(String sourceSystemQueueKey) {
    this.sourceSystemQueueKey = sourceSystemQueueKey;
    return this;
  }

  /**
   * Get sourceSystemQueueKey
   * @return sourceSystemQueueKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemQueueKey() {
    return sourceSystemQueueKey;
  }

  public void setSourceSystemQueueKey(String sourceSystemQueueKey) {
    this.sourceSystemQueueKey = sourceSystemQueueKey;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataQueueUpdate orgResoMetadataQueueUpdate = (OrgResoMetadataQueueUpdate) o;
    return Objects.equals(this.className, orgResoMetadataQueueUpdate.className) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataQueueUpdate.modificationTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataQueueUpdate.originatingSystemID) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataQueueUpdate.originatingSystemName) &&
        Objects.equals(this.originatingSystemQueueKey, orgResoMetadataQueueUpdate.originatingSystemQueueKey) &&
        Objects.equals(this.queueTransactionKeyNumeric, orgResoMetadataQueueUpdate.queueTransactionKeyNumeric) &&
        Objects.equals(this.queueTransactionType, orgResoMetadataQueueUpdate.queueTransactionType) &&
        Objects.equals(this.resourceName, orgResoMetadataQueueUpdate.resourceName) &&
        Objects.equals(this.resourceRecordID, orgResoMetadataQueueUpdate.resourceRecordID) &&
        Objects.equals(this.resourceRecordKey, orgResoMetadataQueueUpdate.resourceRecordKey) &&
        Objects.equals(this.resourceRecordKeyNumeric, orgResoMetadataQueueUpdate.resourceRecordKeyNumeric) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataQueueUpdate.sourceSystemID) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataQueueUpdate.sourceSystemName) &&
        Objects.equals(this.sourceSystemQueueKey, orgResoMetadataQueueUpdate.sourceSystemQueueKey);
  }

  @Override
  public int hashCode() {
    return Objects.hash(className, modificationTimestamp, originatingSystemID, originatingSystemName, originatingSystemQueueKey, queueTransactionKeyNumeric, queueTransactionType, resourceName, resourceRecordID, resourceRecordKey, resourceRecordKeyNumeric, sourceSystemID, sourceSystemName, sourceSystemQueueKey);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataQueueUpdate {\n");
    
    sb.append("    className: ").append(toIndentedString(className)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    originatingSystemQueueKey: ").append(toIndentedString(originatingSystemQueueKey)).append("\n");
    sb.append("    queueTransactionKeyNumeric: ").append(toIndentedString(queueTransactionKeyNumeric)).append("\n");
    sb.append("    queueTransactionType: ").append(toIndentedString(queueTransactionType)).append("\n");
    sb.append("    resourceName: ").append(toIndentedString(resourceName)).append("\n");
    sb.append("    resourceRecordID: ").append(toIndentedString(resourceRecordID)).append("\n");
    sb.append("    resourceRecordKey: ").append(toIndentedString(resourceRecordKey)).append("\n");
    sb.append("    resourceRecordKeyNumeric: ").append(toIndentedString(resourceRecordKeyNumeric)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    sourceSystemQueueKey: ").append(toIndentedString(sourceSystemQueueKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
