package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits {

}
