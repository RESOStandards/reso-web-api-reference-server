package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateConcessionsAmount
*/
public interface AnyOforgResoMetadataPropertyCreateConcessionsAmount {

}
