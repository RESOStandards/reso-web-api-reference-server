package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric {

}
