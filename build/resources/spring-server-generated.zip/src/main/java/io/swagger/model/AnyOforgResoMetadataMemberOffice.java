package io.swagger.model;


/**
* AnyOforgResoMetadataMemberOffice
*/
public interface AnyOforgResoMetadataMemberOffice {

}
