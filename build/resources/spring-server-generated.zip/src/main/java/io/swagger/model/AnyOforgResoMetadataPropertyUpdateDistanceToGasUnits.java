package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToGasUnits {

}
