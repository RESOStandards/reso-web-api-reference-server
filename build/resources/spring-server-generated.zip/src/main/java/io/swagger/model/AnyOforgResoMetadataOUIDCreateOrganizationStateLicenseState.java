package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationStateLicenseState
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationStateLicenseState {

}
