package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateHomeStateOrProvince
*/
public interface AnyOforgResoMetadataContactsCreateHomeStateOrProvince {

}
