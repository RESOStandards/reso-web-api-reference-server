package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNewTaxesExpense
*/
public interface AnyOforgResoMetadataPropertyCreateNewTaxesExpense {

}
