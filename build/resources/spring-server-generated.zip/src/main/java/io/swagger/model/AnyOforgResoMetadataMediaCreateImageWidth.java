package io.swagger.model;


/**
* AnyOforgResoMetadataMediaCreateImageWidth
*/
public interface AnyOforgResoMetadataMediaCreateImageWidth {

}
