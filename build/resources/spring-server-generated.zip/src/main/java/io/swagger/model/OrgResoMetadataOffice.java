package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Count;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.model.OrgResoMetadataHistoryTransactional;
import io.swagger.model.OrgResoMetadataMedia;
import io.swagger.model.OrgResoMetadataSocialMedia;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOffice
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOffice  implements AnyOforgResoMetadataMemberOffice, AnyOforgResoMetadataOfficeMainOffice, AnyOforgResoMetadataPropertyBuyerOffice, AnyOforgResoMetadataPropertyCoBuyerOffice, AnyOforgResoMetadataPropertyCoListOffice, AnyOforgResoMetadataPropertyListOffice {
  @JsonProperty("FranchiseAffiliation")
  private String franchiseAffiliation = null;

  @JsonProperty("IDXOfficeParticipationYN")
  private Boolean idXOfficeParticipationYN = null;

  @JsonProperty("MainOfficeKey")
  private String mainOfficeKey = null;

  @JsonProperty("MainOfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeMainOfficeKeyNumeric mainOfficeKeyNumeric = null;

  @JsonProperty("MainOfficeMlsId")
  private String mainOfficeMlsId = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OfficeAOR")
  private AnyOforgResoMetadataOfficeOfficeAOR officeAOR = null;

  @JsonProperty("OfficeAORMlsId")
  private String officeAORMlsId = null;

  @JsonProperty("OfficeAORkey")
  private String officeAORkey = null;

  @JsonProperty("OfficeAORkeyNumeric")
  private AnyOforgResoMetadataOfficeOfficeAORkeyNumeric officeAORkeyNumeric = null;

  @JsonProperty("OfficeAddress1")
  private String officeAddress1 = null;

  @JsonProperty("OfficeAddress2")
  private String officeAddress2 = null;

  @JsonProperty("OfficeAssociationComments")
  private String officeAssociationComments = null;

  @JsonProperty("OfficeBranchType")
  private AnyOforgResoMetadataOfficeOfficeBranchType officeBranchType = null;

  @JsonProperty("OfficeBrokerKey")
  private String officeBrokerKey = null;

  @JsonProperty("OfficeBrokerKeyNumeric")
  private AnyOforgResoMetadataOfficeOfficeBrokerKeyNumeric officeBrokerKeyNumeric = null;

  @JsonProperty("OfficeBrokerMlsId")
  private String officeBrokerMlsId = null;

  @JsonProperty("OfficeCity")
  private String officeCity = null;

  @JsonProperty("OfficeCorporateLicense")
  private String officeCorporateLicense = null;

  @JsonProperty("OfficeCountyOrParish")
  private AnyOforgResoMetadataOfficeOfficeCountyOrParish officeCountyOrParish = null;

  @JsonProperty("OfficeEmail")
  private String officeEmail = null;

  @JsonProperty("OfficeFax")
  private String officeFax = null;

  @JsonProperty("OfficeKey")
  private String officeKey = null;

  @JsonProperty("OfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeOfficeKeyNumeric officeKeyNumeric = null;

  @JsonProperty("OfficeManagerKey")
  private String officeManagerKey = null;

  @JsonProperty("OfficeManagerKeyNumeric")
  private AnyOforgResoMetadataOfficeOfficeManagerKeyNumeric officeManagerKeyNumeric = null;

  @JsonProperty("OfficeManagerMlsId")
  private String officeManagerMlsId = null;

  @JsonProperty("OfficeMlsId")
  private String officeMlsId = null;

  @JsonProperty("OfficeName")
  private String officeName = null;

  @JsonProperty("OfficeNationalAssociationId")
  private String officeNationalAssociationId = null;

  @JsonProperty("OfficePhone")
  private String officePhone = null;

  @JsonProperty("OfficePhoneExt")
  private String officePhoneExt = null;

  @JsonProperty("OfficePostalCode")
  private String officePostalCode = null;

  @JsonProperty("OfficePostalCodePlus4")
  private String officePostalCodePlus4 = null;

  @JsonProperty("OfficeStateOrProvince")
  private AnyOforgResoMetadataOfficeOfficeStateOrProvince officeStateOrProvince = null;

  @JsonProperty("OfficeStatus")
  private AnyOforgResoMetadataOfficeOfficeStatus officeStatus = null;

  @JsonProperty("OfficeType")
  private AnyOforgResoMetadataOfficeOfficeType officeType = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OriginatingSystemOfficeKey")
  private String originatingSystemOfficeKey = null;

  @JsonProperty("SocialMediaType")
  private AnyOforgResoMetadataOfficeSocialMediaType socialMediaType = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SourceSystemOfficeKey")
  private String sourceSystemOfficeKey = null;

  @JsonProperty("SyndicateAgentOption")
  private AnyOforgResoMetadataOfficeSyndicateAgentOption syndicateAgentOption = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  @JsonProperty("MainOffice")
  private AnyOforgResoMetadataOfficeMainOffice mainOffice = null;

  @JsonProperty("OfficeBroker")
  private AnyOforgResoMetadataOfficeOfficeBroker officeBroker = null;

  @JsonProperty("OfficeManager")
  private AnyOforgResoMetadataOfficeOfficeManager officeManager = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataOfficeOriginatingSystem originatingSystem = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataOfficeSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactional> historyTransactional = null;

  @JsonProperty("HistoryTransactional@odata.count")
  private Count historyTransactionalAtOdataCount = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMedia> media = null;

  @JsonProperty("Media@odata.count")
  private Count mediaAtOdataCount = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMedia> socialMedia = null;

  @JsonProperty("SocialMedia@odata.count")
  private Count socialMediaAtOdataCount = null;

  public OrgResoMetadataOffice franchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
    return this;
  }

  /**
   * Get franchiseAffiliation
   * @return franchiseAffiliation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getFranchiseAffiliation() {
    return franchiseAffiliation;
  }

  public void setFranchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
  }

  public OrgResoMetadataOffice idXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
    return this;
  }

  /**
   * Get idXOfficeParticipationYN
   * @return idXOfficeParticipationYN
   **/
  @Schema(description = "")
  
    public Boolean isIdXOfficeParticipationYN() {
    return idXOfficeParticipationYN;
  }

  public void setIdXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
  }

  public OrgResoMetadataOffice mainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
    return this;
  }

  /**
   * Get mainOfficeKey
   * @return mainOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getMainOfficeKey() {
    return mainOfficeKey;
  }

  public void setMainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
  }

  public OrgResoMetadataOffice mainOfficeKeyNumeric(AnyOforgResoMetadataOfficeMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
    return this;
  }

  /**
   * Get mainOfficeKeyNumeric
   * @return mainOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeMainOfficeKeyNumeric getMainOfficeKeyNumeric() {
    return mainOfficeKeyNumeric;
  }

  public void setMainOfficeKeyNumeric(AnyOforgResoMetadataOfficeMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
  }

  public OrgResoMetadataOffice mainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
    return this;
  }

  /**
   * Get mainOfficeMlsId
   * @return mainOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMainOfficeMlsId() {
    return mainOfficeMlsId;
  }

  public void setMainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
  }

  public OrgResoMetadataOffice modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOffice officeAOR(AnyOforgResoMetadataOfficeOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
    return this;
  }

  /**
   * Get officeAOR
   * @return officeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeAOR getOfficeAOR() {
    return officeAOR;
  }

  public void setOfficeAOR(AnyOforgResoMetadataOfficeOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
  }

  public OrgResoMetadataOffice officeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
    return this;
  }

  /**
   * Get officeAORMlsId
   * @return officeAORMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeAORMlsId() {
    return officeAORMlsId;
  }

  public void setOfficeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
  }

  public OrgResoMetadataOffice officeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
    return this;
  }

  /**
   * Get officeAORkey
   * @return officeAORkey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeAORkey() {
    return officeAORkey;
  }

  public void setOfficeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
  }

  public OrgResoMetadataOffice officeAORkeyNumeric(AnyOforgResoMetadataOfficeOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
    return this;
  }

  /**
   * Get officeAORkeyNumeric
   * @return officeAORkeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeOfficeAORkeyNumeric getOfficeAORkeyNumeric() {
    return officeAORkeyNumeric;
  }

  public void setOfficeAORkeyNumeric(AnyOforgResoMetadataOfficeOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
  }

  public OrgResoMetadataOffice officeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
    return this;
  }

  /**
   * Get officeAddress1
   * @return officeAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress1() {
    return officeAddress1;
  }

  public void setOfficeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
  }

  public OrgResoMetadataOffice officeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
    return this;
  }

  /**
   * Get officeAddress2
   * @return officeAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress2() {
    return officeAddress2;
  }

  public void setOfficeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
  }

  public OrgResoMetadataOffice officeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
    return this;
  }

  /**
   * Get officeAssociationComments
   * @return officeAssociationComments
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getOfficeAssociationComments() {
    return officeAssociationComments;
  }

  public void setOfficeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
  }

  public OrgResoMetadataOffice officeBranchType(AnyOforgResoMetadataOfficeOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
    return this;
  }

  /**
   * Get officeBranchType
   * @return officeBranchType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeBranchType getOfficeBranchType() {
    return officeBranchType;
  }

  public void setOfficeBranchType(AnyOforgResoMetadataOfficeOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
  }

  public OrgResoMetadataOffice officeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
    return this;
  }

  /**
   * Get officeBrokerKey
   * @return officeBrokerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeBrokerKey() {
    return officeBrokerKey;
  }

  public void setOfficeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
  }

  public OrgResoMetadataOffice officeBrokerKeyNumeric(AnyOforgResoMetadataOfficeOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
    return this;
  }

  /**
   * Get officeBrokerKeyNumeric
   * @return officeBrokerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeOfficeBrokerKeyNumeric getOfficeBrokerKeyNumeric() {
    return officeBrokerKeyNumeric;
  }

  public void setOfficeBrokerKeyNumeric(AnyOforgResoMetadataOfficeOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
  }

  public OrgResoMetadataOffice officeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
    return this;
  }

  /**
   * Get officeBrokerMlsId
   * @return officeBrokerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeBrokerMlsId() {
    return officeBrokerMlsId;
  }

  public void setOfficeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
  }

  public OrgResoMetadataOffice officeCity(String officeCity) {
    this.officeCity = officeCity;
    return this;
  }

  /**
   * Get officeCity
   * @return officeCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCity() {
    return officeCity;
  }

  public void setOfficeCity(String officeCity) {
    this.officeCity = officeCity;
  }

  public OrgResoMetadataOffice officeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
    return this;
  }

  /**
   * Get officeCorporateLicense
   * @return officeCorporateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCorporateLicense() {
    return officeCorporateLicense;
  }

  public void setOfficeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
  }

  public OrgResoMetadataOffice officeCountyOrParish(AnyOforgResoMetadataOfficeOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
    return this;
  }

  /**
   * Get officeCountyOrParish
   * @return officeCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeCountyOrParish getOfficeCountyOrParish() {
    return officeCountyOrParish;
  }

  public void setOfficeCountyOrParish(AnyOforgResoMetadataOfficeOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
  }

  public OrgResoMetadataOffice officeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
    return this;
  }

  /**
   * Get officeEmail
   * @return officeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getOfficeEmail() {
    return officeEmail;
  }

  public void setOfficeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
  }

  public OrgResoMetadataOffice officeFax(String officeFax) {
    this.officeFax = officeFax;
    return this;
  }

  /**
   * Get officeFax
   * @return officeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficeFax() {
    return officeFax;
  }

  public void setOfficeFax(String officeFax) {
    this.officeFax = officeFax;
  }

  public OrgResoMetadataOffice officeKey(String officeKey) {
    this.officeKey = officeKey;
    return this;
  }

  /**
   * Get officeKey
   * @return officeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeKey() {
    return officeKey;
  }

  public void setOfficeKey(String officeKey) {
    this.officeKey = officeKey;
  }

  public OrgResoMetadataOffice officeKeyNumeric(AnyOforgResoMetadataOfficeOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
    return this;
  }

  /**
   * Get officeKeyNumeric
   * @return officeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeOfficeKeyNumeric getOfficeKeyNumeric() {
    return officeKeyNumeric;
  }

  public void setOfficeKeyNumeric(AnyOforgResoMetadataOfficeOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
  }

  public OrgResoMetadataOffice officeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
    return this;
  }

  /**
   * Get officeManagerKey
   * @return officeManagerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeManagerKey() {
    return officeManagerKey;
  }

  public void setOfficeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
  }

  public OrgResoMetadataOffice officeManagerKeyNumeric(AnyOforgResoMetadataOfficeOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
    return this;
  }

  /**
   * Get officeManagerKeyNumeric
   * @return officeManagerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeOfficeManagerKeyNumeric getOfficeManagerKeyNumeric() {
    return officeManagerKeyNumeric;
  }

  public void setOfficeManagerKeyNumeric(AnyOforgResoMetadataOfficeOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
  }

  public OrgResoMetadataOffice officeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
    return this;
  }

  /**
   * Get officeManagerMlsId
   * @return officeManagerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeManagerMlsId() {
    return officeManagerMlsId;
  }

  public void setOfficeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
  }

  public OrgResoMetadataOffice officeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
    return this;
  }

  /**
   * Get officeMlsId
   * @return officeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeMlsId() {
    return officeMlsId;
  }

  public void setOfficeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
  }

  public OrgResoMetadataOffice officeName(String officeName) {
    this.officeName = officeName;
    return this;
  }

  /**
   * Get officeName
   * @return officeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeName() {
    return officeName;
  }

  public void setOfficeName(String officeName) {
    this.officeName = officeName;
  }

  public OrgResoMetadataOffice officeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
    return this;
  }

  /**
   * Get officeNationalAssociationId
   * @return officeNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeNationalAssociationId() {
    return officeNationalAssociationId;
  }

  public void setOfficeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
  }

  public OrgResoMetadataOffice officePhone(String officePhone) {
    this.officePhone = officePhone;
    return this;
  }

  /**
   * Get officePhone
   * @return officePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficePhone() {
    return officePhone;
  }

  public void setOfficePhone(String officePhone) {
    this.officePhone = officePhone;
  }

  public OrgResoMetadataOffice officePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
    return this;
  }

  /**
   * Get officePhoneExt
   * @return officePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePhoneExt() {
    return officePhoneExt;
  }

  public void setOfficePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
  }

  public OrgResoMetadataOffice officePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
    return this;
  }

  /**
   * Get officePostalCode
   * @return officePostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePostalCode() {
    return officePostalCode;
  }

  public void setOfficePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
  }

  public OrgResoMetadataOffice officePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
    return this;
  }

  /**
   * Get officePostalCodePlus4
   * @return officePostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getOfficePostalCodePlus4() {
    return officePostalCodePlus4;
  }

  public void setOfficePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
  }

  public OrgResoMetadataOffice officeStateOrProvince(AnyOforgResoMetadataOfficeOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
    return this;
  }

  /**
   * Get officeStateOrProvince
   * @return officeStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeStateOrProvince getOfficeStateOrProvince() {
    return officeStateOrProvince;
  }

  public void setOfficeStateOrProvince(AnyOforgResoMetadataOfficeOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
  }

  public OrgResoMetadataOffice officeStatus(AnyOforgResoMetadataOfficeOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
    return this;
  }

  /**
   * Get officeStatus
   * @return officeStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeStatus getOfficeStatus() {
    return officeStatus;
  }

  public void setOfficeStatus(AnyOforgResoMetadataOfficeOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
  }

  public OrgResoMetadataOffice officeType(AnyOforgResoMetadataOfficeOfficeType officeType) {
    this.officeType = officeType;
    return this;
  }

  /**
   * Get officeType
   * @return officeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeType getOfficeType() {
    return officeType;
  }

  public void setOfficeType(AnyOforgResoMetadataOfficeOfficeType officeType) {
    this.officeType = officeType;
  }

  public OrgResoMetadataOffice originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataOffice originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataOffice originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataOffice originatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
    return this;
  }

  /**
   * Get originatingSystemOfficeKey
   * @return originatingSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemOfficeKey() {
    return originatingSystemOfficeKey;
  }

  public void setOriginatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
  }

  public OrgResoMetadataOffice socialMediaType(AnyOforgResoMetadataOfficeSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
    return this;
  }

  /**
   * Get socialMediaType
   * @return socialMediaType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeSocialMediaType getSocialMediaType() {
    return socialMediaType;
  }

  public void setSocialMediaType(AnyOforgResoMetadataOfficeSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
  }

  public OrgResoMetadataOffice sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataOffice sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataOffice sourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
    return this;
  }

  /**
   * Get sourceSystemOfficeKey
   * @return sourceSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemOfficeKey() {
    return sourceSystemOfficeKey;
  }

  public void setSourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
  }

  public OrgResoMetadataOffice syndicateAgentOption(AnyOforgResoMetadataOfficeSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
    return this;
  }

  /**
   * Get syndicateAgentOption
   * @return syndicateAgentOption
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeSyndicateAgentOption getSyndicateAgentOption() {
    return syndicateAgentOption;
  }

  public void setSyndicateAgentOption(AnyOforgResoMetadataOfficeSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
  }

  public OrgResoMetadataOffice syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataOffice addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }

  public OrgResoMetadataOffice mainOffice(AnyOforgResoMetadataOfficeMainOffice mainOffice) {
    this.mainOffice = mainOffice;
    return this;
  }

  /**
   * Get mainOffice
   * @return mainOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeMainOffice getMainOffice() {
    return mainOffice;
  }

  public void setMainOffice(AnyOforgResoMetadataOfficeMainOffice mainOffice) {
    this.mainOffice = mainOffice;
  }

  public OrgResoMetadataOffice officeBroker(AnyOforgResoMetadataOfficeOfficeBroker officeBroker) {
    this.officeBroker = officeBroker;
    return this;
  }

  /**
   * Get officeBroker
   * @return officeBroker
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeBroker getOfficeBroker() {
    return officeBroker;
  }

  public void setOfficeBroker(AnyOforgResoMetadataOfficeOfficeBroker officeBroker) {
    this.officeBroker = officeBroker;
  }

  public OrgResoMetadataOffice officeManager(AnyOforgResoMetadataOfficeOfficeManager officeManager) {
    this.officeManager = officeManager;
    return this;
  }

  /**
   * Get officeManager
   * @return officeManager
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOfficeManager getOfficeManager() {
    return officeManager;
  }

  public void setOfficeManager(AnyOforgResoMetadataOfficeOfficeManager officeManager) {
    this.officeManager = officeManager;
  }

  public OrgResoMetadataOffice originatingSystem(AnyOforgResoMetadataOfficeOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataOfficeOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataOffice sourceSystem(AnyOforgResoMetadataOfficeSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataOfficeSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataOffice historyTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataOffice addHistoryTransactionalItem(OrgResoMetadataHistoryTransactional historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactional>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactional> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataOffice historyTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
    return this;
  }

  /**
   * Get historyTransactionalAtOdataCount
   * @return historyTransactionalAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getHistoryTransactionalAtOdataCount() {
    return historyTransactionalAtOdataCount;
  }

  public void setHistoryTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
  }

  public OrgResoMetadataOffice media(List<OrgResoMetadataMedia> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataOffice addMediaItem(OrgResoMetadataMedia mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMedia>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMedia> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMedia> media) {
    this.media = media;
  }

  public OrgResoMetadataOffice mediaAtOdataCount(Count mediaAtOdataCount) {
    this.mediaAtOdataCount = mediaAtOdataCount;
    return this;
  }

  /**
   * Get mediaAtOdataCount
   * @return mediaAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getMediaAtOdataCount() {
    return mediaAtOdataCount;
  }

  public void setMediaAtOdataCount(Count mediaAtOdataCount) {
    this.mediaAtOdataCount = mediaAtOdataCount;
  }

  public OrgResoMetadataOffice socialMedia(List<OrgResoMetadataSocialMedia> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataOffice addSocialMediaItem(OrgResoMetadataSocialMedia socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMedia>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMedia> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMedia> socialMedia) {
    this.socialMedia = socialMedia;
  }

  public OrgResoMetadataOffice socialMediaAtOdataCount(Count socialMediaAtOdataCount) {
    this.socialMediaAtOdataCount = socialMediaAtOdataCount;
    return this;
  }

  /**
   * Get socialMediaAtOdataCount
   * @return socialMediaAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getSocialMediaAtOdataCount() {
    return socialMediaAtOdataCount;
  }

  public void setSocialMediaAtOdataCount(Count socialMediaAtOdataCount) {
    this.socialMediaAtOdataCount = socialMediaAtOdataCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOffice orgResoMetadataOffice = (OrgResoMetadataOffice) o;
    return Objects.equals(this.franchiseAffiliation, orgResoMetadataOffice.franchiseAffiliation) &&
        Objects.equals(this.idXOfficeParticipationYN, orgResoMetadataOffice.idXOfficeParticipationYN) &&
        Objects.equals(this.mainOfficeKey, orgResoMetadataOffice.mainOfficeKey) &&
        Objects.equals(this.mainOfficeKeyNumeric, orgResoMetadataOffice.mainOfficeKeyNumeric) &&
        Objects.equals(this.mainOfficeMlsId, orgResoMetadataOffice.mainOfficeMlsId) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOffice.modificationTimestamp) &&
        Objects.equals(this.officeAOR, orgResoMetadataOffice.officeAOR) &&
        Objects.equals(this.officeAORMlsId, orgResoMetadataOffice.officeAORMlsId) &&
        Objects.equals(this.officeAORkey, orgResoMetadataOffice.officeAORkey) &&
        Objects.equals(this.officeAORkeyNumeric, orgResoMetadataOffice.officeAORkeyNumeric) &&
        Objects.equals(this.officeAddress1, orgResoMetadataOffice.officeAddress1) &&
        Objects.equals(this.officeAddress2, orgResoMetadataOffice.officeAddress2) &&
        Objects.equals(this.officeAssociationComments, orgResoMetadataOffice.officeAssociationComments) &&
        Objects.equals(this.officeBranchType, orgResoMetadataOffice.officeBranchType) &&
        Objects.equals(this.officeBrokerKey, orgResoMetadataOffice.officeBrokerKey) &&
        Objects.equals(this.officeBrokerKeyNumeric, orgResoMetadataOffice.officeBrokerKeyNumeric) &&
        Objects.equals(this.officeBrokerMlsId, orgResoMetadataOffice.officeBrokerMlsId) &&
        Objects.equals(this.officeCity, orgResoMetadataOffice.officeCity) &&
        Objects.equals(this.officeCorporateLicense, orgResoMetadataOffice.officeCorporateLicense) &&
        Objects.equals(this.officeCountyOrParish, orgResoMetadataOffice.officeCountyOrParish) &&
        Objects.equals(this.officeEmail, orgResoMetadataOffice.officeEmail) &&
        Objects.equals(this.officeFax, orgResoMetadataOffice.officeFax) &&
        Objects.equals(this.officeKey, orgResoMetadataOffice.officeKey) &&
        Objects.equals(this.officeKeyNumeric, orgResoMetadataOffice.officeKeyNumeric) &&
        Objects.equals(this.officeManagerKey, orgResoMetadataOffice.officeManagerKey) &&
        Objects.equals(this.officeManagerKeyNumeric, orgResoMetadataOffice.officeManagerKeyNumeric) &&
        Objects.equals(this.officeManagerMlsId, orgResoMetadataOffice.officeManagerMlsId) &&
        Objects.equals(this.officeMlsId, orgResoMetadataOffice.officeMlsId) &&
        Objects.equals(this.officeName, orgResoMetadataOffice.officeName) &&
        Objects.equals(this.officeNationalAssociationId, orgResoMetadataOffice.officeNationalAssociationId) &&
        Objects.equals(this.officePhone, orgResoMetadataOffice.officePhone) &&
        Objects.equals(this.officePhoneExt, orgResoMetadataOffice.officePhoneExt) &&
        Objects.equals(this.officePostalCode, orgResoMetadataOffice.officePostalCode) &&
        Objects.equals(this.officePostalCodePlus4, orgResoMetadataOffice.officePostalCodePlus4) &&
        Objects.equals(this.officeStateOrProvince, orgResoMetadataOffice.officeStateOrProvince) &&
        Objects.equals(this.officeStatus, orgResoMetadataOffice.officeStatus) &&
        Objects.equals(this.officeType, orgResoMetadataOffice.officeType) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataOffice.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataOffice.originatingSystemID) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataOffice.originatingSystemName) &&
        Objects.equals(this.originatingSystemOfficeKey, orgResoMetadataOffice.originatingSystemOfficeKey) &&
        Objects.equals(this.socialMediaType, orgResoMetadataOffice.socialMediaType) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataOffice.sourceSystemID) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataOffice.sourceSystemName) &&
        Objects.equals(this.sourceSystemOfficeKey, orgResoMetadataOffice.sourceSystemOfficeKey) &&
        Objects.equals(this.syndicateAgentOption, orgResoMetadataOffice.syndicateAgentOption) &&
        Objects.equals(this.syndicateTo, orgResoMetadataOffice.syndicateTo) &&
        Objects.equals(this.mainOffice, orgResoMetadataOffice.mainOffice) &&
        Objects.equals(this.officeBroker, orgResoMetadataOffice.officeBroker) &&
        Objects.equals(this.officeManager, orgResoMetadataOffice.officeManager) &&
        Objects.equals(this.originatingSystem, orgResoMetadataOffice.originatingSystem) &&
        Objects.equals(this.sourceSystem, orgResoMetadataOffice.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataOffice.historyTransactional) &&
        Objects.equals(this.historyTransactionalAtOdataCount, orgResoMetadataOffice.historyTransactionalAtOdataCount) &&
        Objects.equals(this.media, orgResoMetadataOffice.media) &&
        Objects.equals(this.mediaAtOdataCount, orgResoMetadataOffice.mediaAtOdataCount) &&
        Objects.equals(this.socialMedia, orgResoMetadataOffice.socialMedia) &&
        Objects.equals(this.socialMediaAtOdataCount, orgResoMetadataOffice.socialMediaAtOdataCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(franchiseAffiliation, idXOfficeParticipationYN, mainOfficeKey, mainOfficeKeyNumeric, mainOfficeMlsId, modificationTimestamp, officeAOR, officeAORMlsId, officeAORkey, officeAORkeyNumeric, officeAddress1, officeAddress2, officeAssociationComments, officeBranchType, officeBrokerKey, officeBrokerKeyNumeric, officeBrokerMlsId, officeCity, officeCorporateLicense, officeCountyOrParish, officeEmail, officeFax, officeKey, officeKeyNumeric, officeManagerKey, officeManagerKeyNumeric, officeManagerMlsId, officeMlsId, officeName, officeNationalAssociationId, officePhone, officePhoneExt, officePostalCode, officePostalCodePlus4, officeStateOrProvince, officeStatus, officeType, originalEntryTimestamp, originatingSystemID, originatingSystemName, originatingSystemOfficeKey, socialMediaType, sourceSystemID, sourceSystemName, sourceSystemOfficeKey, syndicateAgentOption, syndicateTo, mainOffice, officeBroker, officeManager, originatingSystem, sourceSystem, historyTransactional, historyTransactionalAtOdataCount, media, mediaAtOdataCount, socialMedia, socialMediaAtOdataCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOffice {\n");
    
    sb.append("    franchiseAffiliation: ").append(toIndentedString(franchiseAffiliation)).append("\n");
    sb.append("    idXOfficeParticipationYN: ").append(toIndentedString(idXOfficeParticipationYN)).append("\n");
    sb.append("    mainOfficeKey: ").append(toIndentedString(mainOfficeKey)).append("\n");
    sb.append("    mainOfficeKeyNumeric: ").append(toIndentedString(mainOfficeKeyNumeric)).append("\n");
    sb.append("    mainOfficeMlsId: ").append(toIndentedString(mainOfficeMlsId)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    officeAOR: ").append(toIndentedString(officeAOR)).append("\n");
    sb.append("    officeAORMlsId: ").append(toIndentedString(officeAORMlsId)).append("\n");
    sb.append("    officeAORkey: ").append(toIndentedString(officeAORkey)).append("\n");
    sb.append("    officeAORkeyNumeric: ").append(toIndentedString(officeAORkeyNumeric)).append("\n");
    sb.append("    officeAddress1: ").append(toIndentedString(officeAddress1)).append("\n");
    sb.append("    officeAddress2: ").append(toIndentedString(officeAddress2)).append("\n");
    sb.append("    officeAssociationComments: ").append(toIndentedString(officeAssociationComments)).append("\n");
    sb.append("    officeBranchType: ").append(toIndentedString(officeBranchType)).append("\n");
    sb.append("    officeBrokerKey: ").append(toIndentedString(officeBrokerKey)).append("\n");
    sb.append("    officeBrokerKeyNumeric: ").append(toIndentedString(officeBrokerKeyNumeric)).append("\n");
    sb.append("    officeBrokerMlsId: ").append(toIndentedString(officeBrokerMlsId)).append("\n");
    sb.append("    officeCity: ").append(toIndentedString(officeCity)).append("\n");
    sb.append("    officeCorporateLicense: ").append(toIndentedString(officeCorporateLicense)).append("\n");
    sb.append("    officeCountyOrParish: ").append(toIndentedString(officeCountyOrParish)).append("\n");
    sb.append("    officeEmail: ").append(toIndentedString(officeEmail)).append("\n");
    sb.append("    officeFax: ").append(toIndentedString(officeFax)).append("\n");
    sb.append("    officeKey: ").append(toIndentedString(officeKey)).append("\n");
    sb.append("    officeKeyNumeric: ").append(toIndentedString(officeKeyNumeric)).append("\n");
    sb.append("    officeManagerKey: ").append(toIndentedString(officeManagerKey)).append("\n");
    sb.append("    officeManagerKeyNumeric: ").append(toIndentedString(officeManagerKeyNumeric)).append("\n");
    sb.append("    officeManagerMlsId: ").append(toIndentedString(officeManagerMlsId)).append("\n");
    sb.append("    officeMlsId: ").append(toIndentedString(officeMlsId)).append("\n");
    sb.append("    officeName: ").append(toIndentedString(officeName)).append("\n");
    sb.append("    officeNationalAssociationId: ").append(toIndentedString(officeNationalAssociationId)).append("\n");
    sb.append("    officePhone: ").append(toIndentedString(officePhone)).append("\n");
    sb.append("    officePhoneExt: ").append(toIndentedString(officePhoneExt)).append("\n");
    sb.append("    officePostalCode: ").append(toIndentedString(officePostalCode)).append("\n");
    sb.append("    officePostalCodePlus4: ").append(toIndentedString(officePostalCodePlus4)).append("\n");
    sb.append("    officeStateOrProvince: ").append(toIndentedString(officeStateOrProvince)).append("\n");
    sb.append("    officeStatus: ").append(toIndentedString(officeStatus)).append("\n");
    sb.append("    officeType: ").append(toIndentedString(officeType)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    originatingSystemOfficeKey: ").append(toIndentedString(originatingSystemOfficeKey)).append("\n");
    sb.append("    socialMediaType: ").append(toIndentedString(socialMediaType)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    sourceSystemOfficeKey: ").append(toIndentedString(sourceSystemOfficeKey)).append("\n");
    sb.append("    syndicateAgentOption: ").append(toIndentedString(syndicateAgentOption)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("    mainOffice: ").append(toIndentedString(mainOffice)).append("\n");
    sb.append("    officeBroker: ").append(toIndentedString(officeBroker)).append("\n");
    sb.append("    officeManager: ").append(toIndentedString(officeManager)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    historyTransactionalAtOdataCount: ").append(toIndentedString(historyTransactionalAtOdataCount)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    mediaAtOdataCount: ").append(toIndentedString(mediaAtOdataCount)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("    socialMediaAtOdataCount: ").append(toIndentedString(socialMediaAtOdataCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
