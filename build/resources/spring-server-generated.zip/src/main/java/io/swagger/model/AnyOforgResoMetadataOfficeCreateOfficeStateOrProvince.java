package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince
*/
public interface AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince {

}
