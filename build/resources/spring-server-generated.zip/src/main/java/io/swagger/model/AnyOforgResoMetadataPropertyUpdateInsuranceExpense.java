package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateInsuranceExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateInsuranceExpense {

}
