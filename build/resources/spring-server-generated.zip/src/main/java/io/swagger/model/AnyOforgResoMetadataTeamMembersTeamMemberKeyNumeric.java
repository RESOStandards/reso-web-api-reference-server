package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric
*/
public interface AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric {

}
