package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToBusUnits {

}
