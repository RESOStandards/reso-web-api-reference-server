package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOpenHouseUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOpenHouseUpdate   {
  @JsonProperty("AppointmentRequiredYN")
  private Boolean appointmentRequiredYN = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataOpenHouseUpdateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OpenHouseAttendedBy")
  private AnyOforgResoMetadataOpenHouseUpdateOpenHouseAttendedBy openHouseAttendedBy = null;

  @JsonProperty("OpenHouseDate")
  private LocalDate openHouseDate = null;

  @JsonProperty("OpenHouseEndTime")
  private OffsetDateTime openHouseEndTime = null;

  @JsonProperty("OpenHouseId")
  private String openHouseId = null;

  @JsonProperty("OpenHouseKeyNumeric")
  private AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric openHouseKeyNumeric = null;

  @JsonProperty("OpenHouseRemarks")
  private String openHouseRemarks = null;

  @JsonProperty("OpenHouseStartTime")
  private OffsetDateTime openHouseStartTime = null;

  @JsonProperty("OpenHouseStatus")
  private AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus openHouseStatus = null;

  @JsonProperty("OpenHouseType")
  private AnyOforgResoMetadataOpenHouseUpdateOpenHouseType openHouseType = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("Refreshments")
  private String refreshments = null;

  @JsonProperty("ShowingAgentFirstName")
  private String showingAgentFirstName = null;

  @JsonProperty("ShowingAgentKey")
  private String showingAgentKey = null;

  @JsonProperty("ShowingAgentKeyNumeric")
  private AnyOforgResoMetadataOpenHouseUpdateShowingAgentKeyNumeric showingAgentKeyNumeric = null;

  @JsonProperty("ShowingAgentLastName")
  private String showingAgentLastName = null;

  @JsonProperty("ShowingAgentMlsID")
  private String showingAgentMlsID = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  public OrgResoMetadataOpenHouseUpdate appointmentRequiredYN(Boolean appointmentRequiredYN) {
    this.appointmentRequiredYN = appointmentRequiredYN;
    return this;
  }

  /**
   * Get appointmentRequiredYN
   * @return appointmentRequiredYN
   **/
  @Schema(description = "")
  
    public Boolean isAppointmentRequiredYN() {
    return appointmentRequiredYN;
  }

  public void setAppointmentRequiredYN(Boolean appointmentRequiredYN) {
    this.appointmentRequiredYN = appointmentRequiredYN;
  }

  public OrgResoMetadataOpenHouseUpdate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataOpenHouseUpdate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataOpenHouseUpdate listingKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataOpenHouseUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseAttendedBy(AnyOforgResoMetadataOpenHouseUpdateOpenHouseAttendedBy openHouseAttendedBy) {
    this.openHouseAttendedBy = openHouseAttendedBy;
    return this;
  }

  /**
   * Get openHouseAttendedBy
   * @return openHouseAttendedBy
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateOpenHouseAttendedBy getOpenHouseAttendedBy() {
    return openHouseAttendedBy;
  }

  public void setOpenHouseAttendedBy(AnyOforgResoMetadataOpenHouseUpdateOpenHouseAttendedBy openHouseAttendedBy) {
    this.openHouseAttendedBy = openHouseAttendedBy;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseDate(LocalDate openHouseDate) {
    this.openHouseDate = openHouseDate;
    return this;
  }

  /**
   * Get openHouseDate
   * @return openHouseDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOpenHouseDate() {
    return openHouseDate;
  }

  public void setOpenHouseDate(LocalDate openHouseDate) {
    this.openHouseDate = openHouseDate;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseEndTime(OffsetDateTime openHouseEndTime) {
    this.openHouseEndTime = openHouseEndTime;
    return this;
  }

  /**
   * Get openHouseEndTime
   * @return openHouseEndTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOpenHouseEndTime() {
    return openHouseEndTime;
  }

  public void setOpenHouseEndTime(OffsetDateTime openHouseEndTime) {
    this.openHouseEndTime = openHouseEndTime;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseId(String openHouseId) {
    this.openHouseId = openHouseId;
    return this;
  }

  /**
   * Get openHouseId
   * @return openHouseId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOpenHouseId() {
    return openHouseId;
  }

  public void setOpenHouseId(String openHouseId) {
    this.openHouseId = openHouseId;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric openHouseKeyNumeric) {
    this.openHouseKeyNumeric = openHouseKeyNumeric;
    return this;
  }

  /**
   * Get openHouseKeyNumeric
   * @return openHouseKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric getOpenHouseKeyNumeric() {
    return openHouseKeyNumeric;
  }

  public void setOpenHouseKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric openHouseKeyNumeric) {
    this.openHouseKeyNumeric = openHouseKeyNumeric;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseRemarks(String openHouseRemarks) {
    this.openHouseRemarks = openHouseRemarks;
    return this;
  }

  /**
   * Get openHouseRemarks
   * @return openHouseRemarks
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getOpenHouseRemarks() {
    return openHouseRemarks;
  }

  public void setOpenHouseRemarks(String openHouseRemarks) {
    this.openHouseRemarks = openHouseRemarks;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseStartTime(OffsetDateTime openHouseStartTime) {
    this.openHouseStartTime = openHouseStartTime;
    return this;
  }

  /**
   * Get openHouseStartTime
   * @return openHouseStartTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOpenHouseStartTime() {
    return openHouseStartTime;
  }

  public void setOpenHouseStartTime(OffsetDateTime openHouseStartTime) {
    this.openHouseStartTime = openHouseStartTime;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseStatus(AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus openHouseStatus) {
    this.openHouseStatus = openHouseStatus;
    return this;
  }

  /**
   * Get openHouseStatus
   * @return openHouseStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus getOpenHouseStatus() {
    return openHouseStatus;
  }

  public void setOpenHouseStatus(AnyOforgResoMetadataOpenHouseUpdateOpenHouseStatus openHouseStatus) {
    this.openHouseStatus = openHouseStatus;
  }

  public OrgResoMetadataOpenHouseUpdate openHouseType(AnyOforgResoMetadataOpenHouseUpdateOpenHouseType openHouseType) {
    this.openHouseType = openHouseType;
    return this;
  }

  /**
   * Get openHouseType
   * @return openHouseType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateOpenHouseType getOpenHouseType() {
    return openHouseType;
  }

  public void setOpenHouseType(AnyOforgResoMetadataOpenHouseUpdateOpenHouseType openHouseType) {
    this.openHouseType = openHouseType;
  }

  public OrgResoMetadataOpenHouseUpdate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataOpenHouseUpdate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataOpenHouseUpdate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataOpenHouseUpdate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataOpenHouseUpdate refreshments(String refreshments) {
    this.refreshments = refreshments;
    return this;
  }

  /**
   * Get refreshments
   * @return refreshments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getRefreshments() {
    return refreshments;
  }

  public void setRefreshments(String refreshments) {
    this.refreshments = refreshments;
  }

  public OrgResoMetadataOpenHouseUpdate showingAgentFirstName(String showingAgentFirstName) {
    this.showingAgentFirstName = showingAgentFirstName;
    return this;
  }

  /**
   * Get showingAgentFirstName
   * @return showingAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getShowingAgentFirstName() {
    return showingAgentFirstName;
  }

  public void setShowingAgentFirstName(String showingAgentFirstName) {
    this.showingAgentFirstName = showingAgentFirstName;
  }

  public OrgResoMetadataOpenHouseUpdate showingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
    return this;
  }

  /**
   * Get showingAgentKey
   * @return showingAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingAgentKey() {
    return showingAgentKey;
  }

  public void setShowingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
  }

  public OrgResoMetadataOpenHouseUpdate showingAgentKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
    return this;
  }

  /**
   * Get showingAgentKeyNumeric
   * @return showingAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOpenHouseUpdateShowingAgentKeyNumeric getShowingAgentKeyNumeric() {
    return showingAgentKeyNumeric;
  }

  public void setShowingAgentKeyNumeric(AnyOforgResoMetadataOpenHouseUpdateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
  }

  public OrgResoMetadataOpenHouseUpdate showingAgentLastName(String showingAgentLastName) {
    this.showingAgentLastName = showingAgentLastName;
    return this;
  }

  /**
   * Get showingAgentLastName
   * @return showingAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getShowingAgentLastName() {
    return showingAgentLastName;
  }

  public void setShowingAgentLastName(String showingAgentLastName) {
    this.showingAgentLastName = showingAgentLastName;
  }

  public OrgResoMetadataOpenHouseUpdate showingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
    return this;
  }

  /**
   * Get showingAgentMlsID
   * @return showingAgentMlsID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getShowingAgentMlsID() {
    return showingAgentMlsID;
  }

  public void setShowingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
  }

  public OrgResoMetadataOpenHouseUpdate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataOpenHouseUpdate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataOpenHouseUpdate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOpenHouseUpdate orgResoMetadataOpenHouseUpdate = (OrgResoMetadataOpenHouseUpdate) o;
    return Objects.equals(this.appointmentRequiredYN, orgResoMetadataOpenHouseUpdate.appointmentRequiredYN) &&
        Objects.equals(this.listingId, orgResoMetadataOpenHouseUpdate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataOpenHouseUpdate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataOpenHouseUpdate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOpenHouseUpdate.modificationTimestamp) &&
        Objects.equals(this.openHouseAttendedBy, orgResoMetadataOpenHouseUpdate.openHouseAttendedBy) &&
        Objects.equals(this.openHouseDate, orgResoMetadataOpenHouseUpdate.openHouseDate) &&
        Objects.equals(this.openHouseEndTime, orgResoMetadataOpenHouseUpdate.openHouseEndTime) &&
        Objects.equals(this.openHouseId, orgResoMetadataOpenHouseUpdate.openHouseId) &&
        Objects.equals(this.openHouseKeyNumeric, orgResoMetadataOpenHouseUpdate.openHouseKeyNumeric) &&
        Objects.equals(this.openHouseRemarks, orgResoMetadataOpenHouseUpdate.openHouseRemarks) &&
        Objects.equals(this.openHouseStartTime, orgResoMetadataOpenHouseUpdate.openHouseStartTime) &&
        Objects.equals(this.openHouseStatus, orgResoMetadataOpenHouseUpdate.openHouseStatus) &&
        Objects.equals(this.openHouseType, orgResoMetadataOpenHouseUpdate.openHouseType) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataOpenHouseUpdate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataOpenHouseUpdate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataOpenHouseUpdate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataOpenHouseUpdate.originatingSystemName) &&
        Objects.equals(this.refreshments, orgResoMetadataOpenHouseUpdate.refreshments) &&
        Objects.equals(this.showingAgentFirstName, orgResoMetadataOpenHouseUpdate.showingAgentFirstName) &&
        Objects.equals(this.showingAgentKey, orgResoMetadataOpenHouseUpdate.showingAgentKey) &&
        Objects.equals(this.showingAgentKeyNumeric, orgResoMetadataOpenHouseUpdate.showingAgentKeyNumeric) &&
        Objects.equals(this.showingAgentLastName, orgResoMetadataOpenHouseUpdate.showingAgentLastName) &&
        Objects.equals(this.showingAgentMlsID, orgResoMetadataOpenHouseUpdate.showingAgentMlsID) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataOpenHouseUpdate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataOpenHouseUpdate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataOpenHouseUpdate.sourceSystemName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentRequiredYN, listingId, listingKey, listingKeyNumeric, modificationTimestamp, openHouseAttendedBy, openHouseDate, openHouseEndTime, openHouseId, openHouseKeyNumeric, openHouseRemarks, openHouseStartTime, openHouseStatus, openHouseType, originalEntryTimestamp, originatingSystemID, originatingSystemKey, originatingSystemName, refreshments, showingAgentFirstName, showingAgentKey, showingAgentKeyNumeric, showingAgentLastName, showingAgentMlsID, sourceSystemID, sourceSystemKey, sourceSystemName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOpenHouseUpdate {\n");
    
    sb.append("    appointmentRequiredYN: ").append(toIndentedString(appointmentRequiredYN)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    openHouseAttendedBy: ").append(toIndentedString(openHouseAttendedBy)).append("\n");
    sb.append("    openHouseDate: ").append(toIndentedString(openHouseDate)).append("\n");
    sb.append("    openHouseEndTime: ").append(toIndentedString(openHouseEndTime)).append("\n");
    sb.append("    openHouseId: ").append(toIndentedString(openHouseId)).append("\n");
    sb.append("    openHouseKeyNumeric: ").append(toIndentedString(openHouseKeyNumeric)).append("\n");
    sb.append("    openHouseRemarks: ").append(toIndentedString(openHouseRemarks)).append("\n");
    sb.append("    openHouseStartTime: ").append(toIndentedString(openHouseStartTime)).append("\n");
    sb.append("    openHouseStatus: ").append(toIndentedString(openHouseStatus)).append("\n");
    sb.append("    openHouseType: ").append(toIndentedString(openHouseType)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    refreshments: ").append(toIndentedString(refreshments)).append("\n");
    sb.append("    showingAgentFirstName: ").append(toIndentedString(showingAgentFirstName)).append("\n");
    sb.append("    showingAgentKey: ").append(toIndentedString(showingAgentKey)).append("\n");
    sb.append("    showingAgentKeyNumeric: ").append(toIndentedString(showingAgentKeyNumeric)).append("\n");
    sb.append("    showingAgentLastName: ").append(toIndentedString(showingAgentLastName)).append("\n");
    sb.append("    showingAgentMlsID: ").append(toIndentedString(showingAgentMlsID)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
