package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationUniqueIdKeyNumeric
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationUniqueIdKeyNumeric {

}
