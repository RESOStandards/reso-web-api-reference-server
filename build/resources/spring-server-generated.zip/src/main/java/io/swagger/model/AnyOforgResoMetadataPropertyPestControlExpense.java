package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPestControlExpense
*/
public interface AnyOforgResoMetadataPropertyPestControlExpense {

}
