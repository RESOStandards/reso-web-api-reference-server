package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyRoomsListingKeyNumeric {

}
