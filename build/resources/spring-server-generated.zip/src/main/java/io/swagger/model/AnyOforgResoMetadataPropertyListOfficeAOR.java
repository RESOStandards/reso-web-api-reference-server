package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListOfficeAOR
*/
public interface AnyOforgResoMetadataPropertyListOfficeAOR {

}
