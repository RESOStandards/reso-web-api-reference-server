package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger
*/
public interface AnyOforgResoMetadataPropertyUpdateBathroomsTotalInteger {

}
