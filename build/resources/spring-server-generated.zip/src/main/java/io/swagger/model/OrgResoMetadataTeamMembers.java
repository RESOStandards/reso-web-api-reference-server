package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Count;
import io.swagger.model.OrgResoMetadataHistoryTransactional;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataTeamMembers
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataTeamMembers   {
  @JsonProperty("MemberKey")
  private String memberKey = null;

  @JsonProperty("MemberKeyNumeric")
  private AnyOforgResoMetadataTeamMembersMemberKeyNumeric memberKeyNumeric = null;

  @JsonProperty("MemberLoginId")
  private String memberLoginId = null;

  @JsonProperty("MemberMlsId")
  private String memberMlsId = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("TeamImpersonationLevel")
  private AnyOforgResoMetadataTeamMembersTeamImpersonationLevel teamImpersonationLevel = null;

  @JsonProperty("TeamKey")
  private String teamKey = null;

  @JsonProperty("TeamKeyNumeric")
  private AnyOforgResoMetadataTeamMembersTeamKeyNumeric teamKeyNumeric = null;

  @JsonProperty("TeamMemberKey")
  private String teamMemberKey = null;

  @JsonProperty("TeamMemberKeyNumeric")
  private AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric teamMemberKeyNumeric = null;

  @JsonProperty("TeamMemberNationalAssociationId")
  private String teamMemberNationalAssociationId = null;

  @JsonProperty("TeamMemberStateLicense")
  private String teamMemberStateLicense = null;

  @JsonProperty("TeamMemberType")
  private AnyOforgResoMetadataTeamMembersTeamMemberType teamMemberType = null;

  @JsonProperty("Member")
  private AnyOforgResoMetadataTeamMembersMember member = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataTeamMembersOriginatingSystem originatingSystem = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataTeamMembersSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactional> historyTransactional = null;

  @JsonProperty("HistoryTransactional@odata.count")
  private Count historyTransactionalAtOdataCount = null;

  public OrgResoMetadataTeamMembers memberKey(String memberKey) {
    this.memberKey = memberKey;
    return this;
  }

  /**
   * Get memberKey
   * @return memberKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getMemberKey() {
    return memberKey;
  }

  public void setMemberKey(String memberKey) {
    this.memberKey = memberKey;
  }

  public OrgResoMetadataTeamMembers memberKeyNumeric(AnyOforgResoMetadataTeamMembersMemberKeyNumeric memberKeyNumeric) {
    this.memberKeyNumeric = memberKeyNumeric;
    return this;
  }

  /**
   * Get memberKeyNumeric
   * @return memberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersMemberKeyNumeric getMemberKeyNumeric() {
    return memberKeyNumeric;
  }

  public void setMemberKeyNumeric(AnyOforgResoMetadataTeamMembersMemberKeyNumeric memberKeyNumeric) {
    this.memberKeyNumeric = memberKeyNumeric;
  }

  public OrgResoMetadataTeamMembers memberLoginId(String memberLoginId) {
    this.memberLoginId = memberLoginId;
    return this;
  }

  /**
   * Get memberLoginId
   * @return memberLoginId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMemberLoginId() {
    return memberLoginId;
  }

  public void setMemberLoginId(String memberLoginId) {
    this.memberLoginId = memberLoginId;
  }

  public OrgResoMetadataTeamMembers memberMlsId(String memberMlsId) {
    this.memberMlsId = memberMlsId;
    return this;
  }

  /**
   * Get memberMlsId
   * @return memberMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMemberMlsId() {
    return memberMlsId;
  }

  public void setMemberMlsId(String memberMlsId) {
    this.memberMlsId = memberMlsId;
  }

  public OrgResoMetadataTeamMembers modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataTeamMembers originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataTeamMembers originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataTeamMembers originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataTeamMembers originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataTeamMembers sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataTeamMembers sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataTeamMembers sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataTeamMembers teamImpersonationLevel(AnyOforgResoMetadataTeamMembersTeamImpersonationLevel teamImpersonationLevel) {
    this.teamImpersonationLevel = teamImpersonationLevel;
    return this;
  }

  /**
   * Get teamImpersonationLevel
   * @return teamImpersonationLevel
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersTeamImpersonationLevel getTeamImpersonationLevel() {
    return teamImpersonationLevel;
  }

  public void setTeamImpersonationLevel(AnyOforgResoMetadataTeamMembersTeamImpersonationLevel teamImpersonationLevel) {
    this.teamImpersonationLevel = teamImpersonationLevel;
  }

  public OrgResoMetadataTeamMembers teamKey(String teamKey) {
    this.teamKey = teamKey;
    return this;
  }

  /**
   * Get teamKey
   * @return teamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTeamKey() {
    return teamKey;
  }

  public void setTeamKey(String teamKey) {
    this.teamKey = teamKey;
  }

  public OrgResoMetadataTeamMembers teamKeyNumeric(AnyOforgResoMetadataTeamMembersTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
    return this;
  }

  /**
   * Get teamKeyNumeric
   * @return teamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersTeamKeyNumeric getTeamKeyNumeric() {
    return teamKeyNumeric;
  }

  public void setTeamKeyNumeric(AnyOforgResoMetadataTeamMembersTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
  }

  public OrgResoMetadataTeamMembers teamMemberKey(String teamMemberKey) {
    this.teamMemberKey = teamMemberKey;
    return this;
  }

  /**
   * Get teamMemberKey
   * @return teamMemberKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTeamMemberKey() {
    return teamMemberKey;
  }

  public void setTeamMemberKey(String teamMemberKey) {
    this.teamMemberKey = teamMemberKey;
  }

  public OrgResoMetadataTeamMembers teamMemberKeyNumeric(AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric teamMemberKeyNumeric) {
    this.teamMemberKeyNumeric = teamMemberKeyNumeric;
    return this;
  }

  /**
   * Get teamMemberKeyNumeric
   * @return teamMemberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric getTeamMemberKeyNumeric() {
    return teamMemberKeyNumeric;
  }

  public void setTeamMemberKeyNumeric(AnyOforgResoMetadataTeamMembersTeamMemberKeyNumeric teamMemberKeyNumeric) {
    this.teamMemberKeyNumeric = teamMemberKeyNumeric;
  }

  public OrgResoMetadataTeamMembers teamMemberNationalAssociationId(String teamMemberNationalAssociationId) {
    this.teamMemberNationalAssociationId = teamMemberNationalAssociationId;
    return this;
  }

  /**
   * Get teamMemberNationalAssociationId
   * @return teamMemberNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTeamMemberNationalAssociationId() {
    return teamMemberNationalAssociationId;
  }

  public void setTeamMemberNationalAssociationId(String teamMemberNationalAssociationId) {
    this.teamMemberNationalAssociationId = teamMemberNationalAssociationId;
  }

  public OrgResoMetadataTeamMembers teamMemberStateLicense(String teamMemberStateLicense) {
    this.teamMemberStateLicense = teamMemberStateLicense;
    return this;
  }

  /**
   * Get teamMemberStateLicense
   * @return teamMemberStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamMemberStateLicense() {
    return teamMemberStateLicense;
  }

  public void setTeamMemberStateLicense(String teamMemberStateLicense) {
    this.teamMemberStateLicense = teamMemberStateLicense;
  }

  public OrgResoMetadataTeamMembers teamMemberType(AnyOforgResoMetadataTeamMembersTeamMemberType teamMemberType) {
    this.teamMemberType = teamMemberType;
    return this;
  }

  /**
   * Get teamMemberType
   * @return teamMemberType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersTeamMemberType getTeamMemberType() {
    return teamMemberType;
  }

  public void setTeamMemberType(AnyOforgResoMetadataTeamMembersTeamMemberType teamMemberType) {
    this.teamMemberType = teamMemberType;
  }

  public OrgResoMetadataTeamMembers member(AnyOforgResoMetadataTeamMembersMember member) {
    this.member = member;
    return this;
  }

  /**
   * Get member
   * @return member
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersMember getMember() {
    return member;
  }

  public void setMember(AnyOforgResoMetadataTeamMembersMember member) {
    this.member = member;
  }

  public OrgResoMetadataTeamMembers originatingSystem(AnyOforgResoMetadataTeamMembersOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataTeamMembersOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataTeamMembers sourceSystem(AnyOforgResoMetadataTeamMembersSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataTeamMembersSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataTeamMembers historyTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataTeamMembers addHistoryTransactionalItem(OrgResoMetadataHistoryTransactional historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactional>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactional> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataTeamMembers historyTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
    return this;
  }

  /**
   * Get historyTransactionalAtOdataCount
   * @return historyTransactionalAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getHistoryTransactionalAtOdataCount() {
    return historyTransactionalAtOdataCount;
  }

  public void setHistoryTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataTeamMembers orgResoMetadataTeamMembers = (OrgResoMetadataTeamMembers) o;
    return Objects.equals(this.memberKey, orgResoMetadataTeamMembers.memberKey) &&
        Objects.equals(this.memberKeyNumeric, orgResoMetadataTeamMembers.memberKeyNumeric) &&
        Objects.equals(this.memberLoginId, orgResoMetadataTeamMembers.memberLoginId) &&
        Objects.equals(this.memberMlsId, orgResoMetadataTeamMembers.memberMlsId) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataTeamMembers.modificationTimestamp) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataTeamMembers.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataTeamMembers.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataTeamMembers.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataTeamMembers.originatingSystemName) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataTeamMembers.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataTeamMembers.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataTeamMembers.sourceSystemName) &&
        Objects.equals(this.teamImpersonationLevel, orgResoMetadataTeamMembers.teamImpersonationLevel) &&
        Objects.equals(this.teamKey, orgResoMetadataTeamMembers.teamKey) &&
        Objects.equals(this.teamKeyNumeric, orgResoMetadataTeamMembers.teamKeyNumeric) &&
        Objects.equals(this.teamMemberKey, orgResoMetadataTeamMembers.teamMemberKey) &&
        Objects.equals(this.teamMemberKeyNumeric, orgResoMetadataTeamMembers.teamMemberKeyNumeric) &&
        Objects.equals(this.teamMemberNationalAssociationId, orgResoMetadataTeamMembers.teamMemberNationalAssociationId) &&
        Objects.equals(this.teamMemberStateLicense, orgResoMetadataTeamMembers.teamMemberStateLicense) &&
        Objects.equals(this.teamMemberType, orgResoMetadataTeamMembers.teamMemberType) &&
        Objects.equals(this.member, orgResoMetadataTeamMembers.member) &&
        Objects.equals(this.originatingSystem, orgResoMetadataTeamMembers.originatingSystem) &&
        Objects.equals(this.sourceSystem, orgResoMetadataTeamMembers.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataTeamMembers.historyTransactional) &&
        Objects.equals(this.historyTransactionalAtOdataCount, orgResoMetadataTeamMembers.historyTransactionalAtOdataCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(memberKey, memberKeyNumeric, memberLoginId, memberMlsId, modificationTimestamp, originalEntryTimestamp, originatingSystemID, originatingSystemKey, originatingSystemName, sourceSystemID, sourceSystemKey, sourceSystemName, teamImpersonationLevel, teamKey, teamKeyNumeric, teamMemberKey, teamMemberKeyNumeric, teamMemberNationalAssociationId, teamMemberStateLicense, teamMemberType, member, originatingSystem, sourceSystem, historyTransactional, historyTransactionalAtOdataCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataTeamMembers {\n");
    
    sb.append("    memberKey: ").append(toIndentedString(memberKey)).append("\n");
    sb.append("    memberKeyNumeric: ").append(toIndentedString(memberKeyNumeric)).append("\n");
    sb.append("    memberLoginId: ").append(toIndentedString(memberLoginId)).append("\n");
    sb.append("    memberMlsId: ").append(toIndentedString(memberMlsId)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    teamImpersonationLevel: ").append(toIndentedString(teamImpersonationLevel)).append("\n");
    sb.append("    teamKey: ").append(toIndentedString(teamKey)).append("\n");
    sb.append("    teamKeyNumeric: ").append(toIndentedString(teamKeyNumeric)).append("\n");
    sb.append("    teamMemberKey: ").append(toIndentedString(teamMemberKey)).append("\n");
    sb.append("    teamMemberKeyNumeric: ").append(toIndentedString(teamMemberKeyNumeric)).append("\n");
    sb.append("    teamMemberNationalAssociationId: ").append(toIndentedString(teamMemberNationalAssociationId)).append("\n");
    sb.append("    teamMemberStateLicense: ").append(toIndentedString(teamMemberStateLicense)).append("\n");
    sb.append("    teamMemberType: ").append(toIndentedString(teamMemberType)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    historyTransactionalAtOdataCount: ").append(toIndentedString(historyTransactionalAtOdataCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
