package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric
*/
public interface AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric {

}
