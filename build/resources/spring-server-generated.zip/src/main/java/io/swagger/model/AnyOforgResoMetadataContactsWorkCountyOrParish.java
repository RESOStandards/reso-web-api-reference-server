package io.swagger.model;


/**
* AnyOforgResoMetadataContactsWorkCountyOrParish
*/
public interface AnyOforgResoMetadataContactsWorkCountyOrParish {

}
