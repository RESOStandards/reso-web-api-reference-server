package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataPropertyGreenVerificationUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataPropertyGreenVerificationUpdate   {
  @JsonProperty("GreenBuildingVerificationKeyNumeric")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationKeyNumeric greenBuildingVerificationKeyNumeric = null;

  @JsonProperty("GreenBuildingVerificationType")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationType greenBuildingVerificationType = null;

  @JsonProperty("GreenVerificationBody")
  private String greenVerificationBody = null;

  @JsonProperty("GreenVerificationMetric")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric greenVerificationMetric = null;

  @JsonProperty("GreenVerificationRating")
  private String greenVerificationRating = null;

  @JsonProperty("GreenVerificationSource")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource greenVerificationSource = null;

  @JsonProperty("GreenVerificationStatus")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationStatus greenVerificationStatus = null;

  @JsonProperty("GreenVerificationURL")
  private String greenVerificationURL = null;

  @JsonProperty("GreenVerificationVersion")
  private String greenVerificationVersion = null;

  @JsonProperty("GreenVerificationYear")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationYear greenVerificationYear = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyGreenVerificationUpdateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  public OrgResoMetadataPropertyGreenVerificationUpdate greenBuildingVerificationKeyNumeric(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationKeyNumeric greenBuildingVerificationKeyNumeric) {
    this.greenBuildingVerificationKeyNumeric = greenBuildingVerificationKeyNumeric;
    return this;
  }

  /**
   * Get greenBuildingVerificationKeyNumeric
   * @return greenBuildingVerificationKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationKeyNumeric getGreenBuildingVerificationKeyNumeric() {
    return greenBuildingVerificationKeyNumeric;
  }

  public void setGreenBuildingVerificationKeyNumeric(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationKeyNumeric greenBuildingVerificationKeyNumeric) {
    this.greenBuildingVerificationKeyNumeric = greenBuildingVerificationKeyNumeric;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenBuildingVerificationType(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationType greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
    return this;
  }

  /**
   * Get greenBuildingVerificationType
   * @return greenBuildingVerificationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationType getGreenBuildingVerificationType() {
    return greenBuildingVerificationType;
  }

  public void setGreenBuildingVerificationType(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenBuildingVerificationType greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationBody(String greenVerificationBody) {
    this.greenVerificationBody = greenVerificationBody;
    return this;
  }

  /**
   * Get greenVerificationBody
   * @return greenVerificationBody
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getGreenVerificationBody() {
    return greenVerificationBody;
  }

  public void setGreenVerificationBody(String greenVerificationBody) {
    this.greenVerificationBody = greenVerificationBody;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationMetric(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric greenVerificationMetric) {
    this.greenVerificationMetric = greenVerificationMetric;
    return this;
  }

  /**
   * Get greenVerificationMetric
   * @return greenVerificationMetric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric getGreenVerificationMetric() {
    return greenVerificationMetric;
  }

  public void setGreenVerificationMetric(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationMetric greenVerificationMetric) {
    this.greenVerificationMetric = greenVerificationMetric;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationRating(String greenVerificationRating) {
    this.greenVerificationRating = greenVerificationRating;
    return this;
  }

  /**
   * Get greenVerificationRating
   * @return greenVerificationRating
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getGreenVerificationRating() {
    return greenVerificationRating;
  }

  public void setGreenVerificationRating(String greenVerificationRating) {
    this.greenVerificationRating = greenVerificationRating;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationSource(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource greenVerificationSource) {
    this.greenVerificationSource = greenVerificationSource;
    return this;
  }

  /**
   * Get greenVerificationSource
   * @return greenVerificationSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource getGreenVerificationSource() {
    return greenVerificationSource;
  }

  public void setGreenVerificationSource(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource greenVerificationSource) {
    this.greenVerificationSource = greenVerificationSource;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationStatus(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationStatus greenVerificationStatus) {
    this.greenVerificationStatus = greenVerificationStatus;
    return this;
  }

  /**
   * Get greenVerificationStatus
   * @return greenVerificationStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationStatus getGreenVerificationStatus() {
    return greenVerificationStatus;
  }

  public void setGreenVerificationStatus(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationStatus greenVerificationStatus) {
    this.greenVerificationStatus = greenVerificationStatus;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationURL(String greenVerificationURL) {
    this.greenVerificationURL = greenVerificationURL;
    return this;
  }

  /**
   * Get greenVerificationURL
   * @return greenVerificationURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getGreenVerificationURL() {
    return greenVerificationURL;
  }

  public void setGreenVerificationURL(String greenVerificationURL) {
    this.greenVerificationURL = greenVerificationURL;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationVersion(String greenVerificationVersion) {
    this.greenVerificationVersion = greenVerificationVersion;
    return this;
  }

  /**
   * Get greenVerificationVersion
   * @return greenVerificationVersion
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getGreenVerificationVersion() {
    return greenVerificationVersion;
  }

  public void setGreenVerificationVersion(String greenVerificationVersion) {
    this.greenVerificationVersion = greenVerificationVersion;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate greenVerificationYear(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationYear greenVerificationYear) {
    this.greenVerificationYear = greenVerificationYear;
    return this;
  }

  /**
   * Get greenVerificationYear
   * @return greenVerificationYear
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationYear getGreenVerificationYear() {
    return greenVerificationYear;
  }

  public void setGreenVerificationYear(AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationYear greenVerificationYear) {
    this.greenVerificationYear = greenVerificationYear;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate listingKeyNumeric(AnyOforgResoMetadataPropertyGreenVerificationUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyGreenVerificationUpdateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyGreenVerificationUpdateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataPropertyGreenVerificationUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataPropertyGreenVerificationUpdate orgResoMetadataPropertyGreenVerificationUpdate = (OrgResoMetadataPropertyGreenVerificationUpdate) o;
    return Objects.equals(this.greenBuildingVerificationKeyNumeric, orgResoMetadataPropertyGreenVerificationUpdate.greenBuildingVerificationKeyNumeric) &&
        Objects.equals(this.greenBuildingVerificationType, orgResoMetadataPropertyGreenVerificationUpdate.greenBuildingVerificationType) &&
        Objects.equals(this.greenVerificationBody, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationBody) &&
        Objects.equals(this.greenVerificationMetric, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationMetric) &&
        Objects.equals(this.greenVerificationRating, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationRating) &&
        Objects.equals(this.greenVerificationSource, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationSource) &&
        Objects.equals(this.greenVerificationStatus, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationStatus) &&
        Objects.equals(this.greenVerificationURL, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationURL) &&
        Objects.equals(this.greenVerificationVersion, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationVersion) &&
        Objects.equals(this.greenVerificationYear, orgResoMetadataPropertyGreenVerificationUpdate.greenVerificationYear) &&
        Objects.equals(this.listingId, orgResoMetadataPropertyGreenVerificationUpdate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataPropertyGreenVerificationUpdate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataPropertyGreenVerificationUpdate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataPropertyGreenVerificationUpdate.modificationTimestamp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(greenBuildingVerificationKeyNumeric, greenBuildingVerificationType, greenVerificationBody, greenVerificationMetric, greenVerificationRating, greenVerificationSource, greenVerificationStatus, greenVerificationURL, greenVerificationVersion, greenVerificationYear, listingId, listingKey, listingKeyNumeric, modificationTimestamp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataPropertyGreenVerificationUpdate {\n");
    
    sb.append("    greenBuildingVerificationKeyNumeric: ").append(toIndentedString(greenBuildingVerificationKeyNumeric)).append("\n");
    sb.append("    greenBuildingVerificationType: ").append(toIndentedString(greenBuildingVerificationType)).append("\n");
    sb.append("    greenVerificationBody: ").append(toIndentedString(greenVerificationBody)).append("\n");
    sb.append("    greenVerificationMetric: ").append(toIndentedString(greenVerificationMetric)).append("\n");
    sb.append("    greenVerificationRating: ").append(toIndentedString(greenVerificationRating)).append("\n");
    sb.append("    greenVerificationSource: ").append(toIndentedString(greenVerificationSource)).append("\n");
    sb.append("    greenVerificationStatus: ").append(toIndentedString(greenVerificationStatus)).append("\n");
    sb.append("    greenVerificationURL: ").append(toIndentedString(greenVerificationURL)).append("\n");
    sb.append("    greenVerificationVersion: ").append(toIndentedString(greenVerificationVersion)).append("\n");
    sb.append("    greenVerificationYear: ").append(toIndentedString(greenVerificationYear)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
