package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateActorLatitude
*/
public interface AnyOforgResoMetadataInternetTrackingCreateActorLatitude {

}
