package io.swagger.model;


/**
* AnyOforgResoMetadataMediaUpdateMediaStatus
*/
public interface AnyOforgResoMetadataMediaUpdateMediaStatus {

}
