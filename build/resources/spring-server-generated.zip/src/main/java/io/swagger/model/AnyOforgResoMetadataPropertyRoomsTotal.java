package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsTotal
*/
public interface AnyOforgResoMetadataPropertyRoomsTotal {

}
