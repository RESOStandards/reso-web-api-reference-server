package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingsCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataContactListingsCreateListingKeyNumeric {

}
