package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate
*/
public interface AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate {

}
