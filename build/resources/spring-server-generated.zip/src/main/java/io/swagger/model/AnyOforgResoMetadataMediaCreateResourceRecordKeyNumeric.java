package io.swagger.model;


/**
* AnyOforgResoMetadataMediaCreateResourceRecordKeyNumeric
*/
public interface AnyOforgResoMetadataMediaCreateResourceRecordKeyNumeric {

}
