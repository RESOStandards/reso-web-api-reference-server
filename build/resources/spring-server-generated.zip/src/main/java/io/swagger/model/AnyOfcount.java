package io.swagger.model;


/**
* AnyOfcount
*/
public interface AnyOfcount {

}
