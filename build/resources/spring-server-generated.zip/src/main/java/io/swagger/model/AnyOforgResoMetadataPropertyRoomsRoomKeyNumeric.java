package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsRoomKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyRoomsRoomKeyNumeric {

}
