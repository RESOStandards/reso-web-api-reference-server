package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListPriceLow
*/
public interface AnyOforgResoMetadataPropertyListPriceLow {

}
