package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCoListAgent
*/
public interface AnyOforgResoMetadataPropertyCoListAgent {

}
