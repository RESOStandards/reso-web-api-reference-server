package io.swagger.model;


/**
* AnyOforgResoMetadataMediaOrder
*/
public interface AnyOforgResoMetadataMediaOrder {

}
