package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyAssociationFeeFrequency
*/
public interface AnyOforgResoMetadataPropertyAssociationFeeFrequency {

}
