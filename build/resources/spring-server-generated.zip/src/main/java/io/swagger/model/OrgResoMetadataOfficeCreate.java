package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.model.OrgResoMetadataSocialMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOfficeCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOfficeCreate  implements AnyOforgResoMetadataMemberCreateOffice, AnyOforgResoMetadataOfficeCreateMainOffice, AnyOforgResoMetadataPropertyCreateBuyerOffice, AnyOforgResoMetadataPropertyCreateCoBuyerOffice, AnyOforgResoMetadataPropertyCreateCoListOffice, AnyOforgResoMetadataPropertyCreateListOffice {
  @JsonProperty("FranchiseAffiliation")
  private String franchiseAffiliation = null;

  @JsonProperty("IDXOfficeParticipationYN")
  private Boolean idXOfficeParticipationYN = null;

  @JsonProperty("MainOfficeKey")
  private String mainOfficeKey = null;

  @JsonProperty("MainOfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeCreateMainOfficeKeyNumeric mainOfficeKeyNumeric = null;

  @JsonProperty("MainOfficeMlsId")
  private String mainOfficeMlsId = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OfficeAOR")
  private AnyOforgResoMetadataOfficeCreateOfficeAOR officeAOR = null;

  @JsonProperty("OfficeAORMlsId")
  private String officeAORMlsId = null;

  @JsonProperty("OfficeAORkey")
  private String officeAORkey = null;

  @JsonProperty("OfficeAORkeyNumeric")
  private AnyOforgResoMetadataOfficeCreateOfficeAORkeyNumeric officeAORkeyNumeric = null;

  @JsonProperty("OfficeAddress1")
  private String officeAddress1 = null;

  @JsonProperty("OfficeAddress2")
  private String officeAddress2 = null;

  @JsonProperty("OfficeAssociationComments")
  private String officeAssociationComments = null;

  @JsonProperty("OfficeBranchType")
  private AnyOforgResoMetadataOfficeCreateOfficeBranchType officeBranchType = null;

  @JsonProperty("OfficeBrokerKey")
  private String officeBrokerKey = null;

  @JsonProperty("OfficeBrokerKeyNumeric")
  private AnyOforgResoMetadataOfficeCreateOfficeBrokerKeyNumeric officeBrokerKeyNumeric = null;

  @JsonProperty("OfficeBrokerMlsId")
  private String officeBrokerMlsId = null;

  @JsonProperty("OfficeCity")
  private String officeCity = null;

  @JsonProperty("OfficeCorporateLicense")
  private String officeCorporateLicense = null;

  @JsonProperty("OfficeCountyOrParish")
  private AnyOforgResoMetadataOfficeCreateOfficeCountyOrParish officeCountyOrParish = null;

  @JsonProperty("OfficeEmail")
  private String officeEmail = null;

  @JsonProperty("OfficeFax")
  private String officeFax = null;

  @JsonProperty("OfficeKey")
  private String officeKey = null;

  @JsonProperty("OfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric officeKeyNumeric = null;

  @JsonProperty("OfficeManagerKey")
  private String officeManagerKey = null;

  @JsonProperty("OfficeManagerKeyNumeric")
  private AnyOforgResoMetadataOfficeCreateOfficeManagerKeyNumeric officeManagerKeyNumeric = null;

  @JsonProperty("OfficeManagerMlsId")
  private String officeManagerMlsId = null;

  @JsonProperty("OfficeMlsId")
  private String officeMlsId = null;

  @JsonProperty("OfficeName")
  private String officeName = null;

  @JsonProperty("OfficeNationalAssociationId")
  private String officeNationalAssociationId = null;

  @JsonProperty("OfficePhone")
  private String officePhone = null;

  @JsonProperty("OfficePhoneExt")
  private String officePhoneExt = null;

  @JsonProperty("OfficePostalCode")
  private String officePostalCode = null;

  @JsonProperty("OfficePostalCodePlus4")
  private String officePostalCodePlus4 = null;

  @JsonProperty("OfficeStateOrProvince")
  private AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince officeStateOrProvince = null;

  @JsonProperty("OfficeStatus")
  private AnyOforgResoMetadataOfficeCreateOfficeStatus officeStatus = null;

  @JsonProperty("OfficeType")
  private AnyOforgResoMetadataOfficeCreateOfficeType officeType = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OriginatingSystemOfficeKey")
  private String originatingSystemOfficeKey = null;

  @JsonProperty("SocialMediaType")
  private AnyOforgResoMetadataOfficeCreateSocialMediaType socialMediaType = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SourceSystemOfficeKey")
  private String sourceSystemOfficeKey = null;

  @JsonProperty("SyndicateAgentOption")
  private AnyOforgResoMetadataOfficeCreateSyndicateAgentOption syndicateAgentOption = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  @JsonProperty("MainOffice")
  private AnyOforgResoMetadataOfficeCreateMainOffice mainOffice = null;

  @JsonProperty("OfficeBroker")
  private AnyOforgResoMetadataOfficeCreateOfficeBroker officeBroker = null;

  @JsonProperty("OfficeManager")
  private AnyOforgResoMetadataOfficeCreateOfficeManager officeManager = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataOfficeCreateOriginatingSystem originatingSystem = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataOfficeCreateSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMediaCreate> socialMedia = null;

  public OrgResoMetadataOfficeCreate franchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
    return this;
  }

  /**
   * Get franchiseAffiliation
   * @return franchiseAffiliation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getFranchiseAffiliation() {
    return franchiseAffiliation;
  }

  public void setFranchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
  }

  public OrgResoMetadataOfficeCreate idXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
    return this;
  }

  /**
   * Get idXOfficeParticipationYN
   * @return idXOfficeParticipationYN
   **/
  @Schema(description = "")
  
    public Boolean isIdXOfficeParticipationYN() {
    return idXOfficeParticipationYN;
  }

  public void setIdXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
  }

  public OrgResoMetadataOfficeCreate mainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
    return this;
  }

  /**
   * Get mainOfficeKey
   * @return mainOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getMainOfficeKey() {
    return mainOfficeKey;
  }

  public void setMainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
  }

  public OrgResoMetadataOfficeCreate mainOfficeKeyNumeric(AnyOforgResoMetadataOfficeCreateMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
    return this;
  }

  /**
   * Get mainOfficeKeyNumeric
   * @return mainOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeCreateMainOfficeKeyNumeric getMainOfficeKeyNumeric() {
    return mainOfficeKeyNumeric;
  }

  public void setMainOfficeKeyNumeric(AnyOforgResoMetadataOfficeCreateMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
  }

  public OrgResoMetadataOfficeCreate mainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
    return this;
  }

  /**
   * Get mainOfficeMlsId
   * @return mainOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMainOfficeMlsId() {
    return mainOfficeMlsId;
  }

  public void setMainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
  }

  public OrgResoMetadataOfficeCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOfficeCreate officeAOR(AnyOforgResoMetadataOfficeCreateOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
    return this;
  }

  /**
   * Get officeAOR
   * @return officeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeAOR getOfficeAOR() {
    return officeAOR;
  }

  public void setOfficeAOR(AnyOforgResoMetadataOfficeCreateOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
  }

  public OrgResoMetadataOfficeCreate officeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
    return this;
  }

  /**
   * Get officeAORMlsId
   * @return officeAORMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeAORMlsId() {
    return officeAORMlsId;
  }

  public void setOfficeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
  }

  public OrgResoMetadataOfficeCreate officeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
    return this;
  }

  /**
   * Get officeAORkey
   * @return officeAORkey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeAORkey() {
    return officeAORkey;
  }

  public void setOfficeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
  }

  public OrgResoMetadataOfficeCreate officeAORkeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
    return this;
  }

  /**
   * Get officeAORkeyNumeric
   * @return officeAORkeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeAORkeyNumeric getOfficeAORkeyNumeric() {
    return officeAORkeyNumeric;
  }

  public void setOfficeAORkeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
  }

  public OrgResoMetadataOfficeCreate officeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
    return this;
  }

  /**
   * Get officeAddress1
   * @return officeAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress1() {
    return officeAddress1;
  }

  public void setOfficeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
  }

  public OrgResoMetadataOfficeCreate officeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
    return this;
  }

  /**
   * Get officeAddress2
   * @return officeAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress2() {
    return officeAddress2;
  }

  public void setOfficeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
  }

  public OrgResoMetadataOfficeCreate officeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
    return this;
  }

  /**
   * Get officeAssociationComments
   * @return officeAssociationComments
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getOfficeAssociationComments() {
    return officeAssociationComments;
  }

  public void setOfficeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
  }

  public OrgResoMetadataOfficeCreate officeBranchType(AnyOforgResoMetadataOfficeCreateOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
    return this;
  }

  /**
   * Get officeBranchType
   * @return officeBranchType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeBranchType getOfficeBranchType() {
    return officeBranchType;
  }

  public void setOfficeBranchType(AnyOforgResoMetadataOfficeCreateOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
  }

  public OrgResoMetadataOfficeCreate officeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
    return this;
  }

  /**
   * Get officeBrokerKey
   * @return officeBrokerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeBrokerKey() {
    return officeBrokerKey;
  }

  public void setOfficeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
  }

  public OrgResoMetadataOfficeCreate officeBrokerKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
    return this;
  }

  /**
   * Get officeBrokerKeyNumeric
   * @return officeBrokerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeBrokerKeyNumeric getOfficeBrokerKeyNumeric() {
    return officeBrokerKeyNumeric;
  }

  public void setOfficeBrokerKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
  }

  public OrgResoMetadataOfficeCreate officeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
    return this;
  }

  /**
   * Get officeBrokerMlsId
   * @return officeBrokerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeBrokerMlsId() {
    return officeBrokerMlsId;
  }

  public void setOfficeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
  }

  public OrgResoMetadataOfficeCreate officeCity(String officeCity) {
    this.officeCity = officeCity;
    return this;
  }

  /**
   * Get officeCity
   * @return officeCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCity() {
    return officeCity;
  }

  public void setOfficeCity(String officeCity) {
    this.officeCity = officeCity;
  }

  public OrgResoMetadataOfficeCreate officeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
    return this;
  }

  /**
   * Get officeCorporateLicense
   * @return officeCorporateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCorporateLicense() {
    return officeCorporateLicense;
  }

  public void setOfficeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
  }

  public OrgResoMetadataOfficeCreate officeCountyOrParish(AnyOforgResoMetadataOfficeCreateOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
    return this;
  }

  /**
   * Get officeCountyOrParish
   * @return officeCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeCountyOrParish getOfficeCountyOrParish() {
    return officeCountyOrParish;
  }

  public void setOfficeCountyOrParish(AnyOforgResoMetadataOfficeCreateOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
  }

  public OrgResoMetadataOfficeCreate officeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
    return this;
  }

  /**
   * Get officeEmail
   * @return officeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getOfficeEmail() {
    return officeEmail;
  }

  public void setOfficeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
  }

  public OrgResoMetadataOfficeCreate officeFax(String officeFax) {
    this.officeFax = officeFax;
    return this;
  }

  /**
   * Get officeFax
   * @return officeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficeFax() {
    return officeFax;
  }

  public void setOfficeFax(String officeFax) {
    this.officeFax = officeFax;
  }

  public OrgResoMetadataOfficeCreate officeKey(String officeKey) {
    this.officeKey = officeKey;
    return this;
  }

  /**
   * Get officeKey
   * @return officeKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getOfficeKey() {
    return officeKey;
  }

  public void setOfficeKey(String officeKey) {
    this.officeKey = officeKey;
  }

  public OrgResoMetadataOfficeCreate officeKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
    return this;
  }

  /**
   * Get officeKeyNumeric
   * @return officeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric getOfficeKeyNumeric() {
    return officeKeyNumeric;
  }

  public void setOfficeKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
  }

  public OrgResoMetadataOfficeCreate officeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
    return this;
  }

  /**
   * Get officeManagerKey
   * @return officeManagerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeManagerKey() {
    return officeManagerKey;
  }

  public void setOfficeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
  }

  public OrgResoMetadataOfficeCreate officeManagerKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
    return this;
  }

  /**
   * Get officeManagerKeyNumeric
   * @return officeManagerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeManagerKeyNumeric getOfficeManagerKeyNumeric() {
    return officeManagerKeyNumeric;
  }

  public void setOfficeManagerKeyNumeric(AnyOforgResoMetadataOfficeCreateOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
  }

  public OrgResoMetadataOfficeCreate officeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
    return this;
  }

  /**
   * Get officeManagerMlsId
   * @return officeManagerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeManagerMlsId() {
    return officeManagerMlsId;
  }

  public void setOfficeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
  }

  public OrgResoMetadataOfficeCreate officeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
    return this;
  }

  /**
   * Get officeMlsId
   * @return officeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeMlsId() {
    return officeMlsId;
  }

  public void setOfficeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
  }

  public OrgResoMetadataOfficeCreate officeName(String officeName) {
    this.officeName = officeName;
    return this;
  }

  /**
   * Get officeName
   * @return officeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeName() {
    return officeName;
  }

  public void setOfficeName(String officeName) {
    this.officeName = officeName;
  }

  public OrgResoMetadataOfficeCreate officeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
    return this;
  }

  /**
   * Get officeNationalAssociationId
   * @return officeNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeNationalAssociationId() {
    return officeNationalAssociationId;
  }

  public void setOfficeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
  }

  public OrgResoMetadataOfficeCreate officePhone(String officePhone) {
    this.officePhone = officePhone;
    return this;
  }

  /**
   * Get officePhone
   * @return officePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficePhone() {
    return officePhone;
  }

  public void setOfficePhone(String officePhone) {
    this.officePhone = officePhone;
  }

  public OrgResoMetadataOfficeCreate officePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
    return this;
  }

  /**
   * Get officePhoneExt
   * @return officePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePhoneExt() {
    return officePhoneExt;
  }

  public void setOfficePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
  }

  public OrgResoMetadataOfficeCreate officePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
    return this;
  }

  /**
   * Get officePostalCode
   * @return officePostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePostalCode() {
    return officePostalCode;
  }

  public void setOfficePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
  }

  public OrgResoMetadataOfficeCreate officePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
    return this;
  }

  /**
   * Get officePostalCodePlus4
   * @return officePostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getOfficePostalCodePlus4() {
    return officePostalCodePlus4;
  }

  public void setOfficePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
  }

  public OrgResoMetadataOfficeCreate officeStateOrProvince(AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
    return this;
  }

  /**
   * Get officeStateOrProvince
   * @return officeStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince getOfficeStateOrProvince() {
    return officeStateOrProvince;
  }

  public void setOfficeStateOrProvince(AnyOforgResoMetadataOfficeCreateOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
  }

  public OrgResoMetadataOfficeCreate officeStatus(AnyOforgResoMetadataOfficeCreateOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
    return this;
  }

  /**
   * Get officeStatus
   * @return officeStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeStatus getOfficeStatus() {
    return officeStatus;
  }

  public void setOfficeStatus(AnyOforgResoMetadataOfficeCreateOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
  }

  public OrgResoMetadataOfficeCreate officeType(AnyOforgResoMetadataOfficeCreateOfficeType officeType) {
    this.officeType = officeType;
    return this;
  }

  /**
   * Get officeType
   * @return officeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeType getOfficeType() {
    return officeType;
  }

  public void setOfficeType(AnyOforgResoMetadataOfficeCreateOfficeType officeType) {
    this.officeType = officeType;
  }

  public OrgResoMetadataOfficeCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataOfficeCreate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataOfficeCreate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataOfficeCreate originatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
    return this;
  }

  /**
   * Get originatingSystemOfficeKey
   * @return originatingSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemOfficeKey() {
    return originatingSystemOfficeKey;
  }

  public void setOriginatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
  }

  public OrgResoMetadataOfficeCreate socialMediaType(AnyOforgResoMetadataOfficeCreateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
    return this;
  }

  /**
   * Get socialMediaType
   * @return socialMediaType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateSocialMediaType getSocialMediaType() {
    return socialMediaType;
  }

  public void setSocialMediaType(AnyOforgResoMetadataOfficeCreateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
  }

  public OrgResoMetadataOfficeCreate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataOfficeCreate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataOfficeCreate sourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
    return this;
  }

  /**
   * Get sourceSystemOfficeKey
   * @return sourceSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemOfficeKey() {
    return sourceSystemOfficeKey;
  }

  public void setSourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
  }

  public OrgResoMetadataOfficeCreate syndicateAgentOption(AnyOforgResoMetadataOfficeCreateSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
    return this;
  }

  /**
   * Get syndicateAgentOption
   * @return syndicateAgentOption
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateSyndicateAgentOption getSyndicateAgentOption() {
    return syndicateAgentOption;
  }

  public void setSyndicateAgentOption(AnyOforgResoMetadataOfficeCreateSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
  }

  public OrgResoMetadataOfficeCreate syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataOfficeCreate addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }

  public OrgResoMetadataOfficeCreate mainOffice(AnyOforgResoMetadataOfficeCreateMainOffice mainOffice) {
    this.mainOffice = mainOffice;
    return this;
  }

  /**
   * Get mainOffice
   * @return mainOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateMainOffice getMainOffice() {
    return mainOffice;
  }

  public void setMainOffice(AnyOforgResoMetadataOfficeCreateMainOffice mainOffice) {
    this.mainOffice = mainOffice;
  }

  public OrgResoMetadataOfficeCreate officeBroker(AnyOforgResoMetadataOfficeCreateOfficeBroker officeBroker) {
    this.officeBroker = officeBroker;
    return this;
  }

  /**
   * Get officeBroker
   * @return officeBroker
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeBroker getOfficeBroker() {
    return officeBroker;
  }

  public void setOfficeBroker(AnyOforgResoMetadataOfficeCreateOfficeBroker officeBroker) {
    this.officeBroker = officeBroker;
  }

  public OrgResoMetadataOfficeCreate officeManager(AnyOforgResoMetadataOfficeCreateOfficeManager officeManager) {
    this.officeManager = officeManager;
    return this;
  }

  /**
   * Get officeManager
   * @return officeManager
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOfficeManager getOfficeManager() {
    return officeManager;
  }

  public void setOfficeManager(AnyOforgResoMetadataOfficeCreateOfficeManager officeManager) {
    this.officeManager = officeManager;
  }

  public OrgResoMetadataOfficeCreate originatingSystem(AnyOforgResoMetadataOfficeCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataOfficeCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataOfficeCreate sourceSystem(AnyOforgResoMetadataOfficeCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeCreateSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataOfficeCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataOfficeCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataOfficeCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataOfficeCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataOfficeCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }

  public OrgResoMetadataOfficeCreate socialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataOfficeCreate addSocialMediaItem(OrgResoMetadataSocialMediaCreate socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMediaCreate>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMediaCreate> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOfficeCreate orgResoMetadataOfficeCreate = (OrgResoMetadataOfficeCreate) o;
    return Objects.equals(this.franchiseAffiliation, orgResoMetadataOfficeCreate.franchiseAffiliation) &&
        Objects.equals(this.idXOfficeParticipationYN, orgResoMetadataOfficeCreate.idXOfficeParticipationYN) &&
        Objects.equals(this.mainOfficeKey, orgResoMetadataOfficeCreate.mainOfficeKey) &&
        Objects.equals(this.mainOfficeKeyNumeric, orgResoMetadataOfficeCreate.mainOfficeKeyNumeric) &&
        Objects.equals(this.mainOfficeMlsId, orgResoMetadataOfficeCreate.mainOfficeMlsId) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOfficeCreate.modificationTimestamp) &&
        Objects.equals(this.officeAOR, orgResoMetadataOfficeCreate.officeAOR) &&
        Objects.equals(this.officeAORMlsId, orgResoMetadataOfficeCreate.officeAORMlsId) &&
        Objects.equals(this.officeAORkey, orgResoMetadataOfficeCreate.officeAORkey) &&
        Objects.equals(this.officeAORkeyNumeric, orgResoMetadataOfficeCreate.officeAORkeyNumeric) &&
        Objects.equals(this.officeAddress1, orgResoMetadataOfficeCreate.officeAddress1) &&
        Objects.equals(this.officeAddress2, orgResoMetadataOfficeCreate.officeAddress2) &&
        Objects.equals(this.officeAssociationComments, orgResoMetadataOfficeCreate.officeAssociationComments) &&
        Objects.equals(this.officeBranchType, orgResoMetadataOfficeCreate.officeBranchType) &&
        Objects.equals(this.officeBrokerKey, orgResoMetadataOfficeCreate.officeBrokerKey) &&
        Objects.equals(this.officeBrokerKeyNumeric, orgResoMetadataOfficeCreate.officeBrokerKeyNumeric) &&
        Objects.equals(this.officeBrokerMlsId, orgResoMetadataOfficeCreate.officeBrokerMlsId) &&
        Objects.equals(this.officeCity, orgResoMetadataOfficeCreate.officeCity) &&
        Objects.equals(this.officeCorporateLicense, orgResoMetadataOfficeCreate.officeCorporateLicense) &&
        Objects.equals(this.officeCountyOrParish, orgResoMetadataOfficeCreate.officeCountyOrParish) &&
        Objects.equals(this.officeEmail, orgResoMetadataOfficeCreate.officeEmail) &&
        Objects.equals(this.officeFax, orgResoMetadataOfficeCreate.officeFax) &&
        Objects.equals(this.officeKey, orgResoMetadataOfficeCreate.officeKey) &&
        Objects.equals(this.officeKeyNumeric, orgResoMetadataOfficeCreate.officeKeyNumeric) &&
        Objects.equals(this.officeManagerKey, orgResoMetadataOfficeCreate.officeManagerKey) &&
        Objects.equals(this.officeManagerKeyNumeric, orgResoMetadataOfficeCreate.officeManagerKeyNumeric) &&
        Objects.equals(this.officeManagerMlsId, orgResoMetadataOfficeCreate.officeManagerMlsId) &&
        Objects.equals(this.officeMlsId, orgResoMetadataOfficeCreate.officeMlsId) &&
        Objects.equals(this.officeName, orgResoMetadataOfficeCreate.officeName) &&
        Objects.equals(this.officeNationalAssociationId, orgResoMetadataOfficeCreate.officeNationalAssociationId) &&
        Objects.equals(this.officePhone, orgResoMetadataOfficeCreate.officePhone) &&
        Objects.equals(this.officePhoneExt, orgResoMetadataOfficeCreate.officePhoneExt) &&
        Objects.equals(this.officePostalCode, orgResoMetadataOfficeCreate.officePostalCode) &&
        Objects.equals(this.officePostalCodePlus4, orgResoMetadataOfficeCreate.officePostalCodePlus4) &&
        Objects.equals(this.officeStateOrProvince, orgResoMetadataOfficeCreate.officeStateOrProvince) &&
        Objects.equals(this.officeStatus, orgResoMetadataOfficeCreate.officeStatus) &&
        Objects.equals(this.officeType, orgResoMetadataOfficeCreate.officeType) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataOfficeCreate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataOfficeCreate.originatingSystemID) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataOfficeCreate.originatingSystemName) &&
        Objects.equals(this.originatingSystemOfficeKey, orgResoMetadataOfficeCreate.originatingSystemOfficeKey) &&
        Objects.equals(this.socialMediaType, orgResoMetadataOfficeCreate.socialMediaType) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataOfficeCreate.sourceSystemID) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataOfficeCreate.sourceSystemName) &&
        Objects.equals(this.sourceSystemOfficeKey, orgResoMetadataOfficeCreate.sourceSystemOfficeKey) &&
        Objects.equals(this.syndicateAgentOption, orgResoMetadataOfficeCreate.syndicateAgentOption) &&
        Objects.equals(this.syndicateTo, orgResoMetadataOfficeCreate.syndicateTo) &&
        Objects.equals(this.mainOffice, orgResoMetadataOfficeCreate.mainOffice) &&
        Objects.equals(this.officeBroker, orgResoMetadataOfficeCreate.officeBroker) &&
        Objects.equals(this.officeManager, orgResoMetadataOfficeCreate.officeManager) &&
        Objects.equals(this.originatingSystem, orgResoMetadataOfficeCreate.originatingSystem) &&
        Objects.equals(this.sourceSystem, orgResoMetadataOfficeCreate.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataOfficeCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataOfficeCreate.media) &&
        Objects.equals(this.socialMedia, orgResoMetadataOfficeCreate.socialMedia);
  }

  @Override
  public int hashCode() {
    return Objects.hash(franchiseAffiliation, idXOfficeParticipationYN, mainOfficeKey, mainOfficeKeyNumeric, mainOfficeMlsId, modificationTimestamp, officeAOR, officeAORMlsId, officeAORkey, officeAORkeyNumeric, officeAddress1, officeAddress2, officeAssociationComments, officeBranchType, officeBrokerKey, officeBrokerKeyNumeric, officeBrokerMlsId, officeCity, officeCorporateLicense, officeCountyOrParish, officeEmail, officeFax, officeKey, officeKeyNumeric, officeManagerKey, officeManagerKeyNumeric, officeManagerMlsId, officeMlsId, officeName, officeNationalAssociationId, officePhone, officePhoneExt, officePostalCode, officePostalCodePlus4, officeStateOrProvince, officeStatus, officeType, originalEntryTimestamp, originatingSystemID, originatingSystemName, originatingSystemOfficeKey, socialMediaType, sourceSystemID, sourceSystemName, sourceSystemOfficeKey, syndicateAgentOption, syndicateTo, mainOffice, officeBroker, officeManager, originatingSystem, sourceSystem, historyTransactional, media, socialMedia);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOfficeCreate {\n");
    
    sb.append("    franchiseAffiliation: ").append(toIndentedString(franchiseAffiliation)).append("\n");
    sb.append("    idXOfficeParticipationYN: ").append(toIndentedString(idXOfficeParticipationYN)).append("\n");
    sb.append("    mainOfficeKey: ").append(toIndentedString(mainOfficeKey)).append("\n");
    sb.append("    mainOfficeKeyNumeric: ").append(toIndentedString(mainOfficeKeyNumeric)).append("\n");
    sb.append("    mainOfficeMlsId: ").append(toIndentedString(mainOfficeMlsId)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    officeAOR: ").append(toIndentedString(officeAOR)).append("\n");
    sb.append("    officeAORMlsId: ").append(toIndentedString(officeAORMlsId)).append("\n");
    sb.append("    officeAORkey: ").append(toIndentedString(officeAORkey)).append("\n");
    sb.append("    officeAORkeyNumeric: ").append(toIndentedString(officeAORkeyNumeric)).append("\n");
    sb.append("    officeAddress1: ").append(toIndentedString(officeAddress1)).append("\n");
    sb.append("    officeAddress2: ").append(toIndentedString(officeAddress2)).append("\n");
    sb.append("    officeAssociationComments: ").append(toIndentedString(officeAssociationComments)).append("\n");
    sb.append("    officeBranchType: ").append(toIndentedString(officeBranchType)).append("\n");
    sb.append("    officeBrokerKey: ").append(toIndentedString(officeBrokerKey)).append("\n");
    sb.append("    officeBrokerKeyNumeric: ").append(toIndentedString(officeBrokerKeyNumeric)).append("\n");
    sb.append("    officeBrokerMlsId: ").append(toIndentedString(officeBrokerMlsId)).append("\n");
    sb.append("    officeCity: ").append(toIndentedString(officeCity)).append("\n");
    sb.append("    officeCorporateLicense: ").append(toIndentedString(officeCorporateLicense)).append("\n");
    sb.append("    officeCountyOrParish: ").append(toIndentedString(officeCountyOrParish)).append("\n");
    sb.append("    officeEmail: ").append(toIndentedString(officeEmail)).append("\n");
    sb.append("    officeFax: ").append(toIndentedString(officeFax)).append("\n");
    sb.append("    officeKey: ").append(toIndentedString(officeKey)).append("\n");
    sb.append("    officeKeyNumeric: ").append(toIndentedString(officeKeyNumeric)).append("\n");
    sb.append("    officeManagerKey: ").append(toIndentedString(officeManagerKey)).append("\n");
    sb.append("    officeManagerKeyNumeric: ").append(toIndentedString(officeManagerKeyNumeric)).append("\n");
    sb.append("    officeManagerMlsId: ").append(toIndentedString(officeManagerMlsId)).append("\n");
    sb.append("    officeMlsId: ").append(toIndentedString(officeMlsId)).append("\n");
    sb.append("    officeName: ").append(toIndentedString(officeName)).append("\n");
    sb.append("    officeNationalAssociationId: ").append(toIndentedString(officeNationalAssociationId)).append("\n");
    sb.append("    officePhone: ").append(toIndentedString(officePhone)).append("\n");
    sb.append("    officePhoneExt: ").append(toIndentedString(officePhoneExt)).append("\n");
    sb.append("    officePostalCode: ").append(toIndentedString(officePostalCode)).append("\n");
    sb.append("    officePostalCodePlus4: ").append(toIndentedString(officePostalCodePlus4)).append("\n");
    sb.append("    officeStateOrProvince: ").append(toIndentedString(officeStateOrProvince)).append("\n");
    sb.append("    officeStatus: ").append(toIndentedString(officeStatus)).append("\n");
    sb.append("    officeType: ").append(toIndentedString(officeType)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    originatingSystemOfficeKey: ").append(toIndentedString(originatingSystemOfficeKey)).append("\n");
    sb.append("    socialMediaType: ").append(toIndentedString(socialMediaType)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    sourceSystemOfficeKey: ").append(toIndentedString(sourceSystemOfficeKey)).append("\n");
    sb.append("    syndicateAgentOption: ").append(toIndentedString(syndicateAgentOption)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("    mainOffice: ").append(toIndentedString(mainOffice)).append("\n");
    sb.append("    officeBroker: ").append(toIndentedString(officeBroker)).append("\n");
    sb.append("    officeManager: ").append(toIndentedString(officeManager)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
