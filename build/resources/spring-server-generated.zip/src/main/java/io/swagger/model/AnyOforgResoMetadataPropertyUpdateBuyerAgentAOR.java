package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR
*/
public interface AnyOforgResoMetadataPropertyUpdateBuyerAgentAOR {

}
