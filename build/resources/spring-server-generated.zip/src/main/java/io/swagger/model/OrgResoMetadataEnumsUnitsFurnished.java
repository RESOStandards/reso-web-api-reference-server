package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.UnitsFurnished
 */
public enum OrgResoMetadataEnumsUnitsFurnished {
  ALLUNITS("AllUnits"),
    NONE("None"),
    VARIESBYUNIT("VariesByUnit");

  private String value;

  OrgResoMetadataEnumsUnitsFurnished(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsUnitsFurnished fromValue(String text) {
    for (OrgResoMetadataEnumsUnitsFurnished b : OrgResoMetadataEnumsUnitsFurnished.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
