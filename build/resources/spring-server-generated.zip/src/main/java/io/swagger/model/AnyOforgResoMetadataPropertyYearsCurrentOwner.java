package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyYearsCurrentOwner
*/
public interface AnyOforgResoMetadataPropertyYearsCurrentOwner {

}
