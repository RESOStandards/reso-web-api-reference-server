package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyNewTaxesExpense
*/
public interface AnyOforgResoMetadataPropertyNewTaxesExpense {

}
