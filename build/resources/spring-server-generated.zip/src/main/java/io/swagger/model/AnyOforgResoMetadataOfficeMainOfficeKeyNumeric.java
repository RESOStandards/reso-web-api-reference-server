package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeMainOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataOfficeMainOfficeKeyNumeric {

}
