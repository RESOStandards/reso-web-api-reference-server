package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.CurrentUse
 */
public enum OrgResoMetadataEnumsCurrentUse {
  AGRICULTURAL("Agricultural"),
    AUTOMOTIVE("Automotive"),
    CATTLE("Cattle"),
    COMMERCIAL("Commercial"),
    DAIRY("Dairy"),
    FARM("Farm"),
    FISHERY("Fishery"),
    GRAZING("Grazing"),
    HIGHWAYTOURISTSERVICE("HighwayTouristService"),
    HORSES("Horses"),
    HUNTING("Hunting"),
    INDUSTRIAL("Industrial"),
    INVESTMENT("Investment"),
    LIVESTOCK("Livestock"),
    MANUFACTUREDHOME("ManufacturedHome"),
    MEDICALDENTAL("MedicalDental"),
    MINISTORAGE("MiniStorage"),
    MIXEDUSE("MixedUse"),
    MULTIFAMILY("MultiFamily"),
    NURSERY("Nursery"),
    OFFICE("Office"),
    ORCHARD("Orchard"),
    OTHER("Other"),
    PASTURE("Pasture"),
    PLACEOFWORSHIP("PlaceOfWorship"),
    PLANTABLE("Plantable"),
    POULTRY("Poultry"),
    RANCH("Ranch"),
    RECREATIONAL("Recreational"),
    RESIDENTIAL("Residential"),
    RETAIL("Retail"),
    ROWCROPS("RowCrops"),
    SEEREMARKS("SeeRemarks"),
    SINGLEFAMILY("SingleFamily"),
    SUBDIVISION("Subdivision"),
    TIMBER("Timber"),
    TREEFARM("TreeFarm"),
    UNIMPROVED("Unimproved"),
    VACANT("Vacant"),
    VINEYARD("Vineyard"),
    WAREHOUSE("Warehouse");

  private String value;

  OrgResoMetadataEnumsCurrentUse(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsCurrentUse fromValue(String text) {
    for (OrgResoMetadataEnumsCurrentUse b : OrgResoMetadataEnumsCurrentUse.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
