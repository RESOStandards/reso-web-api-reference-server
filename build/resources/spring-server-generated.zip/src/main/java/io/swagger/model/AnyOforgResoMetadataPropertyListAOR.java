package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListAOR
*/
public interface AnyOforgResoMetadataPropertyListAOR {

}
