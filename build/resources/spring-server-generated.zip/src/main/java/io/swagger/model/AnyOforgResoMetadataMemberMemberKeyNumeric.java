package io.swagger.model;


/**
* AnyOforgResoMetadataMemberMemberKeyNumeric
*/
public interface AnyOforgResoMetadataMemberMemberKeyNumeric {

}
