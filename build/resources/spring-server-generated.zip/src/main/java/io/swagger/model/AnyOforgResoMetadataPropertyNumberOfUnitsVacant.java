package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyNumberOfUnitsVacant
*/
public interface AnyOforgResoMetadataPropertyNumberOfUnitsVacant {

}
