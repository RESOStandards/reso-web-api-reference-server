package io.swagger.model;


/**
* AnyOforgResoMetadataQueueSourceSystem
*/
public interface AnyOforgResoMetadataQueueSourceSystem {

}
