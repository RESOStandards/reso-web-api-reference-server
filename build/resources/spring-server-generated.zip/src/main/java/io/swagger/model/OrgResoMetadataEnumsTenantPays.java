package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.TenantPays
 */
public enum OrgResoMetadataEnumsTenantPays {
  ALLUTILITIES("AllUtilities"),
    ASSOCIATIONFEES("AssociationFees"),
    CABLETV("CableTv"),
    COMMONAREAMAINTENANCE("CommonAreaMaintenance"),
    ELECTRICITY("Electricity"),
    EXTERIORMAINTENANCE("ExteriorMaintenance"),
    GAS("Gas"),
    GROUNDSCARE("GroundsCare"),
    HOTWATER("HotWater"),
    HVACMAINTENANCE("HvacMaintenance"),
    INSURANCE("Insurance"),
    JANITORIALSERVICE("JanitorialService"),
    MANAGEMENT("Management"),
    NONE("None"),
    OTHER("Other"),
    OTHERTAX("OtherTax"),
    PARKINGFEE("ParkingFee"),
    PESTCONTROL("PestControl"),
    POOLMAINTENANCE("PoolMaintenance"),
    REPAIRS("Repairs"),
    ROOF("Roof"),
    SECURITY("Security"),
    SEEREMARKS("SeeRemarks"),
    SEWER("Sewer"),
    SNOWREMOVAL("SnowRemoval"),
    TAXES("Taxes"),
    TELEPHONE("Telephone"),
    TRASHCOLLECTION("TrashCollection"),
    WATER("Water");

  private String value;

  OrgResoMetadataEnumsTenantPays(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsTenantPays fromValue(String text) {
    for (OrgResoMetadataEnumsTenantPays b : OrgResoMetadataEnumsTenantPays.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
