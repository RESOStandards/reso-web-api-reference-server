package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseOpenHouseKeyNumeric
*/
public interface AnyOforgResoMetadataOpenHouseOpenHouseKeyNumeric {

}
