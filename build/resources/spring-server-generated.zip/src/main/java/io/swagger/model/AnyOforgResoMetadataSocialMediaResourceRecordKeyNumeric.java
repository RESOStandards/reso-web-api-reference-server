package io.swagger.model;


/**
* AnyOforgResoMetadataSocialMediaResourceRecordKeyNumeric
*/
public interface AnyOforgResoMetadataSocialMediaResourceRecordKeyNumeric {

}
