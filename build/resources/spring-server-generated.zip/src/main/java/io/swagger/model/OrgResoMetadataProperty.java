package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Count;
import io.swagger.model.OrgResoMetadataEnumsAccessibilityFeatures;
import io.swagger.model.OrgResoMetadataEnumsAppliances;
import io.swagger.model.OrgResoMetadataEnumsArchitecturalStyle;
import io.swagger.model.OrgResoMetadataEnumsAssociationAmenities;
import io.swagger.model.OrgResoMetadataEnumsAssociationFeeIncludes;
import io.swagger.model.OrgResoMetadataEnumsBasement;
import io.swagger.model.OrgResoMetadataEnumsBodyType;
import io.swagger.model.OrgResoMetadataEnumsBuildingFeatures;
import io.swagger.model.OrgResoMetadataEnumsBusinessType;
import io.swagger.model.OrgResoMetadataEnumsBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsBuyerFinancing;
import io.swagger.model.OrgResoMetadataEnumsCoBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCoListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCommonWalls;
import io.swagger.model.OrgResoMetadataEnumsCommunityFeatures;
import io.swagger.model.OrgResoMetadataEnumsConstructionMaterials;
import io.swagger.model.OrgResoMetadataEnumsCooling;
import io.swagger.model.OrgResoMetadataEnumsCurrentFinancing;
import io.swagger.model.OrgResoMetadataEnumsCurrentUse;
import io.swagger.model.OrgResoMetadataEnumsDevelopmentStatus;
import io.swagger.model.OrgResoMetadataEnumsDisclosures;
import io.swagger.model.OrgResoMetadataEnumsDocumentsAvailable;
import io.swagger.model.OrgResoMetadataEnumsDoorFeatures;
import io.swagger.model.OrgResoMetadataEnumsElectric;
import io.swagger.model.OrgResoMetadataEnumsExistingLeaseType;
import io.swagger.model.OrgResoMetadataEnumsExteriorFeatures;
import io.swagger.model.OrgResoMetadataEnumsFencing;
import io.swagger.model.OrgResoMetadataEnumsFinancialDataSource;
import io.swagger.model.OrgResoMetadataEnumsFireplaceFeatures;
import io.swagger.model.OrgResoMetadataEnumsFlooring;
import io.swagger.model.OrgResoMetadataEnumsFoundationDetails;
import io.swagger.model.OrgResoMetadataEnumsFrontageType;
import io.swagger.model.OrgResoMetadataEnumsGreenBuildingVerificationType;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyEfficient;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyGeneration;
import io.swagger.model.OrgResoMetadataEnumsGreenIndoorAirQuality;
import io.swagger.model.OrgResoMetadataEnumsGreenLocation;
import io.swagger.model.OrgResoMetadataEnumsGreenSustainability;
import io.swagger.model.OrgResoMetadataEnumsGreenWaterConservation;
import io.swagger.model.OrgResoMetadataEnumsHeating;
import io.swagger.model.OrgResoMetadataEnumsHorseAmenities;
import io.swagger.model.OrgResoMetadataEnumsHoursDaysOfOperation;
import io.swagger.model.OrgResoMetadataEnumsIncomeIncludes;
import io.swagger.model.OrgResoMetadataEnumsInteriorOrRoomFeatures;
import io.swagger.model.OrgResoMetadataEnumsIrrigationSource;
import io.swagger.model.OrgResoMetadataEnumsLaborInformation;
import io.swagger.model.OrgResoMetadataEnumsLaundryFeatures;
import io.swagger.model.OrgResoMetadataEnumsLeaseRenewalCompensation;
import io.swagger.model.OrgResoMetadataEnumsLevels;
import io.swagger.model.OrgResoMetadataEnumsListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsListingTerms;
import io.swagger.model.OrgResoMetadataEnumsLockBoxType;
import io.swagger.model.OrgResoMetadataEnumsLotFeatures;
import io.swagger.model.OrgResoMetadataEnumsOperatingExpenseIncludes;
import io.swagger.model.OrgResoMetadataEnumsOtherEquipment;
import io.swagger.model.OrgResoMetadataEnumsOtherStructures;
import io.swagger.model.OrgResoMetadataEnumsOwnerPays;
import io.swagger.model.OrgResoMetadataEnumsParkingFeatures;
import io.swagger.model.OrgResoMetadataEnumsPatioAndPorchFeatures;
import io.swagger.model.OrgResoMetadataEnumsPetsAllowed;
import io.swagger.model.OrgResoMetadataEnumsPoolFeatures;
import io.swagger.model.OrgResoMetadataEnumsPossession;
import io.swagger.model.OrgResoMetadataEnumsPossibleUse;
import io.swagger.model.OrgResoMetadataEnumsPowerProductionType;
import io.swagger.model.OrgResoMetadataEnumsPropertyCondition;
import io.swagger.model.OrgResoMetadataEnumsRentIncludes;
import io.swagger.model.OrgResoMetadataEnumsRoadFrontageType;
import io.swagger.model.OrgResoMetadataEnumsRoadResponsibility;
import io.swagger.model.OrgResoMetadataEnumsRoadSurfaceType;
import io.swagger.model.OrgResoMetadataEnumsRoof;
import io.swagger.model.OrgResoMetadataEnumsRoomType;
import io.swagger.model.OrgResoMetadataEnumsSecurityFeatures;
import io.swagger.model.OrgResoMetadataEnumsSewer;
import io.swagger.model.OrgResoMetadataEnumsShowingContactType;
import io.swagger.model.OrgResoMetadataEnumsShowingDays;
import io.swagger.model.OrgResoMetadataEnumsShowingRequirements;
import io.swagger.model.OrgResoMetadataEnumsSkirt;
import io.swagger.model.OrgResoMetadataEnumsSpaFeatures;
import io.swagger.model.OrgResoMetadataEnumsSpecialLicenses;
import io.swagger.model.OrgResoMetadataEnumsSpecialListingConditions;
import io.swagger.model.OrgResoMetadataEnumsStructureType;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.model.OrgResoMetadataEnumsTaxStatusCurrent;
import io.swagger.model.OrgResoMetadataEnumsTenantPays;
import io.swagger.model.OrgResoMetadataEnumsUnitTypeType;
import io.swagger.model.OrgResoMetadataEnumsUtilities;
import io.swagger.model.OrgResoMetadataEnumsVegetation;
import io.swagger.model.OrgResoMetadataEnumsView;
import io.swagger.model.OrgResoMetadataEnumsWaterSource;
import io.swagger.model.OrgResoMetadataEnumsWaterfrontFeatures;
import io.swagger.model.OrgResoMetadataEnumsWindowFeatures;
import io.swagger.model.OrgResoMetadataHistoryTransactional;
import io.swagger.model.OrgResoMetadataMedia;
import io.swagger.model.OrgResoMetadataOpenHouse;
import io.swagger.model.OrgResoMetadataSocialMedia;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataProperty
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataProperty  implements AnyOforgResoMetadataContactListingsListing, AnyOforgResoMetadataOpenHouseListing, AnyOforgResoMetadataPropertyGreenVerificationListing, AnyOforgResoMetadataPropertyPowerProductionListing, AnyOforgResoMetadataPropertyRoomsListing, AnyOforgResoMetadataPropertyUnitTypesListing, AnyOforgResoMetadataShowingListing {
  @JsonProperty("AboveGradeFinishedArea")
  private AnyOforgResoMetadataPropertyAboveGradeFinishedArea aboveGradeFinishedArea = null;

  @JsonProperty("AboveGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource = null;

  @JsonProperty("AboveGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits = null;

  @JsonProperty("AccessCode")
  private String accessCode = null;

  @JsonProperty("AccessibilityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures = null;

  @JsonProperty("AdditionalParcelsDescription")
  private String additionalParcelsDescription = null;

  @JsonProperty("AdditionalParcelsYN")
  private Boolean additionalParcelsYN = null;

  @JsonProperty("AnchorsCoTenants")
  private String anchorsCoTenants = null;

  @JsonProperty("Appliances")
  @Valid
  private List<OrgResoMetadataEnumsAppliances> appliances = null;

  @JsonProperty("ArchitecturalStyle")
  @Valid
  private List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle = null;

  @JsonProperty("AssociationAmenities")
  @Valid
  private List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities = null;

  @JsonProperty("AssociationFee")
  private AnyOforgResoMetadataPropertyAssociationFee associationFee = null;

  @JsonProperty("AssociationFee2")
  private AnyOforgResoMetadataPropertyAssociationFee2 associationFee2 = null;

  @JsonProperty("AssociationFee2Frequency")
  private AnyOforgResoMetadataPropertyAssociationFee2Frequency associationFee2Frequency = null;

  @JsonProperty("AssociationFeeFrequency")
  private AnyOforgResoMetadataPropertyAssociationFeeFrequency associationFeeFrequency = null;

  @JsonProperty("AssociationFeeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes = null;

  @JsonProperty("AssociationName")
  private String associationName = null;

  @JsonProperty("AssociationName2")
  private String associationName2 = null;

  @JsonProperty("AssociationPhone")
  private String associationPhone = null;

  @JsonProperty("AssociationPhone2")
  private String associationPhone2 = null;

  @JsonProperty("AssociationYN")
  private Boolean associationYN = null;

  @JsonProperty("AttachedGarageYN")
  private Boolean attachedGarageYN = null;

  @JsonProperty("AvailabilityDate")
  private LocalDate availabilityDate = null;

  @JsonProperty("Basement")
  @Valid
  private List<OrgResoMetadataEnumsBasement> basement = null;

  @JsonProperty("BasementYN")
  private Boolean basementYN = null;

  @JsonProperty("BathroomsFull")
  private AnyOforgResoMetadataPropertyBathroomsFull bathroomsFull = null;

  @JsonProperty("BathroomsHalf")
  private AnyOforgResoMetadataPropertyBathroomsHalf bathroomsHalf = null;

  @JsonProperty("BathroomsOneQuarter")
  private AnyOforgResoMetadataPropertyBathroomsOneQuarter bathroomsOneQuarter = null;

  @JsonProperty("BathroomsPartial")
  private AnyOforgResoMetadataPropertyBathroomsPartial bathroomsPartial = null;

  @JsonProperty("BathroomsThreeQuarter")
  private AnyOforgResoMetadataPropertyBathroomsThreeQuarter bathroomsThreeQuarter = null;

  @JsonProperty("BathroomsTotalInteger")
  private AnyOforgResoMetadataPropertyBathroomsTotalInteger bathroomsTotalInteger = null;

  @JsonProperty("BedroomsPossible")
  private AnyOforgResoMetadataPropertyBedroomsPossible bedroomsPossible = null;

  @JsonProperty("BedroomsTotal")
  private AnyOforgResoMetadataPropertyBedroomsTotal bedroomsTotal = null;

  @JsonProperty("BelowGradeFinishedArea")
  private AnyOforgResoMetadataPropertyBelowGradeFinishedArea belowGradeFinishedArea = null;

  @JsonProperty("BelowGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyBelowGradeFinishedAreaSource belowGradeFinishedAreaSource = null;

  @JsonProperty("BelowGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits = null;

  @JsonProperty("BodyType")
  @Valid
  private List<OrgResoMetadataEnumsBodyType> bodyType = null;

  @JsonProperty("BuilderModel")
  private String builderModel = null;

  @JsonProperty("BuilderName")
  private String builderName = null;

  @JsonProperty("BuildingAreaSource")
  private AnyOforgResoMetadataPropertyBuildingAreaSource buildingAreaSource = null;

  @JsonProperty("BuildingAreaTotal")
  private AnyOforgResoMetadataPropertyBuildingAreaTotal buildingAreaTotal = null;

  @JsonProperty("BuildingAreaUnits")
  private AnyOforgResoMetadataPropertyBuildingAreaUnits buildingAreaUnits = null;

  @JsonProperty("BuildingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures = null;

  @JsonProperty("BuildingName")
  private String buildingName = null;

  @JsonProperty("BusinessName")
  private String businessName = null;

  @JsonProperty("BusinessType")
  @Valid
  private List<OrgResoMetadataEnumsBusinessType> businessType = null;

  @JsonProperty("BuyerAgencyCompensation")
  private String buyerAgencyCompensation = null;

  @JsonProperty("BuyerAgencyCompensationType")
  private AnyOforgResoMetadataPropertyBuyerAgencyCompensationType buyerAgencyCompensationType = null;

  @JsonProperty("BuyerAgentAOR")
  private AnyOforgResoMetadataPropertyBuyerAgentAOR buyerAgentAOR = null;

  @JsonProperty("BuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation = null;

  @JsonProperty("BuyerAgentDirectPhone")
  private String buyerAgentDirectPhone = null;

  @JsonProperty("BuyerAgentEmail")
  private String buyerAgentEmail = null;

  @JsonProperty("BuyerAgentFax")
  private String buyerAgentFax = null;

  @JsonProperty("BuyerAgentFirstName")
  private String buyerAgentFirstName = null;

  @JsonProperty("BuyerAgentFullName")
  private String buyerAgentFullName = null;

  @JsonProperty("BuyerAgentHomePhone")
  private String buyerAgentHomePhone = null;

  @JsonProperty("BuyerAgentKey")
  private String buyerAgentKey = null;

  @JsonProperty("BuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyBuyerAgentKeyNumeric buyerAgentKeyNumeric = null;

  @JsonProperty("BuyerAgentLastName")
  private String buyerAgentLastName = null;

  @JsonProperty("BuyerAgentMiddleName")
  private String buyerAgentMiddleName = null;

  @JsonProperty("BuyerAgentMlsId")
  private String buyerAgentMlsId = null;

  @JsonProperty("BuyerAgentMobilePhone")
  private String buyerAgentMobilePhone = null;

  @JsonProperty("BuyerAgentNamePrefix")
  private String buyerAgentNamePrefix = null;

  @JsonProperty("BuyerAgentNameSuffix")
  private String buyerAgentNameSuffix = null;

  @JsonProperty("BuyerAgentOfficePhone")
  private String buyerAgentOfficePhone = null;

  @JsonProperty("BuyerAgentOfficePhoneExt")
  private String buyerAgentOfficePhoneExt = null;

  @JsonProperty("BuyerAgentPager")
  private String buyerAgentPager = null;

  @JsonProperty("BuyerAgentPreferredPhone")
  private String buyerAgentPreferredPhone = null;

  @JsonProperty("BuyerAgentPreferredPhoneExt")
  private String buyerAgentPreferredPhoneExt = null;

  @JsonProperty("BuyerAgentStateLicense")
  private String buyerAgentStateLicense = null;

  @JsonProperty("BuyerAgentTollFreePhone")
  private String buyerAgentTollFreePhone = null;

  @JsonProperty("BuyerAgentURL")
  private String buyerAgentURL = null;

  @JsonProperty("BuyerAgentVoiceMail")
  private String buyerAgentVoiceMail = null;

  @JsonProperty("BuyerAgentVoiceMailExt")
  private String buyerAgentVoiceMailExt = null;

  @JsonProperty("BuyerFinancing")
  @Valid
  private List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing = null;

  @JsonProperty("BuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyBuyerOfficeAOR buyerOfficeAOR = null;

  @JsonProperty("BuyerOfficeEmail")
  private String buyerOfficeEmail = null;

  @JsonProperty("BuyerOfficeFax")
  private String buyerOfficeFax = null;

  @JsonProperty("BuyerOfficeKey")
  private String buyerOfficeKey = null;

  @JsonProperty("BuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric buyerOfficeKeyNumeric = null;

  @JsonProperty("BuyerOfficeMlsId")
  private String buyerOfficeMlsId = null;

  @JsonProperty("BuyerOfficeName")
  private String buyerOfficeName = null;

  @JsonProperty("BuyerOfficePhone")
  private String buyerOfficePhone = null;

  @JsonProperty("BuyerOfficePhoneExt")
  private String buyerOfficePhoneExt = null;

  @JsonProperty("BuyerOfficeURL")
  private String buyerOfficeURL = null;

  @JsonProperty("BuyerTeamKey")
  private String buyerTeamKey = null;

  @JsonProperty("BuyerTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyBuyerTeamKeyNumeric buyerTeamKeyNumeric = null;

  @JsonProperty("BuyerTeamName")
  private String buyerTeamName = null;

  @JsonProperty("CableTvExpense")
  private AnyOforgResoMetadataPropertyCableTvExpense cableTvExpense = null;

  @JsonProperty("CancellationDate")
  private LocalDate cancellationDate = null;

  @JsonProperty("CapRate")
  private AnyOforgResoMetadataPropertyCapRate capRate = null;

  @JsonProperty("CarportSpaces")
  private AnyOforgResoMetadataPropertyCarportSpaces carportSpaces = null;

  @JsonProperty("CarportYN")
  private Boolean carportYN = null;

  @JsonProperty("CarrierRoute")
  private String carrierRoute = null;

  @JsonProperty("City")
  private AnyOforgResoMetadataPropertyCity city = null;

  @JsonProperty("CityRegion")
  private String cityRegion = null;

  @JsonProperty("CloseDate")
  private LocalDate closeDate = null;

  @JsonProperty("ClosePrice")
  private AnyOforgResoMetadataPropertyClosePrice closePrice = null;

  @JsonProperty("CoBuyerAgentAOR")
  private AnyOforgResoMetadataPropertyCoBuyerAgentAOR coBuyerAgentAOR = null;

  @JsonProperty("CoBuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation = null;

  @JsonProperty("CoBuyerAgentDirectPhone")
  private String coBuyerAgentDirectPhone = null;

  @JsonProperty("CoBuyerAgentEmail")
  private String coBuyerAgentEmail = null;

  @JsonProperty("CoBuyerAgentFax")
  private String coBuyerAgentFax = null;

  @JsonProperty("CoBuyerAgentFirstName")
  private String coBuyerAgentFirstName = null;

  @JsonProperty("CoBuyerAgentFullName")
  private String coBuyerAgentFullName = null;

  @JsonProperty("CoBuyerAgentHomePhone")
  private String coBuyerAgentHomePhone = null;

  @JsonProperty("CoBuyerAgentKey")
  private String coBuyerAgentKey = null;

  @JsonProperty("CoBuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric = null;

  @JsonProperty("CoBuyerAgentLastName")
  private String coBuyerAgentLastName = null;

  @JsonProperty("CoBuyerAgentMiddleName")
  private String coBuyerAgentMiddleName = null;

  @JsonProperty("CoBuyerAgentMlsId")
  private String coBuyerAgentMlsId = null;

  @JsonProperty("CoBuyerAgentMobilePhone")
  private String coBuyerAgentMobilePhone = null;

  @JsonProperty("CoBuyerAgentNamePrefix")
  private String coBuyerAgentNamePrefix = null;

  @JsonProperty("CoBuyerAgentNameSuffix")
  private String coBuyerAgentNameSuffix = null;

  @JsonProperty("CoBuyerAgentOfficePhone")
  private String coBuyerAgentOfficePhone = null;

  @JsonProperty("CoBuyerAgentOfficePhoneExt")
  private String coBuyerAgentOfficePhoneExt = null;

  @JsonProperty("CoBuyerAgentPager")
  private String coBuyerAgentPager = null;

  @JsonProperty("CoBuyerAgentPreferredPhone")
  private String coBuyerAgentPreferredPhone = null;

  @JsonProperty("CoBuyerAgentPreferredPhoneExt")
  private String coBuyerAgentPreferredPhoneExt = null;

  @JsonProperty("CoBuyerAgentStateLicense")
  private String coBuyerAgentStateLicense = null;

  @JsonProperty("CoBuyerAgentTollFreePhone")
  private String coBuyerAgentTollFreePhone = null;

  @JsonProperty("CoBuyerAgentURL")
  private String coBuyerAgentURL = null;

  @JsonProperty("CoBuyerAgentVoiceMail")
  private String coBuyerAgentVoiceMail = null;

  @JsonProperty("CoBuyerAgentVoiceMailExt")
  private String coBuyerAgentVoiceMailExt = null;

  @JsonProperty("CoBuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyCoBuyerOfficeAOR coBuyerOfficeAOR = null;

  @JsonProperty("CoBuyerOfficeEmail")
  private String coBuyerOfficeEmail = null;

  @JsonProperty("CoBuyerOfficeFax")
  private String coBuyerOfficeFax = null;

  @JsonProperty("CoBuyerOfficeKey")
  private String coBuyerOfficeKey = null;

  @JsonProperty("CoBuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric = null;

  @JsonProperty("CoBuyerOfficeMlsId")
  private String coBuyerOfficeMlsId = null;

  @JsonProperty("CoBuyerOfficeName")
  private String coBuyerOfficeName = null;

  @JsonProperty("CoBuyerOfficePhone")
  private String coBuyerOfficePhone = null;

  @JsonProperty("CoBuyerOfficePhoneExt")
  private String coBuyerOfficePhoneExt = null;

  @JsonProperty("CoBuyerOfficeURL")
  private String coBuyerOfficeURL = null;

  @JsonProperty("CoListAgentAOR")
  private AnyOforgResoMetadataPropertyCoListAgentAOR coListAgentAOR = null;

  @JsonProperty("CoListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation = null;

  @JsonProperty("CoListAgentDirectPhone")
  private String coListAgentDirectPhone = null;

  @JsonProperty("CoListAgentEmail")
  private String coListAgentEmail = null;

  @JsonProperty("CoListAgentFax")
  private String coListAgentFax = null;

  @JsonProperty("CoListAgentFirstName")
  private String coListAgentFirstName = null;

  @JsonProperty("CoListAgentFullName")
  private String coListAgentFullName = null;

  @JsonProperty("CoListAgentHomePhone")
  private String coListAgentHomePhone = null;

  @JsonProperty("CoListAgentKey")
  private String coListAgentKey = null;

  @JsonProperty("CoListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCoListAgentKeyNumeric coListAgentKeyNumeric = null;

  @JsonProperty("CoListAgentLastName")
  private String coListAgentLastName = null;

  @JsonProperty("CoListAgentMiddleName")
  private String coListAgentMiddleName = null;

  @JsonProperty("CoListAgentMlsId")
  private String coListAgentMlsId = null;

  @JsonProperty("CoListAgentMobilePhone")
  private String coListAgentMobilePhone = null;

  @JsonProperty("CoListAgentNamePrefix")
  private String coListAgentNamePrefix = null;

  @JsonProperty("CoListAgentNameSuffix")
  private String coListAgentNameSuffix = null;

  @JsonProperty("CoListAgentOfficePhone")
  private String coListAgentOfficePhone = null;

  @JsonProperty("CoListAgentOfficePhoneExt")
  private String coListAgentOfficePhoneExt = null;

  @JsonProperty("CoListAgentPager")
  private String coListAgentPager = null;

  @JsonProperty("CoListAgentPreferredPhone")
  private String coListAgentPreferredPhone = null;

  @JsonProperty("CoListAgentPreferredPhoneExt")
  private String coListAgentPreferredPhoneExt = null;

  @JsonProperty("CoListAgentStateLicense")
  private String coListAgentStateLicense = null;

  @JsonProperty("CoListAgentTollFreePhone")
  private String coListAgentTollFreePhone = null;

  @JsonProperty("CoListAgentURL")
  private String coListAgentURL = null;

  @JsonProperty("CoListAgentVoiceMail")
  private String coListAgentVoiceMail = null;

  @JsonProperty("CoListAgentVoiceMailExt")
  private String coListAgentVoiceMailExt = null;

  @JsonProperty("CoListOfficeAOR")
  private AnyOforgResoMetadataPropertyCoListOfficeAOR coListOfficeAOR = null;

  @JsonProperty("CoListOfficeEmail")
  private String coListOfficeEmail = null;

  @JsonProperty("CoListOfficeFax")
  private String coListOfficeFax = null;

  @JsonProperty("CoListOfficeKey")
  private String coListOfficeKey = null;

  @JsonProperty("CoListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCoListOfficeKeyNumeric coListOfficeKeyNumeric = null;

  @JsonProperty("CoListOfficeMlsId")
  private String coListOfficeMlsId = null;

  @JsonProperty("CoListOfficeName")
  private String coListOfficeName = null;

  @JsonProperty("CoListOfficePhone")
  private String coListOfficePhone = null;

  @JsonProperty("CoListOfficePhoneExt")
  private String coListOfficePhoneExt = null;

  @JsonProperty("CoListOfficeURL")
  private String coListOfficeURL = null;

  @JsonProperty("CommonInterest")
  private AnyOforgResoMetadataPropertyCommonInterest commonInterest = null;

  @JsonProperty("CommonWalls")
  @Valid
  private List<OrgResoMetadataEnumsCommonWalls> commonWalls = null;

  @JsonProperty("CommunityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures = null;

  @JsonProperty("Concessions")
  private AnyOforgResoMetadataPropertyConcessions concessions = null;

  @JsonProperty("ConcessionsAmount")
  private AnyOforgResoMetadataPropertyConcessionsAmount concessionsAmount = null;

  @JsonProperty("ConcessionsComments")
  private String concessionsComments = null;

  @JsonProperty("ConstructionMaterials")
  @Valid
  private List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials = null;

  @JsonProperty("ContinentRegion")
  private String continentRegion = null;

  @JsonProperty("Contingency")
  private String contingency = null;

  @JsonProperty("ContingentDate")
  private LocalDate contingentDate = null;

  @JsonProperty("ContractStatusChangeDate")
  private LocalDate contractStatusChangeDate = null;

  @JsonProperty("Cooling")
  @Valid
  private List<OrgResoMetadataEnumsCooling> cooling = null;

  @JsonProperty("CoolingYN")
  private Boolean coolingYN = null;

  @JsonProperty("CopyrightNotice")
  private String copyrightNotice = null;

  @JsonProperty("Country")
  private AnyOforgResoMetadataPropertyCountry country = null;

  @JsonProperty("CountryRegion")
  private String countryRegion = null;

  @JsonProperty("CountyOrParish")
  private AnyOforgResoMetadataPropertyCountyOrParish countyOrParish = null;

  @JsonProperty("CoveredSpaces")
  private AnyOforgResoMetadataPropertyCoveredSpaces coveredSpaces = null;

  @JsonProperty("CropsIncludedYN")
  private Boolean cropsIncludedYN = null;

  @JsonProperty("CrossStreet")
  private String crossStreet = null;

  @JsonProperty("CultivatedArea")
  private AnyOforgResoMetadataPropertyCultivatedArea cultivatedArea = null;

  @JsonProperty("CumulativeDaysOnMarket")
  private AnyOforgResoMetadataPropertyCumulativeDaysOnMarket cumulativeDaysOnMarket = null;

  @JsonProperty("CurrentFinancing")
  @Valid
  private List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing = null;

  @JsonProperty("CurrentUse")
  @Valid
  private List<OrgResoMetadataEnumsCurrentUse> currentUse = null;

  @JsonProperty("DOH1")
  private String doH1 = null;

  @JsonProperty("DOH2")
  private String doH2 = null;

  @JsonProperty("DOH3")
  private String doH3 = null;

  @JsonProperty("DaysOnMarket")
  private AnyOforgResoMetadataPropertyDaysOnMarket daysOnMarket = null;

  @JsonProperty("DevelopmentStatus")
  @Valid
  private List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus = null;

  @JsonProperty("DirectionFaces")
  private AnyOforgResoMetadataPropertyDirectionFaces directionFaces = null;

  @JsonProperty("Directions")
  private String directions = null;

  @JsonProperty("Disclaimer")
  private String disclaimer = null;

  @JsonProperty("Disclosures")
  @Valid
  private List<OrgResoMetadataEnumsDisclosures> disclosures = null;

  @JsonProperty("DistanceToBusComments")
  private String distanceToBusComments = null;

  @JsonProperty("DistanceToBusNumeric")
  private AnyOforgResoMetadataPropertyDistanceToBusNumeric distanceToBusNumeric = null;

  @JsonProperty("DistanceToBusUnits")
  private AnyOforgResoMetadataPropertyDistanceToBusUnits distanceToBusUnits = null;

  @JsonProperty("DistanceToElectricComments")
  private String distanceToElectricComments = null;

  @JsonProperty("DistanceToElectricNumeric")
  private AnyOforgResoMetadataPropertyDistanceToElectricNumeric distanceToElectricNumeric = null;

  @JsonProperty("DistanceToElectricUnits")
  private AnyOforgResoMetadataPropertyDistanceToElectricUnits distanceToElectricUnits = null;

  @JsonProperty("DistanceToFreewayComments")
  private String distanceToFreewayComments = null;

  @JsonProperty("DistanceToFreewayNumeric")
  private AnyOforgResoMetadataPropertyDistanceToFreewayNumeric distanceToFreewayNumeric = null;

  @JsonProperty("DistanceToFreewayUnits")
  private AnyOforgResoMetadataPropertyDistanceToFreewayUnits distanceToFreewayUnits = null;

  @JsonProperty("DistanceToGasComments")
  private String distanceToGasComments = null;

  @JsonProperty("DistanceToGasNumeric")
  private AnyOforgResoMetadataPropertyDistanceToGasNumeric distanceToGasNumeric = null;

  @JsonProperty("DistanceToGasUnits")
  private AnyOforgResoMetadataPropertyDistanceToGasUnits distanceToGasUnits = null;

  @JsonProperty("DistanceToPhoneServiceComments")
  private String distanceToPhoneServiceComments = null;

  @JsonProperty("DistanceToPhoneServiceNumeric")
  private AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric = null;

  @JsonProperty("DistanceToPhoneServiceUnits")
  private AnyOforgResoMetadataPropertyDistanceToPhoneServiceUnits distanceToPhoneServiceUnits = null;

  @JsonProperty("DistanceToPlaceofWorshipComments")
  private String distanceToPlaceofWorshipComments = null;

  @JsonProperty("DistanceToPlaceofWorshipNumeric")
  private AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric = null;

  @JsonProperty("DistanceToPlaceofWorshipUnits")
  private AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits = null;

  @JsonProperty("DistanceToSchoolBusComments")
  private String distanceToSchoolBusComments = null;

  @JsonProperty("DistanceToSchoolBusNumeric")
  private AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric distanceToSchoolBusNumeric = null;

  @JsonProperty("DistanceToSchoolBusUnits")
  private AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits distanceToSchoolBusUnits = null;

  @JsonProperty("DistanceToSchoolsComments")
  private String distanceToSchoolsComments = null;

  @JsonProperty("DistanceToSchoolsNumeric")
  private AnyOforgResoMetadataPropertyDistanceToSchoolsNumeric distanceToSchoolsNumeric = null;

  @JsonProperty("DistanceToSchoolsUnits")
  private AnyOforgResoMetadataPropertyDistanceToSchoolsUnits distanceToSchoolsUnits = null;

  @JsonProperty("DistanceToSewerComments")
  private String distanceToSewerComments = null;

  @JsonProperty("DistanceToSewerNumeric")
  private AnyOforgResoMetadataPropertyDistanceToSewerNumeric distanceToSewerNumeric = null;

  @JsonProperty("DistanceToSewerUnits")
  private AnyOforgResoMetadataPropertyDistanceToSewerUnits distanceToSewerUnits = null;

  @JsonProperty("DistanceToShoppingComments")
  private String distanceToShoppingComments = null;

  @JsonProperty("DistanceToShoppingNumeric")
  private AnyOforgResoMetadataPropertyDistanceToShoppingNumeric distanceToShoppingNumeric = null;

  @JsonProperty("DistanceToShoppingUnits")
  private AnyOforgResoMetadataPropertyDistanceToShoppingUnits distanceToShoppingUnits = null;

  @JsonProperty("DistanceToStreetComments")
  private String distanceToStreetComments = null;

  @JsonProperty("DistanceToStreetNumeric")
  private AnyOforgResoMetadataPropertyDistanceToStreetNumeric distanceToStreetNumeric = null;

  @JsonProperty("DistanceToStreetUnits")
  private AnyOforgResoMetadataPropertyDistanceToStreetUnits distanceToStreetUnits = null;

  @JsonProperty("DistanceToWaterComments")
  private String distanceToWaterComments = null;

  @JsonProperty("DistanceToWaterNumeric")
  private AnyOforgResoMetadataPropertyDistanceToWaterNumeric distanceToWaterNumeric = null;

  @JsonProperty("DistanceToWaterUnits")
  private AnyOforgResoMetadataPropertyDistanceToWaterUnits distanceToWaterUnits = null;

  @JsonProperty("DocumentsAvailable")
  @Valid
  private List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable = null;

  @JsonProperty("DocumentsChangeTimestamp")
  private OffsetDateTime documentsChangeTimestamp = null;

  @JsonProperty("DocumentsCount")
  private AnyOforgResoMetadataPropertyDocumentsCount documentsCount = null;

  @JsonProperty("DoorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsDoorFeatures> doorFeatures = null;

  @JsonProperty("DualVariableCompensationYN")
  private Boolean dualVariableCompensationYN = null;

  @JsonProperty("Electric")
  @Valid
  private List<OrgResoMetadataEnumsElectric> electric = null;

  @JsonProperty("ElectricExpense")
  private AnyOforgResoMetadataPropertyElectricExpense electricExpense = null;

  @JsonProperty("ElectricOnPropertyYN")
  private Boolean electricOnPropertyYN = null;

  @JsonProperty("ElementarySchool")
  private AnyOforgResoMetadataPropertyElementarySchool elementarySchool = null;

  @JsonProperty("ElementarySchoolDistrict")
  private AnyOforgResoMetadataPropertyElementarySchoolDistrict elementarySchoolDistrict = null;

  @JsonProperty("Elevation")
  private AnyOforgResoMetadataPropertyElevation elevation = null;

  @JsonProperty("ElevationUnits")
  private AnyOforgResoMetadataPropertyElevationUnits elevationUnits = null;

  @JsonProperty("EntryLevel")
  private AnyOforgResoMetadataPropertyEntryLevel entryLevel = null;

  @JsonProperty("EntryLocation")
  private String entryLocation = null;

  @JsonProperty("Exclusions")
  private String exclusions = null;

  @JsonProperty("ExistingLeaseType")
  @Valid
  private List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType = null;

  @JsonProperty("ExpirationDate")
  private LocalDate expirationDate = null;

  @JsonProperty("ExteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures = null;

  @JsonProperty("FarmCreditServiceInclYN")
  private Boolean farmCreditServiceInclYN = null;

  @JsonProperty("FarmLandAreaSource")
  private AnyOforgResoMetadataPropertyFarmLandAreaSource farmLandAreaSource = null;

  @JsonProperty("FarmLandAreaUnits")
  private AnyOforgResoMetadataPropertyFarmLandAreaUnits farmLandAreaUnits = null;

  @JsonProperty("Fencing")
  @Valid
  private List<OrgResoMetadataEnumsFencing> fencing = null;

  @JsonProperty("FinancialDataSource")
  @Valid
  private List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource = null;

  @JsonProperty("FireplaceFeatures")
  @Valid
  private List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures = null;

  @JsonProperty("FireplaceYN")
  private Boolean fireplaceYN = null;

  @JsonProperty("FireplacesTotal")
  private AnyOforgResoMetadataPropertyFireplacesTotal fireplacesTotal = null;

  @JsonProperty("Flooring")
  @Valid
  private List<OrgResoMetadataEnumsFlooring> flooring = null;

  @JsonProperty("FoundationArea")
  private AnyOforgResoMetadataPropertyFoundationArea foundationArea = null;

  @JsonProperty("FoundationDetails")
  @Valid
  private List<OrgResoMetadataEnumsFoundationDetails> foundationDetails = null;

  @JsonProperty("FrontageLength")
  private String frontageLength = null;

  @JsonProperty("FrontageType")
  @Valid
  private List<OrgResoMetadataEnumsFrontageType> frontageType = null;

  @JsonProperty("FuelExpense")
  private AnyOforgResoMetadataPropertyFuelExpense fuelExpense = null;

  @JsonProperty("Furnished")
  private AnyOforgResoMetadataPropertyFurnished furnished = null;

  @JsonProperty("FurnitureReplacementExpense")
  private AnyOforgResoMetadataPropertyFurnitureReplacementExpense furnitureReplacementExpense = null;

  @JsonProperty("GarageSpaces")
  private AnyOforgResoMetadataPropertyGarageSpaces garageSpaces = null;

  @JsonProperty("GarageYN")
  private Boolean garageYN = null;

  @JsonProperty("GardenerExpense")
  private AnyOforgResoMetadataPropertyGardenerExpense gardenerExpense = null;

  @JsonProperty("GrazingPermitsBlmYN")
  private Boolean grazingPermitsBlmYN = null;

  @JsonProperty("GrazingPermitsForestServiceYN")
  private Boolean grazingPermitsForestServiceYN = null;

  @JsonProperty("GrazingPermitsPrivateYN")
  private Boolean grazingPermitsPrivateYN = null;

  @JsonProperty("GreenBuildingVerificationType")
  @Valid
  private List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType = null;

  @JsonProperty("GreenEnergyEfficient")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient = null;

  @JsonProperty("GreenEnergyGeneration")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration = null;

  @JsonProperty("GreenIndoorAirQuality")
  @Valid
  private List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality = null;

  @JsonProperty("GreenLocation")
  @Valid
  private List<OrgResoMetadataEnumsGreenLocation> greenLocation = null;

  @JsonProperty("GreenSustainability")
  @Valid
  private List<OrgResoMetadataEnumsGreenSustainability> greenSustainability = null;

  @JsonProperty("GreenWaterConservation")
  @Valid
  private List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation = null;

  @JsonProperty("GrossIncome")
  private AnyOforgResoMetadataPropertyGrossIncome grossIncome = null;

  @JsonProperty("GrossScheduledIncome")
  private AnyOforgResoMetadataPropertyGrossScheduledIncome grossScheduledIncome = null;

  @JsonProperty("HabitableResidenceYN")
  private Boolean habitableResidenceYN = null;

  @JsonProperty("Heating")
  @Valid
  private List<OrgResoMetadataEnumsHeating> heating = null;

  @JsonProperty("HeatingYN")
  private Boolean heatingYN = null;

  @JsonProperty("HighSchool")
  private AnyOforgResoMetadataPropertyHighSchool highSchool = null;

  @JsonProperty("HighSchoolDistrict")
  private AnyOforgResoMetadataPropertyHighSchoolDistrict highSchoolDistrict = null;

  @JsonProperty("HomeWarrantyYN")
  private Boolean homeWarrantyYN = null;

  @JsonProperty("HorseAmenities")
  @Valid
  private List<OrgResoMetadataEnumsHorseAmenities> horseAmenities = null;

  @JsonProperty("HorseYN")
  private Boolean horseYN = null;

  @JsonProperty("HoursDaysOfOperation")
  @Valid
  private List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation = null;

  @JsonProperty("HoursDaysOfOperationDescription")
  private String hoursDaysOfOperationDescription = null;

  @JsonProperty("Inclusions")
  private String inclusions = null;

  @JsonProperty("IncomeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes = null;

  @JsonProperty("InsuranceExpense")
  private AnyOforgResoMetadataPropertyInsuranceExpense insuranceExpense = null;

  @JsonProperty("InteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures = null;

  @JsonProperty("InternetAddressDisplayYN")
  private Boolean internetAddressDisplayYN = null;

  @JsonProperty("InternetAutomatedValuationDisplayYN")
  private Boolean internetAutomatedValuationDisplayYN = null;

  @JsonProperty("InternetConsumerCommentYN")
  private Boolean internetConsumerCommentYN = null;

  @JsonProperty("InternetEntireListingDisplayYN")
  private Boolean internetEntireListingDisplayYN = null;

  @JsonProperty("IrrigationSource")
  @Valid
  private List<OrgResoMetadataEnumsIrrigationSource> irrigationSource = null;

  @JsonProperty("IrrigationWaterRightsAcres")
  private AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres irrigationWaterRightsAcres = null;

  @JsonProperty("IrrigationWaterRightsYN")
  private Boolean irrigationWaterRightsYN = null;

  @JsonProperty("LaborInformation")
  @Valid
  private List<OrgResoMetadataEnumsLaborInformation> laborInformation = null;

  @JsonProperty("LandLeaseAmount")
  private AnyOforgResoMetadataPropertyLandLeaseAmount landLeaseAmount = null;

  @JsonProperty("LandLeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyLandLeaseAmountFrequency landLeaseAmountFrequency = null;

  @JsonProperty("LandLeaseExpirationDate")
  private LocalDate landLeaseExpirationDate = null;

  @JsonProperty("LandLeaseYN")
  private Boolean landLeaseYN = null;

  @JsonProperty("Latitude")
  private AnyOforgResoMetadataPropertyLatitude latitude = null;

  @JsonProperty("LaundryFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures = null;

  @JsonProperty("LeasableArea")
  private AnyOforgResoMetadataPropertyLeasableArea leasableArea = null;

  @JsonProperty("LeasableAreaUnits")
  private AnyOforgResoMetadataPropertyLeasableAreaUnits leasableAreaUnits = null;

  @JsonProperty("LeaseAmount")
  private AnyOforgResoMetadataPropertyLeaseAmount leaseAmount = null;

  @JsonProperty("LeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyLeaseAmountFrequency leaseAmountFrequency = null;

  @JsonProperty("LeaseAssignableYN")
  private Boolean leaseAssignableYN = null;

  @JsonProperty("LeaseConsideredYN")
  private Boolean leaseConsideredYN = null;

  @JsonProperty("LeaseExpiration")
  private LocalDate leaseExpiration = null;

  @JsonProperty("LeaseRenewalCompensation")
  @Valid
  private List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation = null;

  @JsonProperty("LeaseRenewalOptionYN")
  private Boolean leaseRenewalOptionYN = null;

  @JsonProperty("LeaseTerm")
  private AnyOforgResoMetadataPropertyLeaseTerm leaseTerm = null;

  @JsonProperty("Levels")
  @Valid
  private List<OrgResoMetadataEnumsLevels> levels = null;

  @JsonProperty("License1")
  private String license1 = null;

  @JsonProperty("License2")
  private String license2 = null;

  @JsonProperty("License3")
  private String license3 = null;

  @JsonProperty("LicensesExpense")
  private AnyOforgResoMetadataPropertyLicensesExpense licensesExpense = null;

  @JsonProperty("ListAOR")
  private AnyOforgResoMetadataPropertyListAOR listAOR = null;

  @JsonProperty("ListAgentAOR")
  private AnyOforgResoMetadataPropertyListAgentAOR listAgentAOR = null;

  @JsonProperty("ListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation = null;

  @JsonProperty("ListAgentDirectPhone")
  private String listAgentDirectPhone = null;

  @JsonProperty("ListAgentEmail")
  private String listAgentEmail = null;

  @JsonProperty("ListAgentFax")
  private String listAgentFax = null;

  @JsonProperty("ListAgentFirstName")
  private String listAgentFirstName = null;

  @JsonProperty("ListAgentFullName")
  private String listAgentFullName = null;

  @JsonProperty("ListAgentHomePhone")
  private String listAgentHomePhone = null;

  @JsonProperty("ListAgentKey")
  private String listAgentKey = null;

  @JsonProperty("ListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyListAgentKeyNumeric listAgentKeyNumeric = null;

  @JsonProperty("ListAgentLastName")
  private String listAgentLastName = null;

  @JsonProperty("ListAgentMiddleName")
  private String listAgentMiddleName = null;

  @JsonProperty("ListAgentMlsId")
  private String listAgentMlsId = null;

  @JsonProperty("ListAgentMobilePhone")
  private String listAgentMobilePhone = null;

  @JsonProperty("ListAgentNamePrefix")
  private String listAgentNamePrefix = null;

  @JsonProperty("ListAgentNameSuffix")
  private String listAgentNameSuffix = null;

  @JsonProperty("ListAgentOfficePhone")
  private String listAgentOfficePhone = null;

  @JsonProperty("ListAgentOfficePhoneExt")
  private String listAgentOfficePhoneExt = null;

  @JsonProperty("ListAgentPager")
  private String listAgentPager = null;

  @JsonProperty("ListAgentPreferredPhone")
  private String listAgentPreferredPhone = null;

  @JsonProperty("ListAgentPreferredPhoneExt")
  private String listAgentPreferredPhoneExt = null;

  @JsonProperty("ListAgentStateLicense")
  private String listAgentStateLicense = null;

  @JsonProperty("ListAgentTollFreePhone")
  private String listAgentTollFreePhone = null;

  @JsonProperty("ListAgentURL")
  private String listAgentURL = null;

  @JsonProperty("ListAgentVoiceMail")
  private String listAgentVoiceMail = null;

  @JsonProperty("ListAgentVoiceMailExt")
  private String listAgentVoiceMailExt = null;

  @JsonProperty("ListOfficeAOR")
  private AnyOforgResoMetadataPropertyListOfficeAOR listOfficeAOR = null;

  @JsonProperty("ListOfficeEmail")
  private String listOfficeEmail = null;

  @JsonProperty("ListOfficeFax")
  private String listOfficeFax = null;

  @JsonProperty("ListOfficeKey")
  private String listOfficeKey = null;

  @JsonProperty("ListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyListOfficeKeyNumeric listOfficeKeyNumeric = null;

  @JsonProperty("ListOfficeMlsId")
  private String listOfficeMlsId = null;

  @JsonProperty("ListOfficeName")
  private String listOfficeName = null;

  @JsonProperty("ListOfficePhone")
  private String listOfficePhone = null;

  @JsonProperty("ListOfficePhoneExt")
  private String listOfficePhoneExt = null;

  @JsonProperty("ListOfficeURL")
  private String listOfficeURL = null;

  @JsonProperty("ListPrice")
  private AnyOforgResoMetadataPropertyListPrice listPrice = null;

  @JsonProperty("ListPriceLow")
  private AnyOforgResoMetadataPropertyListPriceLow listPriceLow = null;

  @JsonProperty("ListTeamKey")
  private String listTeamKey = null;

  @JsonProperty("ListTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyListTeamKeyNumeric listTeamKeyNumeric = null;

  @JsonProperty("ListTeamName")
  private String listTeamName = null;

  @JsonProperty("ListingAgreement")
  private AnyOforgResoMetadataPropertyListingAgreement listingAgreement = null;

  @JsonProperty("ListingContractDate")
  private LocalDate listingContractDate = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ListingService")
  private AnyOforgResoMetadataPropertyListingService listingService = null;

  @JsonProperty("ListingTerms")
  @Valid
  private List<OrgResoMetadataEnumsListingTerms> listingTerms = null;

  @JsonProperty("LivingArea")
  private AnyOforgResoMetadataPropertyLivingArea livingArea = null;

  @JsonProperty("LivingAreaSource")
  private AnyOforgResoMetadataPropertyLivingAreaSource livingAreaSource = null;

  @JsonProperty("LivingAreaUnits")
  private AnyOforgResoMetadataPropertyLivingAreaUnits livingAreaUnits = null;

  @JsonProperty("LockBoxLocation")
  private String lockBoxLocation = null;

  @JsonProperty("LockBoxSerialNumber")
  private String lockBoxSerialNumber = null;

  @JsonProperty("LockBoxType")
  @Valid
  private List<OrgResoMetadataEnumsLockBoxType> lockBoxType = null;

  @JsonProperty("Longitude")
  private AnyOforgResoMetadataPropertyLongitude longitude = null;

  @JsonProperty("LotDimensionsSource")
  private AnyOforgResoMetadataPropertyLotDimensionsSource lotDimensionsSource = null;

  @JsonProperty("LotFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLotFeatures> lotFeatures = null;

  @JsonProperty("LotSizeAcres")
  private AnyOforgResoMetadataPropertyLotSizeAcres lotSizeAcres = null;

  @JsonProperty("LotSizeArea")
  private AnyOforgResoMetadataPropertyLotSizeArea lotSizeArea = null;

  @JsonProperty("LotSizeDimensions")
  private String lotSizeDimensions = null;

  @JsonProperty("LotSizeSource")
  private AnyOforgResoMetadataPropertyLotSizeSource lotSizeSource = null;

  @JsonProperty("LotSizeSquareFeet")
  private AnyOforgResoMetadataPropertyLotSizeSquareFeet lotSizeSquareFeet = null;

  @JsonProperty("LotSizeUnits")
  private AnyOforgResoMetadataPropertyLotSizeUnits lotSizeUnits = null;

  @JsonProperty("MLSAreaMajor")
  private AnyOforgResoMetadataPropertyMlSAreaMajor mlSAreaMajor = null;

  @JsonProperty("MLSAreaMinor")
  private AnyOforgResoMetadataPropertyMlSAreaMinor mlSAreaMinor = null;

  @JsonProperty("MainLevelBathrooms")
  private AnyOforgResoMetadataPropertyMainLevelBathrooms mainLevelBathrooms = null;

  @JsonProperty("MainLevelBedrooms")
  private AnyOforgResoMetadataPropertyMainLevelBedrooms mainLevelBedrooms = null;

  @JsonProperty("MaintenanceExpense")
  private AnyOforgResoMetadataPropertyMaintenanceExpense maintenanceExpense = null;

  @JsonProperty("MajorChangeTimestamp")
  private OffsetDateTime majorChangeTimestamp = null;

  @JsonProperty("MajorChangeType")
  private AnyOforgResoMetadataPropertyMajorChangeType majorChangeType = null;

  @JsonProperty("Make")
  private String make = null;

  @JsonProperty("ManagerExpense")
  private AnyOforgResoMetadataPropertyManagerExpense managerExpense = null;

  @JsonProperty("MapCoordinate")
  private String mapCoordinate = null;

  @JsonProperty("MapCoordinateSource")
  private String mapCoordinateSource = null;

  @JsonProperty("MapURL")
  private String mapURL = null;

  @JsonProperty("MiddleOrJuniorSchool")
  private AnyOforgResoMetadataPropertyMiddleOrJuniorSchool middleOrJuniorSchool = null;

  @JsonProperty("MiddleOrJuniorSchoolDistrict")
  private AnyOforgResoMetadataPropertyMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict = null;

  @JsonProperty("MlsStatus")
  private AnyOforgResoMetadataPropertyMlsStatus mlsStatus = null;

  @JsonProperty("MobileDimUnits")
  private AnyOforgResoMetadataPropertyMobileDimUnits mobileDimUnits = null;

  @JsonProperty("MobileHomeRemainsYN")
  private Boolean mobileHomeRemainsYN = null;

  @JsonProperty("MobileLength")
  private AnyOforgResoMetadataPropertyMobileLength mobileLength = null;

  @JsonProperty("MobileWidth")
  private AnyOforgResoMetadataPropertyMobileWidth mobileWidth = null;

  @JsonProperty("Model")
  private String model = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NetOperatingIncome")
  private AnyOforgResoMetadataPropertyNetOperatingIncome netOperatingIncome = null;

  @JsonProperty("NewConstructionYN")
  private Boolean newConstructionYN = null;

  @JsonProperty("NewTaxesExpense")
  private AnyOforgResoMetadataPropertyNewTaxesExpense newTaxesExpense = null;

  @JsonProperty("NumberOfBuildings")
  private AnyOforgResoMetadataPropertyNumberOfBuildings numberOfBuildings = null;

  @JsonProperty("NumberOfFullTimeEmployees")
  private AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees numberOfFullTimeEmployees = null;

  @JsonProperty("NumberOfLots")
  private AnyOforgResoMetadataPropertyNumberOfLots numberOfLots = null;

  @JsonProperty("NumberOfPads")
  private AnyOforgResoMetadataPropertyNumberOfPads numberOfPads = null;

  @JsonProperty("NumberOfPartTimeEmployees")
  private AnyOforgResoMetadataPropertyNumberOfPartTimeEmployees numberOfPartTimeEmployees = null;

  @JsonProperty("NumberOfSeparateElectricMeters")
  private AnyOforgResoMetadataPropertyNumberOfSeparateElectricMeters numberOfSeparateElectricMeters = null;

  @JsonProperty("NumberOfSeparateGasMeters")
  private AnyOforgResoMetadataPropertyNumberOfSeparateGasMeters numberOfSeparateGasMeters = null;

  @JsonProperty("NumberOfSeparateWaterMeters")
  private AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters numberOfSeparateWaterMeters = null;

  @JsonProperty("NumberOfUnitsInCommunity")
  private AnyOforgResoMetadataPropertyNumberOfUnitsInCommunity numberOfUnitsInCommunity = null;

  @JsonProperty("NumberOfUnitsLeased")
  private AnyOforgResoMetadataPropertyNumberOfUnitsLeased numberOfUnitsLeased = null;

  @JsonProperty("NumberOfUnitsMoMo")
  private AnyOforgResoMetadataPropertyNumberOfUnitsMoMo numberOfUnitsMoMo = null;

  @JsonProperty("NumberOfUnitsTotal")
  private AnyOforgResoMetadataPropertyNumberOfUnitsTotal numberOfUnitsTotal = null;

  @JsonProperty("NumberOfUnitsVacant")
  private AnyOforgResoMetadataPropertyNumberOfUnitsVacant numberOfUnitsVacant = null;

  @JsonProperty("OccupantName")
  private String occupantName = null;

  @JsonProperty("OccupantPhone")
  private String occupantPhone = null;

  @JsonProperty("OccupantType")
  private AnyOforgResoMetadataPropertyOccupantType occupantType = null;

  @JsonProperty("OffMarketDate")
  private LocalDate offMarketDate = null;

  @JsonProperty("OffMarketTimestamp")
  private OffsetDateTime offMarketTimestamp = null;

  @JsonProperty("OnMarketDate")
  private LocalDate onMarketDate = null;

  @JsonProperty("OnMarketTimestamp")
  private OffsetDateTime onMarketTimestamp = null;

  @JsonProperty("OpenParkingSpaces")
  private AnyOforgResoMetadataPropertyOpenParkingSpaces openParkingSpaces = null;

  @JsonProperty("OpenParkingYN")
  private Boolean openParkingYN = null;

  @JsonProperty("OperatingExpense")
  private AnyOforgResoMetadataPropertyOperatingExpense operatingExpense = null;

  @JsonProperty("OperatingExpenseIncludes")
  @Valid
  private List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginalListPrice")
  private AnyOforgResoMetadataPropertyOriginalListPrice originalListPrice = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OtherEquipment")
  @Valid
  private List<OrgResoMetadataEnumsOtherEquipment> otherEquipment = null;

  @JsonProperty("OtherExpense")
  private AnyOforgResoMetadataPropertyOtherExpense otherExpense = null;

  @JsonProperty("OtherParking")
  private String otherParking = null;

  @JsonProperty("OtherStructures")
  @Valid
  private List<OrgResoMetadataEnumsOtherStructures> otherStructures = null;

  @JsonProperty("OwnerName")
  private String ownerName = null;

  @JsonProperty("OwnerPays")
  @Valid
  private List<OrgResoMetadataEnumsOwnerPays> ownerPays = null;

  @JsonProperty("OwnerPhone")
  private String ownerPhone = null;

  @JsonProperty("Ownership")
  private String ownership = null;

  @JsonProperty("OwnershipType")
  private AnyOforgResoMetadataPropertyOwnershipType ownershipType = null;

  @JsonProperty("ParcelNumber")
  private String parcelNumber = null;

  @JsonProperty("ParkManagerName")
  private String parkManagerName = null;

  @JsonProperty("ParkManagerPhone")
  private String parkManagerPhone = null;

  @JsonProperty("ParkName")
  private String parkName = null;

  @JsonProperty("ParkingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures = null;

  @JsonProperty("ParkingTotal")
  private AnyOforgResoMetadataPropertyParkingTotal parkingTotal = null;

  @JsonProperty("PastureArea")
  private AnyOforgResoMetadataPropertyPastureArea pastureArea = null;

  @JsonProperty("PatioAndPorchFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures = null;

  @JsonProperty("PendingTimestamp")
  private OffsetDateTime pendingTimestamp = null;

  @JsonProperty("PestControlExpense")
  private AnyOforgResoMetadataPropertyPestControlExpense pestControlExpense = null;

  @JsonProperty("PetsAllowed")
  @Valid
  private List<OrgResoMetadataEnumsPetsAllowed> petsAllowed = null;

  @JsonProperty("PhotosChangeTimestamp")
  private OffsetDateTime photosChangeTimestamp = null;

  @JsonProperty("PhotosCount")
  private AnyOforgResoMetadataPropertyPhotosCount photosCount = null;

  @JsonProperty("PoolExpense")
  private AnyOforgResoMetadataPropertyPoolExpense poolExpense = null;

  @JsonProperty("PoolFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPoolFeatures> poolFeatures = null;

  @JsonProperty("PoolPrivateYN")
  private Boolean poolPrivateYN = null;

  @JsonProperty("Possession")
  @Valid
  private List<OrgResoMetadataEnumsPossession> possession = null;

  @JsonProperty("PossibleUse")
  @Valid
  private List<OrgResoMetadataEnumsPossibleUse> possibleUse = null;

  @JsonProperty("PostalCity")
  private AnyOforgResoMetadataPropertyPostalCity postalCity = null;

  @JsonProperty("PostalCode")
  private String postalCode = null;

  @JsonProperty("PostalCodePlus4")
  private String postalCodePlus4 = null;

  @JsonProperty("PowerProductionType")
  @Valid
  private List<OrgResoMetadataEnumsPowerProductionType> powerProductionType = null;

  @JsonProperty("PreviousListPrice")
  private AnyOforgResoMetadataPropertyPreviousListPrice previousListPrice = null;

  @JsonProperty("PriceChangeTimestamp")
  private OffsetDateTime priceChangeTimestamp = null;

  @JsonProperty("PrivateOfficeRemarks")
  private String privateOfficeRemarks = null;

  @JsonProperty("PrivateRemarks")
  private String privateRemarks = null;

  @JsonProperty("ProfessionalManagementExpense")
  private AnyOforgResoMetadataPropertyProfessionalManagementExpense professionalManagementExpense = null;

  @JsonProperty("PropertyAttachedYN")
  private Boolean propertyAttachedYN = null;

  @JsonProperty("PropertyCondition")
  @Valid
  private List<OrgResoMetadataEnumsPropertyCondition> propertyCondition = null;

  @JsonProperty("PropertySubType")
  private AnyOforgResoMetadataPropertyPropertySubType propertySubType = null;

  @JsonProperty("PropertyType")
  private AnyOforgResoMetadataPropertyPropertyType propertyType = null;

  @JsonProperty("PublicRemarks")
  private String publicRemarks = null;

  @JsonProperty("PublicSurveyRange")
  private String publicSurveyRange = null;

  @JsonProperty("PublicSurveySection")
  private String publicSurveySection = null;

  @JsonProperty("PublicSurveyTownship")
  private String publicSurveyTownship = null;

  @JsonProperty("PurchaseContractDate")
  private LocalDate purchaseContractDate = null;

  @JsonProperty("RVParkingDimensions")
  private String rvParkingDimensions = null;

  @JsonProperty("RangeArea")
  private AnyOforgResoMetadataPropertyRangeArea rangeArea = null;

  @JsonProperty("RentControlYN")
  private Boolean rentControlYN = null;

  @JsonProperty("RentIncludes")
  @Valid
  private List<OrgResoMetadataEnumsRentIncludes> rentIncludes = null;

  @JsonProperty("RoadFrontageType")
  @Valid
  private List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType = null;

  @JsonProperty("RoadResponsibility")
  @Valid
  private List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility = null;

  @JsonProperty("RoadSurfaceType")
  @Valid
  private List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType = null;

  @JsonProperty("Roof")
  @Valid
  private List<OrgResoMetadataEnumsRoof> roof = null;

  @JsonProperty("RoomType")
  @Valid
  private List<OrgResoMetadataEnumsRoomType> roomType = null;

  @JsonProperty("RoomsTotal")
  private AnyOforgResoMetadataPropertyRoomsTotal roomsTotal = null;

  @JsonProperty("SeatingCapacity")
  private AnyOforgResoMetadataPropertySeatingCapacity seatingCapacity = null;

  @JsonProperty("SecurityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures = null;

  @JsonProperty("SeniorCommunityYN")
  private Boolean seniorCommunityYN = null;

  @JsonProperty("SerialU")
  private String serialU = null;

  @JsonProperty("SerialX")
  private String serialX = null;

  @JsonProperty("SerialXX")
  private String serialXX = null;

  @JsonProperty("Sewer")
  @Valid
  private List<OrgResoMetadataEnumsSewer> sewer = null;

  @JsonProperty("ShowingAdvanceNotice")
  private AnyOforgResoMetadataPropertyShowingAdvanceNotice showingAdvanceNotice = null;

  @JsonProperty("ShowingAttendedYN")
  private Boolean showingAttendedYN = null;

  @JsonProperty("ShowingContactName")
  private String showingContactName = null;

  @JsonProperty("ShowingContactPhone")
  private String showingContactPhone = null;

  @JsonProperty("ShowingContactPhoneExt")
  private String showingContactPhoneExt = null;

  @JsonProperty("ShowingContactType")
  @Valid
  private List<OrgResoMetadataEnumsShowingContactType> showingContactType = null;

  @JsonProperty("ShowingDays")
  @Valid
  private List<OrgResoMetadataEnumsShowingDays> showingDays = null;

  @JsonProperty("ShowingEndTime")
  private OffsetDateTime showingEndTime = null;

  @JsonProperty("ShowingInstructions")
  private String showingInstructions = null;

  @JsonProperty("ShowingRequirements")
  @Valid
  private List<OrgResoMetadataEnumsShowingRequirements> showingRequirements = null;

  @JsonProperty("ShowingStartTime")
  private OffsetDateTime showingStartTime = null;

  @JsonProperty("SignOnPropertyYN")
  private Boolean signOnPropertyYN = null;

  @JsonProperty("Skirt")
  @Valid
  private List<OrgResoMetadataEnumsSkirt> skirt = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SpaFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSpaFeatures> spaFeatures = null;

  @JsonProperty("SpaYN")
  private Boolean spaYN = null;

  @JsonProperty("SpecialLicenses")
  @Valid
  private List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses = null;

  @JsonProperty("SpecialListingConditions")
  @Valid
  private List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions = null;

  @JsonProperty("StandardStatus")
  private AnyOforgResoMetadataPropertyStandardStatus standardStatus = null;

  @JsonProperty("StateOrProvince")
  private AnyOforgResoMetadataPropertyStateOrProvince stateOrProvince = null;

  @JsonProperty("StateRegion")
  private String stateRegion = null;

  @JsonProperty("StatusChangeTimestamp")
  private OffsetDateTime statusChangeTimestamp = null;

  @JsonProperty("Stories")
  private AnyOforgResoMetadataPropertyStories stories = null;

  @JsonProperty("StoriesTotal")
  private AnyOforgResoMetadataPropertyStoriesTotal storiesTotal = null;

  @JsonProperty("StreetAdditionalInfo")
  private String streetAdditionalInfo = null;

  @JsonProperty("StreetDirPrefix")
  private AnyOforgResoMetadataPropertyStreetDirPrefix streetDirPrefix = null;

  @JsonProperty("StreetDirSuffix")
  private AnyOforgResoMetadataPropertyStreetDirSuffix streetDirSuffix = null;

  @JsonProperty("StreetName")
  private String streetName = null;

  @JsonProperty("StreetNumber")
  private String streetNumber = null;

  @JsonProperty("StreetNumberNumeric")
  private AnyOforgResoMetadataPropertyStreetNumberNumeric streetNumberNumeric = null;

  @JsonProperty("StreetSuffix")
  private AnyOforgResoMetadataPropertyStreetSuffix streetSuffix = null;

  @JsonProperty("StreetSuffixModifier")
  private String streetSuffixModifier = null;

  @JsonProperty("StructureType")
  @Valid
  private List<OrgResoMetadataEnumsStructureType> structureType = null;

  @JsonProperty("SubAgencyCompensation")
  private String subAgencyCompensation = null;

  @JsonProperty("SubAgencyCompensationType")
  private AnyOforgResoMetadataPropertySubAgencyCompensationType subAgencyCompensationType = null;

  @JsonProperty("SubdivisionName")
  private String subdivisionName = null;

  @JsonProperty("SuppliesExpense")
  private AnyOforgResoMetadataPropertySuppliesExpense suppliesExpense = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  @JsonProperty("SyndicationRemarks")
  private String syndicationRemarks = null;

  @JsonProperty("TaxAnnualAmount")
  private AnyOforgResoMetadataPropertyTaxAnnualAmount taxAnnualAmount = null;

  @JsonProperty("TaxAssessedValue")
  private AnyOforgResoMetadataPropertyTaxAssessedValue taxAssessedValue = null;

  @JsonProperty("TaxBlock")
  private String taxBlock = null;

  @JsonProperty("TaxBookNumber")
  private String taxBookNumber = null;

  @JsonProperty("TaxLegalDescription")
  private String taxLegalDescription = null;

  @JsonProperty("TaxLot")
  private String taxLot = null;

  @JsonProperty("TaxMapNumber")
  private String taxMapNumber = null;

  @JsonProperty("TaxOtherAnnualAssessmentAmount")
  private AnyOforgResoMetadataPropertyTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount = null;

  @JsonProperty("TaxParcelLetter")
  private String taxParcelLetter = null;

  @JsonProperty("TaxStatusCurrent")
  @Valid
  private List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent = null;

  @JsonProperty("TaxTract")
  private String taxTract = null;

  @JsonProperty("TaxYear")
  private AnyOforgResoMetadataPropertyTaxYear taxYear = null;

  @JsonProperty("TenantPays")
  @Valid
  private List<OrgResoMetadataEnumsTenantPays> tenantPays = null;

  @JsonProperty("Topography")
  private String topography = null;

  @JsonProperty("TotalActualRent")
  private AnyOforgResoMetadataPropertyTotalActualRent totalActualRent = null;

  @JsonProperty("Township")
  private String township = null;

  @JsonProperty("TransactionBrokerCompensation")
  private String transactionBrokerCompensation = null;

  @JsonProperty("TransactionBrokerCompensationType")
  private AnyOforgResoMetadataPropertyTransactionBrokerCompensationType transactionBrokerCompensationType = null;

  @JsonProperty("TrashExpense")
  private AnyOforgResoMetadataPropertyTrashExpense trashExpense = null;

  @JsonProperty("UnitNumber")
  private String unitNumber = null;

  @JsonProperty("UnitTypeType")
  @Valid
  private List<OrgResoMetadataEnumsUnitTypeType> unitTypeType = null;

  @JsonProperty("UnitsFurnished")
  private AnyOforgResoMetadataPropertyUnitsFurnished unitsFurnished = null;

  @JsonProperty("UniversalPropertyId")
  private String universalPropertyId = null;

  @JsonProperty("UniversalPropertySubId")
  private String universalPropertySubId = null;

  @JsonProperty("UnparsedAddress")
  private String unparsedAddress = null;

  @JsonProperty("Utilities")
  @Valid
  private List<OrgResoMetadataEnumsUtilities> utilities = null;

  @JsonProperty("VacancyAllowance")
  private AnyOforgResoMetadataPropertyVacancyAllowance vacancyAllowance = null;

  @JsonProperty("VacancyAllowanceRate")
  private AnyOforgResoMetadataPropertyVacancyAllowanceRate vacancyAllowanceRate = null;

  @JsonProperty("Vegetation")
  @Valid
  private List<OrgResoMetadataEnumsVegetation> vegetation = null;

  @JsonProperty("VideosChangeTimestamp")
  private OffsetDateTime videosChangeTimestamp = null;

  @JsonProperty("VideosCount")
  private AnyOforgResoMetadataPropertyVideosCount videosCount = null;

  @JsonProperty("View")
  @Valid
  private List<OrgResoMetadataEnumsView> view = null;

  @JsonProperty("ViewYN")
  private Boolean viewYN = null;

  @JsonProperty("VirtualTourURLBranded")
  private String virtualTourURLBranded = null;

  @JsonProperty("VirtualTourURLUnbranded")
  private String virtualTourURLUnbranded = null;

  @JsonProperty("WalkScore")
  private AnyOforgResoMetadataPropertyWalkScore walkScore = null;

  @JsonProperty("WaterBodyName")
  private String waterBodyName = null;

  @JsonProperty("WaterSewerExpense")
  private AnyOforgResoMetadataPropertyWaterSewerExpense waterSewerExpense = null;

  @JsonProperty("WaterSource")
  @Valid
  private List<OrgResoMetadataEnumsWaterSource> waterSource = null;

  @JsonProperty("WaterfrontFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures = null;

  @JsonProperty("WaterfrontYN")
  private Boolean waterfrontYN = null;

  @JsonProperty("WindowFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWindowFeatures> windowFeatures = null;

  @JsonProperty("WithdrawnDate")
  private LocalDate withdrawnDate = null;

  @JsonProperty("WoodedArea")
  private AnyOforgResoMetadataPropertyWoodedArea woodedArea = null;

  @JsonProperty("WorkmansCompensationExpense")
  private AnyOforgResoMetadataPropertyWorkmansCompensationExpense workmansCompensationExpense = null;

  @JsonProperty("YearBuilt")
  private AnyOforgResoMetadataPropertyYearBuilt yearBuilt = null;

  @JsonProperty("YearBuiltDetails")
  private String yearBuiltDetails = null;

  @JsonProperty("YearBuiltEffective")
  private AnyOforgResoMetadataPropertyYearBuiltEffective yearBuiltEffective = null;

  @JsonProperty("YearBuiltSource")
  private AnyOforgResoMetadataPropertyYearBuiltSource yearBuiltSource = null;

  @JsonProperty("YearEstablished")
  private AnyOforgResoMetadataPropertyYearEstablished yearEstablished = null;

  @JsonProperty("YearsCurrentOwner")
  private AnyOforgResoMetadataPropertyYearsCurrentOwner yearsCurrentOwner = null;

  @JsonProperty("Zoning")
  private String zoning = null;

  @JsonProperty("ZoningDescription")
  private String zoningDescription = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataPropertyOriginatingSystem originatingSystem = null;

  @JsonProperty("BuyerAgent")
  private AnyOforgResoMetadataPropertyBuyerAgent buyerAgent = null;

  @JsonProperty("BuyerOffice")
  private AnyOforgResoMetadataPropertyBuyerOffice buyerOffice = null;

  @JsonProperty("CoBuyerAgent")
  private AnyOforgResoMetadataPropertyCoBuyerAgent coBuyerAgent = null;

  @JsonProperty("CoBuyerOffice")
  private AnyOforgResoMetadataPropertyCoBuyerOffice coBuyerOffice = null;

  @JsonProperty("CoListAgent")
  private AnyOforgResoMetadataPropertyCoListAgent coListAgent = null;

  @JsonProperty("CoListOffice")
  private AnyOforgResoMetadataPropertyCoListOffice coListOffice = null;

  @JsonProperty("ListAgent")
  private AnyOforgResoMetadataPropertyListAgent listAgent = null;

  @JsonProperty("ListOffice")
  private AnyOforgResoMetadataPropertyListOffice listOffice = null;

  @JsonProperty("BuyerTeam")
  private AnyOforgResoMetadataPropertyBuyerTeam buyerTeam = null;

  @JsonProperty("ListTeam")
  private AnyOforgResoMetadataPropertyListTeam listTeam = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataPropertySourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactional> historyTransactional = null;

  @JsonProperty("HistoryTransactional@odata.count")
  private Count historyTransactionalAtOdataCount = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMedia> media = null;

  @JsonProperty("Media@odata.count")
  private Count mediaAtOdataCount = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMedia> socialMedia = null;

  @JsonProperty("SocialMedia@odata.count")
  private Count socialMediaAtOdataCount = null;

  @JsonProperty("OpenHouse")
  @Valid
  private List<OrgResoMetadataOpenHouse> openHouse = null;

  @JsonProperty("OpenHouse@odata.count")
  private Count openHouseAtOdataCount = null;

  public OrgResoMetadataProperty aboveGradeFinishedArea(AnyOforgResoMetadataPropertyAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
    return this;
  }

  /**
   * Get aboveGradeFinishedArea
   * @return aboveGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyAboveGradeFinishedArea getAboveGradeFinishedArea() {
    return aboveGradeFinishedArea;
  }

  public void setAboveGradeFinishedArea(AnyOforgResoMetadataPropertyAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
  }

  public OrgResoMetadataProperty aboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaSource
   * @return aboveGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyAboveGradeFinishedAreaSource getAboveGradeFinishedAreaSource() {
    return aboveGradeFinishedAreaSource;
  }

  public void setAboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
  }

  public OrgResoMetadataProperty aboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaUnits
   * @return aboveGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits getAboveGradeFinishedAreaUnits() {
    return aboveGradeFinishedAreaUnits;
  }

  public void setAboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
  }

  public OrgResoMetadataProperty accessCode(String accessCode) {
    this.accessCode = accessCode;
    return this;
  }

  /**
   * Get accessCode
   * @return accessCode
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getAccessCode() {
    return accessCode;
  }

  public void setAccessCode(String accessCode) {
    this.accessCode = accessCode;
  }

  public OrgResoMetadataProperty accessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
    return this;
  }

  public OrgResoMetadataProperty addAccessibilityFeaturesItem(OrgResoMetadataEnumsAccessibilityFeatures accessibilityFeaturesItem) {
    if (this.accessibilityFeatures == null) {
      this.accessibilityFeatures = new ArrayList<OrgResoMetadataEnumsAccessibilityFeatures>();
    }
    this.accessibilityFeatures.add(accessibilityFeaturesItem);
    return this;
  }

  /**
   * Get accessibilityFeatures
   * @return accessibilityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAccessibilityFeatures> getAccessibilityFeatures() {
    return accessibilityFeatures;
  }

  public void setAccessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
  }

  public OrgResoMetadataProperty additionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
    return this;
  }

  /**
   * Get additionalParcelsDescription
   * @return additionalParcelsDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getAdditionalParcelsDescription() {
    return additionalParcelsDescription;
  }

  public void setAdditionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
  }

  public OrgResoMetadataProperty additionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
    return this;
  }

  /**
   * Get additionalParcelsYN
   * @return additionalParcelsYN
   **/
  @Schema(description = "")
  
    public Boolean isAdditionalParcelsYN() {
    return additionalParcelsYN;
  }

  public void setAdditionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
  }

  public OrgResoMetadataProperty anchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
    return this;
  }

  /**
   * Get anchorsCoTenants
   * @return anchorsCoTenants
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getAnchorsCoTenants() {
    return anchorsCoTenants;
  }

  public void setAnchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
  }

  public OrgResoMetadataProperty appliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
    return this;
  }

  public OrgResoMetadataProperty addAppliancesItem(OrgResoMetadataEnumsAppliances appliancesItem) {
    if (this.appliances == null) {
      this.appliances = new ArrayList<OrgResoMetadataEnumsAppliances>();
    }
    this.appliances.add(appliancesItem);
    return this;
  }

  /**
   * Get appliances
   * @return appliances
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAppliances> getAppliances() {
    return appliances;
  }

  public void setAppliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
  }

  public OrgResoMetadataProperty architecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
    return this;
  }

  public OrgResoMetadataProperty addArchitecturalStyleItem(OrgResoMetadataEnumsArchitecturalStyle architecturalStyleItem) {
    if (this.architecturalStyle == null) {
      this.architecturalStyle = new ArrayList<OrgResoMetadataEnumsArchitecturalStyle>();
    }
    this.architecturalStyle.add(architecturalStyleItem);
    return this;
  }

  /**
   * Get architecturalStyle
   * @return architecturalStyle
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsArchitecturalStyle> getArchitecturalStyle() {
    return architecturalStyle;
  }

  public void setArchitecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
  }

  public OrgResoMetadataProperty associationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
    return this;
  }

  public OrgResoMetadataProperty addAssociationAmenitiesItem(OrgResoMetadataEnumsAssociationAmenities associationAmenitiesItem) {
    if (this.associationAmenities == null) {
      this.associationAmenities = new ArrayList<OrgResoMetadataEnumsAssociationAmenities>();
    }
    this.associationAmenities.add(associationAmenitiesItem);
    return this;
  }

  /**
   * Get associationAmenities
   * @return associationAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationAmenities> getAssociationAmenities() {
    return associationAmenities;
  }

  public void setAssociationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
  }

  public OrgResoMetadataProperty associationFee(AnyOforgResoMetadataPropertyAssociationFee associationFee) {
    this.associationFee = associationFee;
    return this;
  }

  /**
   * Get associationFee
   * @return associationFee
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyAssociationFee getAssociationFee() {
    return associationFee;
  }

  public void setAssociationFee(AnyOforgResoMetadataPropertyAssociationFee associationFee) {
    this.associationFee = associationFee;
  }

  public OrgResoMetadataProperty associationFee2(AnyOforgResoMetadataPropertyAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
    return this;
  }

  /**
   * Get associationFee2
   * @return associationFee2
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyAssociationFee2 getAssociationFee2() {
    return associationFee2;
  }

  public void setAssociationFee2(AnyOforgResoMetadataPropertyAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
  }

  public OrgResoMetadataProperty associationFee2Frequency(AnyOforgResoMetadataPropertyAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
    return this;
  }

  /**
   * Get associationFee2Frequency
   * @return associationFee2Frequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyAssociationFee2Frequency getAssociationFee2Frequency() {
    return associationFee2Frequency;
  }

  public void setAssociationFee2Frequency(AnyOforgResoMetadataPropertyAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
  }

  public OrgResoMetadataProperty associationFeeFrequency(AnyOforgResoMetadataPropertyAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
    return this;
  }

  /**
   * Get associationFeeFrequency
   * @return associationFeeFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyAssociationFeeFrequency getAssociationFeeFrequency() {
    return associationFeeFrequency;
  }

  public void setAssociationFeeFrequency(AnyOforgResoMetadataPropertyAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
  }

  public OrgResoMetadataProperty associationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
    return this;
  }

  public OrgResoMetadataProperty addAssociationFeeIncludesItem(OrgResoMetadataEnumsAssociationFeeIncludes associationFeeIncludesItem) {
    if (this.associationFeeIncludes == null) {
      this.associationFeeIncludes = new ArrayList<OrgResoMetadataEnumsAssociationFeeIncludes>();
    }
    this.associationFeeIncludes.add(associationFeeIncludesItem);
    return this;
  }

  /**
   * Get associationFeeIncludes
   * @return associationFeeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationFeeIncludes> getAssociationFeeIncludes() {
    return associationFeeIncludes;
  }

  public void setAssociationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
  }

  public OrgResoMetadataProperty associationName(String associationName) {
    this.associationName = associationName;
    return this;
  }

  /**
   * Get associationName
   * @return associationName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName() {
    return associationName;
  }

  public void setAssociationName(String associationName) {
    this.associationName = associationName;
  }

  public OrgResoMetadataProperty associationName2(String associationName2) {
    this.associationName2 = associationName2;
    return this;
  }

  /**
   * Get associationName2
   * @return associationName2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName2() {
    return associationName2;
  }

  public void setAssociationName2(String associationName2) {
    this.associationName2 = associationName2;
  }

  public OrgResoMetadataProperty associationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
    return this;
  }

  /**
   * Get associationPhone
   * @return associationPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone() {
    return associationPhone;
  }

  public void setAssociationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
  }

  public OrgResoMetadataProperty associationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
    return this;
  }

  /**
   * Get associationPhone2
   * @return associationPhone2
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone2() {
    return associationPhone2;
  }

  public void setAssociationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
  }

  public OrgResoMetadataProperty associationYN(Boolean associationYN) {
    this.associationYN = associationYN;
    return this;
  }

  /**
   * Get associationYN
   * @return associationYN
   **/
  @Schema(description = "")
  
    public Boolean isAssociationYN() {
    return associationYN;
  }

  public void setAssociationYN(Boolean associationYN) {
    this.associationYN = associationYN;
  }

  public OrgResoMetadataProperty attachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
    return this;
  }

  /**
   * Get attachedGarageYN
   * @return attachedGarageYN
   **/
  @Schema(description = "")
  
    public Boolean isAttachedGarageYN() {
    return attachedGarageYN;
  }

  public void setAttachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
  }

  public OrgResoMetadataProperty availabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
    return this;
  }

  /**
   * Get availabilityDate
   * @return availabilityDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getAvailabilityDate() {
    return availabilityDate;
  }

  public void setAvailabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
  }

  public OrgResoMetadataProperty basement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
    return this;
  }

  public OrgResoMetadataProperty addBasementItem(OrgResoMetadataEnumsBasement basementItem) {
    if (this.basement == null) {
      this.basement = new ArrayList<OrgResoMetadataEnumsBasement>();
    }
    this.basement.add(basementItem);
    return this;
  }

  /**
   * Get basement
   * @return basement
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBasement> getBasement() {
    return basement;
  }

  public void setBasement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
  }

  public OrgResoMetadataProperty basementYN(Boolean basementYN) {
    this.basementYN = basementYN;
    return this;
  }

  /**
   * Get basementYN
   * @return basementYN
   **/
  @Schema(description = "")
  
    public Boolean isBasementYN() {
    return basementYN;
  }

  public void setBasementYN(Boolean basementYN) {
    this.basementYN = basementYN;
  }

  public OrgResoMetadataProperty bathroomsFull(AnyOforgResoMetadataPropertyBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
    return this;
  }

  /**
   * Get bathroomsFull
   * @return bathroomsFull
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsFull getBathroomsFull() {
    return bathroomsFull;
  }

  public void setBathroomsFull(AnyOforgResoMetadataPropertyBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
  }

  public OrgResoMetadataProperty bathroomsHalf(AnyOforgResoMetadataPropertyBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
    return this;
  }

  /**
   * Get bathroomsHalf
   * @return bathroomsHalf
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsHalf getBathroomsHalf() {
    return bathroomsHalf;
  }

  public void setBathroomsHalf(AnyOforgResoMetadataPropertyBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
  }

  public OrgResoMetadataProperty bathroomsOneQuarter(AnyOforgResoMetadataPropertyBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
    return this;
  }

  /**
   * Get bathroomsOneQuarter
   * @return bathroomsOneQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsOneQuarter getBathroomsOneQuarter() {
    return bathroomsOneQuarter;
  }

  public void setBathroomsOneQuarter(AnyOforgResoMetadataPropertyBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
  }

  public OrgResoMetadataProperty bathroomsPartial(AnyOforgResoMetadataPropertyBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
    return this;
  }

  /**
   * Get bathroomsPartial
   * @return bathroomsPartial
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsPartial getBathroomsPartial() {
    return bathroomsPartial;
  }

  public void setBathroomsPartial(AnyOforgResoMetadataPropertyBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
  }

  public OrgResoMetadataProperty bathroomsThreeQuarter(AnyOforgResoMetadataPropertyBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
    return this;
  }

  /**
   * Get bathroomsThreeQuarter
   * @return bathroomsThreeQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsThreeQuarter getBathroomsThreeQuarter() {
    return bathroomsThreeQuarter;
  }

  public void setBathroomsThreeQuarter(AnyOforgResoMetadataPropertyBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
  }

  public OrgResoMetadataProperty bathroomsTotalInteger(AnyOforgResoMetadataPropertyBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
    return this;
  }

  /**
   * Get bathroomsTotalInteger
   * @return bathroomsTotalInteger
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBathroomsTotalInteger getBathroomsTotalInteger() {
    return bathroomsTotalInteger;
  }

  public void setBathroomsTotalInteger(AnyOforgResoMetadataPropertyBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
  }

  public OrgResoMetadataProperty bedroomsPossible(AnyOforgResoMetadataPropertyBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
    return this;
  }

  /**
   * Get bedroomsPossible
   * @return bedroomsPossible
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBedroomsPossible getBedroomsPossible() {
    return bedroomsPossible;
  }

  public void setBedroomsPossible(AnyOforgResoMetadataPropertyBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
  }

  public OrgResoMetadataProperty bedroomsTotal(AnyOforgResoMetadataPropertyBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
    return this;
  }

  /**
   * Get bedroomsTotal
   * @return bedroomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBedroomsTotal getBedroomsTotal() {
    return bedroomsTotal;
  }

  public void setBedroomsTotal(AnyOforgResoMetadataPropertyBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
  }

  public OrgResoMetadataProperty belowGradeFinishedArea(AnyOforgResoMetadataPropertyBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
    return this;
  }

  /**
   * Get belowGradeFinishedArea
   * @return belowGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyBelowGradeFinishedArea getBelowGradeFinishedArea() {
    return belowGradeFinishedArea;
  }

  public void setBelowGradeFinishedArea(AnyOforgResoMetadataPropertyBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
  }

  public OrgResoMetadataProperty belowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaSource
   * @return belowGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBelowGradeFinishedAreaSource getBelowGradeFinishedAreaSource() {
    return belowGradeFinishedAreaSource;
  }

  public void setBelowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
  }

  public OrgResoMetadataProperty belowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaUnits
   * @return belowGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBelowGradeFinishedAreaUnits getBelowGradeFinishedAreaUnits() {
    return belowGradeFinishedAreaUnits;
  }

  public void setBelowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
  }

  public OrgResoMetadataProperty bodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
    return this;
  }

  public OrgResoMetadataProperty addBodyTypeItem(OrgResoMetadataEnumsBodyType bodyTypeItem) {
    if (this.bodyType == null) {
      this.bodyType = new ArrayList<OrgResoMetadataEnumsBodyType>();
    }
    this.bodyType.add(bodyTypeItem);
    return this;
  }

  /**
   * Get bodyType
   * @return bodyType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBodyType> getBodyType() {
    return bodyType;
  }

  public void setBodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
  }

  public OrgResoMetadataProperty builderModel(String builderModel) {
    this.builderModel = builderModel;
    return this;
  }

  /**
   * Get builderModel
   * @return builderModel
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderModel() {
    return builderModel;
  }

  public void setBuilderModel(String builderModel) {
    this.builderModel = builderModel;
  }

  public OrgResoMetadataProperty builderName(String builderName) {
    this.builderName = builderName;
    return this;
  }

  /**
   * Get builderName
   * @return builderName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderName() {
    return builderName;
  }

  public void setBuilderName(String builderName) {
    this.builderName = builderName;
  }

  public OrgResoMetadataProperty buildingAreaSource(AnyOforgResoMetadataPropertyBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
    return this;
  }

  /**
   * Get buildingAreaSource
   * @return buildingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuildingAreaSource getBuildingAreaSource() {
    return buildingAreaSource;
  }

  public void setBuildingAreaSource(AnyOforgResoMetadataPropertyBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
  }

  public OrgResoMetadataProperty buildingAreaTotal(AnyOforgResoMetadataPropertyBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
    return this;
  }

  /**
   * Get buildingAreaTotal
   * @return buildingAreaTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyBuildingAreaTotal getBuildingAreaTotal() {
    return buildingAreaTotal;
  }

  public void setBuildingAreaTotal(AnyOforgResoMetadataPropertyBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
  }

  public OrgResoMetadataProperty buildingAreaUnits(AnyOforgResoMetadataPropertyBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
    return this;
  }

  /**
   * Get buildingAreaUnits
   * @return buildingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuildingAreaUnits getBuildingAreaUnits() {
    return buildingAreaUnits;
  }

  public void setBuildingAreaUnits(AnyOforgResoMetadataPropertyBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
  }

  public OrgResoMetadataProperty buildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
    return this;
  }

  public OrgResoMetadataProperty addBuildingFeaturesItem(OrgResoMetadataEnumsBuildingFeatures buildingFeaturesItem) {
    if (this.buildingFeatures == null) {
      this.buildingFeatures = new ArrayList<OrgResoMetadataEnumsBuildingFeatures>();
    }
    this.buildingFeatures.add(buildingFeaturesItem);
    return this;
  }

  /**
   * Get buildingFeatures
   * @return buildingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuildingFeatures> getBuildingFeatures() {
    return buildingFeatures;
  }

  public void setBuildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
  }

  public OrgResoMetadataProperty buildingName(String buildingName) {
    this.buildingName = buildingName;
    return this;
  }

  /**
   * Get buildingName
   * @return buildingName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuildingName() {
    return buildingName;
  }

  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  public OrgResoMetadataProperty businessName(String businessName) {
    this.businessName = businessName;
    return this;
  }

  /**
   * Get businessName
   * @return businessName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBusinessName() {
    return businessName;
  }

  public void setBusinessName(String businessName) {
    this.businessName = businessName;
  }

  public OrgResoMetadataProperty businessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
    return this;
  }

  public OrgResoMetadataProperty addBusinessTypeItem(OrgResoMetadataEnumsBusinessType businessTypeItem) {
    if (this.businessType == null) {
      this.businessType = new ArrayList<OrgResoMetadataEnumsBusinessType>();
    }
    this.businessType.add(businessTypeItem);
    return this;
  }

  /**
   * Get businessType
   * @return businessType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBusinessType> getBusinessType() {
    return businessType;
  }

  public void setBusinessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
  }

  public OrgResoMetadataProperty buyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
    return this;
  }

  /**
   * Get buyerAgencyCompensation
   * @return buyerAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgencyCompensation() {
    return buyerAgencyCompensation;
  }

  public void setBuyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
  }

  public OrgResoMetadataProperty buyerAgencyCompensationType(AnyOforgResoMetadataPropertyBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
    return this;
  }

  /**
   * Get buyerAgencyCompensationType
   * @return buyerAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerAgencyCompensationType getBuyerAgencyCompensationType() {
    return buyerAgencyCompensationType;
  }

  public void setBuyerAgencyCompensationType(AnyOforgResoMetadataPropertyBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
  }

  public OrgResoMetadataProperty buyerAgentAOR(AnyOforgResoMetadataPropertyBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
    return this;
  }

  /**
   * Get buyerAgentAOR
   * @return buyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerAgentAOR getBuyerAgentAOR() {
    return buyerAgentAOR;
  }

  public void setBuyerAgentAOR(AnyOforgResoMetadataPropertyBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
  }

  public OrgResoMetadataProperty buyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataProperty addBuyerAgentDesignationItem(OrgResoMetadataEnumsBuyerAgentDesignation buyerAgentDesignationItem) {
    if (this.buyerAgentDesignation == null) {
      this.buyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsBuyerAgentDesignation>();
    }
    this.buyerAgentDesignation.add(buyerAgentDesignationItem);
    return this;
  }

  /**
   * Get buyerAgentDesignation
   * @return buyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerAgentDesignation> getBuyerAgentDesignation() {
    return buyerAgentDesignation;
  }

  public void setBuyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
  }

  public OrgResoMetadataProperty buyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
    return this;
  }

  /**
   * Get buyerAgentDirectPhone
   * @return buyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentDirectPhone() {
    return buyerAgentDirectPhone;
  }

  public void setBuyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
  }

  public OrgResoMetadataProperty buyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
    return this;
  }

  /**
   * Get buyerAgentEmail
   * @return buyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerAgentEmail() {
    return buyerAgentEmail;
  }

  public void setBuyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
  }

  public OrgResoMetadataProperty buyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
    return this;
  }

  /**
   * Get buyerAgentFax
   * @return buyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentFax() {
    return buyerAgentFax;
  }

  public void setBuyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
  }

  public OrgResoMetadataProperty buyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
    return this;
  }

  /**
   * Get buyerAgentFirstName
   * @return buyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentFirstName() {
    return buyerAgentFirstName;
  }

  public void setBuyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
  }

  public OrgResoMetadataProperty buyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
    return this;
  }

  /**
   * Get buyerAgentFullName
   * @return buyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getBuyerAgentFullName() {
    return buyerAgentFullName;
  }

  public void setBuyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
  }

  public OrgResoMetadataProperty buyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
    return this;
  }

  /**
   * Get buyerAgentHomePhone
   * @return buyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentHomePhone() {
    return buyerAgentHomePhone;
  }

  public void setBuyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
  }

  public OrgResoMetadataProperty buyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
    return this;
  }

  /**
   * Get buyerAgentKey
   * @return buyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerAgentKey() {
    return buyerAgentKey;
  }

  public void setBuyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
  }

  public OrgResoMetadataProperty buyerAgentKeyNumeric(AnyOforgResoMetadataPropertyBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get buyerAgentKeyNumeric
   * @return buyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBuyerAgentKeyNumeric getBuyerAgentKeyNumeric() {
    return buyerAgentKeyNumeric;
  }

  public void setBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
  }

  public OrgResoMetadataProperty buyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
    return this;
  }

  /**
   * Get buyerAgentLastName
   * @return buyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentLastName() {
    return buyerAgentLastName;
  }

  public void setBuyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
  }

  public OrgResoMetadataProperty buyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
    return this;
  }

  /**
   * Get buyerAgentMiddleName
   * @return buyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentMiddleName() {
    return buyerAgentMiddleName;
  }

  public void setBuyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
  }

  public OrgResoMetadataProperty buyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
    return this;
  }

  /**
   * Get buyerAgentMlsId
   * @return buyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgentMlsId() {
    return buyerAgentMlsId;
  }

  public void setBuyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
  }

  public OrgResoMetadataProperty buyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
    return this;
  }

  /**
   * Get buyerAgentMobilePhone
   * @return buyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentMobilePhone() {
    return buyerAgentMobilePhone;
  }

  public void setBuyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
  }

  public OrgResoMetadataProperty buyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
    return this;
  }

  /**
   * Get buyerAgentNamePrefix
   * @return buyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNamePrefix() {
    return buyerAgentNamePrefix;
  }

  public void setBuyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
  }

  public OrgResoMetadataProperty buyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
    return this;
  }

  /**
   * Get buyerAgentNameSuffix
   * @return buyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNameSuffix() {
    return buyerAgentNameSuffix;
  }

  public void setBuyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
  }

  public OrgResoMetadataProperty buyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
    return this;
  }

  /**
   * Get buyerAgentOfficePhone
   * @return buyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentOfficePhone() {
    return buyerAgentOfficePhone;
  }

  public void setBuyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
  }

  public OrgResoMetadataProperty buyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerAgentOfficePhoneExt
   * @return buyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentOfficePhoneExt() {
    return buyerAgentOfficePhoneExt;
  }

  public void setBuyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataProperty buyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
    return this;
  }

  /**
   * Get buyerAgentPager
   * @return buyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPager() {
    return buyerAgentPager;
  }

  public void setBuyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
  }

  public OrgResoMetadataProperty buyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhone
   * @return buyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPreferredPhone() {
    return buyerAgentPreferredPhone;
  }

  public void setBuyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
  }

  public OrgResoMetadataProperty buyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhoneExt
   * @return buyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentPreferredPhoneExt() {
    return buyerAgentPreferredPhoneExt;
  }

  public void setBuyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataProperty buyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
    return this;
  }

  /**
   * Get buyerAgentStateLicense
   * @return buyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentStateLicense() {
    return buyerAgentStateLicense;
  }

  public void setBuyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
  }

  public OrgResoMetadataProperty buyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get buyerAgentTollFreePhone
   * @return buyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentTollFreePhone() {
    return buyerAgentTollFreePhone;
  }

  public void setBuyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
  }

  public OrgResoMetadataProperty buyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
    return this;
  }

  /**
   * Get buyerAgentURL
   * @return buyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerAgentURL() {
    return buyerAgentURL;
  }

  public void setBuyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
  }

  public OrgResoMetadataProperty buyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
    return this;
  }

  /**
   * Get buyerAgentVoiceMail
   * @return buyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentVoiceMail() {
    return buyerAgentVoiceMail;
  }

  public void setBuyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
  }

  public OrgResoMetadataProperty buyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get buyerAgentVoiceMailExt
   * @return buyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentVoiceMailExt() {
    return buyerAgentVoiceMailExt;
  }

  public void setBuyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
  }

  public OrgResoMetadataProperty buyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
    return this;
  }

  public OrgResoMetadataProperty addBuyerFinancingItem(OrgResoMetadataEnumsBuyerFinancing buyerFinancingItem) {
    if (this.buyerFinancing == null) {
      this.buyerFinancing = new ArrayList<OrgResoMetadataEnumsBuyerFinancing>();
    }
    this.buyerFinancing.add(buyerFinancingItem);
    return this;
  }

  /**
   * Get buyerFinancing
   * @return buyerFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerFinancing> getBuyerFinancing() {
    return buyerFinancing;
  }

  public void setBuyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
  }

  public OrgResoMetadataProperty buyerOfficeAOR(AnyOforgResoMetadataPropertyBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
    return this;
  }

  /**
   * Get buyerOfficeAOR
   * @return buyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerOfficeAOR getBuyerOfficeAOR() {
    return buyerOfficeAOR;
  }

  public void setBuyerOfficeAOR(AnyOforgResoMetadataPropertyBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
  }

  public OrgResoMetadataProperty buyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
    return this;
  }

  /**
   * Get buyerOfficeEmail
   * @return buyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerOfficeEmail() {
    return buyerOfficeEmail;
  }

  public void setBuyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
  }

  public OrgResoMetadataProperty buyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
    return this;
  }

  /**
   * Get buyerOfficeFax
   * @return buyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficeFax() {
    return buyerOfficeFax;
  }

  public void setBuyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
  }

  public OrgResoMetadataProperty buyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
    return this;
  }

  /**
   * Get buyerOfficeKey
   * @return buyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeKey() {
    return buyerOfficeKey;
  }

  public void setBuyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
  }

  public OrgResoMetadataProperty buyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get buyerOfficeKeyNumeric
   * @return buyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric getBuyerOfficeKeyNumeric() {
    return buyerOfficeKeyNumeric;
  }

  public void setBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
  }

  public OrgResoMetadataProperty buyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
    return this;
  }

  /**
   * Get buyerOfficeMlsId
   * @return buyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerOfficeMlsId() {
    return buyerOfficeMlsId;
  }

  public void setBuyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
  }

  public OrgResoMetadataProperty buyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
    return this;
  }

  /**
   * Get buyerOfficeName
   * @return buyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeName() {
    return buyerOfficeName;
  }

  public void setBuyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
  }

  public OrgResoMetadataProperty buyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
    return this;
  }

  /**
   * Get buyerOfficePhone
   * @return buyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficePhone() {
    return buyerOfficePhone;
  }

  public void setBuyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
  }

  public OrgResoMetadataProperty buyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerOfficePhoneExt
   * @return buyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerOfficePhoneExt() {
    return buyerOfficePhoneExt;
  }

  public void setBuyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
  }

  public OrgResoMetadataProperty buyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
    return this;
  }

  /**
   * Get buyerOfficeURL
   * @return buyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerOfficeURL() {
    return buyerOfficeURL;
  }

  public void setBuyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
  }

  public OrgResoMetadataProperty buyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
    return this;
  }

  /**
   * Get buyerTeamKey
   * @return buyerTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerTeamKey() {
    return buyerTeamKey;
  }

  public void setBuyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
  }

  public OrgResoMetadataProperty buyerTeamKeyNumeric(AnyOforgResoMetadataPropertyBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
    return this;
  }

  /**
   * Get buyerTeamKeyNumeric
   * @return buyerTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyBuyerTeamKeyNumeric getBuyerTeamKeyNumeric() {
    return buyerTeamKeyNumeric;
  }

  public void setBuyerTeamKeyNumeric(AnyOforgResoMetadataPropertyBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
  }

  public OrgResoMetadataProperty buyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
    return this;
  }

  /**
   * Get buyerTeamName
   * @return buyerTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerTeamName() {
    return buyerTeamName;
  }

  public void setBuyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
  }

  public OrgResoMetadataProperty cableTvExpense(AnyOforgResoMetadataPropertyCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
    return this;
  }

  /**
   * Get cableTvExpense
   * @return cableTvExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCableTvExpense getCableTvExpense() {
    return cableTvExpense;
  }

  public void setCableTvExpense(AnyOforgResoMetadataPropertyCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
  }

  public OrgResoMetadataProperty cancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
    return this;
  }

  /**
   * Get cancellationDate
   * @return cancellationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCancellationDate() {
    return cancellationDate;
  }

  public void setCancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
  }

  public OrgResoMetadataProperty capRate(AnyOforgResoMetadataPropertyCapRate capRate) {
    this.capRate = capRate;
    return this;
  }

  /**
   * Get capRate
   * @return capRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCapRate getCapRate() {
    return capRate;
  }

  public void setCapRate(AnyOforgResoMetadataPropertyCapRate capRate) {
    this.capRate = capRate;
  }

  public OrgResoMetadataProperty carportSpaces(AnyOforgResoMetadataPropertyCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
    return this;
  }

  /**
   * Get carportSpaces
   * @return carportSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCarportSpaces getCarportSpaces() {
    return carportSpaces;
  }

  public void setCarportSpaces(AnyOforgResoMetadataPropertyCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
  }

  public OrgResoMetadataProperty carportYN(Boolean carportYN) {
    this.carportYN = carportYN;
    return this;
  }

  /**
   * Get carportYN
   * @return carportYN
   **/
  @Schema(description = "")
  
    public Boolean isCarportYN() {
    return carportYN;
  }

  public void setCarportYN(Boolean carportYN) {
    this.carportYN = carportYN;
  }

  public OrgResoMetadataProperty carrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
    return this;
  }

  /**
   * Get carrierRoute
   * @return carrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getCarrierRoute() {
    return carrierRoute;
  }

  public void setCarrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
  }

  public OrgResoMetadataProperty city(AnyOforgResoMetadataPropertyCity city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCity getCity() {
    return city;
  }

  public void setCity(AnyOforgResoMetadataPropertyCity city) {
    this.city = city;
  }

  public OrgResoMetadataProperty cityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
    return this;
  }

  /**
   * Get cityRegion
   * @return cityRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCityRegion() {
    return cityRegion;
  }

  public void setCityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
  }

  public OrgResoMetadataProperty closeDate(LocalDate closeDate) {
    this.closeDate = closeDate;
    return this;
  }

  /**
   * Get closeDate
   * @return closeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(LocalDate closeDate) {
    this.closeDate = closeDate;
  }

  public OrgResoMetadataProperty closePrice(AnyOforgResoMetadataPropertyClosePrice closePrice) {
    this.closePrice = closePrice;
    return this;
  }

  /**
   * Get closePrice
   * @return closePrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyClosePrice getClosePrice() {
    return closePrice;
  }

  public void setClosePrice(AnyOforgResoMetadataPropertyClosePrice closePrice) {
    this.closePrice = closePrice;
  }

  public OrgResoMetadataProperty coBuyerAgentAOR(AnyOforgResoMetadataPropertyCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
    return this;
  }

  /**
   * Get coBuyerAgentAOR
   * @return coBuyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerAgentAOR getCoBuyerAgentAOR() {
    return coBuyerAgentAOR;
  }

  public void setCoBuyerAgentAOR(AnyOforgResoMetadataPropertyCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
  }

  public OrgResoMetadataProperty coBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataProperty addCoBuyerAgentDesignationItem(OrgResoMetadataEnumsCoBuyerAgentDesignation coBuyerAgentDesignationItem) {
    if (this.coBuyerAgentDesignation == null) {
      this.coBuyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoBuyerAgentDesignation>();
    }
    this.coBuyerAgentDesignation.add(coBuyerAgentDesignationItem);
    return this;
  }

  /**
   * Get coBuyerAgentDesignation
   * @return coBuyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoBuyerAgentDesignation> getCoBuyerAgentDesignation() {
    return coBuyerAgentDesignation;
  }

  public void setCoBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
  }

  public OrgResoMetadataProperty coBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
    return this;
  }

  /**
   * Get coBuyerAgentDirectPhone
   * @return coBuyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentDirectPhone() {
    return coBuyerAgentDirectPhone;
  }

  public void setCoBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
  }

  public OrgResoMetadataProperty coBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
    return this;
  }

  /**
   * Get coBuyerAgentEmail
   * @return coBuyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerAgentEmail() {
    return coBuyerAgentEmail;
  }

  public void setCoBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
  }

  public OrgResoMetadataProperty coBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
    return this;
  }

  /**
   * Get coBuyerAgentFax
   * @return coBuyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentFax() {
    return coBuyerAgentFax;
  }

  public void setCoBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
  }

  public OrgResoMetadataProperty coBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
    return this;
  }

  /**
   * Get coBuyerAgentFirstName
   * @return coBuyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentFirstName() {
    return coBuyerAgentFirstName;
  }

  public void setCoBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
  }

  public OrgResoMetadataProperty coBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
    return this;
  }

  /**
   * Get coBuyerAgentFullName
   * @return coBuyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoBuyerAgentFullName() {
    return coBuyerAgentFullName;
  }

  public void setCoBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
  }

  public OrgResoMetadataProperty coBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
    return this;
  }

  /**
   * Get coBuyerAgentHomePhone
   * @return coBuyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentHomePhone() {
    return coBuyerAgentHomePhone;
  }

  public void setCoBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
  }

  public OrgResoMetadataProperty coBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
    return this;
  }

  /**
   * Get coBuyerAgentKey
   * @return coBuyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerAgentKey() {
    return coBuyerAgentKey;
  }

  public void setCoBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
  }

  public OrgResoMetadataProperty coBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerAgentKeyNumeric
   * @return coBuyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerAgentKeyNumeric getCoBuyerAgentKeyNumeric() {
    return coBuyerAgentKeyNumeric;
  }

  public void setCoBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
  }

  public OrgResoMetadataProperty coBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
    return this;
  }

  /**
   * Get coBuyerAgentLastName
   * @return coBuyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentLastName() {
    return coBuyerAgentLastName;
  }

  public void setCoBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
  }

  public OrgResoMetadataProperty coBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
    return this;
  }

  /**
   * Get coBuyerAgentMiddleName
   * @return coBuyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentMiddleName() {
    return coBuyerAgentMiddleName;
  }

  public void setCoBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
  }

  public OrgResoMetadataProperty coBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
    return this;
  }

  /**
   * Get coBuyerAgentMlsId
   * @return coBuyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerAgentMlsId() {
    return coBuyerAgentMlsId;
  }

  public void setCoBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
  }

  public OrgResoMetadataProperty coBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
    return this;
  }

  /**
   * Get coBuyerAgentMobilePhone
   * @return coBuyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentMobilePhone() {
    return coBuyerAgentMobilePhone;
  }

  public void setCoBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
  }

  public OrgResoMetadataProperty coBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
    return this;
  }

  /**
   * Get coBuyerAgentNamePrefix
   * @return coBuyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNamePrefix() {
    return coBuyerAgentNamePrefix;
  }

  public void setCoBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
  }

  public OrgResoMetadataProperty coBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
    return this;
  }

  /**
   * Get coBuyerAgentNameSuffix
   * @return coBuyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNameSuffix() {
    return coBuyerAgentNameSuffix;
  }

  public void setCoBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
  }

  public OrgResoMetadataProperty coBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhone
   * @return coBuyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentOfficePhone() {
    return coBuyerAgentOfficePhone;
  }

  public void setCoBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
  }

  public OrgResoMetadataProperty coBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhoneExt
   * @return coBuyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentOfficePhoneExt() {
    return coBuyerAgentOfficePhoneExt;
  }

  public void setCoBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataProperty coBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
    return this;
  }

  /**
   * Get coBuyerAgentPager
   * @return coBuyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPager() {
    return coBuyerAgentPager;
  }

  public void setCoBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
  }

  public OrgResoMetadataProperty coBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhone
   * @return coBuyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPreferredPhone() {
    return coBuyerAgentPreferredPhone;
  }

  public void setCoBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
  }

  public OrgResoMetadataProperty coBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhoneExt
   * @return coBuyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentPreferredPhoneExt() {
    return coBuyerAgentPreferredPhoneExt;
  }

  public void setCoBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataProperty coBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
    return this;
  }

  /**
   * Get coBuyerAgentStateLicense
   * @return coBuyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentStateLicense() {
    return coBuyerAgentStateLicense;
  }

  public void setCoBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
  }

  public OrgResoMetadataProperty coBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get coBuyerAgentTollFreePhone
   * @return coBuyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentTollFreePhone() {
    return coBuyerAgentTollFreePhone;
  }

  public void setCoBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
  }

  public OrgResoMetadataProperty coBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
    return this;
  }

  /**
   * Get coBuyerAgentURL
   * @return coBuyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerAgentURL() {
    return coBuyerAgentURL;
  }

  public void setCoBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
  }

  public OrgResoMetadataProperty coBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMail
   * @return coBuyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentVoiceMail() {
    return coBuyerAgentVoiceMail;
  }

  public void setCoBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
  }

  public OrgResoMetadataProperty coBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMailExt
   * @return coBuyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentVoiceMailExt() {
    return coBuyerAgentVoiceMailExt;
  }

  public void setCoBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
  }

  public OrgResoMetadataProperty coBuyerOfficeAOR(AnyOforgResoMetadataPropertyCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
    return this;
  }

  /**
   * Get coBuyerOfficeAOR
   * @return coBuyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerOfficeAOR getCoBuyerOfficeAOR() {
    return coBuyerOfficeAOR;
  }

  public void setCoBuyerOfficeAOR(AnyOforgResoMetadataPropertyCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
  }

  public OrgResoMetadataProperty coBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
    return this;
  }

  /**
   * Get coBuyerOfficeEmail
   * @return coBuyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerOfficeEmail() {
    return coBuyerOfficeEmail;
  }

  public void setCoBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
  }

  public OrgResoMetadataProperty coBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
    return this;
  }

  /**
   * Get coBuyerOfficeFax
   * @return coBuyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficeFax() {
    return coBuyerOfficeFax;
  }

  public void setCoBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
  }

  public OrgResoMetadataProperty coBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
    return this;
  }

  /**
   * Get coBuyerOfficeKey
   * @return coBuyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeKey() {
    return coBuyerOfficeKey;
  }

  public void setCoBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
  }

  public OrgResoMetadataProperty coBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerOfficeKeyNumeric
   * @return coBuyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerOfficeKeyNumeric getCoBuyerOfficeKeyNumeric() {
    return coBuyerOfficeKeyNumeric;
  }

  public void setCoBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
  }

  public OrgResoMetadataProperty coBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
    return this;
  }

  /**
   * Get coBuyerOfficeMlsId
   * @return coBuyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerOfficeMlsId() {
    return coBuyerOfficeMlsId;
  }

  public void setCoBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
  }

  public OrgResoMetadataProperty coBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
    return this;
  }

  /**
   * Get coBuyerOfficeName
   * @return coBuyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeName() {
    return coBuyerOfficeName;
  }

  public void setCoBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
  }

  public OrgResoMetadataProperty coBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
    return this;
  }

  /**
   * Get coBuyerOfficePhone
   * @return coBuyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficePhone() {
    return coBuyerOfficePhone;
  }

  public void setCoBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
  }

  public OrgResoMetadataProperty coBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerOfficePhoneExt
   * @return coBuyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerOfficePhoneExt() {
    return coBuyerOfficePhoneExt;
  }

  public void setCoBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
  }

  public OrgResoMetadataProperty coBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
    return this;
  }

  /**
   * Get coBuyerOfficeURL
   * @return coBuyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerOfficeURL() {
    return coBuyerOfficeURL;
  }

  public void setCoBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
  }

  public OrgResoMetadataProperty coListAgentAOR(AnyOforgResoMetadataPropertyCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
    return this;
  }

  /**
   * Get coListAgentAOR
   * @return coListAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoListAgentAOR getCoListAgentAOR() {
    return coListAgentAOR;
  }

  public void setCoListAgentAOR(AnyOforgResoMetadataPropertyCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
  }

  public OrgResoMetadataProperty coListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
    return this;
  }

  public OrgResoMetadataProperty addCoListAgentDesignationItem(OrgResoMetadataEnumsCoListAgentDesignation coListAgentDesignationItem) {
    if (this.coListAgentDesignation == null) {
      this.coListAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoListAgentDesignation>();
    }
    this.coListAgentDesignation.add(coListAgentDesignationItem);
    return this;
  }

  /**
   * Get coListAgentDesignation
   * @return coListAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoListAgentDesignation> getCoListAgentDesignation() {
    return coListAgentDesignation;
  }

  public void setCoListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
  }

  public OrgResoMetadataProperty coListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
    return this;
  }

  /**
   * Get coListAgentDirectPhone
   * @return coListAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentDirectPhone() {
    return coListAgentDirectPhone;
  }

  public void setCoListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
  }

  public OrgResoMetadataProperty coListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
    return this;
  }

  /**
   * Get coListAgentEmail
   * @return coListAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListAgentEmail() {
    return coListAgentEmail;
  }

  public void setCoListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
  }

  public OrgResoMetadataProperty coListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
    return this;
  }

  /**
   * Get coListAgentFax
   * @return coListAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentFax() {
    return coListAgentFax;
  }

  public void setCoListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
  }

  public OrgResoMetadataProperty coListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
    return this;
  }

  /**
   * Get coListAgentFirstName
   * @return coListAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentFirstName() {
    return coListAgentFirstName;
  }

  public void setCoListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
  }

  public OrgResoMetadataProperty coListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
    return this;
  }

  /**
   * Get coListAgentFullName
   * @return coListAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoListAgentFullName() {
    return coListAgentFullName;
  }

  public void setCoListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
  }

  public OrgResoMetadataProperty coListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
    return this;
  }

  /**
   * Get coListAgentHomePhone
   * @return coListAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentHomePhone() {
    return coListAgentHomePhone;
  }

  public void setCoListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
  }

  public OrgResoMetadataProperty coListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
    return this;
  }

  /**
   * Get coListAgentKey
   * @return coListAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListAgentKey() {
    return coListAgentKey;
  }

  public void setCoListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
  }

  public OrgResoMetadataProperty coListAgentKeyNumeric(AnyOforgResoMetadataPropertyCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
    return this;
  }

  /**
   * Get coListAgentKeyNumeric
   * @return coListAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCoListAgentKeyNumeric getCoListAgentKeyNumeric() {
    return coListAgentKeyNumeric;
  }

  public void setCoListAgentKeyNumeric(AnyOforgResoMetadataPropertyCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
  }

  public OrgResoMetadataProperty coListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
    return this;
  }

  /**
   * Get coListAgentLastName
   * @return coListAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentLastName() {
    return coListAgentLastName;
  }

  public void setCoListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
  }

  public OrgResoMetadataProperty coListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
    return this;
  }

  /**
   * Get coListAgentMiddleName
   * @return coListAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentMiddleName() {
    return coListAgentMiddleName;
  }

  public void setCoListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
  }

  public OrgResoMetadataProperty coListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
    return this;
  }

  /**
   * Get coListAgentMlsId
   * @return coListAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListAgentMlsId() {
    return coListAgentMlsId;
  }

  public void setCoListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
  }

  public OrgResoMetadataProperty coListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
    return this;
  }

  /**
   * Get coListAgentMobilePhone
   * @return coListAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentMobilePhone() {
    return coListAgentMobilePhone;
  }

  public void setCoListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
  }

  public OrgResoMetadataProperty coListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
    return this;
  }

  /**
   * Get coListAgentNamePrefix
   * @return coListAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNamePrefix() {
    return coListAgentNamePrefix;
  }

  public void setCoListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
  }

  public OrgResoMetadataProperty coListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
    return this;
  }

  /**
   * Get coListAgentNameSuffix
   * @return coListAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNameSuffix() {
    return coListAgentNameSuffix;
  }

  public void setCoListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
  }

  public OrgResoMetadataProperty coListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
    return this;
  }

  /**
   * Get coListAgentOfficePhone
   * @return coListAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentOfficePhone() {
    return coListAgentOfficePhone;
  }

  public void setCoListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
  }

  public OrgResoMetadataProperty coListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coListAgentOfficePhoneExt
   * @return coListAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentOfficePhoneExt() {
    return coListAgentOfficePhoneExt;
  }

  public void setCoListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
  }

  public OrgResoMetadataProperty coListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
    return this;
  }

  /**
   * Get coListAgentPager
   * @return coListAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPager() {
    return coListAgentPager;
  }

  public void setCoListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
  }

  public OrgResoMetadataProperty coListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
    return this;
  }

  /**
   * Get coListAgentPreferredPhone
   * @return coListAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPreferredPhone() {
    return coListAgentPreferredPhone;
  }

  public void setCoListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
  }

  public OrgResoMetadataProperty coListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coListAgentPreferredPhoneExt
   * @return coListAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentPreferredPhoneExt() {
    return coListAgentPreferredPhoneExt;
  }

  public void setCoListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
  }

  public OrgResoMetadataProperty coListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
    return this;
  }

  /**
   * Get coListAgentStateLicense
   * @return coListAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentStateLicense() {
    return coListAgentStateLicense;
  }

  public void setCoListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
  }

  public OrgResoMetadataProperty coListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
    return this;
  }

  /**
   * Get coListAgentTollFreePhone
   * @return coListAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentTollFreePhone() {
    return coListAgentTollFreePhone;
  }

  public void setCoListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
  }

  public OrgResoMetadataProperty coListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
    return this;
  }

  /**
   * Get coListAgentURL
   * @return coListAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListAgentURL() {
    return coListAgentURL;
  }

  public void setCoListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
  }

  public OrgResoMetadataProperty coListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
    return this;
  }

  /**
   * Get coListAgentVoiceMail
   * @return coListAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentVoiceMail() {
    return coListAgentVoiceMail;
  }

  public void setCoListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
  }

  public OrgResoMetadataProperty coListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coListAgentVoiceMailExt
   * @return coListAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentVoiceMailExt() {
    return coListAgentVoiceMailExt;
  }

  public void setCoListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
  }

  public OrgResoMetadataProperty coListOfficeAOR(AnyOforgResoMetadataPropertyCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
    return this;
  }

  /**
   * Get coListOfficeAOR
   * @return coListOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoListOfficeAOR getCoListOfficeAOR() {
    return coListOfficeAOR;
  }

  public void setCoListOfficeAOR(AnyOforgResoMetadataPropertyCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
  }

  public OrgResoMetadataProperty coListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
    return this;
  }

  /**
   * Get coListOfficeEmail
   * @return coListOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListOfficeEmail() {
    return coListOfficeEmail;
  }

  public void setCoListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
  }

  public OrgResoMetadataProperty coListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
    return this;
  }

  /**
   * Get coListOfficeFax
   * @return coListOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficeFax() {
    return coListOfficeFax;
  }

  public void setCoListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
  }

  public OrgResoMetadataProperty coListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
    return this;
  }

  /**
   * Get coListOfficeKey
   * @return coListOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeKey() {
    return coListOfficeKey;
  }

  public void setCoListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
  }

  public OrgResoMetadataProperty coListOfficeKeyNumeric(AnyOforgResoMetadataPropertyCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coListOfficeKeyNumeric
   * @return coListOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCoListOfficeKeyNumeric getCoListOfficeKeyNumeric() {
    return coListOfficeKeyNumeric;
  }

  public void setCoListOfficeKeyNumeric(AnyOforgResoMetadataPropertyCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
  }

  public OrgResoMetadataProperty coListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
    return this;
  }

  /**
   * Get coListOfficeMlsId
   * @return coListOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListOfficeMlsId() {
    return coListOfficeMlsId;
  }

  public void setCoListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
  }

  public OrgResoMetadataProperty coListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
    return this;
  }

  /**
   * Get coListOfficeName
   * @return coListOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeName() {
    return coListOfficeName;
  }

  public void setCoListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
  }

  public OrgResoMetadataProperty coListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
    return this;
  }

  /**
   * Get coListOfficePhone
   * @return coListOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficePhone() {
    return coListOfficePhone;
  }

  public void setCoListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
  }

  public OrgResoMetadataProperty coListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
    return this;
  }

  /**
   * Get coListOfficePhoneExt
   * @return coListOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListOfficePhoneExt() {
    return coListOfficePhoneExt;
  }

  public void setCoListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
  }

  public OrgResoMetadataProperty coListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
    return this;
  }

  /**
   * Get coListOfficeURL
   * @return coListOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListOfficeURL() {
    return coListOfficeURL;
  }

  public void setCoListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
  }

  public OrgResoMetadataProperty commonInterest(AnyOforgResoMetadataPropertyCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
    return this;
  }

  /**
   * Get commonInterest
   * @return commonInterest
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCommonInterest getCommonInterest() {
    return commonInterest;
  }

  public void setCommonInterest(AnyOforgResoMetadataPropertyCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
  }

  public OrgResoMetadataProperty commonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
    return this;
  }

  public OrgResoMetadataProperty addCommonWallsItem(OrgResoMetadataEnumsCommonWalls commonWallsItem) {
    if (this.commonWalls == null) {
      this.commonWalls = new ArrayList<OrgResoMetadataEnumsCommonWalls>();
    }
    this.commonWalls.add(commonWallsItem);
    return this;
  }

  /**
   * Get commonWalls
   * @return commonWalls
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommonWalls> getCommonWalls() {
    return commonWalls;
  }

  public void setCommonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
  }

  public OrgResoMetadataProperty communityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
    return this;
  }

  public OrgResoMetadataProperty addCommunityFeaturesItem(OrgResoMetadataEnumsCommunityFeatures communityFeaturesItem) {
    if (this.communityFeatures == null) {
      this.communityFeatures = new ArrayList<OrgResoMetadataEnumsCommunityFeatures>();
    }
    this.communityFeatures.add(communityFeaturesItem);
    return this;
  }

  /**
   * Get communityFeatures
   * @return communityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommunityFeatures> getCommunityFeatures() {
    return communityFeatures;
  }

  public void setCommunityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
  }

  public OrgResoMetadataProperty concessions(AnyOforgResoMetadataPropertyConcessions concessions) {
    this.concessions = concessions;
    return this;
  }

  /**
   * Get concessions
   * @return concessions
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyConcessions getConcessions() {
    return concessions;
  }

  public void setConcessions(AnyOforgResoMetadataPropertyConcessions concessions) {
    this.concessions = concessions;
  }

  public OrgResoMetadataProperty concessionsAmount(AnyOforgResoMetadataPropertyConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
    return this;
  }

  /**
   * Get concessionsAmount
   * @return concessionsAmount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyConcessionsAmount getConcessionsAmount() {
    return concessionsAmount;
  }

  public void setConcessionsAmount(AnyOforgResoMetadataPropertyConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
  }

  public OrgResoMetadataProperty concessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
    return this;
  }

  /**
   * Get concessionsComments
   * @return concessionsComments
   **/
  @Schema(description = "")
  
  @Size(max=200)   public String getConcessionsComments() {
    return concessionsComments;
  }

  public void setConcessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
  }

  public OrgResoMetadataProperty constructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
    return this;
  }

  public OrgResoMetadataProperty addConstructionMaterialsItem(OrgResoMetadataEnumsConstructionMaterials constructionMaterialsItem) {
    if (this.constructionMaterials == null) {
      this.constructionMaterials = new ArrayList<OrgResoMetadataEnumsConstructionMaterials>();
    }
    this.constructionMaterials.add(constructionMaterialsItem);
    return this;
  }

  /**
   * Get constructionMaterials
   * @return constructionMaterials
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsConstructionMaterials> getConstructionMaterials() {
    return constructionMaterials;
  }

  public void setConstructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
  }

  public OrgResoMetadataProperty continentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
    return this;
  }

  /**
   * Get continentRegion
   * @return continentRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getContinentRegion() {
    return continentRegion;
  }

  public void setContinentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
  }

  public OrgResoMetadataProperty contingency(String contingency) {
    this.contingency = contingency;
    return this;
  }

  /**
   * Get contingency
   * @return contingency
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getContingency() {
    return contingency;
  }

  public void setContingency(String contingency) {
    this.contingency = contingency;
  }

  public OrgResoMetadataProperty contingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
    return this;
  }

  /**
   * Get contingentDate
   * @return contingentDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContingentDate() {
    return contingentDate;
  }

  public void setContingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
  }

  public OrgResoMetadataProperty contractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
    return this;
  }

  /**
   * Get contractStatusChangeDate
   * @return contractStatusChangeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContractStatusChangeDate() {
    return contractStatusChangeDate;
  }

  public void setContractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
  }

  public OrgResoMetadataProperty cooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
    return this;
  }

  public OrgResoMetadataProperty addCoolingItem(OrgResoMetadataEnumsCooling coolingItem) {
    if (this.cooling == null) {
      this.cooling = new ArrayList<OrgResoMetadataEnumsCooling>();
    }
    this.cooling.add(coolingItem);
    return this;
  }

  /**
   * Get cooling
   * @return cooling
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCooling> getCooling() {
    return cooling;
  }

  public void setCooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
  }

  public OrgResoMetadataProperty coolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
    return this;
  }

  /**
   * Get coolingYN
   * @return coolingYN
   **/
  @Schema(description = "")
  
    public Boolean isCoolingYN() {
    return coolingYN;
  }

  public void setCoolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
  }

  public OrgResoMetadataProperty copyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
    return this;
  }

  /**
   * Get copyrightNotice
   * @return copyrightNotice
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getCopyrightNotice() {
    return copyrightNotice;
  }

  public void setCopyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
  }

  public OrgResoMetadataProperty country(AnyOforgResoMetadataPropertyCountry country) {
    this.country = country;
    return this;
  }

  /**
   * Get country
   * @return country
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCountry getCountry() {
    return country;
  }

  public void setCountry(AnyOforgResoMetadataPropertyCountry country) {
    this.country = country;
  }

  public OrgResoMetadataProperty countryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
    return this;
  }

  /**
   * Get countryRegion
   * @return countryRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCountryRegion() {
    return countryRegion;
  }

  public void setCountryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
  }

  public OrgResoMetadataProperty countyOrParish(AnyOforgResoMetadataPropertyCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
    return this;
  }

  /**
   * Get countyOrParish
   * @return countyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCountyOrParish getCountyOrParish() {
    return countyOrParish;
  }

  public void setCountyOrParish(AnyOforgResoMetadataPropertyCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
  }

  public OrgResoMetadataProperty coveredSpaces(AnyOforgResoMetadataPropertyCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
    return this;
  }

  /**
   * Get coveredSpaces
   * @return coveredSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCoveredSpaces getCoveredSpaces() {
    return coveredSpaces;
  }

  public void setCoveredSpaces(AnyOforgResoMetadataPropertyCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
  }

  public OrgResoMetadataProperty cropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
    return this;
  }

  /**
   * Get cropsIncludedYN
   * @return cropsIncludedYN
   **/
  @Schema(description = "")
  
    public Boolean isCropsIncludedYN() {
    return cropsIncludedYN;
  }

  public void setCropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
  }

  public OrgResoMetadataProperty crossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
    return this;
  }

  /**
   * Get crossStreet
   * @return crossStreet
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCrossStreet() {
    return crossStreet;
  }

  public void setCrossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
  }

  public OrgResoMetadataProperty cultivatedArea(AnyOforgResoMetadataPropertyCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
    return this;
  }

  /**
   * Get cultivatedArea
   * @return cultivatedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCultivatedArea getCultivatedArea() {
    return cultivatedArea;
  }

  public void setCultivatedArea(AnyOforgResoMetadataPropertyCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
  }

  public OrgResoMetadataProperty cumulativeDaysOnMarket(AnyOforgResoMetadataPropertyCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
    return this;
  }

  /**
   * Get cumulativeDaysOnMarket
   * @return cumulativeDaysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCumulativeDaysOnMarket getCumulativeDaysOnMarket() {
    return cumulativeDaysOnMarket;
  }

  public void setCumulativeDaysOnMarket(AnyOforgResoMetadataPropertyCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
  }

  public OrgResoMetadataProperty currentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
    return this;
  }

  public OrgResoMetadataProperty addCurrentFinancingItem(OrgResoMetadataEnumsCurrentFinancing currentFinancingItem) {
    if (this.currentFinancing == null) {
      this.currentFinancing = new ArrayList<OrgResoMetadataEnumsCurrentFinancing>();
    }
    this.currentFinancing.add(currentFinancingItem);
    return this;
  }

  /**
   * Get currentFinancing
   * @return currentFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentFinancing> getCurrentFinancing() {
    return currentFinancing;
  }

  public void setCurrentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
  }

  public OrgResoMetadataProperty currentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
    return this;
  }

  public OrgResoMetadataProperty addCurrentUseItem(OrgResoMetadataEnumsCurrentUse currentUseItem) {
    if (this.currentUse == null) {
      this.currentUse = new ArrayList<OrgResoMetadataEnumsCurrentUse>();
    }
    this.currentUse.add(currentUseItem);
    return this;
  }

  /**
   * Get currentUse
   * @return currentUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentUse> getCurrentUse() {
    return currentUse;
  }

  public void setCurrentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
  }

  public OrgResoMetadataProperty doH1(String doH1) {
    this.doH1 = doH1;
    return this;
  }

  /**
   * Get doH1
   * @return doH1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH1() {
    return doH1;
  }

  public void setDoH1(String doH1) {
    this.doH1 = doH1;
  }

  public OrgResoMetadataProperty doH2(String doH2) {
    this.doH2 = doH2;
    return this;
  }

  /**
   * Get doH2
   * @return doH2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH2() {
    return doH2;
  }

  public void setDoH2(String doH2) {
    this.doH2 = doH2;
  }

  public OrgResoMetadataProperty doH3(String doH3) {
    this.doH3 = doH3;
    return this;
  }

  /**
   * Get doH3
   * @return doH3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH3() {
    return doH3;
  }

  public void setDoH3(String doH3) {
    this.doH3 = doH3;
  }

  public OrgResoMetadataProperty daysOnMarket(AnyOforgResoMetadataPropertyDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
    return this;
  }

  /**
   * Get daysOnMarket
   * @return daysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDaysOnMarket getDaysOnMarket() {
    return daysOnMarket;
  }

  public void setDaysOnMarket(AnyOforgResoMetadataPropertyDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
  }

  public OrgResoMetadataProperty developmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
    return this;
  }

  public OrgResoMetadataProperty addDevelopmentStatusItem(OrgResoMetadataEnumsDevelopmentStatus developmentStatusItem) {
    if (this.developmentStatus == null) {
      this.developmentStatus = new ArrayList<OrgResoMetadataEnumsDevelopmentStatus>();
    }
    this.developmentStatus.add(developmentStatusItem);
    return this;
  }

  /**
   * Get developmentStatus
   * @return developmentStatus
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDevelopmentStatus> getDevelopmentStatus() {
    return developmentStatus;
  }

  public void setDevelopmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
  }

  public OrgResoMetadataProperty directionFaces(AnyOforgResoMetadataPropertyDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
    return this;
  }

  /**
   * Get directionFaces
   * @return directionFaces
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDirectionFaces getDirectionFaces() {
    return directionFaces;
  }

  public void setDirectionFaces(AnyOforgResoMetadataPropertyDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
  }

  public OrgResoMetadataProperty directions(String directions) {
    this.directions = directions;
    return this;
  }

  /**
   * Get directions
   * @return directions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getDirections() {
    return directions;
  }

  public void setDirections(String directions) {
    this.directions = directions;
  }

  public OrgResoMetadataProperty disclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
    return this;
  }

  /**
   * Get disclaimer
   * @return disclaimer
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getDisclaimer() {
    return disclaimer;
  }

  public void setDisclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
  }

  public OrgResoMetadataProperty disclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
    return this;
  }

  public OrgResoMetadataProperty addDisclosuresItem(OrgResoMetadataEnumsDisclosures disclosuresItem) {
    if (this.disclosures == null) {
      this.disclosures = new ArrayList<OrgResoMetadataEnumsDisclosures>();
    }
    this.disclosures.add(disclosuresItem);
    return this;
  }

  /**
   * Get disclosures
   * @return disclosures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDisclosures> getDisclosures() {
    return disclosures;
  }

  public void setDisclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
  }

  public OrgResoMetadataProperty distanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
    return this;
  }

  /**
   * Get distanceToBusComments
   * @return distanceToBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToBusComments() {
    return distanceToBusComments;
  }

  public void setDistanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
  }

  public OrgResoMetadataProperty distanceToBusNumeric(AnyOforgResoMetadataPropertyDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
    return this;
  }

  /**
   * Get distanceToBusNumeric
   * @return distanceToBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToBusNumeric getDistanceToBusNumeric() {
    return distanceToBusNumeric;
  }

  public void setDistanceToBusNumeric(AnyOforgResoMetadataPropertyDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
  }

  public OrgResoMetadataProperty distanceToBusUnits(AnyOforgResoMetadataPropertyDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
    return this;
  }

  /**
   * Get distanceToBusUnits
   * @return distanceToBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToBusUnits getDistanceToBusUnits() {
    return distanceToBusUnits;
  }

  public void setDistanceToBusUnits(AnyOforgResoMetadataPropertyDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
  }

  public OrgResoMetadataProperty distanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
    return this;
  }

  /**
   * Get distanceToElectricComments
   * @return distanceToElectricComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToElectricComments() {
    return distanceToElectricComments;
  }

  public void setDistanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
  }

  public OrgResoMetadataProperty distanceToElectricNumeric(AnyOforgResoMetadataPropertyDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
    return this;
  }

  /**
   * Get distanceToElectricNumeric
   * @return distanceToElectricNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToElectricNumeric getDistanceToElectricNumeric() {
    return distanceToElectricNumeric;
  }

  public void setDistanceToElectricNumeric(AnyOforgResoMetadataPropertyDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
  }

  public OrgResoMetadataProperty distanceToElectricUnits(AnyOforgResoMetadataPropertyDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
    return this;
  }

  /**
   * Get distanceToElectricUnits
   * @return distanceToElectricUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToElectricUnits getDistanceToElectricUnits() {
    return distanceToElectricUnits;
  }

  public void setDistanceToElectricUnits(AnyOforgResoMetadataPropertyDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
  }

  public OrgResoMetadataProperty distanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
    return this;
  }

  /**
   * Get distanceToFreewayComments
   * @return distanceToFreewayComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToFreewayComments() {
    return distanceToFreewayComments;
  }

  public void setDistanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
  }

  public OrgResoMetadataProperty distanceToFreewayNumeric(AnyOforgResoMetadataPropertyDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
    return this;
  }

  /**
   * Get distanceToFreewayNumeric
   * @return distanceToFreewayNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToFreewayNumeric getDistanceToFreewayNumeric() {
    return distanceToFreewayNumeric;
  }

  public void setDistanceToFreewayNumeric(AnyOforgResoMetadataPropertyDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
  }

  public OrgResoMetadataProperty distanceToFreewayUnits(AnyOforgResoMetadataPropertyDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
    return this;
  }

  /**
   * Get distanceToFreewayUnits
   * @return distanceToFreewayUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToFreewayUnits getDistanceToFreewayUnits() {
    return distanceToFreewayUnits;
  }

  public void setDistanceToFreewayUnits(AnyOforgResoMetadataPropertyDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
  }

  public OrgResoMetadataProperty distanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
    return this;
  }

  /**
   * Get distanceToGasComments
   * @return distanceToGasComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToGasComments() {
    return distanceToGasComments;
  }

  public void setDistanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
  }

  public OrgResoMetadataProperty distanceToGasNumeric(AnyOforgResoMetadataPropertyDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
    return this;
  }

  /**
   * Get distanceToGasNumeric
   * @return distanceToGasNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToGasNumeric getDistanceToGasNumeric() {
    return distanceToGasNumeric;
  }

  public void setDistanceToGasNumeric(AnyOforgResoMetadataPropertyDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
  }

  public OrgResoMetadataProperty distanceToGasUnits(AnyOforgResoMetadataPropertyDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
    return this;
  }

  /**
   * Get distanceToGasUnits
   * @return distanceToGasUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToGasUnits getDistanceToGasUnits() {
    return distanceToGasUnits;
  }

  public void setDistanceToGasUnits(AnyOforgResoMetadataPropertyDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
  }

  public OrgResoMetadataProperty distanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
    return this;
  }

  /**
   * Get distanceToPhoneServiceComments
   * @return distanceToPhoneServiceComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPhoneServiceComments() {
    return distanceToPhoneServiceComments;
  }

  public void setDistanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
  }

  public OrgResoMetadataProperty distanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
    return this;
  }

  /**
   * Get distanceToPhoneServiceNumeric
   * @return distanceToPhoneServiceNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric getDistanceToPhoneServiceNumeric() {
    return distanceToPhoneServiceNumeric;
  }

  public void setDistanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
  }

  public OrgResoMetadataProperty distanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
    return this;
  }

  /**
   * Get distanceToPhoneServiceUnits
   * @return distanceToPhoneServiceUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToPhoneServiceUnits getDistanceToPhoneServiceUnits() {
    return distanceToPhoneServiceUnits;
  }

  public void setDistanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
  }

  public OrgResoMetadataProperty distanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipComments
   * @return distanceToPlaceofWorshipComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPlaceofWorshipComments() {
    return distanceToPlaceofWorshipComments;
  }

  public void setDistanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
  }

  public OrgResoMetadataProperty distanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipNumeric
   * @return distanceToPlaceofWorshipNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipNumeric getDistanceToPlaceofWorshipNumeric() {
    return distanceToPlaceofWorshipNumeric;
  }

  public void setDistanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
  }

  public OrgResoMetadataProperty distanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipUnits
   * @return distanceToPlaceofWorshipUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipUnits getDistanceToPlaceofWorshipUnits() {
    return distanceToPlaceofWorshipUnits;
  }

  public void setDistanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
  }

  public OrgResoMetadataProperty distanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
    return this;
  }

  /**
   * Get distanceToSchoolBusComments
   * @return distanceToSchoolBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolBusComments() {
    return distanceToSchoolBusComments;
  }

  public void setDistanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
  }

  public OrgResoMetadataProperty distanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolBusNumeric
   * @return distanceToSchoolBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric getDistanceToSchoolBusNumeric() {
    return distanceToSchoolBusNumeric;
  }

  public void setDistanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
  }

  public OrgResoMetadataProperty distanceToSchoolBusUnits(AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
    return this;
  }

  /**
   * Get distanceToSchoolBusUnits
   * @return distanceToSchoolBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits getDistanceToSchoolBusUnits() {
    return distanceToSchoolBusUnits;
  }

  public void setDistanceToSchoolBusUnits(AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
  }

  public OrgResoMetadataProperty distanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
    return this;
  }

  /**
   * Get distanceToSchoolsComments
   * @return distanceToSchoolsComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolsComments() {
    return distanceToSchoolsComments;
  }

  public void setDistanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
  }

  public OrgResoMetadataProperty distanceToSchoolsNumeric(AnyOforgResoMetadataPropertyDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolsNumeric
   * @return distanceToSchoolsNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSchoolsNumeric getDistanceToSchoolsNumeric() {
    return distanceToSchoolsNumeric;
  }

  public void setDistanceToSchoolsNumeric(AnyOforgResoMetadataPropertyDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
  }

  public OrgResoMetadataProperty distanceToSchoolsUnits(AnyOforgResoMetadataPropertyDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
    return this;
  }

  /**
   * Get distanceToSchoolsUnits
   * @return distanceToSchoolsUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSchoolsUnits getDistanceToSchoolsUnits() {
    return distanceToSchoolsUnits;
  }

  public void setDistanceToSchoolsUnits(AnyOforgResoMetadataPropertyDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
  }

  public OrgResoMetadataProperty distanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
    return this;
  }

  /**
   * Get distanceToSewerComments
   * @return distanceToSewerComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSewerComments() {
    return distanceToSewerComments;
  }

  public void setDistanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
  }

  public OrgResoMetadataProperty distanceToSewerNumeric(AnyOforgResoMetadataPropertyDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
    return this;
  }

  /**
   * Get distanceToSewerNumeric
   * @return distanceToSewerNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSewerNumeric getDistanceToSewerNumeric() {
    return distanceToSewerNumeric;
  }

  public void setDistanceToSewerNumeric(AnyOforgResoMetadataPropertyDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
  }

  public OrgResoMetadataProperty distanceToSewerUnits(AnyOforgResoMetadataPropertyDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
    return this;
  }

  /**
   * Get distanceToSewerUnits
   * @return distanceToSewerUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToSewerUnits getDistanceToSewerUnits() {
    return distanceToSewerUnits;
  }

  public void setDistanceToSewerUnits(AnyOforgResoMetadataPropertyDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
  }

  public OrgResoMetadataProperty distanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
    return this;
  }

  /**
   * Get distanceToShoppingComments
   * @return distanceToShoppingComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToShoppingComments() {
    return distanceToShoppingComments;
  }

  public void setDistanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
  }

  public OrgResoMetadataProperty distanceToShoppingNumeric(AnyOforgResoMetadataPropertyDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
    return this;
  }

  /**
   * Get distanceToShoppingNumeric
   * @return distanceToShoppingNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToShoppingNumeric getDistanceToShoppingNumeric() {
    return distanceToShoppingNumeric;
  }

  public void setDistanceToShoppingNumeric(AnyOforgResoMetadataPropertyDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
  }

  public OrgResoMetadataProperty distanceToShoppingUnits(AnyOforgResoMetadataPropertyDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
    return this;
  }

  /**
   * Get distanceToShoppingUnits
   * @return distanceToShoppingUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToShoppingUnits getDistanceToShoppingUnits() {
    return distanceToShoppingUnits;
  }

  public void setDistanceToShoppingUnits(AnyOforgResoMetadataPropertyDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
  }

  public OrgResoMetadataProperty distanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
    return this;
  }

  /**
   * Get distanceToStreetComments
   * @return distanceToStreetComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToStreetComments() {
    return distanceToStreetComments;
  }

  public void setDistanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
  }

  public OrgResoMetadataProperty distanceToStreetNumeric(AnyOforgResoMetadataPropertyDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
    return this;
  }

  /**
   * Get distanceToStreetNumeric
   * @return distanceToStreetNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToStreetNumeric getDistanceToStreetNumeric() {
    return distanceToStreetNumeric;
  }

  public void setDistanceToStreetNumeric(AnyOforgResoMetadataPropertyDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
  }

  public OrgResoMetadataProperty distanceToStreetUnits(AnyOforgResoMetadataPropertyDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
    return this;
  }

  /**
   * Get distanceToStreetUnits
   * @return distanceToStreetUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToStreetUnits getDistanceToStreetUnits() {
    return distanceToStreetUnits;
  }

  public void setDistanceToStreetUnits(AnyOforgResoMetadataPropertyDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
  }

  public OrgResoMetadataProperty distanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
    return this;
  }

  /**
   * Get distanceToWaterComments
   * @return distanceToWaterComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToWaterComments() {
    return distanceToWaterComments;
  }

  public void setDistanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
  }

  public OrgResoMetadataProperty distanceToWaterNumeric(AnyOforgResoMetadataPropertyDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
    return this;
  }

  /**
   * Get distanceToWaterNumeric
   * @return distanceToWaterNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToWaterNumeric getDistanceToWaterNumeric() {
    return distanceToWaterNumeric;
  }

  public void setDistanceToWaterNumeric(AnyOforgResoMetadataPropertyDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
  }

  public OrgResoMetadataProperty distanceToWaterUnits(AnyOforgResoMetadataPropertyDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
    return this;
  }

  /**
   * Get distanceToWaterUnits
   * @return distanceToWaterUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyDistanceToWaterUnits getDistanceToWaterUnits() {
    return distanceToWaterUnits;
  }

  public void setDistanceToWaterUnits(AnyOforgResoMetadataPropertyDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
  }

  public OrgResoMetadataProperty documentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
    return this;
  }

  public OrgResoMetadataProperty addDocumentsAvailableItem(OrgResoMetadataEnumsDocumentsAvailable documentsAvailableItem) {
    if (this.documentsAvailable == null) {
      this.documentsAvailable = new ArrayList<OrgResoMetadataEnumsDocumentsAvailable>();
    }
    this.documentsAvailable.add(documentsAvailableItem);
    return this;
  }

  /**
   * Get documentsAvailable
   * @return documentsAvailable
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDocumentsAvailable> getDocumentsAvailable() {
    return documentsAvailable;
  }

  public void setDocumentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
  }

  public OrgResoMetadataProperty documentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
    return this;
  }

  /**
   * Get documentsChangeTimestamp
   * @return documentsChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDocumentsChangeTimestamp() {
    return documentsChangeTimestamp;
  }

  public void setDocumentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
  }

  public OrgResoMetadataProperty documentsCount(AnyOforgResoMetadataPropertyDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
    return this;
  }

  /**
   * Get documentsCount
   * @return documentsCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyDocumentsCount getDocumentsCount() {
    return documentsCount;
  }

  public void setDocumentsCount(AnyOforgResoMetadataPropertyDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
  }

  public OrgResoMetadataProperty doorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
    return this;
  }

  public OrgResoMetadataProperty addDoorFeaturesItem(OrgResoMetadataEnumsDoorFeatures doorFeaturesItem) {
    if (this.doorFeatures == null) {
      this.doorFeatures = new ArrayList<OrgResoMetadataEnumsDoorFeatures>();
    }
    this.doorFeatures.add(doorFeaturesItem);
    return this;
  }

  /**
   * Get doorFeatures
   * @return doorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDoorFeatures> getDoorFeatures() {
    return doorFeatures;
  }

  public void setDoorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
  }

  public OrgResoMetadataProperty dualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
    return this;
  }

  /**
   * Get dualVariableCompensationYN
   * @return dualVariableCompensationYN
   **/
  @Schema(description = "")
  
    public Boolean isDualVariableCompensationYN() {
    return dualVariableCompensationYN;
  }

  public void setDualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
  }

  public OrgResoMetadataProperty electric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
    return this;
  }

  public OrgResoMetadataProperty addElectricItem(OrgResoMetadataEnumsElectric electricItem) {
    if (this.electric == null) {
      this.electric = new ArrayList<OrgResoMetadataEnumsElectric>();
    }
    this.electric.add(electricItem);
    return this;
  }

  /**
   * Get electric
   * @return electric
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsElectric> getElectric() {
    return electric;
  }

  public void setElectric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
  }

  public OrgResoMetadataProperty electricExpense(AnyOforgResoMetadataPropertyElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
    return this;
  }

  /**
   * Get electricExpense
   * @return electricExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyElectricExpense getElectricExpense() {
    return electricExpense;
  }

  public void setElectricExpense(AnyOforgResoMetadataPropertyElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
  }

  public OrgResoMetadataProperty electricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
    return this;
  }

  /**
   * Get electricOnPropertyYN
   * @return electricOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isElectricOnPropertyYN() {
    return electricOnPropertyYN;
  }

  public void setElectricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
  }

  public OrgResoMetadataProperty elementarySchool(AnyOforgResoMetadataPropertyElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
    return this;
  }

  /**
   * Get elementarySchool
   * @return elementarySchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyElementarySchool getElementarySchool() {
    return elementarySchool;
  }

  public void setElementarySchool(AnyOforgResoMetadataPropertyElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
  }

  public OrgResoMetadataProperty elementarySchoolDistrict(AnyOforgResoMetadataPropertyElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
    return this;
  }

  /**
   * Get elementarySchoolDistrict
   * @return elementarySchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyElementarySchoolDistrict getElementarySchoolDistrict() {
    return elementarySchoolDistrict;
  }

  public void setElementarySchoolDistrict(AnyOforgResoMetadataPropertyElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
  }

  public OrgResoMetadataProperty elevation(AnyOforgResoMetadataPropertyElevation elevation) {
    this.elevation = elevation;
    return this;
  }

  /**
   * Get elevation
   * @return elevation
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyElevation getElevation() {
    return elevation;
  }

  public void setElevation(AnyOforgResoMetadataPropertyElevation elevation) {
    this.elevation = elevation;
  }

  public OrgResoMetadataProperty elevationUnits(AnyOforgResoMetadataPropertyElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
    return this;
  }

  /**
   * Get elevationUnits
   * @return elevationUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyElevationUnits getElevationUnits() {
    return elevationUnits;
  }

  public void setElevationUnits(AnyOforgResoMetadataPropertyElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
  }

  public OrgResoMetadataProperty entryLevel(AnyOforgResoMetadataPropertyEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
    return this;
  }

  /**
   * Get entryLevel
   * @return entryLevel
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyEntryLevel getEntryLevel() {
    return entryLevel;
  }

  public void setEntryLevel(AnyOforgResoMetadataPropertyEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
  }

  public OrgResoMetadataProperty entryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
    return this;
  }

  /**
   * Get entryLocation
   * @return entryLocation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getEntryLocation() {
    return entryLocation;
  }

  public void setEntryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
  }

  public OrgResoMetadataProperty exclusions(String exclusions) {
    this.exclusions = exclusions;
    return this;
  }

  /**
   * Get exclusions
   * @return exclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getExclusions() {
    return exclusions;
  }

  public void setExclusions(String exclusions) {
    this.exclusions = exclusions;
  }

  public OrgResoMetadataProperty existingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
    return this;
  }

  public OrgResoMetadataProperty addExistingLeaseTypeItem(OrgResoMetadataEnumsExistingLeaseType existingLeaseTypeItem) {
    if (this.existingLeaseType == null) {
      this.existingLeaseType = new ArrayList<OrgResoMetadataEnumsExistingLeaseType>();
    }
    this.existingLeaseType.add(existingLeaseTypeItem);
    return this;
  }

  /**
   * Get existingLeaseType
   * @return existingLeaseType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExistingLeaseType> getExistingLeaseType() {
    return existingLeaseType;
  }

  public void setExistingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
  }

  public OrgResoMetadataProperty expirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
    return this;
  }

  /**
   * Get expirationDate
   * @return expirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
  }

  public OrgResoMetadataProperty exteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
    return this;
  }

  public OrgResoMetadataProperty addExteriorFeaturesItem(OrgResoMetadataEnumsExteriorFeatures exteriorFeaturesItem) {
    if (this.exteriorFeatures == null) {
      this.exteriorFeatures = new ArrayList<OrgResoMetadataEnumsExteriorFeatures>();
    }
    this.exteriorFeatures.add(exteriorFeaturesItem);
    return this;
  }

  /**
   * Get exteriorFeatures
   * @return exteriorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExteriorFeatures> getExteriorFeatures() {
    return exteriorFeatures;
  }

  public void setExteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
  }

  public OrgResoMetadataProperty farmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
    return this;
  }

  /**
   * Get farmCreditServiceInclYN
   * @return farmCreditServiceInclYN
   **/
  @Schema(description = "")
  
    public Boolean isFarmCreditServiceInclYN() {
    return farmCreditServiceInclYN;
  }

  public void setFarmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
  }

  public OrgResoMetadataProperty farmLandAreaSource(AnyOforgResoMetadataPropertyFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
    return this;
  }

  /**
   * Get farmLandAreaSource
   * @return farmLandAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyFarmLandAreaSource getFarmLandAreaSource() {
    return farmLandAreaSource;
  }

  public void setFarmLandAreaSource(AnyOforgResoMetadataPropertyFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
  }

  public OrgResoMetadataProperty farmLandAreaUnits(AnyOforgResoMetadataPropertyFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
    return this;
  }

  /**
   * Get farmLandAreaUnits
   * @return farmLandAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyFarmLandAreaUnits getFarmLandAreaUnits() {
    return farmLandAreaUnits;
  }

  public void setFarmLandAreaUnits(AnyOforgResoMetadataPropertyFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
  }

  public OrgResoMetadataProperty fencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
    return this;
  }

  public OrgResoMetadataProperty addFencingItem(OrgResoMetadataEnumsFencing fencingItem) {
    if (this.fencing == null) {
      this.fencing = new ArrayList<OrgResoMetadataEnumsFencing>();
    }
    this.fencing.add(fencingItem);
    return this;
  }

  /**
   * Get fencing
   * @return fencing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFencing> getFencing() {
    return fencing;
  }

  public void setFencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
  }

  public OrgResoMetadataProperty financialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
    return this;
  }

  public OrgResoMetadataProperty addFinancialDataSourceItem(OrgResoMetadataEnumsFinancialDataSource financialDataSourceItem) {
    if (this.financialDataSource == null) {
      this.financialDataSource = new ArrayList<OrgResoMetadataEnumsFinancialDataSource>();
    }
    this.financialDataSource.add(financialDataSourceItem);
    return this;
  }

  /**
   * Get financialDataSource
   * @return financialDataSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFinancialDataSource> getFinancialDataSource() {
    return financialDataSource;
  }

  public void setFinancialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
  }

  public OrgResoMetadataProperty fireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
    return this;
  }

  public OrgResoMetadataProperty addFireplaceFeaturesItem(OrgResoMetadataEnumsFireplaceFeatures fireplaceFeaturesItem) {
    if (this.fireplaceFeatures == null) {
      this.fireplaceFeatures = new ArrayList<OrgResoMetadataEnumsFireplaceFeatures>();
    }
    this.fireplaceFeatures.add(fireplaceFeaturesItem);
    return this;
  }

  /**
   * Get fireplaceFeatures
   * @return fireplaceFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFireplaceFeatures> getFireplaceFeatures() {
    return fireplaceFeatures;
  }

  public void setFireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
  }

  public OrgResoMetadataProperty fireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
    return this;
  }

  /**
   * Get fireplaceYN
   * @return fireplaceYN
   **/
  @Schema(description = "")
  
    public Boolean isFireplaceYN() {
    return fireplaceYN;
  }

  public void setFireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
  }

  public OrgResoMetadataProperty fireplacesTotal(AnyOforgResoMetadataPropertyFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
    return this;
  }

  /**
   * Get fireplacesTotal
   * @return fireplacesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyFireplacesTotal getFireplacesTotal() {
    return fireplacesTotal;
  }

  public void setFireplacesTotal(AnyOforgResoMetadataPropertyFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
  }

  public OrgResoMetadataProperty flooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
    return this;
  }

  public OrgResoMetadataProperty addFlooringItem(OrgResoMetadataEnumsFlooring flooringItem) {
    if (this.flooring == null) {
      this.flooring = new ArrayList<OrgResoMetadataEnumsFlooring>();
    }
    this.flooring.add(flooringItem);
    return this;
  }

  /**
   * Get flooring
   * @return flooring
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFlooring> getFlooring() {
    return flooring;
  }

  public void setFlooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
  }

  public OrgResoMetadataProperty foundationArea(AnyOforgResoMetadataPropertyFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
    return this;
  }

  /**
   * Get foundationArea
   * @return foundationArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyFoundationArea getFoundationArea() {
    return foundationArea;
  }

  public void setFoundationArea(AnyOforgResoMetadataPropertyFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
  }

  public OrgResoMetadataProperty foundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
    return this;
  }

  public OrgResoMetadataProperty addFoundationDetailsItem(OrgResoMetadataEnumsFoundationDetails foundationDetailsItem) {
    if (this.foundationDetails == null) {
      this.foundationDetails = new ArrayList<OrgResoMetadataEnumsFoundationDetails>();
    }
    this.foundationDetails.add(foundationDetailsItem);
    return this;
  }

  /**
   * Get foundationDetails
   * @return foundationDetails
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFoundationDetails> getFoundationDetails() {
    return foundationDetails;
  }

  public void setFoundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
  }

  public OrgResoMetadataProperty frontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
    return this;
  }

  /**
   * Get frontageLength
   * @return frontageLength
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getFrontageLength() {
    return frontageLength;
  }

  public void setFrontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
  }

  public OrgResoMetadataProperty frontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
    return this;
  }

  public OrgResoMetadataProperty addFrontageTypeItem(OrgResoMetadataEnumsFrontageType frontageTypeItem) {
    if (this.frontageType == null) {
      this.frontageType = new ArrayList<OrgResoMetadataEnumsFrontageType>();
    }
    this.frontageType.add(frontageTypeItem);
    return this;
  }

  /**
   * Get frontageType
   * @return frontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFrontageType> getFrontageType() {
    return frontageType;
  }

  public void setFrontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
  }

  public OrgResoMetadataProperty fuelExpense(AnyOforgResoMetadataPropertyFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
    return this;
  }

  /**
   * Get fuelExpense
   * @return fuelExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyFuelExpense getFuelExpense() {
    return fuelExpense;
  }

  public void setFuelExpense(AnyOforgResoMetadataPropertyFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
  }

  public OrgResoMetadataProperty furnished(AnyOforgResoMetadataPropertyFurnished furnished) {
    this.furnished = furnished;
    return this;
  }

  /**
   * Get furnished
   * @return furnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyFurnished getFurnished() {
    return furnished;
  }

  public void setFurnished(AnyOforgResoMetadataPropertyFurnished furnished) {
    this.furnished = furnished;
  }

  public OrgResoMetadataProperty furnitureReplacementExpense(AnyOforgResoMetadataPropertyFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
    return this;
  }

  /**
   * Get furnitureReplacementExpense
   * @return furnitureReplacementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyFurnitureReplacementExpense getFurnitureReplacementExpense() {
    return furnitureReplacementExpense;
  }

  public void setFurnitureReplacementExpense(AnyOforgResoMetadataPropertyFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
  }

  public OrgResoMetadataProperty garageSpaces(AnyOforgResoMetadataPropertyGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
    return this;
  }

  /**
   * Get garageSpaces
   * @return garageSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyGarageSpaces getGarageSpaces() {
    return garageSpaces;
  }

  public void setGarageSpaces(AnyOforgResoMetadataPropertyGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
  }

  public OrgResoMetadataProperty garageYN(Boolean garageYN) {
    this.garageYN = garageYN;
    return this;
  }

  /**
   * Get garageYN
   * @return garageYN
   **/
  @Schema(description = "")
  
    public Boolean isGarageYN() {
    return garageYN;
  }

  public void setGarageYN(Boolean garageYN) {
    this.garageYN = garageYN;
  }

  public OrgResoMetadataProperty gardenerExpense(AnyOforgResoMetadataPropertyGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
    return this;
  }

  /**
   * Get gardenerExpense
   * @return gardenerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyGardenerExpense getGardenerExpense() {
    return gardenerExpense;
  }

  public void setGardenerExpense(AnyOforgResoMetadataPropertyGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
  }

  public OrgResoMetadataProperty grazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
    return this;
  }

  /**
   * Get grazingPermitsBlmYN
   * @return grazingPermitsBlmYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsBlmYN() {
    return grazingPermitsBlmYN;
  }

  public void setGrazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
  }

  public OrgResoMetadataProperty grazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
    return this;
  }

  /**
   * Get grazingPermitsForestServiceYN
   * @return grazingPermitsForestServiceYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsForestServiceYN() {
    return grazingPermitsForestServiceYN;
  }

  public void setGrazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
  }

  public OrgResoMetadataProperty grazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
    return this;
  }

  /**
   * Get grazingPermitsPrivateYN
   * @return grazingPermitsPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsPrivateYN() {
    return grazingPermitsPrivateYN;
  }

  public void setGrazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
  }

  public OrgResoMetadataProperty greenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
    return this;
  }

  public OrgResoMetadataProperty addGreenBuildingVerificationTypeItem(OrgResoMetadataEnumsGreenBuildingVerificationType greenBuildingVerificationTypeItem) {
    if (this.greenBuildingVerificationType == null) {
      this.greenBuildingVerificationType = new ArrayList<OrgResoMetadataEnumsGreenBuildingVerificationType>();
    }
    this.greenBuildingVerificationType.add(greenBuildingVerificationTypeItem);
    return this;
  }

  /**
   * Get greenBuildingVerificationType
   * @return greenBuildingVerificationType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenBuildingVerificationType> getGreenBuildingVerificationType() {
    return greenBuildingVerificationType;
  }

  public void setGreenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
  }

  public OrgResoMetadataProperty greenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
    return this;
  }

  public OrgResoMetadataProperty addGreenEnergyEfficientItem(OrgResoMetadataEnumsGreenEnergyEfficient greenEnergyEfficientItem) {
    if (this.greenEnergyEfficient == null) {
      this.greenEnergyEfficient = new ArrayList<OrgResoMetadataEnumsGreenEnergyEfficient>();
    }
    this.greenEnergyEfficient.add(greenEnergyEfficientItem);
    return this;
  }

  /**
   * Get greenEnergyEfficient
   * @return greenEnergyEfficient
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyEfficient> getGreenEnergyEfficient() {
    return greenEnergyEfficient;
  }

  public void setGreenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
  }

  public OrgResoMetadataProperty greenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
    return this;
  }

  public OrgResoMetadataProperty addGreenEnergyGenerationItem(OrgResoMetadataEnumsGreenEnergyGeneration greenEnergyGenerationItem) {
    if (this.greenEnergyGeneration == null) {
      this.greenEnergyGeneration = new ArrayList<OrgResoMetadataEnumsGreenEnergyGeneration>();
    }
    this.greenEnergyGeneration.add(greenEnergyGenerationItem);
    return this;
  }

  /**
   * Get greenEnergyGeneration
   * @return greenEnergyGeneration
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyGeneration> getGreenEnergyGeneration() {
    return greenEnergyGeneration;
  }

  public void setGreenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
  }

  public OrgResoMetadataProperty greenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
    return this;
  }

  public OrgResoMetadataProperty addGreenIndoorAirQualityItem(OrgResoMetadataEnumsGreenIndoorAirQuality greenIndoorAirQualityItem) {
    if (this.greenIndoorAirQuality == null) {
      this.greenIndoorAirQuality = new ArrayList<OrgResoMetadataEnumsGreenIndoorAirQuality>();
    }
    this.greenIndoorAirQuality.add(greenIndoorAirQualityItem);
    return this;
  }

  /**
   * Get greenIndoorAirQuality
   * @return greenIndoorAirQuality
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenIndoorAirQuality> getGreenIndoorAirQuality() {
    return greenIndoorAirQuality;
  }

  public void setGreenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
  }

  public OrgResoMetadataProperty greenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
    return this;
  }

  public OrgResoMetadataProperty addGreenLocationItem(OrgResoMetadataEnumsGreenLocation greenLocationItem) {
    if (this.greenLocation == null) {
      this.greenLocation = new ArrayList<OrgResoMetadataEnumsGreenLocation>();
    }
    this.greenLocation.add(greenLocationItem);
    return this;
  }

  /**
   * Get greenLocation
   * @return greenLocation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenLocation> getGreenLocation() {
    return greenLocation;
  }

  public void setGreenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
  }

  public OrgResoMetadataProperty greenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
    return this;
  }

  public OrgResoMetadataProperty addGreenSustainabilityItem(OrgResoMetadataEnumsGreenSustainability greenSustainabilityItem) {
    if (this.greenSustainability == null) {
      this.greenSustainability = new ArrayList<OrgResoMetadataEnumsGreenSustainability>();
    }
    this.greenSustainability.add(greenSustainabilityItem);
    return this;
  }

  /**
   * Get greenSustainability
   * @return greenSustainability
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenSustainability> getGreenSustainability() {
    return greenSustainability;
  }

  public void setGreenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
  }

  public OrgResoMetadataProperty greenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
    return this;
  }

  public OrgResoMetadataProperty addGreenWaterConservationItem(OrgResoMetadataEnumsGreenWaterConservation greenWaterConservationItem) {
    if (this.greenWaterConservation == null) {
      this.greenWaterConservation = new ArrayList<OrgResoMetadataEnumsGreenWaterConservation>();
    }
    this.greenWaterConservation.add(greenWaterConservationItem);
    return this;
  }

  /**
   * Get greenWaterConservation
   * @return greenWaterConservation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenWaterConservation> getGreenWaterConservation() {
    return greenWaterConservation;
  }

  public void setGreenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
  }

  public OrgResoMetadataProperty grossIncome(AnyOforgResoMetadataPropertyGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
    return this;
  }

  /**
   * Get grossIncome
   * @return grossIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyGrossIncome getGrossIncome() {
    return grossIncome;
  }

  public void setGrossIncome(AnyOforgResoMetadataPropertyGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
  }

  public OrgResoMetadataProperty grossScheduledIncome(AnyOforgResoMetadataPropertyGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
    return this;
  }

  /**
   * Get grossScheduledIncome
   * @return grossScheduledIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyGrossScheduledIncome getGrossScheduledIncome() {
    return grossScheduledIncome;
  }

  public void setGrossScheduledIncome(AnyOforgResoMetadataPropertyGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
  }

  public OrgResoMetadataProperty habitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
    return this;
  }

  /**
   * Get habitableResidenceYN
   * @return habitableResidenceYN
   **/
  @Schema(description = "")
  
    public Boolean isHabitableResidenceYN() {
    return habitableResidenceYN;
  }

  public void setHabitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
  }

  public OrgResoMetadataProperty heating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
    return this;
  }

  public OrgResoMetadataProperty addHeatingItem(OrgResoMetadataEnumsHeating heatingItem) {
    if (this.heating == null) {
      this.heating = new ArrayList<OrgResoMetadataEnumsHeating>();
    }
    this.heating.add(heatingItem);
    return this;
  }

  /**
   * Get heating
   * @return heating
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHeating> getHeating() {
    return heating;
  }

  public void setHeating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
  }

  public OrgResoMetadataProperty heatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
    return this;
  }

  /**
   * Get heatingYN
   * @return heatingYN
   **/
  @Schema(description = "")
  
    public Boolean isHeatingYN() {
    return heatingYN;
  }

  public void setHeatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
  }

  public OrgResoMetadataProperty highSchool(AnyOforgResoMetadataPropertyHighSchool highSchool) {
    this.highSchool = highSchool;
    return this;
  }

  /**
   * Get highSchool
   * @return highSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyHighSchool getHighSchool() {
    return highSchool;
  }

  public void setHighSchool(AnyOforgResoMetadataPropertyHighSchool highSchool) {
    this.highSchool = highSchool;
  }

  public OrgResoMetadataProperty highSchoolDistrict(AnyOforgResoMetadataPropertyHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
    return this;
  }

  /**
   * Get highSchoolDistrict
   * @return highSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyHighSchoolDistrict getHighSchoolDistrict() {
    return highSchoolDistrict;
  }

  public void setHighSchoolDistrict(AnyOforgResoMetadataPropertyHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
  }

  public OrgResoMetadataProperty homeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
    return this;
  }

  /**
   * Get homeWarrantyYN
   * @return homeWarrantyYN
   **/
  @Schema(description = "")
  
    public Boolean isHomeWarrantyYN() {
    return homeWarrantyYN;
  }

  public void setHomeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
  }

  public OrgResoMetadataProperty horseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
    return this;
  }

  public OrgResoMetadataProperty addHorseAmenitiesItem(OrgResoMetadataEnumsHorseAmenities horseAmenitiesItem) {
    if (this.horseAmenities == null) {
      this.horseAmenities = new ArrayList<OrgResoMetadataEnumsHorseAmenities>();
    }
    this.horseAmenities.add(horseAmenitiesItem);
    return this;
  }

  /**
   * Get horseAmenities
   * @return horseAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHorseAmenities> getHorseAmenities() {
    return horseAmenities;
  }

  public void setHorseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
  }

  public OrgResoMetadataProperty horseYN(Boolean horseYN) {
    this.horseYN = horseYN;
    return this;
  }

  /**
   * Get horseYN
   * @return horseYN
   **/
  @Schema(description = "")
  
    public Boolean isHorseYN() {
    return horseYN;
  }

  public void setHorseYN(Boolean horseYN) {
    this.horseYN = horseYN;
  }

  public OrgResoMetadataProperty hoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
    return this;
  }

  public OrgResoMetadataProperty addHoursDaysOfOperationItem(OrgResoMetadataEnumsHoursDaysOfOperation hoursDaysOfOperationItem) {
    if (this.hoursDaysOfOperation == null) {
      this.hoursDaysOfOperation = new ArrayList<OrgResoMetadataEnumsHoursDaysOfOperation>();
    }
    this.hoursDaysOfOperation.add(hoursDaysOfOperationItem);
    return this;
  }

  /**
   * Get hoursDaysOfOperation
   * @return hoursDaysOfOperation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHoursDaysOfOperation> getHoursDaysOfOperation() {
    return hoursDaysOfOperation;
  }

  public void setHoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
  }

  public OrgResoMetadataProperty hoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
    return this;
  }

  /**
   * Get hoursDaysOfOperationDescription
   * @return hoursDaysOfOperationDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getHoursDaysOfOperationDescription() {
    return hoursDaysOfOperationDescription;
  }

  public void setHoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
  }

  public OrgResoMetadataProperty inclusions(String inclusions) {
    this.inclusions = inclusions;
    return this;
  }

  /**
   * Get inclusions
   * @return inclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getInclusions() {
    return inclusions;
  }

  public void setInclusions(String inclusions) {
    this.inclusions = inclusions;
  }

  public OrgResoMetadataProperty incomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
    return this;
  }

  public OrgResoMetadataProperty addIncomeIncludesItem(OrgResoMetadataEnumsIncomeIncludes incomeIncludesItem) {
    if (this.incomeIncludes == null) {
      this.incomeIncludes = new ArrayList<OrgResoMetadataEnumsIncomeIncludes>();
    }
    this.incomeIncludes.add(incomeIncludesItem);
    return this;
  }

  /**
   * Get incomeIncludes
   * @return incomeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIncomeIncludes> getIncomeIncludes() {
    return incomeIncludes;
  }

  public void setIncomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
  }

  public OrgResoMetadataProperty insuranceExpense(AnyOforgResoMetadataPropertyInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
    return this;
  }

  /**
   * Get insuranceExpense
   * @return insuranceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyInsuranceExpense getInsuranceExpense() {
    return insuranceExpense;
  }

  public void setInsuranceExpense(AnyOforgResoMetadataPropertyInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
  }

  public OrgResoMetadataProperty interiorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
    return this;
  }

  public OrgResoMetadataProperty addInteriorFeaturesItem(OrgResoMetadataEnumsInteriorOrRoomFeatures interiorFeaturesItem) {
    if (this.interiorFeatures == null) {
      this.interiorFeatures = new ArrayList<OrgResoMetadataEnumsInteriorOrRoomFeatures>();
    }
    this.interiorFeatures.add(interiorFeaturesItem);
    return this;
  }

  /**
   * Get interiorFeatures
   * @return interiorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsInteriorOrRoomFeatures> getInteriorFeatures() {
    return interiorFeatures;
  }

  public void setInteriorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
  }

  public OrgResoMetadataProperty internetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
    return this;
  }

  /**
   * Get internetAddressDisplayYN
   * @return internetAddressDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAddressDisplayYN() {
    return internetAddressDisplayYN;
  }

  public void setInternetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
  }

  public OrgResoMetadataProperty internetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
    return this;
  }

  /**
   * Get internetAutomatedValuationDisplayYN
   * @return internetAutomatedValuationDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAutomatedValuationDisplayYN() {
    return internetAutomatedValuationDisplayYN;
  }

  public void setInternetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
  }

  public OrgResoMetadataProperty internetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
    return this;
  }

  /**
   * Get internetConsumerCommentYN
   * @return internetConsumerCommentYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetConsumerCommentYN() {
    return internetConsumerCommentYN;
  }

  public void setInternetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
  }

  public OrgResoMetadataProperty internetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
    return this;
  }

  /**
   * Get internetEntireListingDisplayYN
   * @return internetEntireListingDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetEntireListingDisplayYN() {
    return internetEntireListingDisplayYN;
  }

  public void setInternetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
  }

  public OrgResoMetadataProperty irrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
    return this;
  }

  public OrgResoMetadataProperty addIrrigationSourceItem(OrgResoMetadataEnumsIrrigationSource irrigationSourceItem) {
    if (this.irrigationSource == null) {
      this.irrigationSource = new ArrayList<OrgResoMetadataEnumsIrrigationSource>();
    }
    this.irrigationSource.add(irrigationSourceItem);
    return this;
  }

  /**
   * Get irrigationSource
   * @return irrigationSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIrrigationSource> getIrrigationSource() {
    return irrigationSource;
  }

  public void setIrrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
  }

  public OrgResoMetadataProperty irrigationWaterRightsAcres(AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
    return this;
  }

  /**
   * Get irrigationWaterRightsAcres
   * @return irrigationWaterRightsAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres getIrrigationWaterRightsAcres() {
    return irrigationWaterRightsAcres;
  }

  public void setIrrigationWaterRightsAcres(AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
  }

  public OrgResoMetadataProperty irrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
    return this;
  }

  /**
   * Get irrigationWaterRightsYN
   * @return irrigationWaterRightsYN
   **/
  @Schema(description = "")
  
    public Boolean isIrrigationWaterRightsYN() {
    return irrigationWaterRightsYN;
  }

  public void setIrrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
  }

  public OrgResoMetadataProperty laborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
    return this;
  }

  public OrgResoMetadataProperty addLaborInformationItem(OrgResoMetadataEnumsLaborInformation laborInformationItem) {
    if (this.laborInformation == null) {
      this.laborInformation = new ArrayList<OrgResoMetadataEnumsLaborInformation>();
    }
    this.laborInformation.add(laborInformationItem);
    return this;
  }

  /**
   * Get laborInformation
   * @return laborInformation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaborInformation> getLaborInformation() {
    return laborInformation;
  }

  public void setLaborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
  }

  public OrgResoMetadataProperty landLeaseAmount(AnyOforgResoMetadataPropertyLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
    return this;
  }

  /**
   * Get landLeaseAmount
   * @return landLeaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLandLeaseAmount getLandLeaseAmount() {
    return landLeaseAmount;
  }

  public void setLandLeaseAmount(AnyOforgResoMetadataPropertyLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
  }

  public OrgResoMetadataProperty landLeaseAmountFrequency(AnyOforgResoMetadataPropertyLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
    return this;
  }

  /**
   * Get landLeaseAmountFrequency
   * @return landLeaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLandLeaseAmountFrequency getLandLeaseAmountFrequency() {
    return landLeaseAmountFrequency;
  }

  public void setLandLeaseAmountFrequency(AnyOforgResoMetadataPropertyLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
  }

  public OrgResoMetadataProperty landLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
    return this;
  }

  /**
   * Get landLeaseExpirationDate
   * @return landLeaseExpirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLandLeaseExpirationDate() {
    return landLeaseExpirationDate;
  }

  public void setLandLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
  }

  public OrgResoMetadataProperty landLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
    return this;
  }

  /**
   * Get landLeaseYN
   * @return landLeaseYN
   **/
  @Schema(description = "")
  
    public Boolean isLandLeaseYN() {
    return landLeaseYN;
  }

  public void setLandLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
  }

  public OrgResoMetadataProperty latitude(AnyOforgResoMetadataPropertyLatitude latitude) {
    this.latitude = latitude;
    return this;
  }

  /**
   * Get latitude
   * @return latitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLatitude getLatitude() {
    return latitude;
  }

  public void setLatitude(AnyOforgResoMetadataPropertyLatitude latitude) {
    this.latitude = latitude;
  }

  public OrgResoMetadataProperty laundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
    return this;
  }

  public OrgResoMetadataProperty addLaundryFeaturesItem(OrgResoMetadataEnumsLaundryFeatures laundryFeaturesItem) {
    if (this.laundryFeatures == null) {
      this.laundryFeatures = new ArrayList<OrgResoMetadataEnumsLaundryFeatures>();
    }
    this.laundryFeatures.add(laundryFeaturesItem);
    return this;
  }

  /**
   * Get laundryFeatures
   * @return laundryFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaundryFeatures> getLaundryFeatures() {
    return laundryFeatures;
  }

  public void setLaundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
  }

  public OrgResoMetadataProperty leasableArea(AnyOforgResoMetadataPropertyLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
    return this;
  }

  /**
   * Get leasableArea
   * @return leasableArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLeasableArea getLeasableArea() {
    return leasableArea;
  }

  public void setLeasableArea(AnyOforgResoMetadataPropertyLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
  }

  public OrgResoMetadataProperty leasableAreaUnits(AnyOforgResoMetadataPropertyLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
    return this;
  }

  /**
   * Get leasableAreaUnits
   * @return leasableAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLeasableAreaUnits getLeasableAreaUnits() {
    return leasableAreaUnits;
  }

  public void setLeasableAreaUnits(AnyOforgResoMetadataPropertyLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
  }

  public OrgResoMetadataProperty leaseAmount(AnyOforgResoMetadataPropertyLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
    return this;
  }

  /**
   * Get leaseAmount
   * @return leaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLeaseAmount getLeaseAmount() {
    return leaseAmount;
  }

  public void setLeaseAmount(AnyOforgResoMetadataPropertyLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
  }

  public OrgResoMetadataProperty leaseAmountFrequency(AnyOforgResoMetadataPropertyLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
    return this;
  }

  /**
   * Get leaseAmountFrequency
   * @return leaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLeaseAmountFrequency getLeaseAmountFrequency() {
    return leaseAmountFrequency;
  }

  public void setLeaseAmountFrequency(AnyOforgResoMetadataPropertyLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
  }

  public OrgResoMetadataProperty leaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
    return this;
  }

  /**
   * Get leaseAssignableYN
   * @return leaseAssignableYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseAssignableYN() {
    return leaseAssignableYN;
  }

  public void setLeaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
  }

  public OrgResoMetadataProperty leaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
    return this;
  }

  /**
   * Get leaseConsideredYN
   * @return leaseConsideredYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseConsideredYN() {
    return leaseConsideredYN;
  }

  public void setLeaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
  }

  public OrgResoMetadataProperty leaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
    return this;
  }

  /**
   * Get leaseExpiration
   * @return leaseExpiration
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLeaseExpiration() {
    return leaseExpiration;
  }

  public void setLeaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
  }

  public OrgResoMetadataProperty leaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
    return this;
  }

  public OrgResoMetadataProperty addLeaseRenewalCompensationItem(OrgResoMetadataEnumsLeaseRenewalCompensation leaseRenewalCompensationItem) {
    if (this.leaseRenewalCompensation == null) {
      this.leaseRenewalCompensation = new ArrayList<OrgResoMetadataEnumsLeaseRenewalCompensation>();
    }
    this.leaseRenewalCompensation.add(leaseRenewalCompensationItem);
    return this;
  }

  /**
   * Get leaseRenewalCompensation
   * @return leaseRenewalCompensation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLeaseRenewalCompensation> getLeaseRenewalCompensation() {
    return leaseRenewalCompensation;
  }

  public void setLeaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
  }

  public OrgResoMetadataProperty leaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
    return this;
  }

  /**
   * Get leaseRenewalOptionYN
   * @return leaseRenewalOptionYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseRenewalOptionYN() {
    return leaseRenewalOptionYN;
  }

  public void setLeaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
  }

  public OrgResoMetadataProperty leaseTerm(AnyOforgResoMetadataPropertyLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
    return this;
  }

  /**
   * Get leaseTerm
   * @return leaseTerm
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLeaseTerm getLeaseTerm() {
    return leaseTerm;
  }

  public void setLeaseTerm(AnyOforgResoMetadataPropertyLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
  }

  public OrgResoMetadataProperty levels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
    return this;
  }

  public OrgResoMetadataProperty addLevelsItem(OrgResoMetadataEnumsLevels levelsItem) {
    if (this.levels == null) {
      this.levels = new ArrayList<OrgResoMetadataEnumsLevels>();
    }
    this.levels.add(levelsItem);
    return this;
  }

  /**
   * Get levels
   * @return levels
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLevels> getLevels() {
    return levels;
  }

  public void setLevels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
  }

  public OrgResoMetadataProperty license1(String license1) {
    this.license1 = license1;
    return this;
  }

  /**
   * Get license1
   * @return license1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense1() {
    return license1;
  }

  public void setLicense1(String license1) {
    this.license1 = license1;
  }

  public OrgResoMetadataProperty license2(String license2) {
    this.license2 = license2;
    return this;
  }

  /**
   * Get license2
   * @return license2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense2() {
    return license2;
  }

  public void setLicense2(String license2) {
    this.license2 = license2;
  }

  public OrgResoMetadataProperty license3(String license3) {
    this.license3 = license3;
    return this;
  }

  /**
   * Get license3
   * @return license3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense3() {
    return license3;
  }

  public void setLicense3(String license3) {
    this.license3 = license3;
  }

  public OrgResoMetadataProperty licensesExpense(AnyOforgResoMetadataPropertyLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
    return this;
  }

  /**
   * Get licensesExpense
   * @return licensesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLicensesExpense getLicensesExpense() {
    return licensesExpense;
  }

  public void setLicensesExpense(AnyOforgResoMetadataPropertyLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
  }

  public OrgResoMetadataProperty listAOR(AnyOforgResoMetadataPropertyListAOR listAOR) {
    this.listAOR = listAOR;
    return this;
  }

  /**
   * Get listAOR
   * @return listAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListAOR getListAOR() {
    return listAOR;
  }

  public void setListAOR(AnyOforgResoMetadataPropertyListAOR listAOR) {
    this.listAOR = listAOR;
  }

  public OrgResoMetadataProperty listAgentAOR(AnyOforgResoMetadataPropertyListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
    return this;
  }

  /**
   * Get listAgentAOR
   * @return listAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListAgentAOR getListAgentAOR() {
    return listAgentAOR;
  }

  public void setListAgentAOR(AnyOforgResoMetadataPropertyListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
  }

  public OrgResoMetadataProperty listAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
    return this;
  }

  public OrgResoMetadataProperty addListAgentDesignationItem(OrgResoMetadataEnumsListAgentDesignation listAgentDesignationItem) {
    if (this.listAgentDesignation == null) {
      this.listAgentDesignation = new ArrayList<OrgResoMetadataEnumsListAgentDesignation>();
    }
    this.listAgentDesignation.add(listAgentDesignationItem);
    return this;
  }

  /**
   * Get listAgentDesignation
   * @return listAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListAgentDesignation> getListAgentDesignation() {
    return listAgentDesignation;
  }

  public void setListAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
  }

  public OrgResoMetadataProperty listAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
    return this;
  }

  /**
   * Get listAgentDirectPhone
   * @return listAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentDirectPhone() {
    return listAgentDirectPhone;
  }

  public void setListAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
  }

  public OrgResoMetadataProperty listAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
    return this;
  }

  /**
   * Get listAgentEmail
   * @return listAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListAgentEmail() {
    return listAgentEmail;
  }

  public void setListAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
  }

  public OrgResoMetadataProperty listAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
    return this;
  }

  /**
   * Get listAgentFax
   * @return listAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentFax() {
    return listAgentFax;
  }

  public void setListAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
  }

  public OrgResoMetadataProperty listAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
    return this;
  }

  /**
   * Get listAgentFirstName
   * @return listAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentFirstName() {
    return listAgentFirstName;
  }

  public void setListAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
  }

  public OrgResoMetadataProperty listAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
    return this;
  }

  /**
   * Get listAgentFullName
   * @return listAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getListAgentFullName() {
    return listAgentFullName;
  }

  public void setListAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
  }

  public OrgResoMetadataProperty listAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
    return this;
  }

  /**
   * Get listAgentHomePhone
   * @return listAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentHomePhone() {
    return listAgentHomePhone;
  }

  public void setListAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
  }

  public OrgResoMetadataProperty listAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
    return this;
  }

  /**
   * Get listAgentKey
   * @return listAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListAgentKey() {
    return listAgentKey;
  }

  public void setListAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
  }

  public OrgResoMetadataProperty listAgentKeyNumeric(AnyOforgResoMetadataPropertyListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
    return this;
  }

  /**
   * Get listAgentKeyNumeric
   * @return listAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyListAgentKeyNumeric getListAgentKeyNumeric() {
    return listAgentKeyNumeric;
  }

  public void setListAgentKeyNumeric(AnyOforgResoMetadataPropertyListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
  }

  public OrgResoMetadataProperty listAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
    return this;
  }

  /**
   * Get listAgentLastName
   * @return listAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentLastName() {
    return listAgentLastName;
  }

  public void setListAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
  }

  public OrgResoMetadataProperty listAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
    return this;
  }

  /**
   * Get listAgentMiddleName
   * @return listAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentMiddleName() {
    return listAgentMiddleName;
  }

  public void setListAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
  }

  public OrgResoMetadataProperty listAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
    return this;
  }

  /**
   * Get listAgentMlsId
   * @return listAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListAgentMlsId() {
    return listAgentMlsId;
  }

  public void setListAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
  }

  public OrgResoMetadataProperty listAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
    return this;
  }

  /**
   * Get listAgentMobilePhone
   * @return listAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentMobilePhone() {
    return listAgentMobilePhone;
  }

  public void setListAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
  }

  public OrgResoMetadataProperty listAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
    return this;
  }

  /**
   * Get listAgentNamePrefix
   * @return listAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNamePrefix() {
    return listAgentNamePrefix;
  }

  public void setListAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
  }

  public OrgResoMetadataProperty listAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
    return this;
  }

  /**
   * Get listAgentNameSuffix
   * @return listAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNameSuffix() {
    return listAgentNameSuffix;
  }

  public void setListAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
  }

  public OrgResoMetadataProperty listAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
    return this;
  }

  /**
   * Get listAgentOfficePhone
   * @return listAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentOfficePhone() {
    return listAgentOfficePhone;
  }

  public void setListAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
  }

  public OrgResoMetadataProperty listAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get listAgentOfficePhoneExt
   * @return listAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentOfficePhoneExt() {
    return listAgentOfficePhoneExt;
  }

  public void setListAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
  }

  public OrgResoMetadataProperty listAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
    return this;
  }

  /**
   * Get listAgentPager
   * @return listAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPager() {
    return listAgentPager;
  }

  public void setListAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
  }

  public OrgResoMetadataProperty listAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
    return this;
  }

  /**
   * Get listAgentPreferredPhone
   * @return listAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPreferredPhone() {
    return listAgentPreferredPhone;
  }

  public void setListAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
  }

  public OrgResoMetadataProperty listAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get listAgentPreferredPhoneExt
   * @return listAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentPreferredPhoneExt() {
    return listAgentPreferredPhoneExt;
  }

  public void setListAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
  }

  public OrgResoMetadataProperty listAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
    return this;
  }

  /**
   * Get listAgentStateLicense
   * @return listAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentStateLicense() {
    return listAgentStateLicense;
  }

  public void setListAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
  }

  public OrgResoMetadataProperty listAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
    return this;
  }

  /**
   * Get listAgentTollFreePhone
   * @return listAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentTollFreePhone() {
    return listAgentTollFreePhone;
  }

  public void setListAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
  }

  public OrgResoMetadataProperty listAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
    return this;
  }

  /**
   * Get listAgentURL
   * @return listAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListAgentURL() {
    return listAgentURL;
  }

  public void setListAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
  }

  public OrgResoMetadataProperty listAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
    return this;
  }

  /**
   * Get listAgentVoiceMail
   * @return listAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentVoiceMail() {
    return listAgentVoiceMail;
  }

  public void setListAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
  }

  public OrgResoMetadataProperty listAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
    return this;
  }

  /**
   * Get listAgentVoiceMailExt
   * @return listAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentVoiceMailExt() {
    return listAgentVoiceMailExt;
  }

  public void setListAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
  }

  public OrgResoMetadataProperty listOfficeAOR(AnyOforgResoMetadataPropertyListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
    return this;
  }

  /**
   * Get listOfficeAOR
   * @return listOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListOfficeAOR getListOfficeAOR() {
    return listOfficeAOR;
  }

  public void setListOfficeAOR(AnyOforgResoMetadataPropertyListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
  }

  public OrgResoMetadataProperty listOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
    return this;
  }

  /**
   * Get listOfficeEmail
   * @return listOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListOfficeEmail() {
    return listOfficeEmail;
  }

  public void setListOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
  }

  public OrgResoMetadataProperty listOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
    return this;
  }

  /**
   * Get listOfficeFax
   * @return listOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficeFax() {
    return listOfficeFax;
  }

  public void setListOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
  }

  public OrgResoMetadataProperty listOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
    return this;
  }

  /**
   * Get listOfficeKey
   * @return listOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeKey() {
    return listOfficeKey;
  }

  public void setListOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
  }

  public OrgResoMetadataProperty listOfficeKeyNumeric(AnyOforgResoMetadataPropertyListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
    return this;
  }

  /**
   * Get listOfficeKeyNumeric
   * @return listOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyListOfficeKeyNumeric getListOfficeKeyNumeric() {
    return listOfficeKeyNumeric;
  }

  public void setListOfficeKeyNumeric(AnyOforgResoMetadataPropertyListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
  }

  public OrgResoMetadataProperty listOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
    return this;
  }

  /**
   * Get listOfficeMlsId
   * @return listOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListOfficeMlsId() {
    return listOfficeMlsId;
  }

  public void setListOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
  }

  public OrgResoMetadataProperty listOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
    return this;
  }

  /**
   * Get listOfficeName
   * @return listOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeName() {
    return listOfficeName;
  }

  public void setListOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
  }

  public OrgResoMetadataProperty listOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
    return this;
  }

  /**
   * Get listOfficePhone
   * @return listOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficePhone() {
    return listOfficePhone;
  }

  public void setListOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
  }

  public OrgResoMetadataProperty listOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
    return this;
  }

  /**
   * Get listOfficePhoneExt
   * @return listOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListOfficePhoneExt() {
    return listOfficePhoneExt;
  }

  public void setListOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
  }

  public OrgResoMetadataProperty listOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
    return this;
  }

  /**
   * Get listOfficeURL
   * @return listOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListOfficeURL() {
    return listOfficeURL;
  }

  public void setListOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
  }

  public OrgResoMetadataProperty listPrice(AnyOforgResoMetadataPropertyListPrice listPrice) {
    this.listPrice = listPrice;
    return this;
  }

  /**
   * Get listPrice
   * @return listPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyListPrice getListPrice() {
    return listPrice;
  }

  public void setListPrice(AnyOforgResoMetadataPropertyListPrice listPrice) {
    this.listPrice = listPrice;
  }

  public OrgResoMetadataProperty listPriceLow(AnyOforgResoMetadataPropertyListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
    return this;
  }

  /**
   * Get listPriceLow
   * @return listPriceLow
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyListPriceLow getListPriceLow() {
    return listPriceLow;
  }

  public void setListPriceLow(AnyOforgResoMetadataPropertyListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
  }

  public OrgResoMetadataProperty listTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
    return this;
  }

  /**
   * Get listTeamKey
   * @return listTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListTeamKey() {
    return listTeamKey;
  }

  public void setListTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
  }

  public OrgResoMetadataProperty listTeamKeyNumeric(AnyOforgResoMetadataPropertyListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
    return this;
  }

  /**
   * Get listTeamKeyNumeric
   * @return listTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyListTeamKeyNumeric getListTeamKeyNumeric() {
    return listTeamKeyNumeric;
  }

  public void setListTeamKeyNumeric(AnyOforgResoMetadataPropertyListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
  }

  public OrgResoMetadataProperty listTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
    return this;
  }

  /**
   * Get listTeamName
   * @return listTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListTeamName() {
    return listTeamName;
  }

  public void setListTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
  }

  public OrgResoMetadataProperty listingAgreement(AnyOforgResoMetadataPropertyListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
    return this;
  }

  /**
   * Get listingAgreement
   * @return listingAgreement
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListingAgreement getListingAgreement() {
    return listingAgreement;
  }

  public void setListingAgreement(AnyOforgResoMetadataPropertyListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
  }

  public OrgResoMetadataProperty listingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
    return this;
  }

  /**
   * Get listingContractDate
   * @return listingContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getListingContractDate() {
    return listingContractDate;
  }

  public void setListingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
  }

  public OrgResoMetadataProperty listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataProperty listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataProperty listingKeyNumeric(AnyOforgResoMetadataPropertyListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataProperty listingService(AnyOforgResoMetadataPropertyListingService listingService) {
    this.listingService = listingService;
    return this;
  }

  /**
   * Get listingService
   * @return listingService
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListingService getListingService() {
    return listingService;
  }

  public void setListingService(AnyOforgResoMetadataPropertyListingService listingService) {
    this.listingService = listingService;
  }

  public OrgResoMetadataProperty listingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
    return this;
  }

  public OrgResoMetadataProperty addListingTermsItem(OrgResoMetadataEnumsListingTerms listingTermsItem) {
    if (this.listingTerms == null) {
      this.listingTerms = new ArrayList<OrgResoMetadataEnumsListingTerms>();
    }
    this.listingTerms.add(listingTermsItem);
    return this;
  }

  /**
   * Get listingTerms
   * @return listingTerms
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListingTerms> getListingTerms() {
    return listingTerms;
  }

  public void setListingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
  }

  public OrgResoMetadataProperty livingArea(AnyOforgResoMetadataPropertyLivingArea livingArea) {
    this.livingArea = livingArea;
    return this;
  }

  /**
   * Get livingArea
   * @return livingArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLivingArea getLivingArea() {
    return livingArea;
  }

  public void setLivingArea(AnyOforgResoMetadataPropertyLivingArea livingArea) {
    this.livingArea = livingArea;
  }

  public OrgResoMetadataProperty livingAreaSource(AnyOforgResoMetadataPropertyLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
    return this;
  }

  /**
   * Get livingAreaSource
   * @return livingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLivingAreaSource getLivingAreaSource() {
    return livingAreaSource;
  }

  public void setLivingAreaSource(AnyOforgResoMetadataPropertyLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
  }

  public OrgResoMetadataProperty livingAreaUnits(AnyOforgResoMetadataPropertyLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
    return this;
  }

  /**
   * Get livingAreaUnits
   * @return livingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLivingAreaUnits getLivingAreaUnits() {
    return livingAreaUnits;
  }

  public void setLivingAreaUnits(AnyOforgResoMetadataPropertyLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
  }

  public OrgResoMetadataProperty lockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
    return this;
  }

  /**
   * Get lockBoxLocation
   * @return lockBoxLocation
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getLockBoxLocation() {
    return lockBoxLocation;
  }

  public void setLockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
  }

  public OrgResoMetadataProperty lockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
    return this;
  }

  /**
   * Get lockBoxSerialNumber
   * @return lockBoxSerialNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLockBoxSerialNumber() {
    return lockBoxSerialNumber;
  }

  public void setLockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
  }

  public OrgResoMetadataProperty lockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
    return this;
  }

  public OrgResoMetadataProperty addLockBoxTypeItem(OrgResoMetadataEnumsLockBoxType lockBoxTypeItem) {
    if (this.lockBoxType == null) {
      this.lockBoxType = new ArrayList<OrgResoMetadataEnumsLockBoxType>();
    }
    this.lockBoxType.add(lockBoxTypeItem);
    return this;
  }

  /**
   * Get lockBoxType
   * @return lockBoxType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLockBoxType> getLockBoxType() {
    return lockBoxType;
  }

  public void setLockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
  }

  public OrgResoMetadataProperty longitude(AnyOforgResoMetadataPropertyLongitude longitude) {
    this.longitude = longitude;
    return this;
  }

  /**
   * Get longitude
   * @return longitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLongitude getLongitude() {
    return longitude;
  }

  public void setLongitude(AnyOforgResoMetadataPropertyLongitude longitude) {
    this.longitude = longitude;
  }

  public OrgResoMetadataProperty lotDimensionsSource(AnyOforgResoMetadataPropertyLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
    return this;
  }

  /**
   * Get lotDimensionsSource
   * @return lotDimensionsSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLotDimensionsSource getLotDimensionsSource() {
    return lotDimensionsSource;
  }

  public void setLotDimensionsSource(AnyOforgResoMetadataPropertyLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
  }

  public OrgResoMetadataProperty lotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
    return this;
  }

  public OrgResoMetadataProperty addLotFeaturesItem(OrgResoMetadataEnumsLotFeatures lotFeaturesItem) {
    if (this.lotFeatures == null) {
      this.lotFeatures = new ArrayList<OrgResoMetadataEnumsLotFeatures>();
    }
    this.lotFeatures.add(lotFeaturesItem);
    return this;
  }

  /**
   * Get lotFeatures
   * @return lotFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLotFeatures> getLotFeatures() {
    return lotFeatures;
  }

  public void setLotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
  }

  public OrgResoMetadataProperty lotSizeAcres(AnyOforgResoMetadataPropertyLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
    return this;
  }

  /**
   * Get lotSizeAcres
   * @return lotSizeAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLotSizeAcres getLotSizeAcres() {
    return lotSizeAcres;
  }

  public void setLotSizeAcres(AnyOforgResoMetadataPropertyLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
  }

  public OrgResoMetadataProperty lotSizeArea(AnyOforgResoMetadataPropertyLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
    return this;
  }

  /**
   * Get lotSizeArea
   * @return lotSizeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLotSizeArea getLotSizeArea() {
    return lotSizeArea;
  }

  public void setLotSizeArea(AnyOforgResoMetadataPropertyLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
  }

  public OrgResoMetadataProperty lotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
    return this;
  }

  /**
   * Get lotSizeDimensions
   * @return lotSizeDimensions
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getLotSizeDimensions() {
    return lotSizeDimensions;
  }

  public void setLotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
  }

  public OrgResoMetadataProperty lotSizeSource(AnyOforgResoMetadataPropertyLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
    return this;
  }

  /**
   * Get lotSizeSource
   * @return lotSizeSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLotSizeSource getLotSizeSource() {
    return lotSizeSource;
  }

  public void setLotSizeSource(AnyOforgResoMetadataPropertyLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
  }

  public OrgResoMetadataProperty lotSizeSquareFeet(AnyOforgResoMetadataPropertyLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
    return this;
  }

  /**
   * Get lotSizeSquareFeet
   * @return lotSizeSquareFeet
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyLotSizeSquareFeet getLotSizeSquareFeet() {
    return lotSizeSquareFeet;
  }

  public void setLotSizeSquareFeet(AnyOforgResoMetadataPropertyLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
  }

  public OrgResoMetadataProperty lotSizeUnits(AnyOforgResoMetadataPropertyLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
    return this;
  }

  /**
   * Get lotSizeUnits
   * @return lotSizeUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyLotSizeUnits getLotSizeUnits() {
    return lotSizeUnits;
  }

  public void setLotSizeUnits(AnyOforgResoMetadataPropertyLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
  }

  public OrgResoMetadataProperty mlSAreaMajor(AnyOforgResoMetadataPropertyMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
    return this;
  }

  /**
   * Get mlSAreaMajor
   * @return mlSAreaMajor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMlSAreaMajor getMlSAreaMajor() {
    return mlSAreaMajor;
  }

  public void setMlSAreaMajor(AnyOforgResoMetadataPropertyMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
  }

  public OrgResoMetadataProperty mlSAreaMinor(AnyOforgResoMetadataPropertyMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
    return this;
  }

  /**
   * Get mlSAreaMinor
   * @return mlSAreaMinor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMlSAreaMinor getMlSAreaMinor() {
    return mlSAreaMinor;
  }

  public void setMlSAreaMinor(AnyOforgResoMetadataPropertyMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
  }

  public OrgResoMetadataProperty mainLevelBathrooms(AnyOforgResoMetadataPropertyMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
    return this;
  }

  /**
   * Get mainLevelBathrooms
   * @return mainLevelBathrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyMainLevelBathrooms getMainLevelBathrooms() {
    return mainLevelBathrooms;
  }

  public void setMainLevelBathrooms(AnyOforgResoMetadataPropertyMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
  }

  public OrgResoMetadataProperty mainLevelBedrooms(AnyOforgResoMetadataPropertyMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
    return this;
  }

  /**
   * Get mainLevelBedrooms
   * @return mainLevelBedrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyMainLevelBedrooms getMainLevelBedrooms() {
    return mainLevelBedrooms;
  }

  public void setMainLevelBedrooms(AnyOforgResoMetadataPropertyMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
  }

  public OrgResoMetadataProperty maintenanceExpense(AnyOforgResoMetadataPropertyMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
    return this;
  }

  /**
   * Get maintenanceExpense
   * @return maintenanceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyMaintenanceExpense getMaintenanceExpense() {
    return maintenanceExpense;
  }

  public void setMaintenanceExpense(AnyOforgResoMetadataPropertyMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
  }

  public OrgResoMetadataProperty majorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
    return this;
  }

  /**
   * Get majorChangeTimestamp
   * @return majorChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getMajorChangeTimestamp() {
    return majorChangeTimestamp;
  }

  public void setMajorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
  }

  public OrgResoMetadataProperty majorChangeType(AnyOforgResoMetadataPropertyMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
    return this;
  }

  /**
   * Get majorChangeType
   * @return majorChangeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMajorChangeType getMajorChangeType() {
    return majorChangeType;
  }

  public void setMajorChangeType(AnyOforgResoMetadataPropertyMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
  }

  public OrgResoMetadataProperty make(String make) {
    this.make = make;
    return this;
  }

  /**
   * Get make
   * @return make
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getMake() {
    return make;
  }

  public void setMake(String make) {
    this.make = make;
  }

  public OrgResoMetadataProperty managerExpense(AnyOforgResoMetadataPropertyManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
    return this;
  }

  /**
   * Get managerExpense
   * @return managerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyManagerExpense getManagerExpense() {
    return managerExpense;
  }

  public void setManagerExpense(AnyOforgResoMetadataPropertyManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
  }

  public OrgResoMetadataProperty mapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
    return this;
  }

  /**
   * Get mapCoordinate
   * @return mapCoordinate
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinate() {
    return mapCoordinate;
  }

  public void setMapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
  }

  public OrgResoMetadataProperty mapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
    return this;
  }

  /**
   * Get mapCoordinateSource
   * @return mapCoordinateSource
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinateSource() {
    return mapCoordinateSource;
  }

  public void setMapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
  }

  public OrgResoMetadataProperty mapURL(String mapURL) {
    this.mapURL = mapURL;
    return this;
  }

  /**
   * Get mapURL
   * @return mapURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getMapURL() {
    return mapURL;
  }

  public void setMapURL(String mapURL) {
    this.mapURL = mapURL;
  }

  public OrgResoMetadataProperty middleOrJuniorSchool(AnyOforgResoMetadataPropertyMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
    return this;
  }

  /**
   * Get middleOrJuniorSchool
   * @return middleOrJuniorSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMiddleOrJuniorSchool getMiddleOrJuniorSchool() {
    return middleOrJuniorSchool;
  }

  public void setMiddleOrJuniorSchool(AnyOforgResoMetadataPropertyMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
  }

  public OrgResoMetadataProperty middleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
    return this;
  }

  /**
   * Get middleOrJuniorSchoolDistrict
   * @return middleOrJuniorSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMiddleOrJuniorSchoolDistrict getMiddleOrJuniorSchoolDistrict() {
    return middleOrJuniorSchoolDistrict;
  }

  public void setMiddleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
  }

  public OrgResoMetadataProperty mlsStatus(AnyOforgResoMetadataPropertyMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
    return this;
  }

  /**
   * Get mlsStatus
   * @return mlsStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMlsStatus getMlsStatus() {
    return mlsStatus;
  }

  public void setMlsStatus(AnyOforgResoMetadataPropertyMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
  }

  public OrgResoMetadataProperty mobileDimUnits(AnyOforgResoMetadataPropertyMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
    return this;
  }

  /**
   * Get mobileDimUnits
   * @return mobileDimUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyMobileDimUnits getMobileDimUnits() {
    return mobileDimUnits;
  }

  public void setMobileDimUnits(AnyOforgResoMetadataPropertyMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
  }

  public OrgResoMetadataProperty mobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
    return this;
  }

  /**
   * Get mobileHomeRemainsYN
   * @return mobileHomeRemainsYN
   **/
  @Schema(description = "")
  
    public Boolean isMobileHomeRemainsYN() {
    return mobileHomeRemainsYN;
  }

  public void setMobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
  }

  public OrgResoMetadataProperty mobileLength(AnyOforgResoMetadataPropertyMobileLength mobileLength) {
    this.mobileLength = mobileLength;
    return this;
  }

  /**
   * Get mobileLength
   * @return mobileLength
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyMobileLength getMobileLength() {
    return mobileLength;
  }

  public void setMobileLength(AnyOforgResoMetadataPropertyMobileLength mobileLength) {
    this.mobileLength = mobileLength;
  }

  public OrgResoMetadataProperty mobileWidth(AnyOforgResoMetadataPropertyMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
    return this;
  }

  /**
   * Get mobileWidth
   * @return mobileWidth
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyMobileWidth getMobileWidth() {
    return mobileWidth;
  }

  public void setMobileWidth(AnyOforgResoMetadataPropertyMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
  }

  public OrgResoMetadataProperty model(String model) {
    this.model = model;
    return this;
  }

  /**
   * Get model
   * @return model
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public OrgResoMetadataProperty modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataProperty netOperatingIncome(AnyOforgResoMetadataPropertyNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
    return this;
  }

  /**
   * Get netOperatingIncome
   * @return netOperatingIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyNetOperatingIncome getNetOperatingIncome() {
    return netOperatingIncome;
  }

  public void setNetOperatingIncome(AnyOforgResoMetadataPropertyNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
  }

  public OrgResoMetadataProperty newConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
    return this;
  }

  /**
   * Get newConstructionYN
   * @return newConstructionYN
   **/
  @Schema(description = "")
  
    public Boolean isNewConstructionYN() {
    return newConstructionYN;
  }

  public void setNewConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
  }

  public OrgResoMetadataProperty newTaxesExpense(AnyOforgResoMetadataPropertyNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
    return this;
  }

  /**
   * Get newTaxesExpense
   * @return newTaxesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyNewTaxesExpense getNewTaxesExpense() {
    return newTaxesExpense;
  }

  public void setNewTaxesExpense(AnyOforgResoMetadataPropertyNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
  }

  public OrgResoMetadataProperty numberOfBuildings(AnyOforgResoMetadataPropertyNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
    return this;
  }

  /**
   * Get numberOfBuildings
   * @return numberOfBuildings
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfBuildings getNumberOfBuildings() {
    return numberOfBuildings;
  }

  public void setNumberOfBuildings(AnyOforgResoMetadataPropertyNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
  }

  public OrgResoMetadataProperty numberOfFullTimeEmployees(AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
    return this;
  }

  /**
   * Get numberOfFullTimeEmployees
   * @return numberOfFullTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees getNumberOfFullTimeEmployees() {
    return numberOfFullTimeEmployees;
  }

  public void setNumberOfFullTimeEmployees(AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
  }

  public OrgResoMetadataProperty numberOfLots(AnyOforgResoMetadataPropertyNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
    return this;
  }

  /**
   * Get numberOfLots
   * @return numberOfLots
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfLots getNumberOfLots() {
    return numberOfLots;
  }

  public void setNumberOfLots(AnyOforgResoMetadataPropertyNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
  }

  public OrgResoMetadataProperty numberOfPads(AnyOforgResoMetadataPropertyNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
    return this;
  }

  /**
   * Get numberOfPads
   * @return numberOfPads
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfPads getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(AnyOforgResoMetadataPropertyNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public OrgResoMetadataProperty numberOfPartTimeEmployees(AnyOforgResoMetadataPropertyNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
    return this;
  }

  /**
   * Get numberOfPartTimeEmployees
   * @return numberOfPartTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfPartTimeEmployees getNumberOfPartTimeEmployees() {
    return numberOfPartTimeEmployees;
  }

  public void setNumberOfPartTimeEmployees(AnyOforgResoMetadataPropertyNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
  }

  public OrgResoMetadataProperty numberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
    return this;
  }

  /**
   * Get numberOfSeparateElectricMeters
   * @return numberOfSeparateElectricMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfSeparateElectricMeters getNumberOfSeparateElectricMeters() {
    return numberOfSeparateElectricMeters;
  }

  public void setNumberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
  }

  public OrgResoMetadataProperty numberOfSeparateGasMeters(AnyOforgResoMetadataPropertyNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
    return this;
  }

  /**
   * Get numberOfSeparateGasMeters
   * @return numberOfSeparateGasMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfSeparateGasMeters getNumberOfSeparateGasMeters() {
    return numberOfSeparateGasMeters;
  }

  public void setNumberOfSeparateGasMeters(AnyOforgResoMetadataPropertyNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
  }

  public OrgResoMetadataProperty numberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
    return this;
  }

  /**
   * Get numberOfSeparateWaterMeters
   * @return numberOfSeparateWaterMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters getNumberOfSeparateWaterMeters() {
    return numberOfSeparateWaterMeters;
  }

  public void setNumberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
  }

  public OrgResoMetadataProperty numberOfUnitsInCommunity(AnyOforgResoMetadataPropertyNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
    return this;
  }

  /**
   * Get numberOfUnitsInCommunity
   * @return numberOfUnitsInCommunity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfUnitsInCommunity getNumberOfUnitsInCommunity() {
    return numberOfUnitsInCommunity;
  }

  public void setNumberOfUnitsInCommunity(AnyOforgResoMetadataPropertyNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
  }

  public OrgResoMetadataProperty numberOfUnitsLeased(AnyOforgResoMetadataPropertyNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
    return this;
  }

  /**
   * Get numberOfUnitsLeased
   * @return numberOfUnitsLeased
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfUnitsLeased getNumberOfUnitsLeased() {
    return numberOfUnitsLeased;
  }

  public void setNumberOfUnitsLeased(AnyOforgResoMetadataPropertyNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
  }

  public OrgResoMetadataProperty numberOfUnitsMoMo(AnyOforgResoMetadataPropertyNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
    return this;
  }

  /**
   * Get numberOfUnitsMoMo
   * @return numberOfUnitsMoMo
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfUnitsMoMo getNumberOfUnitsMoMo() {
    return numberOfUnitsMoMo;
  }

  public void setNumberOfUnitsMoMo(AnyOforgResoMetadataPropertyNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
  }

  public OrgResoMetadataProperty numberOfUnitsTotal(AnyOforgResoMetadataPropertyNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
    return this;
  }

  /**
   * Get numberOfUnitsTotal
   * @return numberOfUnitsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfUnitsTotal getNumberOfUnitsTotal() {
    return numberOfUnitsTotal;
  }

  public void setNumberOfUnitsTotal(AnyOforgResoMetadataPropertyNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
  }

  public OrgResoMetadataProperty numberOfUnitsVacant(AnyOforgResoMetadataPropertyNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
    return this;
  }

  /**
   * Get numberOfUnitsVacant
   * @return numberOfUnitsVacant
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyNumberOfUnitsVacant getNumberOfUnitsVacant() {
    return numberOfUnitsVacant;
  }

  public void setNumberOfUnitsVacant(AnyOforgResoMetadataPropertyNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
  }

  public OrgResoMetadataProperty occupantName(String occupantName) {
    this.occupantName = occupantName;
    return this;
  }

  /**
   * Get occupantName
   * @return occupantName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOccupantName() {
    return occupantName;
  }

  public void setOccupantName(String occupantName) {
    this.occupantName = occupantName;
  }

  public OrgResoMetadataProperty occupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
    return this;
  }

  /**
   * Get occupantPhone
   * @return occupantPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOccupantPhone() {
    return occupantPhone;
  }

  public void setOccupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
  }

  public OrgResoMetadataProperty occupantType(AnyOforgResoMetadataPropertyOccupantType occupantType) {
    this.occupantType = occupantType;
    return this;
  }

  /**
   * Get occupantType
   * @return occupantType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyOccupantType getOccupantType() {
    return occupantType;
  }

  public void setOccupantType(AnyOforgResoMetadataPropertyOccupantType occupantType) {
    this.occupantType = occupantType;
  }

  public OrgResoMetadataProperty offMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
    return this;
  }

  /**
   * Get offMarketDate
   * @return offMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOffMarketDate() {
    return offMarketDate;
  }

  public void setOffMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
  }

  public OrgResoMetadataProperty offMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
    return this;
  }

  /**
   * Get offMarketTimestamp
   * @return offMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOffMarketTimestamp() {
    return offMarketTimestamp;
  }

  public void setOffMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
  }

  public OrgResoMetadataProperty onMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
    return this;
  }

  /**
   * Get onMarketDate
   * @return onMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOnMarketDate() {
    return onMarketDate;
  }

  public void setOnMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
  }

  public OrgResoMetadataProperty onMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
    return this;
  }

  /**
   * Get onMarketTimestamp
   * @return onMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOnMarketTimestamp() {
    return onMarketTimestamp;
  }

  public void setOnMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
  }

  public OrgResoMetadataProperty openParkingSpaces(AnyOforgResoMetadataPropertyOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
    return this;
  }

  /**
   * Get openParkingSpaces
   * @return openParkingSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyOpenParkingSpaces getOpenParkingSpaces() {
    return openParkingSpaces;
  }

  public void setOpenParkingSpaces(AnyOforgResoMetadataPropertyOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
  }

  public OrgResoMetadataProperty openParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
    return this;
  }

  /**
   * Get openParkingYN
   * @return openParkingYN
   **/
  @Schema(description = "")
  
    public Boolean isOpenParkingYN() {
    return openParkingYN;
  }

  public void setOpenParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
  }

  public OrgResoMetadataProperty operatingExpense(AnyOforgResoMetadataPropertyOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
    return this;
  }

  /**
   * Get operatingExpense
   * @return operatingExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyOperatingExpense getOperatingExpense() {
    return operatingExpense;
  }

  public void setOperatingExpense(AnyOforgResoMetadataPropertyOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
  }

  public OrgResoMetadataProperty operatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
    return this;
  }

  public OrgResoMetadataProperty addOperatingExpenseIncludesItem(OrgResoMetadataEnumsOperatingExpenseIncludes operatingExpenseIncludesItem) {
    if (this.operatingExpenseIncludes == null) {
      this.operatingExpenseIncludes = new ArrayList<OrgResoMetadataEnumsOperatingExpenseIncludes>();
    }
    this.operatingExpenseIncludes.add(operatingExpenseIncludesItem);
    return this;
  }

  /**
   * Get operatingExpenseIncludes
   * @return operatingExpenseIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOperatingExpenseIncludes> getOperatingExpenseIncludes() {
    return operatingExpenseIncludes;
  }

  public void setOperatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
  }

  public OrgResoMetadataProperty originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataProperty originalListPrice(AnyOforgResoMetadataPropertyOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
    return this;
  }

  /**
   * Get originalListPrice
   * @return originalListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyOriginalListPrice getOriginalListPrice() {
    return originalListPrice;
  }

  public void setOriginalListPrice(AnyOforgResoMetadataPropertyOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
  }

  public OrgResoMetadataProperty originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataProperty originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataProperty originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataProperty otherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
    return this;
  }

  public OrgResoMetadataProperty addOtherEquipmentItem(OrgResoMetadataEnumsOtherEquipment otherEquipmentItem) {
    if (this.otherEquipment == null) {
      this.otherEquipment = new ArrayList<OrgResoMetadataEnumsOtherEquipment>();
    }
    this.otherEquipment.add(otherEquipmentItem);
    return this;
  }

  /**
   * Get otherEquipment
   * @return otherEquipment
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherEquipment> getOtherEquipment() {
    return otherEquipment;
  }

  public void setOtherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
  }

  public OrgResoMetadataProperty otherExpense(AnyOforgResoMetadataPropertyOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
    return this;
  }

  /**
   * Get otherExpense
   * @return otherExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyOtherExpense getOtherExpense() {
    return otherExpense;
  }

  public void setOtherExpense(AnyOforgResoMetadataPropertyOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
  }

  public OrgResoMetadataProperty otherParking(String otherParking) {
    this.otherParking = otherParking;
    return this;
  }

  /**
   * Get otherParking
   * @return otherParking
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOtherParking() {
    return otherParking;
  }

  public void setOtherParking(String otherParking) {
    this.otherParking = otherParking;
  }

  public OrgResoMetadataProperty otherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
    return this;
  }

  public OrgResoMetadataProperty addOtherStructuresItem(OrgResoMetadataEnumsOtherStructures otherStructuresItem) {
    if (this.otherStructures == null) {
      this.otherStructures = new ArrayList<OrgResoMetadataEnumsOtherStructures>();
    }
    this.otherStructures.add(otherStructuresItem);
    return this;
  }

  /**
   * Get otherStructures
   * @return otherStructures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherStructures> getOtherStructures() {
    return otherStructures;
  }

  public void setOtherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
  }

  public OrgResoMetadataProperty ownerName(String ownerName) {
    this.ownerName = ownerName;
    return this;
  }

  /**
   * Get ownerName
   * @return ownerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOwnerName() {
    return ownerName;
  }

  public void setOwnerName(String ownerName) {
    this.ownerName = ownerName;
  }

  public OrgResoMetadataProperty ownerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
    return this;
  }

  public OrgResoMetadataProperty addOwnerPaysItem(OrgResoMetadataEnumsOwnerPays ownerPaysItem) {
    if (this.ownerPays == null) {
      this.ownerPays = new ArrayList<OrgResoMetadataEnumsOwnerPays>();
    }
    this.ownerPays.add(ownerPaysItem);
    return this;
  }

  /**
   * Get ownerPays
   * @return ownerPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOwnerPays> getOwnerPays() {
    return ownerPays;
  }

  public void setOwnerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
  }

  public OrgResoMetadataProperty ownerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
    return this;
  }

  /**
   * Get ownerPhone
   * @return ownerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOwnerPhone() {
    return ownerPhone;
  }

  public void setOwnerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
  }

  public OrgResoMetadataProperty ownership(String ownership) {
    this.ownership = ownership;
    return this;
  }

  /**
   * Get ownership
   * @return ownership
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOwnership() {
    return ownership;
  }

  public void setOwnership(String ownership) {
    this.ownership = ownership;
  }

  public OrgResoMetadataProperty ownershipType(AnyOforgResoMetadataPropertyOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
    return this;
  }

  /**
   * Get ownershipType
   * @return ownershipType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyOwnershipType getOwnershipType() {
    return ownershipType;
  }

  public void setOwnershipType(AnyOforgResoMetadataPropertyOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
  }

  public OrgResoMetadataProperty parcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
    return this;
  }

  /**
   * Get parcelNumber
   * @return parcelNumber
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParcelNumber() {
    return parcelNumber;
  }

  public void setParcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
  }

  public OrgResoMetadataProperty parkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
    return this;
  }

  /**
   * Get parkManagerName
   * @return parkManagerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkManagerName() {
    return parkManagerName;
  }

  public void setParkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
  }

  public OrgResoMetadataProperty parkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
    return this;
  }

  /**
   * Get parkManagerPhone
   * @return parkManagerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getParkManagerPhone() {
    return parkManagerPhone;
  }

  public void setParkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
  }

  public OrgResoMetadataProperty parkName(String parkName) {
    this.parkName = parkName;
    return this;
  }

  /**
   * Get parkName
   * @return parkName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkName() {
    return parkName;
  }

  public void setParkName(String parkName) {
    this.parkName = parkName;
  }

  public OrgResoMetadataProperty parkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
    return this;
  }

  public OrgResoMetadataProperty addParkingFeaturesItem(OrgResoMetadataEnumsParkingFeatures parkingFeaturesItem) {
    if (this.parkingFeatures == null) {
      this.parkingFeatures = new ArrayList<OrgResoMetadataEnumsParkingFeatures>();
    }
    this.parkingFeatures.add(parkingFeaturesItem);
    return this;
  }

  /**
   * Get parkingFeatures
   * @return parkingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsParkingFeatures> getParkingFeatures() {
    return parkingFeatures;
  }

  public void setParkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
  }

  public OrgResoMetadataProperty parkingTotal(AnyOforgResoMetadataPropertyParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
    return this;
  }

  /**
   * Get parkingTotal
   * @return parkingTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyParkingTotal getParkingTotal() {
    return parkingTotal;
  }

  public void setParkingTotal(AnyOforgResoMetadataPropertyParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
  }

  public OrgResoMetadataProperty pastureArea(AnyOforgResoMetadataPropertyPastureArea pastureArea) {
    this.pastureArea = pastureArea;
    return this;
  }

  /**
   * Get pastureArea
   * @return pastureArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyPastureArea getPastureArea() {
    return pastureArea;
  }

  public void setPastureArea(AnyOforgResoMetadataPropertyPastureArea pastureArea) {
    this.pastureArea = pastureArea;
  }

  public OrgResoMetadataProperty patioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
    return this;
  }

  public OrgResoMetadataProperty addPatioAndPorchFeaturesItem(OrgResoMetadataEnumsPatioAndPorchFeatures patioAndPorchFeaturesItem) {
    if (this.patioAndPorchFeatures == null) {
      this.patioAndPorchFeatures = new ArrayList<OrgResoMetadataEnumsPatioAndPorchFeatures>();
    }
    this.patioAndPorchFeatures.add(patioAndPorchFeaturesItem);
    return this;
  }

  /**
   * Get patioAndPorchFeatures
   * @return patioAndPorchFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPatioAndPorchFeatures> getPatioAndPorchFeatures() {
    return patioAndPorchFeatures;
  }

  public void setPatioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
  }

  public OrgResoMetadataProperty pendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
    return this;
  }

  /**
   * Get pendingTimestamp
   * @return pendingTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPendingTimestamp() {
    return pendingTimestamp;
  }

  public void setPendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
  }

  public OrgResoMetadataProperty pestControlExpense(AnyOforgResoMetadataPropertyPestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
    return this;
  }

  /**
   * Get pestControlExpense
   * @return pestControlExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyPestControlExpense getPestControlExpense() {
    return pestControlExpense;
  }

  public void setPestControlExpense(AnyOforgResoMetadataPropertyPestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
  }

  public OrgResoMetadataProperty petsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
    return this;
  }

  public OrgResoMetadataProperty addPetsAllowedItem(OrgResoMetadataEnumsPetsAllowed petsAllowedItem) {
    if (this.petsAllowed == null) {
      this.petsAllowed = new ArrayList<OrgResoMetadataEnumsPetsAllowed>();
    }
    this.petsAllowed.add(petsAllowedItem);
    return this;
  }

  /**
   * Get petsAllowed
   * @return petsAllowed
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPetsAllowed> getPetsAllowed() {
    return petsAllowed;
  }

  public void setPetsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
  }

  public OrgResoMetadataProperty photosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
    return this;
  }

  /**
   * Get photosChangeTimestamp
   * @return photosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPhotosChangeTimestamp() {
    return photosChangeTimestamp;
  }

  public void setPhotosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
  }

  public OrgResoMetadataProperty photosCount(AnyOforgResoMetadataPropertyPhotosCount photosCount) {
    this.photosCount = photosCount;
    return this;
  }

  /**
   * Get photosCount
   * @return photosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyPhotosCount getPhotosCount() {
    return photosCount;
  }

  public void setPhotosCount(AnyOforgResoMetadataPropertyPhotosCount photosCount) {
    this.photosCount = photosCount;
  }

  public OrgResoMetadataProperty poolExpense(AnyOforgResoMetadataPropertyPoolExpense poolExpense) {
    this.poolExpense = poolExpense;
    return this;
  }

  /**
   * Get poolExpense
   * @return poolExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyPoolExpense getPoolExpense() {
    return poolExpense;
  }

  public void setPoolExpense(AnyOforgResoMetadataPropertyPoolExpense poolExpense) {
    this.poolExpense = poolExpense;
  }

  public OrgResoMetadataProperty poolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
    return this;
  }

  public OrgResoMetadataProperty addPoolFeaturesItem(OrgResoMetadataEnumsPoolFeatures poolFeaturesItem) {
    if (this.poolFeatures == null) {
      this.poolFeatures = new ArrayList<OrgResoMetadataEnumsPoolFeatures>();
    }
    this.poolFeatures.add(poolFeaturesItem);
    return this;
  }

  /**
   * Get poolFeatures
   * @return poolFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPoolFeatures> getPoolFeatures() {
    return poolFeatures;
  }

  public void setPoolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
  }

  public OrgResoMetadataProperty poolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
    return this;
  }

  /**
   * Get poolPrivateYN
   * @return poolPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isPoolPrivateYN() {
    return poolPrivateYN;
  }

  public void setPoolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
  }

  public OrgResoMetadataProperty possession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
    return this;
  }

  public OrgResoMetadataProperty addPossessionItem(OrgResoMetadataEnumsPossession possessionItem) {
    if (this.possession == null) {
      this.possession = new ArrayList<OrgResoMetadataEnumsPossession>();
    }
    this.possession.add(possessionItem);
    return this;
  }

  /**
   * Get possession
   * @return possession
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossession> getPossession() {
    return possession;
  }

  public void setPossession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
  }

  public OrgResoMetadataProperty possibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
    return this;
  }

  public OrgResoMetadataProperty addPossibleUseItem(OrgResoMetadataEnumsPossibleUse possibleUseItem) {
    if (this.possibleUse == null) {
      this.possibleUse = new ArrayList<OrgResoMetadataEnumsPossibleUse>();
    }
    this.possibleUse.add(possibleUseItem);
    return this;
  }

  /**
   * Get possibleUse
   * @return possibleUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossibleUse> getPossibleUse() {
    return possibleUse;
  }

  public void setPossibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
  }

  public OrgResoMetadataProperty postalCity(AnyOforgResoMetadataPropertyPostalCity postalCity) {
    this.postalCity = postalCity;
    return this;
  }

  /**
   * Get postalCity
   * @return postalCity
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPostalCity getPostalCity() {
    return postalCity;
  }

  public void setPostalCity(AnyOforgResoMetadataPropertyPostalCity postalCity) {
    this.postalCity = postalCity;
  }

  public OrgResoMetadataProperty postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Get postalCode
   * @return postalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public OrgResoMetadataProperty postalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
    return this;
  }

  /**
   * Get postalCodePlus4
   * @return postalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getPostalCodePlus4() {
    return postalCodePlus4;
  }

  public void setPostalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
  }

  public OrgResoMetadataProperty powerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
    return this;
  }

  public OrgResoMetadataProperty addPowerProductionTypeItem(OrgResoMetadataEnumsPowerProductionType powerProductionTypeItem) {
    if (this.powerProductionType == null) {
      this.powerProductionType = new ArrayList<OrgResoMetadataEnumsPowerProductionType>();
    }
    this.powerProductionType.add(powerProductionTypeItem);
    return this;
  }

  /**
   * Get powerProductionType
   * @return powerProductionType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPowerProductionType> getPowerProductionType() {
    return powerProductionType;
  }

  public void setPowerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
  }

  public OrgResoMetadataProperty previousListPrice(AnyOforgResoMetadataPropertyPreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
    return this;
  }

  /**
   * Get previousListPrice
   * @return previousListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyPreviousListPrice getPreviousListPrice() {
    return previousListPrice;
  }

  public void setPreviousListPrice(AnyOforgResoMetadataPropertyPreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
  }

  public OrgResoMetadataProperty priceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
    return this;
  }

  /**
   * Get priceChangeTimestamp
   * @return priceChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPriceChangeTimestamp() {
    return priceChangeTimestamp;
  }

  public void setPriceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
  }

  public OrgResoMetadataProperty privateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
    return this;
  }

  /**
   * Get privateOfficeRemarks
   * @return privateOfficeRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateOfficeRemarks() {
    return privateOfficeRemarks;
  }

  public void setPrivateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
  }

  public OrgResoMetadataProperty privateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
    return this;
  }

  /**
   * Get privateRemarks
   * @return privateRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateRemarks() {
    return privateRemarks;
  }

  public void setPrivateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
  }

  public OrgResoMetadataProperty professionalManagementExpense(AnyOforgResoMetadataPropertyProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
    return this;
  }

  /**
   * Get professionalManagementExpense
   * @return professionalManagementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyProfessionalManagementExpense getProfessionalManagementExpense() {
    return professionalManagementExpense;
  }

  public void setProfessionalManagementExpense(AnyOforgResoMetadataPropertyProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
  }

  public OrgResoMetadataProperty propertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
    return this;
  }

  /**
   * Get propertyAttachedYN
   * @return propertyAttachedYN
   **/
  @Schema(description = "")
  
    public Boolean isPropertyAttachedYN() {
    return propertyAttachedYN;
  }

  public void setPropertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
  }

  public OrgResoMetadataProperty propertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
    return this;
  }

  public OrgResoMetadataProperty addPropertyConditionItem(OrgResoMetadataEnumsPropertyCondition propertyConditionItem) {
    if (this.propertyCondition == null) {
      this.propertyCondition = new ArrayList<OrgResoMetadataEnumsPropertyCondition>();
    }
    this.propertyCondition.add(propertyConditionItem);
    return this;
  }

  /**
   * Get propertyCondition
   * @return propertyCondition
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPropertyCondition> getPropertyCondition() {
    return propertyCondition;
  }

  public void setPropertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
  }

  public OrgResoMetadataProperty propertySubType(AnyOforgResoMetadataPropertyPropertySubType propertySubType) {
    this.propertySubType = propertySubType;
    return this;
  }

  /**
   * Get propertySubType
   * @return propertySubType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPropertySubType getPropertySubType() {
    return propertySubType;
  }

  public void setPropertySubType(AnyOforgResoMetadataPropertyPropertySubType propertySubType) {
    this.propertySubType = propertySubType;
  }

  public OrgResoMetadataProperty propertyType(AnyOforgResoMetadataPropertyPropertyType propertyType) {
    this.propertyType = propertyType;
    return this;
  }

  /**
   * Get propertyType
   * @return propertyType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPropertyType getPropertyType() {
    return propertyType;
  }

  public void setPropertyType(AnyOforgResoMetadataPropertyPropertyType propertyType) {
    this.propertyType = propertyType;
  }

  public OrgResoMetadataProperty publicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
    return this;
  }

  /**
   * Get publicRemarks
   * @return publicRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPublicRemarks() {
    return publicRemarks;
  }

  public void setPublicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
  }

  public OrgResoMetadataProperty publicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
    return this;
  }

  /**
   * Get publicSurveyRange
   * @return publicSurveyRange
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyRange() {
    return publicSurveyRange;
  }

  public void setPublicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
  }

  public OrgResoMetadataProperty publicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
    return this;
  }

  /**
   * Get publicSurveySection
   * @return publicSurveySection
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveySection() {
    return publicSurveySection;
  }

  public void setPublicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
  }

  public OrgResoMetadataProperty publicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
    return this;
  }

  /**
   * Get publicSurveyTownship
   * @return publicSurveyTownship
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyTownship() {
    return publicSurveyTownship;
  }

  public void setPublicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
  }

  public OrgResoMetadataProperty purchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
    return this;
  }

  /**
   * Get purchaseContractDate
   * @return purchaseContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getPurchaseContractDate() {
    return purchaseContractDate;
  }

  public void setPurchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
  }

  public OrgResoMetadataProperty rvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
    return this;
  }

  /**
   * Get rvParkingDimensions
   * @return rvParkingDimensions
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getRvParkingDimensions() {
    return rvParkingDimensions;
  }

  public void setRvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
  }

  public OrgResoMetadataProperty rangeArea(AnyOforgResoMetadataPropertyRangeArea rangeArea) {
    this.rangeArea = rangeArea;
    return this;
  }

  /**
   * Get rangeArea
   * @return rangeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyRangeArea getRangeArea() {
    return rangeArea;
  }

  public void setRangeArea(AnyOforgResoMetadataPropertyRangeArea rangeArea) {
    this.rangeArea = rangeArea;
  }

  public OrgResoMetadataProperty rentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
    return this;
  }

  /**
   * Get rentControlYN
   * @return rentControlYN
   **/
  @Schema(description = "")
  
    public Boolean isRentControlYN() {
    return rentControlYN;
  }

  public void setRentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
  }

  public OrgResoMetadataProperty rentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
    return this;
  }

  public OrgResoMetadataProperty addRentIncludesItem(OrgResoMetadataEnumsRentIncludes rentIncludesItem) {
    if (this.rentIncludes == null) {
      this.rentIncludes = new ArrayList<OrgResoMetadataEnumsRentIncludes>();
    }
    this.rentIncludes.add(rentIncludesItem);
    return this;
  }

  /**
   * Get rentIncludes
   * @return rentIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRentIncludes> getRentIncludes() {
    return rentIncludes;
  }

  public void setRentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
  }

  public OrgResoMetadataProperty roadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
    return this;
  }

  public OrgResoMetadataProperty addRoadFrontageTypeItem(OrgResoMetadataEnumsRoadFrontageType roadFrontageTypeItem) {
    if (this.roadFrontageType == null) {
      this.roadFrontageType = new ArrayList<OrgResoMetadataEnumsRoadFrontageType>();
    }
    this.roadFrontageType.add(roadFrontageTypeItem);
    return this;
  }

  /**
   * Get roadFrontageType
   * @return roadFrontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadFrontageType> getRoadFrontageType() {
    return roadFrontageType;
  }

  public void setRoadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
  }

  public OrgResoMetadataProperty roadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
    return this;
  }

  public OrgResoMetadataProperty addRoadResponsibilityItem(OrgResoMetadataEnumsRoadResponsibility roadResponsibilityItem) {
    if (this.roadResponsibility == null) {
      this.roadResponsibility = new ArrayList<OrgResoMetadataEnumsRoadResponsibility>();
    }
    this.roadResponsibility.add(roadResponsibilityItem);
    return this;
  }

  /**
   * Get roadResponsibility
   * @return roadResponsibility
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadResponsibility> getRoadResponsibility() {
    return roadResponsibility;
  }

  public void setRoadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
  }

  public OrgResoMetadataProperty roadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
    return this;
  }

  public OrgResoMetadataProperty addRoadSurfaceTypeItem(OrgResoMetadataEnumsRoadSurfaceType roadSurfaceTypeItem) {
    if (this.roadSurfaceType == null) {
      this.roadSurfaceType = new ArrayList<OrgResoMetadataEnumsRoadSurfaceType>();
    }
    this.roadSurfaceType.add(roadSurfaceTypeItem);
    return this;
  }

  /**
   * Get roadSurfaceType
   * @return roadSurfaceType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadSurfaceType> getRoadSurfaceType() {
    return roadSurfaceType;
  }

  public void setRoadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
  }

  public OrgResoMetadataProperty roof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
    return this;
  }

  public OrgResoMetadataProperty addRoofItem(OrgResoMetadataEnumsRoof roofItem) {
    if (this.roof == null) {
      this.roof = new ArrayList<OrgResoMetadataEnumsRoof>();
    }
    this.roof.add(roofItem);
    return this;
  }

  /**
   * Get roof
   * @return roof
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoof> getRoof() {
    return roof;
  }

  public void setRoof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
  }

  public OrgResoMetadataProperty roomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
    return this;
  }

  public OrgResoMetadataProperty addRoomTypeItem(OrgResoMetadataEnumsRoomType roomTypeItem) {
    if (this.roomType == null) {
      this.roomType = new ArrayList<OrgResoMetadataEnumsRoomType>();
    }
    this.roomType.add(roomTypeItem);
    return this;
  }

  /**
   * Get roomType
   * @return roomType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoomType> getRoomType() {
    return roomType;
  }

  public void setRoomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
  }

  public OrgResoMetadataProperty roomsTotal(AnyOforgResoMetadataPropertyRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
    return this;
  }

  /**
   * Get roomsTotal
   * @return roomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyRoomsTotal getRoomsTotal() {
    return roomsTotal;
  }

  public void setRoomsTotal(AnyOforgResoMetadataPropertyRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
  }

  public OrgResoMetadataProperty seatingCapacity(AnyOforgResoMetadataPropertySeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
    return this;
  }

  /**
   * Get seatingCapacity
   * @return seatingCapacity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertySeatingCapacity getSeatingCapacity() {
    return seatingCapacity;
  }

  public void setSeatingCapacity(AnyOforgResoMetadataPropertySeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
  }

  public OrgResoMetadataProperty securityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
    return this;
  }

  public OrgResoMetadataProperty addSecurityFeaturesItem(OrgResoMetadataEnumsSecurityFeatures securityFeaturesItem) {
    if (this.securityFeatures == null) {
      this.securityFeatures = new ArrayList<OrgResoMetadataEnumsSecurityFeatures>();
    }
    this.securityFeatures.add(securityFeaturesItem);
    return this;
  }

  /**
   * Get securityFeatures
   * @return securityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSecurityFeatures> getSecurityFeatures() {
    return securityFeatures;
  }

  public void setSecurityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
  }

  public OrgResoMetadataProperty seniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
    return this;
  }

  /**
   * Get seniorCommunityYN
   * @return seniorCommunityYN
   **/
  @Schema(description = "")
  
    public Boolean isSeniorCommunityYN() {
    return seniorCommunityYN;
  }

  public void setSeniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
  }

  public OrgResoMetadataProperty serialU(String serialU) {
    this.serialU = serialU;
    return this;
  }

  /**
   * Get serialU
   * @return serialU
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialU() {
    return serialU;
  }

  public void setSerialU(String serialU) {
    this.serialU = serialU;
  }

  public OrgResoMetadataProperty serialX(String serialX) {
    this.serialX = serialX;
    return this;
  }

  /**
   * Get serialX
   * @return serialX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialX() {
    return serialX;
  }

  public void setSerialX(String serialX) {
    this.serialX = serialX;
  }

  public OrgResoMetadataProperty serialXX(String serialXX) {
    this.serialXX = serialXX;
    return this;
  }

  /**
   * Get serialXX
   * @return serialXX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialXX() {
    return serialXX;
  }

  public void setSerialXX(String serialXX) {
    this.serialXX = serialXX;
  }

  public OrgResoMetadataProperty sewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
    return this;
  }

  public OrgResoMetadataProperty addSewerItem(OrgResoMetadataEnumsSewer sewerItem) {
    if (this.sewer == null) {
      this.sewer = new ArrayList<OrgResoMetadataEnumsSewer>();
    }
    this.sewer.add(sewerItem);
    return this;
  }

  /**
   * Get sewer
   * @return sewer
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSewer> getSewer() {
    return sewer;
  }

  public void setSewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
  }

  public OrgResoMetadataProperty showingAdvanceNotice(AnyOforgResoMetadataPropertyShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
    return this;
  }

  /**
   * Get showingAdvanceNotice
   * @return showingAdvanceNotice
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyShowingAdvanceNotice getShowingAdvanceNotice() {
    return showingAdvanceNotice;
  }

  public void setShowingAdvanceNotice(AnyOforgResoMetadataPropertyShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
  }

  public OrgResoMetadataProperty showingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
    return this;
  }

  /**
   * Get showingAttendedYN
   * @return showingAttendedYN
   **/
  @Schema(description = "")
  
    public Boolean isShowingAttendedYN() {
    return showingAttendedYN;
  }

  public void setShowingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
  }

  public OrgResoMetadataProperty showingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
    return this;
  }

  /**
   * Get showingContactName
   * @return showingContactName
   **/
  @Schema(description = "")
  
  @Size(max=40)   public String getShowingContactName() {
    return showingContactName;
  }

  public void setShowingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
  }

  public OrgResoMetadataProperty showingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
    return this;
  }

  /**
   * Get showingContactPhone
   * @return showingContactPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getShowingContactPhone() {
    return showingContactPhone;
  }

  public void setShowingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
  }

  public OrgResoMetadataProperty showingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
    return this;
  }

  /**
   * Get showingContactPhoneExt
   * @return showingContactPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getShowingContactPhoneExt() {
    return showingContactPhoneExt;
  }

  public void setShowingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
  }

  public OrgResoMetadataProperty showingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
    return this;
  }

  public OrgResoMetadataProperty addShowingContactTypeItem(OrgResoMetadataEnumsShowingContactType showingContactTypeItem) {
    if (this.showingContactType == null) {
      this.showingContactType = new ArrayList<OrgResoMetadataEnumsShowingContactType>();
    }
    this.showingContactType.add(showingContactTypeItem);
    return this;
  }

  /**
   * Get showingContactType
   * @return showingContactType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingContactType> getShowingContactType() {
    return showingContactType;
  }

  public void setShowingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
  }

  public OrgResoMetadataProperty showingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
    return this;
  }

  public OrgResoMetadataProperty addShowingDaysItem(OrgResoMetadataEnumsShowingDays showingDaysItem) {
    if (this.showingDays == null) {
      this.showingDays = new ArrayList<OrgResoMetadataEnumsShowingDays>();
    }
    this.showingDays.add(showingDaysItem);
    return this;
  }

  /**
   * Get showingDays
   * @return showingDays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingDays> getShowingDays() {
    return showingDays;
  }

  public void setShowingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
  }

  public OrgResoMetadataProperty showingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
    return this;
  }

  /**
   * Get showingEndTime
   * @return showingEndTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingEndTime() {
    return showingEndTime;
  }

  public void setShowingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
  }

  public OrgResoMetadataProperty showingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
    return this;
  }

  /**
   * Get showingInstructions
   * @return showingInstructions
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getShowingInstructions() {
    return showingInstructions;
  }

  public void setShowingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
  }

  public OrgResoMetadataProperty showingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
    return this;
  }

  public OrgResoMetadataProperty addShowingRequirementsItem(OrgResoMetadataEnumsShowingRequirements showingRequirementsItem) {
    if (this.showingRequirements == null) {
      this.showingRequirements = new ArrayList<OrgResoMetadataEnumsShowingRequirements>();
    }
    this.showingRequirements.add(showingRequirementsItem);
    return this;
  }

  /**
   * Get showingRequirements
   * @return showingRequirements
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingRequirements> getShowingRequirements() {
    return showingRequirements;
  }

  public void setShowingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
  }

  public OrgResoMetadataProperty showingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
    return this;
  }

  /**
   * Get showingStartTime
   * @return showingStartTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingStartTime() {
    return showingStartTime;
  }

  public void setShowingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
  }

  public OrgResoMetadataProperty signOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
    return this;
  }

  /**
   * Get signOnPropertyYN
   * @return signOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isSignOnPropertyYN() {
    return signOnPropertyYN;
  }

  public void setSignOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
  }

  public OrgResoMetadataProperty skirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
    return this;
  }

  public OrgResoMetadataProperty addSkirtItem(OrgResoMetadataEnumsSkirt skirtItem) {
    if (this.skirt == null) {
      this.skirt = new ArrayList<OrgResoMetadataEnumsSkirt>();
    }
    this.skirt.add(skirtItem);
    return this;
  }

  /**
   * Get skirt
   * @return skirt
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSkirt> getSkirt() {
    return skirt;
  }

  public void setSkirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
  }

  public OrgResoMetadataProperty sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataProperty sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataProperty sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataProperty spaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
    return this;
  }

  public OrgResoMetadataProperty addSpaFeaturesItem(OrgResoMetadataEnumsSpaFeatures spaFeaturesItem) {
    if (this.spaFeatures == null) {
      this.spaFeatures = new ArrayList<OrgResoMetadataEnumsSpaFeatures>();
    }
    this.spaFeatures.add(spaFeaturesItem);
    return this;
  }

  /**
   * Get spaFeatures
   * @return spaFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpaFeatures> getSpaFeatures() {
    return spaFeatures;
  }

  public void setSpaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
  }

  public OrgResoMetadataProperty spaYN(Boolean spaYN) {
    this.spaYN = spaYN;
    return this;
  }

  /**
   * Get spaYN
   * @return spaYN
   **/
  @Schema(description = "")
  
    public Boolean isSpaYN() {
    return spaYN;
  }

  public void setSpaYN(Boolean spaYN) {
    this.spaYN = spaYN;
  }

  public OrgResoMetadataProperty specialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
    return this;
  }

  public OrgResoMetadataProperty addSpecialLicensesItem(OrgResoMetadataEnumsSpecialLicenses specialLicensesItem) {
    if (this.specialLicenses == null) {
      this.specialLicenses = new ArrayList<OrgResoMetadataEnumsSpecialLicenses>();
    }
    this.specialLicenses.add(specialLicensesItem);
    return this;
  }

  /**
   * Get specialLicenses
   * @return specialLicenses
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialLicenses> getSpecialLicenses() {
    return specialLicenses;
  }

  public void setSpecialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
  }

  public OrgResoMetadataProperty specialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
    return this;
  }

  public OrgResoMetadataProperty addSpecialListingConditionsItem(OrgResoMetadataEnumsSpecialListingConditions specialListingConditionsItem) {
    if (this.specialListingConditions == null) {
      this.specialListingConditions = new ArrayList<OrgResoMetadataEnumsSpecialListingConditions>();
    }
    this.specialListingConditions.add(specialListingConditionsItem);
    return this;
  }

  /**
   * Get specialListingConditions
   * @return specialListingConditions
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialListingConditions> getSpecialListingConditions() {
    return specialListingConditions;
  }

  public void setSpecialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
  }

  public OrgResoMetadataProperty standardStatus(AnyOforgResoMetadataPropertyStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
    return this;
  }

  /**
   * Get standardStatus
   * @return standardStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyStandardStatus getStandardStatus() {
    return standardStatus;
  }

  public void setStandardStatus(AnyOforgResoMetadataPropertyStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
  }

  public OrgResoMetadataProperty stateOrProvince(AnyOforgResoMetadataPropertyStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
    return this;
  }

  /**
   * Get stateOrProvince
   * @return stateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyStateOrProvince getStateOrProvince() {
    return stateOrProvince;
  }

  public void setStateOrProvince(AnyOforgResoMetadataPropertyStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  public OrgResoMetadataProperty stateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
    return this;
  }

  /**
   * Get stateRegion
   * @return stateRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getStateRegion() {
    return stateRegion;
  }

  public void setStateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
  }

  public OrgResoMetadataProperty statusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
    return this;
  }

  /**
   * Get statusChangeTimestamp
   * @return statusChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStatusChangeTimestamp() {
    return statusChangeTimestamp;
  }

  public void setStatusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
  }

  public OrgResoMetadataProperty stories(AnyOforgResoMetadataPropertyStories stories) {
    this.stories = stories;
    return this;
  }

  /**
   * Get stories
   * @return stories
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyStories getStories() {
    return stories;
  }

  public void setStories(AnyOforgResoMetadataPropertyStories stories) {
    this.stories = stories;
  }

  public OrgResoMetadataProperty storiesTotal(AnyOforgResoMetadataPropertyStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
    return this;
  }

  /**
   * Get storiesTotal
   * @return storiesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyStoriesTotal getStoriesTotal() {
    return storiesTotal;
  }

  public void setStoriesTotal(AnyOforgResoMetadataPropertyStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
  }

  public OrgResoMetadataProperty streetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
    return this;
  }

  /**
   * Get streetAdditionalInfo
   * @return streetAdditionalInfo
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetAdditionalInfo() {
    return streetAdditionalInfo;
  }

  public void setStreetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
  }

  public OrgResoMetadataProperty streetDirPrefix(AnyOforgResoMetadataPropertyStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
    return this;
  }

  /**
   * Get streetDirPrefix
   * @return streetDirPrefix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyStreetDirPrefix getStreetDirPrefix() {
    return streetDirPrefix;
  }

  public void setStreetDirPrefix(AnyOforgResoMetadataPropertyStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
  }

  public OrgResoMetadataProperty streetDirSuffix(AnyOforgResoMetadataPropertyStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
    return this;
  }

  /**
   * Get streetDirSuffix
   * @return streetDirSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyStreetDirSuffix getStreetDirSuffix() {
    return streetDirSuffix;
  }

  public void setStreetDirSuffix(AnyOforgResoMetadataPropertyStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
  }

  public OrgResoMetadataProperty streetName(String streetName) {
    this.streetName = streetName;
    return this;
  }

  /**
   * Get streetName
   * @return streetName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetName() {
    return streetName;
  }

  public void setStreetName(String streetName) {
    this.streetName = streetName;
  }

  public OrgResoMetadataProperty streetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
    return this;
  }

  /**
   * Get streetNumber
   * @return streetNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetNumber() {
    return streetNumber;
  }

  public void setStreetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
  }

  public OrgResoMetadataProperty streetNumberNumeric(AnyOforgResoMetadataPropertyStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
    return this;
  }

  /**
   * Get streetNumberNumeric
   * @return streetNumberNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyStreetNumberNumeric getStreetNumberNumeric() {
    return streetNumberNumeric;
  }

  public void setStreetNumberNumeric(AnyOforgResoMetadataPropertyStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
  }

  public OrgResoMetadataProperty streetSuffix(AnyOforgResoMetadataPropertyStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
    return this;
  }

  /**
   * Get streetSuffix
   * @return streetSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyStreetSuffix getStreetSuffix() {
    return streetSuffix;
  }

  public void setStreetSuffix(AnyOforgResoMetadataPropertyStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
  }

  public OrgResoMetadataProperty streetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
    return this;
  }

  /**
   * Get streetSuffixModifier
   * @return streetSuffixModifier
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetSuffixModifier() {
    return streetSuffixModifier;
  }

  public void setStreetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
  }

  public OrgResoMetadataProperty structureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
    return this;
  }

  public OrgResoMetadataProperty addStructureTypeItem(OrgResoMetadataEnumsStructureType structureTypeItem) {
    if (this.structureType == null) {
      this.structureType = new ArrayList<OrgResoMetadataEnumsStructureType>();
    }
    this.structureType.add(structureTypeItem);
    return this;
  }

  /**
   * Get structureType
   * @return structureType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsStructureType> getStructureType() {
    return structureType;
  }

  public void setStructureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
  }

  public OrgResoMetadataProperty subAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
    return this;
  }

  /**
   * Get subAgencyCompensation
   * @return subAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSubAgencyCompensation() {
    return subAgencyCompensation;
  }

  public void setSubAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
  }

  public OrgResoMetadataProperty subAgencyCompensationType(AnyOforgResoMetadataPropertySubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
    return this;
  }

  /**
   * Get subAgencyCompensationType
   * @return subAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertySubAgencyCompensationType getSubAgencyCompensationType() {
    return subAgencyCompensationType;
  }

  public void setSubAgencyCompensationType(AnyOforgResoMetadataPropertySubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
  }

  public OrgResoMetadataProperty subdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
    return this;
  }

  /**
   * Get subdivisionName
   * @return subdivisionName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getSubdivisionName() {
    return subdivisionName;
  }

  public void setSubdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
  }

  public OrgResoMetadataProperty suppliesExpense(AnyOforgResoMetadataPropertySuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
    return this;
  }

  /**
   * Get suppliesExpense
   * @return suppliesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertySuppliesExpense getSuppliesExpense() {
    return suppliesExpense;
  }

  public void setSuppliesExpense(AnyOforgResoMetadataPropertySuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
  }

  public OrgResoMetadataProperty syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataProperty addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }

  public OrgResoMetadataProperty syndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
    return this;
  }

  /**
   * Get syndicationRemarks
   * @return syndicationRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getSyndicationRemarks() {
    return syndicationRemarks;
  }

  public void setSyndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
  }

  public OrgResoMetadataProperty taxAnnualAmount(AnyOforgResoMetadataPropertyTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
    return this;
  }

  /**
   * Get taxAnnualAmount
   * @return taxAnnualAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyTaxAnnualAmount getTaxAnnualAmount() {
    return taxAnnualAmount;
  }

  public void setTaxAnnualAmount(AnyOforgResoMetadataPropertyTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
  }

  public OrgResoMetadataProperty taxAssessedValue(AnyOforgResoMetadataPropertyTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
    return this;
  }

  /**
   * Get taxAssessedValue
   * @return taxAssessedValue
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyTaxAssessedValue getTaxAssessedValue() {
    return taxAssessedValue;
  }

  public void setTaxAssessedValue(AnyOforgResoMetadataPropertyTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
  }

  public OrgResoMetadataProperty taxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
    return this;
  }

  /**
   * Get taxBlock
   * @return taxBlock
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBlock() {
    return taxBlock;
  }

  public void setTaxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
  }

  public OrgResoMetadataProperty taxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
    return this;
  }

  /**
   * Get taxBookNumber
   * @return taxBookNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBookNumber() {
    return taxBookNumber;
  }

  public void setTaxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
  }

  public OrgResoMetadataProperty taxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
    return this;
  }

  /**
   * Get taxLegalDescription
   * @return taxLegalDescription
   **/
  @Schema(description = "")
  
  @Size(max=6000)   public String getTaxLegalDescription() {
    return taxLegalDescription;
  }

  public void setTaxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
  }

  public OrgResoMetadataProperty taxLot(String taxLot) {
    this.taxLot = taxLot;
    return this;
  }

  /**
   * Get taxLot
   * @return taxLot
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxLot() {
    return taxLot;
  }

  public void setTaxLot(String taxLot) {
    this.taxLot = taxLot;
  }

  public OrgResoMetadataProperty taxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
    return this;
  }

  /**
   * Get taxMapNumber
   * @return taxMapNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxMapNumber() {
    return taxMapNumber;
  }

  public void setTaxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
  }

  public OrgResoMetadataProperty taxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
    return this;
  }

  /**
   * Get taxOtherAnnualAssessmentAmount
   * @return taxOtherAnnualAssessmentAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyTaxOtherAnnualAssessmentAmount getTaxOtherAnnualAssessmentAmount() {
    return taxOtherAnnualAssessmentAmount;
  }

  public void setTaxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
  }

  public OrgResoMetadataProperty taxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
    return this;
  }

  /**
   * Get taxParcelLetter
   * @return taxParcelLetter
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxParcelLetter() {
    return taxParcelLetter;
  }

  public void setTaxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
  }

  public OrgResoMetadataProperty taxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
    return this;
  }

  public OrgResoMetadataProperty addTaxStatusCurrentItem(OrgResoMetadataEnumsTaxStatusCurrent taxStatusCurrentItem) {
    if (this.taxStatusCurrent == null) {
      this.taxStatusCurrent = new ArrayList<OrgResoMetadataEnumsTaxStatusCurrent>();
    }
    this.taxStatusCurrent.add(taxStatusCurrentItem);
    return this;
  }

  /**
   * Get taxStatusCurrent
   * @return taxStatusCurrent
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTaxStatusCurrent> getTaxStatusCurrent() {
    return taxStatusCurrent;
  }

  public void setTaxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
  }

  public OrgResoMetadataProperty taxTract(String taxTract) {
    this.taxTract = taxTract;
    return this;
  }

  /**
   * Get taxTract
   * @return taxTract
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxTract() {
    return taxTract;
  }

  public void setTaxTract(String taxTract) {
    this.taxTract = taxTract;
  }

  public OrgResoMetadataProperty taxYear(AnyOforgResoMetadataPropertyTaxYear taxYear) {
    this.taxYear = taxYear;
    return this;
  }

  /**
   * Get taxYear
   * @return taxYear
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyTaxYear getTaxYear() {
    return taxYear;
  }

  public void setTaxYear(AnyOforgResoMetadataPropertyTaxYear taxYear) {
    this.taxYear = taxYear;
  }

  public OrgResoMetadataProperty tenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
    return this;
  }

  public OrgResoMetadataProperty addTenantPaysItem(OrgResoMetadataEnumsTenantPays tenantPaysItem) {
    if (this.tenantPays == null) {
      this.tenantPays = new ArrayList<OrgResoMetadataEnumsTenantPays>();
    }
    this.tenantPays.add(tenantPaysItem);
    return this;
  }

  /**
   * Get tenantPays
   * @return tenantPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTenantPays> getTenantPays() {
    return tenantPays;
  }

  public void setTenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
  }

  public OrgResoMetadataProperty topography(String topography) {
    this.topography = topography;
    return this;
  }

  /**
   * Get topography
   * @return topography
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTopography() {
    return topography;
  }

  public void setTopography(String topography) {
    this.topography = topography;
  }

  public OrgResoMetadataProperty totalActualRent(AnyOforgResoMetadataPropertyTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
    return this;
  }

  /**
   * Get totalActualRent
   * @return totalActualRent
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyTotalActualRent getTotalActualRent() {
    return totalActualRent;
  }

  public void setTotalActualRent(AnyOforgResoMetadataPropertyTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
  }

  public OrgResoMetadataProperty township(String township) {
    this.township = township;
    return this;
  }

  /**
   * Get township
   * @return township
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTownship() {
    return township;
  }

  public void setTownship(String township) {
    this.township = township;
  }

  public OrgResoMetadataProperty transactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
    return this;
  }

  /**
   * Get transactionBrokerCompensation
   * @return transactionBrokerCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTransactionBrokerCompensation() {
    return transactionBrokerCompensation;
  }

  public void setTransactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
  }

  public OrgResoMetadataProperty transactionBrokerCompensationType(AnyOforgResoMetadataPropertyTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
    return this;
  }

  /**
   * Get transactionBrokerCompensationType
   * @return transactionBrokerCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyTransactionBrokerCompensationType getTransactionBrokerCompensationType() {
    return transactionBrokerCompensationType;
  }

  public void setTransactionBrokerCompensationType(AnyOforgResoMetadataPropertyTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
  }

  public OrgResoMetadataProperty trashExpense(AnyOforgResoMetadataPropertyTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
    return this;
  }

  /**
   * Get trashExpense
   * @return trashExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyTrashExpense getTrashExpense() {
    return trashExpense;
  }

  public void setTrashExpense(AnyOforgResoMetadataPropertyTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
  }

  public OrgResoMetadataProperty unitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
    return this;
  }

  /**
   * Get unitNumber
   * @return unitNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getUnitNumber() {
    return unitNumber;
  }

  public void setUnitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
  }

  public OrgResoMetadataProperty unitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
    return this;
  }

  public OrgResoMetadataProperty addUnitTypeTypeItem(OrgResoMetadataEnumsUnitTypeType unitTypeTypeItem) {
    if (this.unitTypeType == null) {
      this.unitTypeType = new ArrayList<OrgResoMetadataEnumsUnitTypeType>();
    }
    this.unitTypeType.add(unitTypeTypeItem);
    return this;
  }

  /**
   * Get unitTypeType
   * @return unitTypeType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUnitTypeType> getUnitTypeType() {
    return unitTypeType;
  }

  public void setUnitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
  }

  public OrgResoMetadataProperty unitsFurnished(AnyOforgResoMetadataPropertyUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
    return this;
  }

  /**
   * Get unitsFurnished
   * @return unitsFurnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUnitsFurnished getUnitsFurnished() {
    return unitsFurnished;
  }

  public void setUnitsFurnished(AnyOforgResoMetadataPropertyUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
  }

  public OrgResoMetadataProperty universalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
    return this;
  }

  /**
   * Get universalPropertyId
   * @return universalPropertyId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertyId() {
    return universalPropertyId;
  }

  public void setUniversalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
  }

  public OrgResoMetadataProperty universalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
    return this;
  }

  /**
   * Get universalPropertySubId
   * @return universalPropertySubId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertySubId() {
    return universalPropertySubId;
  }

  public void setUniversalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
  }

  public OrgResoMetadataProperty unparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
    return this;
  }

  /**
   * Get unparsedAddress
   * @return unparsedAddress
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getUnparsedAddress() {
    return unparsedAddress;
  }

  public void setUnparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
  }

  public OrgResoMetadataProperty utilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
    return this;
  }

  public OrgResoMetadataProperty addUtilitiesItem(OrgResoMetadataEnumsUtilities utilitiesItem) {
    if (this.utilities == null) {
      this.utilities = new ArrayList<OrgResoMetadataEnumsUtilities>();
    }
    this.utilities.add(utilitiesItem);
    return this;
  }

  /**
   * Get utilities
   * @return utilities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUtilities> getUtilities() {
    return utilities;
  }

  public void setUtilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
  }

  public OrgResoMetadataProperty vacancyAllowance(AnyOforgResoMetadataPropertyVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
    return this;
  }

  /**
   * Get vacancyAllowance
   * @return vacancyAllowance
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyVacancyAllowance getVacancyAllowance() {
    return vacancyAllowance;
  }

  public void setVacancyAllowance(AnyOforgResoMetadataPropertyVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
  }

  public OrgResoMetadataProperty vacancyAllowanceRate(AnyOforgResoMetadataPropertyVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
    return this;
  }

  /**
   * Get vacancyAllowanceRate
   * @return vacancyAllowanceRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyVacancyAllowanceRate getVacancyAllowanceRate() {
    return vacancyAllowanceRate;
  }

  public void setVacancyAllowanceRate(AnyOforgResoMetadataPropertyVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
  }

  public OrgResoMetadataProperty vegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
    return this;
  }

  public OrgResoMetadataProperty addVegetationItem(OrgResoMetadataEnumsVegetation vegetationItem) {
    if (this.vegetation == null) {
      this.vegetation = new ArrayList<OrgResoMetadataEnumsVegetation>();
    }
    this.vegetation.add(vegetationItem);
    return this;
  }

  /**
   * Get vegetation
   * @return vegetation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsVegetation> getVegetation() {
    return vegetation;
  }

  public void setVegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
  }

  public OrgResoMetadataProperty videosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
    return this;
  }

  /**
   * Get videosChangeTimestamp
   * @return videosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getVideosChangeTimestamp() {
    return videosChangeTimestamp;
  }

  public void setVideosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
  }

  public OrgResoMetadataProperty videosCount(AnyOforgResoMetadataPropertyVideosCount videosCount) {
    this.videosCount = videosCount;
    return this;
  }

  /**
   * Get videosCount
   * @return videosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyVideosCount getVideosCount() {
    return videosCount;
  }

  public void setVideosCount(AnyOforgResoMetadataPropertyVideosCount videosCount) {
    this.videosCount = videosCount;
  }

  public OrgResoMetadataProperty view(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
    return this;
  }

  public OrgResoMetadataProperty addViewItem(OrgResoMetadataEnumsView viewItem) {
    if (this.view == null) {
      this.view = new ArrayList<OrgResoMetadataEnumsView>();
    }
    this.view.add(viewItem);
    return this;
  }

  /**
   * Get view
   * @return view
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsView> getView() {
    return view;
  }

  public void setView(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
  }

  public OrgResoMetadataProperty viewYN(Boolean viewYN) {
    this.viewYN = viewYN;
    return this;
  }

  /**
   * Get viewYN
   * @return viewYN
   **/
  @Schema(description = "")
  
    public Boolean isViewYN() {
    return viewYN;
  }

  public void setViewYN(Boolean viewYN) {
    this.viewYN = viewYN;
  }

  public OrgResoMetadataProperty virtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
    return this;
  }

  /**
   * Get virtualTourURLBranded
   * @return virtualTourURLBranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLBranded() {
    return virtualTourURLBranded;
  }

  public void setVirtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
  }

  public OrgResoMetadataProperty virtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
    return this;
  }

  /**
   * Get virtualTourURLUnbranded
   * @return virtualTourURLUnbranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLUnbranded() {
    return virtualTourURLUnbranded;
  }

  public void setVirtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
  }

  public OrgResoMetadataProperty walkScore(AnyOforgResoMetadataPropertyWalkScore walkScore) {
    this.walkScore = walkScore;
    return this;
  }

  /**
   * Get walkScore
   * @return walkScore
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyWalkScore getWalkScore() {
    return walkScore;
  }

  public void setWalkScore(AnyOforgResoMetadataPropertyWalkScore walkScore) {
    this.walkScore = walkScore;
  }

  public OrgResoMetadataProperty waterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
    return this;
  }

  /**
   * Get waterBodyName
   * @return waterBodyName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWaterBodyName() {
    return waterBodyName;
  }

  public void setWaterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
  }

  public OrgResoMetadataProperty waterSewerExpense(AnyOforgResoMetadataPropertyWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
    return this;
  }

  /**
   * Get waterSewerExpense
   * @return waterSewerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyWaterSewerExpense getWaterSewerExpense() {
    return waterSewerExpense;
  }

  public void setWaterSewerExpense(AnyOforgResoMetadataPropertyWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
  }

  public OrgResoMetadataProperty waterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
    return this;
  }

  public OrgResoMetadataProperty addWaterSourceItem(OrgResoMetadataEnumsWaterSource waterSourceItem) {
    if (this.waterSource == null) {
      this.waterSource = new ArrayList<OrgResoMetadataEnumsWaterSource>();
    }
    this.waterSource.add(waterSourceItem);
    return this;
  }

  /**
   * Get waterSource
   * @return waterSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterSource> getWaterSource() {
    return waterSource;
  }

  public void setWaterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
  }

  public OrgResoMetadataProperty waterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
    return this;
  }

  public OrgResoMetadataProperty addWaterfrontFeaturesItem(OrgResoMetadataEnumsWaterfrontFeatures waterfrontFeaturesItem) {
    if (this.waterfrontFeatures == null) {
      this.waterfrontFeatures = new ArrayList<OrgResoMetadataEnumsWaterfrontFeatures>();
    }
    this.waterfrontFeatures.add(waterfrontFeaturesItem);
    return this;
  }

  /**
   * Get waterfrontFeatures
   * @return waterfrontFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterfrontFeatures> getWaterfrontFeatures() {
    return waterfrontFeatures;
  }

  public void setWaterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
  }

  public OrgResoMetadataProperty waterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
    return this;
  }

  /**
   * Get waterfrontYN
   * @return waterfrontYN
   **/
  @Schema(description = "")
  
    public Boolean isWaterfrontYN() {
    return waterfrontYN;
  }

  public void setWaterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
  }

  public OrgResoMetadataProperty windowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
    return this;
  }

  public OrgResoMetadataProperty addWindowFeaturesItem(OrgResoMetadataEnumsWindowFeatures windowFeaturesItem) {
    if (this.windowFeatures == null) {
      this.windowFeatures = new ArrayList<OrgResoMetadataEnumsWindowFeatures>();
    }
    this.windowFeatures.add(windowFeaturesItem);
    return this;
  }

  /**
   * Get windowFeatures
   * @return windowFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWindowFeatures> getWindowFeatures() {
    return windowFeatures;
  }

  public void setWindowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
  }

  public OrgResoMetadataProperty withdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
    return this;
  }

  /**
   * Get withdrawnDate
   * @return withdrawnDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getWithdrawnDate() {
    return withdrawnDate;
  }

  public void setWithdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
  }

  public OrgResoMetadataProperty woodedArea(AnyOforgResoMetadataPropertyWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
    return this;
  }

  /**
   * Get woodedArea
   * @return woodedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyWoodedArea getWoodedArea() {
    return woodedArea;
  }

  public void setWoodedArea(AnyOforgResoMetadataPropertyWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
  }

  public OrgResoMetadataProperty workmansCompensationExpense(AnyOforgResoMetadataPropertyWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
    return this;
  }

  /**
   * Get workmansCompensationExpense
   * @return workmansCompensationExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyWorkmansCompensationExpense getWorkmansCompensationExpense() {
    return workmansCompensationExpense;
  }

  public void setWorkmansCompensationExpense(AnyOforgResoMetadataPropertyWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
  }

  public OrgResoMetadataProperty yearBuilt(AnyOforgResoMetadataPropertyYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
    return this;
  }

  /**
   * Get yearBuilt
   * @return yearBuilt
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyYearBuilt getYearBuilt() {
    return yearBuilt;
  }

  public void setYearBuilt(AnyOforgResoMetadataPropertyYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
  }

  public OrgResoMetadataProperty yearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
    return this;
  }

  /**
   * Get yearBuiltDetails
   * @return yearBuiltDetails
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getYearBuiltDetails() {
    return yearBuiltDetails;
  }

  public void setYearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
  }

  public OrgResoMetadataProperty yearBuiltEffective(AnyOforgResoMetadataPropertyYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
    return this;
  }

  /**
   * Get yearBuiltEffective
   * @return yearBuiltEffective
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyYearBuiltEffective getYearBuiltEffective() {
    return yearBuiltEffective;
  }

  public void setYearBuiltEffective(AnyOforgResoMetadataPropertyYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
  }

  public OrgResoMetadataProperty yearBuiltSource(AnyOforgResoMetadataPropertyYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
    return this;
  }

  /**
   * Get yearBuiltSource
   * @return yearBuiltSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyYearBuiltSource getYearBuiltSource() {
    return yearBuiltSource;
  }

  public void setYearBuiltSource(AnyOforgResoMetadataPropertyYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
  }

  public OrgResoMetadataProperty yearEstablished(AnyOforgResoMetadataPropertyYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
    return this;
  }

  /**
   * Get yearEstablished
   * @return yearEstablished
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyYearEstablished getYearEstablished() {
    return yearEstablished;
  }

  public void setYearEstablished(AnyOforgResoMetadataPropertyYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
  }

  public OrgResoMetadataProperty yearsCurrentOwner(AnyOforgResoMetadataPropertyYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
    return this;
  }

  /**
   * Get yearsCurrentOwner
   * @return yearsCurrentOwner
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyYearsCurrentOwner getYearsCurrentOwner() {
    return yearsCurrentOwner;
  }

  public void setYearsCurrentOwner(AnyOforgResoMetadataPropertyYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
  }

  public OrgResoMetadataProperty zoning(String zoning) {
    this.zoning = zoning;
    return this;
  }

  /**
   * Get zoning
   * @return zoning
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getZoning() {
    return zoning;
  }

  public void setZoning(String zoning) {
    this.zoning = zoning;
  }

  public OrgResoMetadataProperty zoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
    return this;
  }

  /**
   * Get zoningDescription
   * @return zoningDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getZoningDescription() {
    return zoningDescription;
  }

  public void setZoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
  }

  public OrgResoMetadataProperty originatingSystem(AnyOforgResoMetadataPropertyOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataPropertyOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataProperty buyerAgent(AnyOforgResoMetadataPropertyBuyerAgent buyerAgent) {
    this.buyerAgent = buyerAgent;
    return this;
  }

  /**
   * Get buyerAgent
   * @return buyerAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerAgent getBuyerAgent() {
    return buyerAgent;
  }

  public void setBuyerAgent(AnyOforgResoMetadataPropertyBuyerAgent buyerAgent) {
    this.buyerAgent = buyerAgent;
  }

  public OrgResoMetadataProperty buyerOffice(AnyOforgResoMetadataPropertyBuyerOffice buyerOffice) {
    this.buyerOffice = buyerOffice;
    return this;
  }

  /**
   * Get buyerOffice
   * @return buyerOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerOffice getBuyerOffice() {
    return buyerOffice;
  }

  public void setBuyerOffice(AnyOforgResoMetadataPropertyBuyerOffice buyerOffice) {
    this.buyerOffice = buyerOffice;
  }

  public OrgResoMetadataProperty coBuyerAgent(AnyOforgResoMetadataPropertyCoBuyerAgent coBuyerAgent) {
    this.coBuyerAgent = coBuyerAgent;
    return this;
  }

  /**
   * Get coBuyerAgent
   * @return coBuyerAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerAgent getCoBuyerAgent() {
    return coBuyerAgent;
  }

  public void setCoBuyerAgent(AnyOforgResoMetadataPropertyCoBuyerAgent coBuyerAgent) {
    this.coBuyerAgent = coBuyerAgent;
  }

  public OrgResoMetadataProperty coBuyerOffice(AnyOforgResoMetadataPropertyCoBuyerOffice coBuyerOffice) {
    this.coBuyerOffice = coBuyerOffice;
    return this;
  }

  /**
   * Get coBuyerOffice
   * @return coBuyerOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoBuyerOffice getCoBuyerOffice() {
    return coBuyerOffice;
  }

  public void setCoBuyerOffice(AnyOforgResoMetadataPropertyCoBuyerOffice coBuyerOffice) {
    this.coBuyerOffice = coBuyerOffice;
  }

  public OrgResoMetadataProperty coListAgent(AnyOforgResoMetadataPropertyCoListAgent coListAgent) {
    this.coListAgent = coListAgent;
    return this;
  }

  /**
   * Get coListAgent
   * @return coListAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoListAgent getCoListAgent() {
    return coListAgent;
  }

  public void setCoListAgent(AnyOforgResoMetadataPropertyCoListAgent coListAgent) {
    this.coListAgent = coListAgent;
  }

  public OrgResoMetadataProperty coListOffice(AnyOforgResoMetadataPropertyCoListOffice coListOffice) {
    this.coListOffice = coListOffice;
    return this;
  }

  /**
   * Get coListOffice
   * @return coListOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCoListOffice getCoListOffice() {
    return coListOffice;
  }

  public void setCoListOffice(AnyOforgResoMetadataPropertyCoListOffice coListOffice) {
    this.coListOffice = coListOffice;
  }

  public OrgResoMetadataProperty listAgent(AnyOforgResoMetadataPropertyListAgent listAgent) {
    this.listAgent = listAgent;
    return this;
  }

  /**
   * Get listAgent
   * @return listAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListAgent getListAgent() {
    return listAgent;
  }

  public void setListAgent(AnyOforgResoMetadataPropertyListAgent listAgent) {
    this.listAgent = listAgent;
  }

  public OrgResoMetadataProperty listOffice(AnyOforgResoMetadataPropertyListOffice listOffice) {
    this.listOffice = listOffice;
    return this;
  }

  /**
   * Get listOffice
   * @return listOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListOffice getListOffice() {
    return listOffice;
  }

  public void setListOffice(AnyOforgResoMetadataPropertyListOffice listOffice) {
    this.listOffice = listOffice;
  }

  public OrgResoMetadataProperty buyerTeam(AnyOforgResoMetadataPropertyBuyerTeam buyerTeam) {
    this.buyerTeam = buyerTeam;
    return this;
  }

  /**
   * Get buyerTeam
   * @return buyerTeam
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyBuyerTeam getBuyerTeam() {
    return buyerTeam;
  }

  public void setBuyerTeam(AnyOforgResoMetadataPropertyBuyerTeam buyerTeam) {
    this.buyerTeam = buyerTeam;
  }

  public OrgResoMetadataProperty listTeam(AnyOforgResoMetadataPropertyListTeam listTeam) {
    this.listTeam = listTeam;
    return this;
  }

  /**
   * Get listTeam
   * @return listTeam
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyListTeam getListTeam() {
    return listTeam;
  }

  public void setListTeam(AnyOforgResoMetadataPropertyListTeam listTeam) {
    this.listTeam = listTeam;
  }

  public OrgResoMetadataProperty sourceSystem(AnyOforgResoMetadataPropertySourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertySourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataPropertySourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataProperty historyTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataProperty addHistoryTransactionalItem(OrgResoMetadataHistoryTransactional historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactional>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactional> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactional> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataProperty historyTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
    return this;
  }

  /**
   * Get historyTransactionalAtOdataCount
   * @return historyTransactionalAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getHistoryTransactionalAtOdataCount() {
    return historyTransactionalAtOdataCount;
  }

  public void setHistoryTransactionalAtOdataCount(Count historyTransactionalAtOdataCount) {
    this.historyTransactionalAtOdataCount = historyTransactionalAtOdataCount;
  }

  public OrgResoMetadataProperty media(List<OrgResoMetadataMedia> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataProperty addMediaItem(OrgResoMetadataMedia mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMedia>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMedia> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMedia> media) {
    this.media = media;
  }

  public OrgResoMetadataProperty mediaAtOdataCount(Count mediaAtOdataCount) {
    this.mediaAtOdataCount = mediaAtOdataCount;
    return this;
  }

  /**
   * Get mediaAtOdataCount
   * @return mediaAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getMediaAtOdataCount() {
    return mediaAtOdataCount;
  }

  public void setMediaAtOdataCount(Count mediaAtOdataCount) {
    this.mediaAtOdataCount = mediaAtOdataCount;
  }

  public OrgResoMetadataProperty socialMedia(List<OrgResoMetadataSocialMedia> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataProperty addSocialMediaItem(OrgResoMetadataSocialMedia socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMedia>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMedia> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMedia> socialMedia) {
    this.socialMedia = socialMedia;
  }

  public OrgResoMetadataProperty socialMediaAtOdataCount(Count socialMediaAtOdataCount) {
    this.socialMediaAtOdataCount = socialMediaAtOdataCount;
    return this;
  }

  /**
   * Get socialMediaAtOdataCount
   * @return socialMediaAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getSocialMediaAtOdataCount() {
    return socialMediaAtOdataCount;
  }

  public void setSocialMediaAtOdataCount(Count socialMediaAtOdataCount) {
    this.socialMediaAtOdataCount = socialMediaAtOdataCount;
  }

  public OrgResoMetadataProperty openHouse(List<OrgResoMetadataOpenHouse> openHouse) {
    this.openHouse = openHouse;
    return this;
  }

  public OrgResoMetadataProperty addOpenHouseItem(OrgResoMetadataOpenHouse openHouseItem) {
    if (this.openHouse == null) {
      this.openHouse = new ArrayList<OrgResoMetadataOpenHouse>();
    }
    this.openHouse.add(openHouseItem);
    return this;
  }

  /**
   * Get openHouse
   * @return openHouse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataOpenHouse> getOpenHouse() {
    return openHouse;
  }

  public void setOpenHouse(List<OrgResoMetadataOpenHouse> openHouse) {
    this.openHouse = openHouse;
  }

  public OrgResoMetadataProperty openHouseAtOdataCount(Count openHouseAtOdataCount) {
    this.openHouseAtOdataCount = openHouseAtOdataCount;
    return this;
  }

  /**
   * Get openHouseAtOdataCount
   * @return openHouseAtOdataCount
   **/
  @Schema(description = "")
  
    @Valid
    public Count getOpenHouseAtOdataCount() {
    return openHouseAtOdataCount;
  }

  public void setOpenHouseAtOdataCount(Count openHouseAtOdataCount) {
    this.openHouseAtOdataCount = openHouseAtOdataCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataProperty orgResoMetadataProperty = (OrgResoMetadataProperty) o;
    return Objects.equals(this.aboveGradeFinishedArea, orgResoMetadataProperty.aboveGradeFinishedArea) &&
        Objects.equals(this.aboveGradeFinishedAreaSource, orgResoMetadataProperty.aboveGradeFinishedAreaSource) &&
        Objects.equals(this.aboveGradeFinishedAreaUnits, orgResoMetadataProperty.aboveGradeFinishedAreaUnits) &&
        Objects.equals(this.accessCode, orgResoMetadataProperty.accessCode) &&
        Objects.equals(this.accessibilityFeatures, orgResoMetadataProperty.accessibilityFeatures) &&
        Objects.equals(this.additionalParcelsDescription, orgResoMetadataProperty.additionalParcelsDescription) &&
        Objects.equals(this.additionalParcelsYN, orgResoMetadataProperty.additionalParcelsYN) &&
        Objects.equals(this.anchorsCoTenants, orgResoMetadataProperty.anchorsCoTenants) &&
        Objects.equals(this.appliances, orgResoMetadataProperty.appliances) &&
        Objects.equals(this.architecturalStyle, orgResoMetadataProperty.architecturalStyle) &&
        Objects.equals(this.associationAmenities, orgResoMetadataProperty.associationAmenities) &&
        Objects.equals(this.associationFee, orgResoMetadataProperty.associationFee) &&
        Objects.equals(this.associationFee2, orgResoMetadataProperty.associationFee2) &&
        Objects.equals(this.associationFee2Frequency, orgResoMetadataProperty.associationFee2Frequency) &&
        Objects.equals(this.associationFeeFrequency, orgResoMetadataProperty.associationFeeFrequency) &&
        Objects.equals(this.associationFeeIncludes, orgResoMetadataProperty.associationFeeIncludes) &&
        Objects.equals(this.associationName, orgResoMetadataProperty.associationName) &&
        Objects.equals(this.associationName2, orgResoMetadataProperty.associationName2) &&
        Objects.equals(this.associationPhone, orgResoMetadataProperty.associationPhone) &&
        Objects.equals(this.associationPhone2, orgResoMetadataProperty.associationPhone2) &&
        Objects.equals(this.associationYN, orgResoMetadataProperty.associationYN) &&
        Objects.equals(this.attachedGarageYN, orgResoMetadataProperty.attachedGarageYN) &&
        Objects.equals(this.availabilityDate, orgResoMetadataProperty.availabilityDate) &&
        Objects.equals(this.basement, orgResoMetadataProperty.basement) &&
        Objects.equals(this.basementYN, orgResoMetadataProperty.basementYN) &&
        Objects.equals(this.bathroomsFull, orgResoMetadataProperty.bathroomsFull) &&
        Objects.equals(this.bathroomsHalf, orgResoMetadataProperty.bathroomsHalf) &&
        Objects.equals(this.bathroomsOneQuarter, orgResoMetadataProperty.bathroomsOneQuarter) &&
        Objects.equals(this.bathroomsPartial, orgResoMetadataProperty.bathroomsPartial) &&
        Objects.equals(this.bathroomsThreeQuarter, orgResoMetadataProperty.bathroomsThreeQuarter) &&
        Objects.equals(this.bathroomsTotalInteger, orgResoMetadataProperty.bathroomsTotalInteger) &&
        Objects.equals(this.bedroomsPossible, orgResoMetadataProperty.bedroomsPossible) &&
        Objects.equals(this.bedroomsTotal, orgResoMetadataProperty.bedroomsTotal) &&
        Objects.equals(this.belowGradeFinishedArea, orgResoMetadataProperty.belowGradeFinishedArea) &&
        Objects.equals(this.belowGradeFinishedAreaSource, orgResoMetadataProperty.belowGradeFinishedAreaSource) &&
        Objects.equals(this.belowGradeFinishedAreaUnits, orgResoMetadataProperty.belowGradeFinishedAreaUnits) &&
        Objects.equals(this.bodyType, orgResoMetadataProperty.bodyType) &&
        Objects.equals(this.builderModel, orgResoMetadataProperty.builderModel) &&
        Objects.equals(this.builderName, orgResoMetadataProperty.builderName) &&
        Objects.equals(this.buildingAreaSource, orgResoMetadataProperty.buildingAreaSource) &&
        Objects.equals(this.buildingAreaTotal, orgResoMetadataProperty.buildingAreaTotal) &&
        Objects.equals(this.buildingAreaUnits, orgResoMetadataProperty.buildingAreaUnits) &&
        Objects.equals(this.buildingFeatures, orgResoMetadataProperty.buildingFeatures) &&
        Objects.equals(this.buildingName, orgResoMetadataProperty.buildingName) &&
        Objects.equals(this.businessName, orgResoMetadataProperty.businessName) &&
        Objects.equals(this.businessType, orgResoMetadataProperty.businessType) &&
        Objects.equals(this.buyerAgencyCompensation, orgResoMetadataProperty.buyerAgencyCompensation) &&
        Objects.equals(this.buyerAgencyCompensationType, orgResoMetadataProperty.buyerAgencyCompensationType) &&
        Objects.equals(this.buyerAgentAOR, orgResoMetadataProperty.buyerAgentAOR) &&
        Objects.equals(this.buyerAgentDesignation, orgResoMetadataProperty.buyerAgentDesignation) &&
        Objects.equals(this.buyerAgentDirectPhone, orgResoMetadataProperty.buyerAgentDirectPhone) &&
        Objects.equals(this.buyerAgentEmail, orgResoMetadataProperty.buyerAgentEmail) &&
        Objects.equals(this.buyerAgentFax, orgResoMetadataProperty.buyerAgentFax) &&
        Objects.equals(this.buyerAgentFirstName, orgResoMetadataProperty.buyerAgentFirstName) &&
        Objects.equals(this.buyerAgentFullName, orgResoMetadataProperty.buyerAgentFullName) &&
        Objects.equals(this.buyerAgentHomePhone, orgResoMetadataProperty.buyerAgentHomePhone) &&
        Objects.equals(this.buyerAgentKey, orgResoMetadataProperty.buyerAgentKey) &&
        Objects.equals(this.buyerAgentKeyNumeric, orgResoMetadataProperty.buyerAgentKeyNumeric) &&
        Objects.equals(this.buyerAgentLastName, orgResoMetadataProperty.buyerAgentLastName) &&
        Objects.equals(this.buyerAgentMiddleName, orgResoMetadataProperty.buyerAgentMiddleName) &&
        Objects.equals(this.buyerAgentMlsId, orgResoMetadataProperty.buyerAgentMlsId) &&
        Objects.equals(this.buyerAgentMobilePhone, orgResoMetadataProperty.buyerAgentMobilePhone) &&
        Objects.equals(this.buyerAgentNamePrefix, orgResoMetadataProperty.buyerAgentNamePrefix) &&
        Objects.equals(this.buyerAgentNameSuffix, orgResoMetadataProperty.buyerAgentNameSuffix) &&
        Objects.equals(this.buyerAgentOfficePhone, orgResoMetadataProperty.buyerAgentOfficePhone) &&
        Objects.equals(this.buyerAgentOfficePhoneExt, orgResoMetadataProperty.buyerAgentOfficePhoneExt) &&
        Objects.equals(this.buyerAgentPager, orgResoMetadataProperty.buyerAgentPager) &&
        Objects.equals(this.buyerAgentPreferredPhone, orgResoMetadataProperty.buyerAgentPreferredPhone) &&
        Objects.equals(this.buyerAgentPreferredPhoneExt, orgResoMetadataProperty.buyerAgentPreferredPhoneExt) &&
        Objects.equals(this.buyerAgentStateLicense, orgResoMetadataProperty.buyerAgentStateLicense) &&
        Objects.equals(this.buyerAgentTollFreePhone, orgResoMetadataProperty.buyerAgentTollFreePhone) &&
        Objects.equals(this.buyerAgentURL, orgResoMetadataProperty.buyerAgentURL) &&
        Objects.equals(this.buyerAgentVoiceMail, orgResoMetadataProperty.buyerAgentVoiceMail) &&
        Objects.equals(this.buyerAgentVoiceMailExt, orgResoMetadataProperty.buyerAgentVoiceMailExt) &&
        Objects.equals(this.buyerFinancing, orgResoMetadataProperty.buyerFinancing) &&
        Objects.equals(this.buyerOfficeAOR, orgResoMetadataProperty.buyerOfficeAOR) &&
        Objects.equals(this.buyerOfficeEmail, orgResoMetadataProperty.buyerOfficeEmail) &&
        Objects.equals(this.buyerOfficeFax, orgResoMetadataProperty.buyerOfficeFax) &&
        Objects.equals(this.buyerOfficeKey, orgResoMetadataProperty.buyerOfficeKey) &&
        Objects.equals(this.buyerOfficeKeyNumeric, orgResoMetadataProperty.buyerOfficeKeyNumeric) &&
        Objects.equals(this.buyerOfficeMlsId, orgResoMetadataProperty.buyerOfficeMlsId) &&
        Objects.equals(this.buyerOfficeName, orgResoMetadataProperty.buyerOfficeName) &&
        Objects.equals(this.buyerOfficePhone, orgResoMetadataProperty.buyerOfficePhone) &&
        Objects.equals(this.buyerOfficePhoneExt, orgResoMetadataProperty.buyerOfficePhoneExt) &&
        Objects.equals(this.buyerOfficeURL, orgResoMetadataProperty.buyerOfficeURL) &&
        Objects.equals(this.buyerTeamKey, orgResoMetadataProperty.buyerTeamKey) &&
        Objects.equals(this.buyerTeamKeyNumeric, orgResoMetadataProperty.buyerTeamKeyNumeric) &&
        Objects.equals(this.buyerTeamName, orgResoMetadataProperty.buyerTeamName) &&
        Objects.equals(this.cableTvExpense, orgResoMetadataProperty.cableTvExpense) &&
        Objects.equals(this.cancellationDate, orgResoMetadataProperty.cancellationDate) &&
        Objects.equals(this.capRate, orgResoMetadataProperty.capRate) &&
        Objects.equals(this.carportSpaces, orgResoMetadataProperty.carportSpaces) &&
        Objects.equals(this.carportYN, orgResoMetadataProperty.carportYN) &&
        Objects.equals(this.carrierRoute, orgResoMetadataProperty.carrierRoute) &&
        Objects.equals(this.city, orgResoMetadataProperty.city) &&
        Objects.equals(this.cityRegion, orgResoMetadataProperty.cityRegion) &&
        Objects.equals(this.closeDate, orgResoMetadataProperty.closeDate) &&
        Objects.equals(this.closePrice, orgResoMetadataProperty.closePrice) &&
        Objects.equals(this.coBuyerAgentAOR, orgResoMetadataProperty.coBuyerAgentAOR) &&
        Objects.equals(this.coBuyerAgentDesignation, orgResoMetadataProperty.coBuyerAgentDesignation) &&
        Objects.equals(this.coBuyerAgentDirectPhone, orgResoMetadataProperty.coBuyerAgentDirectPhone) &&
        Objects.equals(this.coBuyerAgentEmail, orgResoMetadataProperty.coBuyerAgentEmail) &&
        Objects.equals(this.coBuyerAgentFax, orgResoMetadataProperty.coBuyerAgentFax) &&
        Objects.equals(this.coBuyerAgentFirstName, orgResoMetadataProperty.coBuyerAgentFirstName) &&
        Objects.equals(this.coBuyerAgentFullName, orgResoMetadataProperty.coBuyerAgentFullName) &&
        Objects.equals(this.coBuyerAgentHomePhone, orgResoMetadataProperty.coBuyerAgentHomePhone) &&
        Objects.equals(this.coBuyerAgentKey, orgResoMetadataProperty.coBuyerAgentKey) &&
        Objects.equals(this.coBuyerAgentKeyNumeric, orgResoMetadataProperty.coBuyerAgentKeyNumeric) &&
        Objects.equals(this.coBuyerAgentLastName, orgResoMetadataProperty.coBuyerAgentLastName) &&
        Objects.equals(this.coBuyerAgentMiddleName, orgResoMetadataProperty.coBuyerAgentMiddleName) &&
        Objects.equals(this.coBuyerAgentMlsId, orgResoMetadataProperty.coBuyerAgentMlsId) &&
        Objects.equals(this.coBuyerAgentMobilePhone, orgResoMetadataProperty.coBuyerAgentMobilePhone) &&
        Objects.equals(this.coBuyerAgentNamePrefix, orgResoMetadataProperty.coBuyerAgentNamePrefix) &&
        Objects.equals(this.coBuyerAgentNameSuffix, orgResoMetadataProperty.coBuyerAgentNameSuffix) &&
        Objects.equals(this.coBuyerAgentOfficePhone, orgResoMetadataProperty.coBuyerAgentOfficePhone) &&
        Objects.equals(this.coBuyerAgentOfficePhoneExt, orgResoMetadataProperty.coBuyerAgentOfficePhoneExt) &&
        Objects.equals(this.coBuyerAgentPager, orgResoMetadataProperty.coBuyerAgentPager) &&
        Objects.equals(this.coBuyerAgentPreferredPhone, orgResoMetadataProperty.coBuyerAgentPreferredPhone) &&
        Objects.equals(this.coBuyerAgentPreferredPhoneExt, orgResoMetadataProperty.coBuyerAgentPreferredPhoneExt) &&
        Objects.equals(this.coBuyerAgentStateLicense, orgResoMetadataProperty.coBuyerAgentStateLicense) &&
        Objects.equals(this.coBuyerAgentTollFreePhone, orgResoMetadataProperty.coBuyerAgentTollFreePhone) &&
        Objects.equals(this.coBuyerAgentURL, orgResoMetadataProperty.coBuyerAgentURL) &&
        Objects.equals(this.coBuyerAgentVoiceMail, orgResoMetadataProperty.coBuyerAgentVoiceMail) &&
        Objects.equals(this.coBuyerAgentVoiceMailExt, orgResoMetadataProperty.coBuyerAgentVoiceMailExt) &&
        Objects.equals(this.coBuyerOfficeAOR, orgResoMetadataProperty.coBuyerOfficeAOR) &&
        Objects.equals(this.coBuyerOfficeEmail, orgResoMetadataProperty.coBuyerOfficeEmail) &&
        Objects.equals(this.coBuyerOfficeFax, orgResoMetadataProperty.coBuyerOfficeFax) &&
        Objects.equals(this.coBuyerOfficeKey, orgResoMetadataProperty.coBuyerOfficeKey) &&
        Objects.equals(this.coBuyerOfficeKeyNumeric, orgResoMetadataProperty.coBuyerOfficeKeyNumeric) &&
        Objects.equals(this.coBuyerOfficeMlsId, orgResoMetadataProperty.coBuyerOfficeMlsId) &&
        Objects.equals(this.coBuyerOfficeName, orgResoMetadataProperty.coBuyerOfficeName) &&
        Objects.equals(this.coBuyerOfficePhone, orgResoMetadataProperty.coBuyerOfficePhone) &&
        Objects.equals(this.coBuyerOfficePhoneExt, orgResoMetadataProperty.coBuyerOfficePhoneExt) &&
        Objects.equals(this.coBuyerOfficeURL, orgResoMetadataProperty.coBuyerOfficeURL) &&
        Objects.equals(this.coListAgentAOR, orgResoMetadataProperty.coListAgentAOR) &&
        Objects.equals(this.coListAgentDesignation, orgResoMetadataProperty.coListAgentDesignation) &&
        Objects.equals(this.coListAgentDirectPhone, orgResoMetadataProperty.coListAgentDirectPhone) &&
        Objects.equals(this.coListAgentEmail, orgResoMetadataProperty.coListAgentEmail) &&
        Objects.equals(this.coListAgentFax, orgResoMetadataProperty.coListAgentFax) &&
        Objects.equals(this.coListAgentFirstName, orgResoMetadataProperty.coListAgentFirstName) &&
        Objects.equals(this.coListAgentFullName, orgResoMetadataProperty.coListAgentFullName) &&
        Objects.equals(this.coListAgentHomePhone, orgResoMetadataProperty.coListAgentHomePhone) &&
        Objects.equals(this.coListAgentKey, orgResoMetadataProperty.coListAgentKey) &&
        Objects.equals(this.coListAgentKeyNumeric, orgResoMetadataProperty.coListAgentKeyNumeric) &&
        Objects.equals(this.coListAgentLastName, orgResoMetadataProperty.coListAgentLastName) &&
        Objects.equals(this.coListAgentMiddleName, orgResoMetadataProperty.coListAgentMiddleName) &&
        Objects.equals(this.coListAgentMlsId, orgResoMetadataProperty.coListAgentMlsId) &&
        Objects.equals(this.coListAgentMobilePhone, orgResoMetadataProperty.coListAgentMobilePhone) &&
        Objects.equals(this.coListAgentNamePrefix, orgResoMetadataProperty.coListAgentNamePrefix) &&
        Objects.equals(this.coListAgentNameSuffix, orgResoMetadataProperty.coListAgentNameSuffix) &&
        Objects.equals(this.coListAgentOfficePhone, orgResoMetadataProperty.coListAgentOfficePhone) &&
        Objects.equals(this.coListAgentOfficePhoneExt, orgResoMetadataProperty.coListAgentOfficePhoneExt) &&
        Objects.equals(this.coListAgentPager, orgResoMetadataProperty.coListAgentPager) &&
        Objects.equals(this.coListAgentPreferredPhone, orgResoMetadataProperty.coListAgentPreferredPhone) &&
        Objects.equals(this.coListAgentPreferredPhoneExt, orgResoMetadataProperty.coListAgentPreferredPhoneExt) &&
        Objects.equals(this.coListAgentStateLicense, orgResoMetadataProperty.coListAgentStateLicense) &&
        Objects.equals(this.coListAgentTollFreePhone, orgResoMetadataProperty.coListAgentTollFreePhone) &&
        Objects.equals(this.coListAgentURL, orgResoMetadataProperty.coListAgentURL) &&
        Objects.equals(this.coListAgentVoiceMail, orgResoMetadataProperty.coListAgentVoiceMail) &&
        Objects.equals(this.coListAgentVoiceMailExt, orgResoMetadataProperty.coListAgentVoiceMailExt) &&
        Objects.equals(this.coListOfficeAOR, orgResoMetadataProperty.coListOfficeAOR) &&
        Objects.equals(this.coListOfficeEmail, orgResoMetadataProperty.coListOfficeEmail) &&
        Objects.equals(this.coListOfficeFax, orgResoMetadataProperty.coListOfficeFax) &&
        Objects.equals(this.coListOfficeKey, orgResoMetadataProperty.coListOfficeKey) &&
        Objects.equals(this.coListOfficeKeyNumeric, orgResoMetadataProperty.coListOfficeKeyNumeric) &&
        Objects.equals(this.coListOfficeMlsId, orgResoMetadataProperty.coListOfficeMlsId) &&
        Objects.equals(this.coListOfficeName, orgResoMetadataProperty.coListOfficeName) &&
        Objects.equals(this.coListOfficePhone, orgResoMetadataProperty.coListOfficePhone) &&
        Objects.equals(this.coListOfficePhoneExt, orgResoMetadataProperty.coListOfficePhoneExt) &&
        Objects.equals(this.coListOfficeURL, orgResoMetadataProperty.coListOfficeURL) &&
        Objects.equals(this.commonInterest, orgResoMetadataProperty.commonInterest) &&
        Objects.equals(this.commonWalls, orgResoMetadataProperty.commonWalls) &&
        Objects.equals(this.communityFeatures, orgResoMetadataProperty.communityFeatures) &&
        Objects.equals(this.concessions, orgResoMetadataProperty.concessions) &&
        Objects.equals(this.concessionsAmount, orgResoMetadataProperty.concessionsAmount) &&
        Objects.equals(this.concessionsComments, orgResoMetadataProperty.concessionsComments) &&
        Objects.equals(this.constructionMaterials, orgResoMetadataProperty.constructionMaterials) &&
        Objects.equals(this.continentRegion, orgResoMetadataProperty.continentRegion) &&
        Objects.equals(this.contingency, orgResoMetadataProperty.contingency) &&
        Objects.equals(this.contingentDate, orgResoMetadataProperty.contingentDate) &&
        Objects.equals(this.contractStatusChangeDate, orgResoMetadataProperty.contractStatusChangeDate) &&
        Objects.equals(this.cooling, orgResoMetadataProperty.cooling) &&
        Objects.equals(this.coolingYN, orgResoMetadataProperty.coolingYN) &&
        Objects.equals(this.copyrightNotice, orgResoMetadataProperty.copyrightNotice) &&
        Objects.equals(this.country, orgResoMetadataProperty.country) &&
        Objects.equals(this.countryRegion, orgResoMetadataProperty.countryRegion) &&
        Objects.equals(this.countyOrParish, orgResoMetadataProperty.countyOrParish) &&
        Objects.equals(this.coveredSpaces, orgResoMetadataProperty.coveredSpaces) &&
        Objects.equals(this.cropsIncludedYN, orgResoMetadataProperty.cropsIncludedYN) &&
        Objects.equals(this.crossStreet, orgResoMetadataProperty.crossStreet) &&
        Objects.equals(this.cultivatedArea, orgResoMetadataProperty.cultivatedArea) &&
        Objects.equals(this.cumulativeDaysOnMarket, orgResoMetadataProperty.cumulativeDaysOnMarket) &&
        Objects.equals(this.currentFinancing, orgResoMetadataProperty.currentFinancing) &&
        Objects.equals(this.currentUse, orgResoMetadataProperty.currentUse) &&
        Objects.equals(this.doH1, orgResoMetadataProperty.doH1) &&
        Objects.equals(this.doH2, orgResoMetadataProperty.doH2) &&
        Objects.equals(this.doH3, orgResoMetadataProperty.doH3) &&
        Objects.equals(this.daysOnMarket, orgResoMetadataProperty.daysOnMarket) &&
        Objects.equals(this.developmentStatus, orgResoMetadataProperty.developmentStatus) &&
        Objects.equals(this.directionFaces, orgResoMetadataProperty.directionFaces) &&
        Objects.equals(this.directions, orgResoMetadataProperty.directions) &&
        Objects.equals(this.disclaimer, orgResoMetadataProperty.disclaimer) &&
        Objects.equals(this.disclosures, orgResoMetadataProperty.disclosures) &&
        Objects.equals(this.distanceToBusComments, orgResoMetadataProperty.distanceToBusComments) &&
        Objects.equals(this.distanceToBusNumeric, orgResoMetadataProperty.distanceToBusNumeric) &&
        Objects.equals(this.distanceToBusUnits, orgResoMetadataProperty.distanceToBusUnits) &&
        Objects.equals(this.distanceToElectricComments, orgResoMetadataProperty.distanceToElectricComments) &&
        Objects.equals(this.distanceToElectricNumeric, orgResoMetadataProperty.distanceToElectricNumeric) &&
        Objects.equals(this.distanceToElectricUnits, orgResoMetadataProperty.distanceToElectricUnits) &&
        Objects.equals(this.distanceToFreewayComments, orgResoMetadataProperty.distanceToFreewayComments) &&
        Objects.equals(this.distanceToFreewayNumeric, orgResoMetadataProperty.distanceToFreewayNumeric) &&
        Objects.equals(this.distanceToFreewayUnits, orgResoMetadataProperty.distanceToFreewayUnits) &&
        Objects.equals(this.distanceToGasComments, orgResoMetadataProperty.distanceToGasComments) &&
        Objects.equals(this.distanceToGasNumeric, orgResoMetadataProperty.distanceToGasNumeric) &&
        Objects.equals(this.distanceToGasUnits, orgResoMetadataProperty.distanceToGasUnits) &&
        Objects.equals(this.distanceToPhoneServiceComments, orgResoMetadataProperty.distanceToPhoneServiceComments) &&
        Objects.equals(this.distanceToPhoneServiceNumeric, orgResoMetadataProperty.distanceToPhoneServiceNumeric) &&
        Objects.equals(this.distanceToPhoneServiceUnits, orgResoMetadataProperty.distanceToPhoneServiceUnits) &&
        Objects.equals(this.distanceToPlaceofWorshipComments, orgResoMetadataProperty.distanceToPlaceofWorshipComments) &&
        Objects.equals(this.distanceToPlaceofWorshipNumeric, orgResoMetadataProperty.distanceToPlaceofWorshipNumeric) &&
        Objects.equals(this.distanceToPlaceofWorshipUnits, orgResoMetadataProperty.distanceToPlaceofWorshipUnits) &&
        Objects.equals(this.distanceToSchoolBusComments, orgResoMetadataProperty.distanceToSchoolBusComments) &&
        Objects.equals(this.distanceToSchoolBusNumeric, orgResoMetadataProperty.distanceToSchoolBusNumeric) &&
        Objects.equals(this.distanceToSchoolBusUnits, orgResoMetadataProperty.distanceToSchoolBusUnits) &&
        Objects.equals(this.distanceToSchoolsComments, orgResoMetadataProperty.distanceToSchoolsComments) &&
        Objects.equals(this.distanceToSchoolsNumeric, orgResoMetadataProperty.distanceToSchoolsNumeric) &&
        Objects.equals(this.distanceToSchoolsUnits, orgResoMetadataProperty.distanceToSchoolsUnits) &&
        Objects.equals(this.distanceToSewerComments, orgResoMetadataProperty.distanceToSewerComments) &&
        Objects.equals(this.distanceToSewerNumeric, orgResoMetadataProperty.distanceToSewerNumeric) &&
        Objects.equals(this.distanceToSewerUnits, orgResoMetadataProperty.distanceToSewerUnits) &&
        Objects.equals(this.distanceToShoppingComments, orgResoMetadataProperty.distanceToShoppingComments) &&
        Objects.equals(this.distanceToShoppingNumeric, orgResoMetadataProperty.distanceToShoppingNumeric) &&
        Objects.equals(this.distanceToShoppingUnits, orgResoMetadataProperty.distanceToShoppingUnits) &&
        Objects.equals(this.distanceToStreetComments, orgResoMetadataProperty.distanceToStreetComments) &&
        Objects.equals(this.distanceToStreetNumeric, orgResoMetadataProperty.distanceToStreetNumeric) &&
        Objects.equals(this.distanceToStreetUnits, orgResoMetadataProperty.distanceToStreetUnits) &&
        Objects.equals(this.distanceToWaterComments, orgResoMetadataProperty.distanceToWaterComments) &&
        Objects.equals(this.distanceToWaterNumeric, orgResoMetadataProperty.distanceToWaterNumeric) &&
        Objects.equals(this.distanceToWaterUnits, orgResoMetadataProperty.distanceToWaterUnits) &&
        Objects.equals(this.documentsAvailable, orgResoMetadataProperty.documentsAvailable) &&
        Objects.equals(this.documentsChangeTimestamp, orgResoMetadataProperty.documentsChangeTimestamp) &&
        Objects.equals(this.documentsCount, orgResoMetadataProperty.documentsCount) &&
        Objects.equals(this.doorFeatures, orgResoMetadataProperty.doorFeatures) &&
        Objects.equals(this.dualVariableCompensationYN, orgResoMetadataProperty.dualVariableCompensationYN) &&
        Objects.equals(this.electric, orgResoMetadataProperty.electric) &&
        Objects.equals(this.electricExpense, orgResoMetadataProperty.electricExpense) &&
        Objects.equals(this.electricOnPropertyYN, orgResoMetadataProperty.electricOnPropertyYN) &&
        Objects.equals(this.elementarySchool, orgResoMetadataProperty.elementarySchool) &&
        Objects.equals(this.elementarySchoolDistrict, orgResoMetadataProperty.elementarySchoolDistrict) &&
        Objects.equals(this.elevation, orgResoMetadataProperty.elevation) &&
        Objects.equals(this.elevationUnits, orgResoMetadataProperty.elevationUnits) &&
        Objects.equals(this.entryLevel, orgResoMetadataProperty.entryLevel) &&
        Objects.equals(this.entryLocation, orgResoMetadataProperty.entryLocation) &&
        Objects.equals(this.exclusions, orgResoMetadataProperty.exclusions) &&
        Objects.equals(this.existingLeaseType, orgResoMetadataProperty.existingLeaseType) &&
        Objects.equals(this.expirationDate, orgResoMetadataProperty.expirationDate) &&
        Objects.equals(this.exteriorFeatures, orgResoMetadataProperty.exteriorFeatures) &&
        Objects.equals(this.farmCreditServiceInclYN, orgResoMetadataProperty.farmCreditServiceInclYN) &&
        Objects.equals(this.farmLandAreaSource, orgResoMetadataProperty.farmLandAreaSource) &&
        Objects.equals(this.farmLandAreaUnits, orgResoMetadataProperty.farmLandAreaUnits) &&
        Objects.equals(this.fencing, orgResoMetadataProperty.fencing) &&
        Objects.equals(this.financialDataSource, orgResoMetadataProperty.financialDataSource) &&
        Objects.equals(this.fireplaceFeatures, orgResoMetadataProperty.fireplaceFeatures) &&
        Objects.equals(this.fireplaceYN, orgResoMetadataProperty.fireplaceYN) &&
        Objects.equals(this.fireplacesTotal, orgResoMetadataProperty.fireplacesTotal) &&
        Objects.equals(this.flooring, orgResoMetadataProperty.flooring) &&
        Objects.equals(this.foundationArea, orgResoMetadataProperty.foundationArea) &&
        Objects.equals(this.foundationDetails, orgResoMetadataProperty.foundationDetails) &&
        Objects.equals(this.frontageLength, orgResoMetadataProperty.frontageLength) &&
        Objects.equals(this.frontageType, orgResoMetadataProperty.frontageType) &&
        Objects.equals(this.fuelExpense, orgResoMetadataProperty.fuelExpense) &&
        Objects.equals(this.furnished, orgResoMetadataProperty.furnished) &&
        Objects.equals(this.furnitureReplacementExpense, orgResoMetadataProperty.furnitureReplacementExpense) &&
        Objects.equals(this.garageSpaces, orgResoMetadataProperty.garageSpaces) &&
        Objects.equals(this.garageYN, orgResoMetadataProperty.garageYN) &&
        Objects.equals(this.gardenerExpense, orgResoMetadataProperty.gardenerExpense) &&
        Objects.equals(this.grazingPermitsBlmYN, orgResoMetadataProperty.grazingPermitsBlmYN) &&
        Objects.equals(this.grazingPermitsForestServiceYN, orgResoMetadataProperty.grazingPermitsForestServiceYN) &&
        Objects.equals(this.grazingPermitsPrivateYN, orgResoMetadataProperty.grazingPermitsPrivateYN) &&
        Objects.equals(this.greenBuildingVerificationType, orgResoMetadataProperty.greenBuildingVerificationType) &&
        Objects.equals(this.greenEnergyEfficient, orgResoMetadataProperty.greenEnergyEfficient) &&
        Objects.equals(this.greenEnergyGeneration, orgResoMetadataProperty.greenEnergyGeneration) &&
        Objects.equals(this.greenIndoorAirQuality, orgResoMetadataProperty.greenIndoorAirQuality) &&
        Objects.equals(this.greenLocation, orgResoMetadataProperty.greenLocation) &&
        Objects.equals(this.greenSustainability, orgResoMetadataProperty.greenSustainability) &&
        Objects.equals(this.greenWaterConservation, orgResoMetadataProperty.greenWaterConservation) &&
        Objects.equals(this.grossIncome, orgResoMetadataProperty.grossIncome) &&
        Objects.equals(this.grossScheduledIncome, orgResoMetadataProperty.grossScheduledIncome) &&
        Objects.equals(this.habitableResidenceYN, orgResoMetadataProperty.habitableResidenceYN) &&
        Objects.equals(this.heating, orgResoMetadataProperty.heating) &&
        Objects.equals(this.heatingYN, orgResoMetadataProperty.heatingYN) &&
        Objects.equals(this.highSchool, orgResoMetadataProperty.highSchool) &&
        Objects.equals(this.highSchoolDistrict, orgResoMetadataProperty.highSchoolDistrict) &&
        Objects.equals(this.homeWarrantyYN, orgResoMetadataProperty.homeWarrantyYN) &&
        Objects.equals(this.horseAmenities, orgResoMetadataProperty.horseAmenities) &&
        Objects.equals(this.horseYN, orgResoMetadataProperty.horseYN) &&
        Objects.equals(this.hoursDaysOfOperation, orgResoMetadataProperty.hoursDaysOfOperation) &&
        Objects.equals(this.hoursDaysOfOperationDescription, orgResoMetadataProperty.hoursDaysOfOperationDescription) &&
        Objects.equals(this.inclusions, orgResoMetadataProperty.inclusions) &&
        Objects.equals(this.incomeIncludes, orgResoMetadataProperty.incomeIncludes) &&
        Objects.equals(this.insuranceExpense, orgResoMetadataProperty.insuranceExpense) &&
        Objects.equals(this.interiorFeatures, orgResoMetadataProperty.interiorFeatures) &&
        Objects.equals(this.internetAddressDisplayYN, orgResoMetadataProperty.internetAddressDisplayYN) &&
        Objects.equals(this.internetAutomatedValuationDisplayYN, orgResoMetadataProperty.internetAutomatedValuationDisplayYN) &&
        Objects.equals(this.internetConsumerCommentYN, orgResoMetadataProperty.internetConsumerCommentYN) &&
        Objects.equals(this.internetEntireListingDisplayYN, orgResoMetadataProperty.internetEntireListingDisplayYN) &&
        Objects.equals(this.irrigationSource, orgResoMetadataProperty.irrigationSource) &&
        Objects.equals(this.irrigationWaterRightsAcres, orgResoMetadataProperty.irrigationWaterRightsAcres) &&
        Objects.equals(this.irrigationWaterRightsYN, orgResoMetadataProperty.irrigationWaterRightsYN) &&
        Objects.equals(this.laborInformation, orgResoMetadataProperty.laborInformation) &&
        Objects.equals(this.landLeaseAmount, orgResoMetadataProperty.landLeaseAmount) &&
        Objects.equals(this.landLeaseAmountFrequency, orgResoMetadataProperty.landLeaseAmountFrequency) &&
        Objects.equals(this.landLeaseExpirationDate, orgResoMetadataProperty.landLeaseExpirationDate) &&
        Objects.equals(this.landLeaseYN, orgResoMetadataProperty.landLeaseYN) &&
        Objects.equals(this.latitude, orgResoMetadataProperty.latitude) &&
        Objects.equals(this.laundryFeatures, orgResoMetadataProperty.laundryFeatures) &&
        Objects.equals(this.leasableArea, orgResoMetadataProperty.leasableArea) &&
        Objects.equals(this.leasableAreaUnits, orgResoMetadataProperty.leasableAreaUnits) &&
        Objects.equals(this.leaseAmount, orgResoMetadataProperty.leaseAmount) &&
        Objects.equals(this.leaseAmountFrequency, orgResoMetadataProperty.leaseAmountFrequency) &&
        Objects.equals(this.leaseAssignableYN, orgResoMetadataProperty.leaseAssignableYN) &&
        Objects.equals(this.leaseConsideredYN, orgResoMetadataProperty.leaseConsideredYN) &&
        Objects.equals(this.leaseExpiration, orgResoMetadataProperty.leaseExpiration) &&
        Objects.equals(this.leaseRenewalCompensation, orgResoMetadataProperty.leaseRenewalCompensation) &&
        Objects.equals(this.leaseRenewalOptionYN, orgResoMetadataProperty.leaseRenewalOptionYN) &&
        Objects.equals(this.leaseTerm, orgResoMetadataProperty.leaseTerm) &&
        Objects.equals(this.levels, orgResoMetadataProperty.levels) &&
        Objects.equals(this.license1, orgResoMetadataProperty.license1) &&
        Objects.equals(this.license2, orgResoMetadataProperty.license2) &&
        Objects.equals(this.license3, orgResoMetadataProperty.license3) &&
        Objects.equals(this.licensesExpense, orgResoMetadataProperty.licensesExpense) &&
        Objects.equals(this.listAOR, orgResoMetadataProperty.listAOR) &&
        Objects.equals(this.listAgentAOR, orgResoMetadataProperty.listAgentAOR) &&
        Objects.equals(this.listAgentDesignation, orgResoMetadataProperty.listAgentDesignation) &&
        Objects.equals(this.listAgentDirectPhone, orgResoMetadataProperty.listAgentDirectPhone) &&
        Objects.equals(this.listAgentEmail, orgResoMetadataProperty.listAgentEmail) &&
        Objects.equals(this.listAgentFax, orgResoMetadataProperty.listAgentFax) &&
        Objects.equals(this.listAgentFirstName, orgResoMetadataProperty.listAgentFirstName) &&
        Objects.equals(this.listAgentFullName, orgResoMetadataProperty.listAgentFullName) &&
        Objects.equals(this.listAgentHomePhone, orgResoMetadataProperty.listAgentHomePhone) &&
        Objects.equals(this.listAgentKey, orgResoMetadataProperty.listAgentKey) &&
        Objects.equals(this.listAgentKeyNumeric, orgResoMetadataProperty.listAgentKeyNumeric) &&
        Objects.equals(this.listAgentLastName, orgResoMetadataProperty.listAgentLastName) &&
        Objects.equals(this.listAgentMiddleName, orgResoMetadataProperty.listAgentMiddleName) &&
        Objects.equals(this.listAgentMlsId, orgResoMetadataProperty.listAgentMlsId) &&
        Objects.equals(this.listAgentMobilePhone, orgResoMetadataProperty.listAgentMobilePhone) &&
        Objects.equals(this.listAgentNamePrefix, orgResoMetadataProperty.listAgentNamePrefix) &&
        Objects.equals(this.listAgentNameSuffix, orgResoMetadataProperty.listAgentNameSuffix) &&
        Objects.equals(this.listAgentOfficePhone, orgResoMetadataProperty.listAgentOfficePhone) &&
        Objects.equals(this.listAgentOfficePhoneExt, orgResoMetadataProperty.listAgentOfficePhoneExt) &&
        Objects.equals(this.listAgentPager, orgResoMetadataProperty.listAgentPager) &&
        Objects.equals(this.listAgentPreferredPhone, orgResoMetadataProperty.listAgentPreferredPhone) &&
        Objects.equals(this.listAgentPreferredPhoneExt, orgResoMetadataProperty.listAgentPreferredPhoneExt) &&
        Objects.equals(this.listAgentStateLicense, orgResoMetadataProperty.listAgentStateLicense) &&
        Objects.equals(this.listAgentTollFreePhone, orgResoMetadataProperty.listAgentTollFreePhone) &&
        Objects.equals(this.listAgentURL, orgResoMetadataProperty.listAgentURL) &&
        Objects.equals(this.listAgentVoiceMail, orgResoMetadataProperty.listAgentVoiceMail) &&
        Objects.equals(this.listAgentVoiceMailExt, orgResoMetadataProperty.listAgentVoiceMailExt) &&
        Objects.equals(this.listOfficeAOR, orgResoMetadataProperty.listOfficeAOR) &&
        Objects.equals(this.listOfficeEmail, orgResoMetadataProperty.listOfficeEmail) &&
        Objects.equals(this.listOfficeFax, orgResoMetadataProperty.listOfficeFax) &&
        Objects.equals(this.listOfficeKey, orgResoMetadataProperty.listOfficeKey) &&
        Objects.equals(this.listOfficeKeyNumeric, orgResoMetadataProperty.listOfficeKeyNumeric) &&
        Objects.equals(this.listOfficeMlsId, orgResoMetadataProperty.listOfficeMlsId) &&
        Objects.equals(this.listOfficeName, orgResoMetadataProperty.listOfficeName) &&
        Objects.equals(this.listOfficePhone, orgResoMetadataProperty.listOfficePhone) &&
        Objects.equals(this.listOfficePhoneExt, orgResoMetadataProperty.listOfficePhoneExt) &&
        Objects.equals(this.listOfficeURL, orgResoMetadataProperty.listOfficeURL) &&
        Objects.equals(this.listPrice, orgResoMetadataProperty.listPrice) &&
        Objects.equals(this.listPriceLow, orgResoMetadataProperty.listPriceLow) &&
        Objects.equals(this.listTeamKey, orgResoMetadataProperty.listTeamKey) &&
        Objects.equals(this.listTeamKeyNumeric, orgResoMetadataProperty.listTeamKeyNumeric) &&
        Objects.equals(this.listTeamName, orgResoMetadataProperty.listTeamName) &&
        Objects.equals(this.listingAgreement, orgResoMetadataProperty.listingAgreement) &&
        Objects.equals(this.listingContractDate, orgResoMetadataProperty.listingContractDate) &&
        Objects.equals(this.listingId, orgResoMetadataProperty.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataProperty.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataProperty.listingKeyNumeric) &&
        Objects.equals(this.listingService, orgResoMetadataProperty.listingService) &&
        Objects.equals(this.listingTerms, orgResoMetadataProperty.listingTerms) &&
        Objects.equals(this.livingArea, orgResoMetadataProperty.livingArea) &&
        Objects.equals(this.livingAreaSource, orgResoMetadataProperty.livingAreaSource) &&
        Objects.equals(this.livingAreaUnits, orgResoMetadataProperty.livingAreaUnits) &&
        Objects.equals(this.lockBoxLocation, orgResoMetadataProperty.lockBoxLocation) &&
        Objects.equals(this.lockBoxSerialNumber, orgResoMetadataProperty.lockBoxSerialNumber) &&
        Objects.equals(this.lockBoxType, orgResoMetadataProperty.lockBoxType) &&
        Objects.equals(this.longitude, orgResoMetadataProperty.longitude) &&
        Objects.equals(this.lotDimensionsSource, orgResoMetadataProperty.lotDimensionsSource) &&
        Objects.equals(this.lotFeatures, orgResoMetadataProperty.lotFeatures) &&
        Objects.equals(this.lotSizeAcres, orgResoMetadataProperty.lotSizeAcres) &&
        Objects.equals(this.lotSizeArea, orgResoMetadataProperty.lotSizeArea) &&
        Objects.equals(this.lotSizeDimensions, orgResoMetadataProperty.lotSizeDimensions) &&
        Objects.equals(this.lotSizeSource, orgResoMetadataProperty.lotSizeSource) &&
        Objects.equals(this.lotSizeSquareFeet, orgResoMetadataProperty.lotSizeSquareFeet) &&
        Objects.equals(this.lotSizeUnits, orgResoMetadataProperty.lotSizeUnits) &&
        Objects.equals(this.mlSAreaMajor, orgResoMetadataProperty.mlSAreaMajor) &&
        Objects.equals(this.mlSAreaMinor, orgResoMetadataProperty.mlSAreaMinor) &&
        Objects.equals(this.mainLevelBathrooms, orgResoMetadataProperty.mainLevelBathrooms) &&
        Objects.equals(this.mainLevelBedrooms, orgResoMetadataProperty.mainLevelBedrooms) &&
        Objects.equals(this.maintenanceExpense, orgResoMetadataProperty.maintenanceExpense) &&
        Objects.equals(this.majorChangeTimestamp, orgResoMetadataProperty.majorChangeTimestamp) &&
        Objects.equals(this.majorChangeType, orgResoMetadataProperty.majorChangeType) &&
        Objects.equals(this.make, orgResoMetadataProperty.make) &&
        Objects.equals(this.managerExpense, orgResoMetadataProperty.managerExpense) &&
        Objects.equals(this.mapCoordinate, orgResoMetadataProperty.mapCoordinate) &&
        Objects.equals(this.mapCoordinateSource, orgResoMetadataProperty.mapCoordinateSource) &&
        Objects.equals(this.mapURL, orgResoMetadataProperty.mapURL) &&
        Objects.equals(this.middleOrJuniorSchool, orgResoMetadataProperty.middleOrJuniorSchool) &&
        Objects.equals(this.middleOrJuniorSchoolDistrict, orgResoMetadataProperty.middleOrJuniorSchoolDistrict) &&
        Objects.equals(this.mlsStatus, orgResoMetadataProperty.mlsStatus) &&
        Objects.equals(this.mobileDimUnits, orgResoMetadataProperty.mobileDimUnits) &&
        Objects.equals(this.mobileHomeRemainsYN, orgResoMetadataProperty.mobileHomeRemainsYN) &&
        Objects.equals(this.mobileLength, orgResoMetadataProperty.mobileLength) &&
        Objects.equals(this.mobileWidth, orgResoMetadataProperty.mobileWidth) &&
        Objects.equals(this.model, orgResoMetadataProperty.model) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataProperty.modificationTimestamp) &&
        Objects.equals(this.netOperatingIncome, orgResoMetadataProperty.netOperatingIncome) &&
        Objects.equals(this.newConstructionYN, orgResoMetadataProperty.newConstructionYN) &&
        Objects.equals(this.newTaxesExpense, orgResoMetadataProperty.newTaxesExpense) &&
        Objects.equals(this.numberOfBuildings, orgResoMetadataProperty.numberOfBuildings) &&
        Objects.equals(this.numberOfFullTimeEmployees, orgResoMetadataProperty.numberOfFullTimeEmployees) &&
        Objects.equals(this.numberOfLots, orgResoMetadataProperty.numberOfLots) &&
        Objects.equals(this.numberOfPads, orgResoMetadataProperty.numberOfPads) &&
        Objects.equals(this.numberOfPartTimeEmployees, orgResoMetadataProperty.numberOfPartTimeEmployees) &&
        Objects.equals(this.numberOfSeparateElectricMeters, orgResoMetadataProperty.numberOfSeparateElectricMeters) &&
        Objects.equals(this.numberOfSeparateGasMeters, orgResoMetadataProperty.numberOfSeparateGasMeters) &&
        Objects.equals(this.numberOfSeparateWaterMeters, orgResoMetadataProperty.numberOfSeparateWaterMeters) &&
        Objects.equals(this.numberOfUnitsInCommunity, orgResoMetadataProperty.numberOfUnitsInCommunity) &&
        Objects.equals(this.numberOfUnitsLeased, orgResoMetadataProperty.numberOfUnitsLeased) &&
        Objects.equals(this.numberOfUnitsMoMo, orgResoMetadataProperty.numberOfUnitsMoMo) &&
        Objects.equals(this.numberOfUnitsTotal, orgResoMetadataProperty.numberOfUnitsTotal) &&
        Objects.equals(this.numberOfUnitsVacant, orgResoMetadataProperty.numberOfUnitsVacant) &&
        Objects.equals(this.occupantName, orgResoMetadataProperty.occupantName) &&
        Objects.equals(this.occupantPhone, orgResoMetadataProperty.occupantPhone) &&
        Objects.equals(this.occupantType, orgResoMetadataProperty.occupantType) &&
        Objects.equals(this.offMarketDate, orgResoMetadataProperty.offMarketDate) &&
        Objects.equals(this.offMarketTimestamp, orgResoMetadataProperty.offMarketTimestamp) &&
        Objects.equals(this.onMarketDate, orgResoMetadataProperty.onMarketDate) &&
        Objects.equals(this.onMarketTimestamp, orgResoMetadataProperty.onMarketTimestamp) &&
        Objects.equals(this.openParkingSpaces, orgResoMetadataProperty.openParkingSpaces) &&
        Objects.equals(this.openParkingYN, orgResoMetadataProperty.openParkingYN) &&
        Objects.equals(this.operatingExpense, orgResoMetadataProperty.operatingExpense) &&
        Objects.equals(this.operatingExpenseIncludes, orgResoMetadataProperty.operatingExpenseIncludes) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataProperty.originalEntryTimestamp) &&
        Objects.equals(this.originalListPrice, orgResoMetadataProperty.originalListPrice) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataProperty.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataProperty.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataProperty.originatingSystemName) &&
        Objects.equals(this.otherEquipment, orgResoMetadataProperty.otherEquipment) &&
        Objects.equals(this.otherExpense, orgResoMetadataProperty.otherExpense) &&
        Objects.equals(this.otherParking, orgResoMetadataProperty.otherParking) &&
        Objects.equals(this.otherStructures, orgResoMetadataProperty.otherStructures) &&
        Objects.equals(this.ownerName, orgResoMetadataProperty.ownerName) &&
        Objects.equals(this.ownerPays, orgResoMetadataProperty.ownerPays) &&
        Objects.equals(this.ownerPhone, orgResoMetadataProperty.ownerPhone) &&
        Objects.equals(this.ownership, orgResoMetadataProperty.ownership) &&
        Objects.equals(this.ownershipType, orgResoMetadataProperty.ownershipType) &&
        Objects.equals(this.parcelNumber, orgResoMetadataProperty.parcelNumber) &&
        Objects.equals(this.parkManagerName, orgResoMetadataProperty.parkManagerName) &&
        Objects.equals(this.parkManagerPhone, orgResoMetadataProperty.parkManagerPhone) &&
        Objects.equals(this.parkName, orgResoMetadataProperty.parkName) &&
        Objects.equals(this.parkingFeatures, orgResoMetadataProperty.parkingFeatures) &&
        Objects.equals(this.parkingTotal, orgResoMetadataProperty.parkingTotal) &&
        Objects.equals(this.pastureArea, orgResoMetadataProperty.pastureArea) &&
        Objects.equals(this.patioAndPorchFeatures, orgResoMetadataProperty.patioAndPorchFeatures) &&
        Objects.equals(this.pendingTimestamp, orgResoMetadataProperty.pendingTimestamp) &&
        Objects.equals(this.pestControlExpense, orgResoMetadataProperty.pestControlExpense) &&
        Objects.equals(this.petsAllowed, orgResoMetadataProperty.petsAllowed) &&
        Objects.equals(this.photosChangeTimestamp, orgResoMetadataProperty.photosChangeTimestamp) &&
        Objects.equals(this.photosCount, orgResoMetadataProperty.photosCount) &&
        Objects.equals(this.poolExpense, orgResoMetadataProperty.poolExpense) &&
        Objects.equals(this.poolFeatures, orgResoMetadataProperty.poolFeatures) &&
        Objects.equals(this.poolPrivateYN, orgResoMetadataProperty.poolPrivateYN) &&
        Objects.equals(this.possession, orgResoMetadataProperty.possession) &&
        Objects.equals(this.possibleUse, orgResoMetadataProperty.possibleUse) &&
        Objects.equals(this.postalCity, orgResoMetadataProperty.postalCity) &&
        Objects.equals(this.postalCode, orgResoMetadataProperty.postalCode) &&
        Objects.equals(this.postalCodePlus4, orgResoMetadataProperty.postalCodePlus4) &&
        Objects.equals(this.powerProductionType, orgResoMetadataProperty.powerProductionType) &&
        Objects.equals(this.previousListPrice, orgResoMetadataProperty.previousListPrice) &&
        Objects.equals(this.priceChangeTimestamp, orgResoMetadataProperty.priceChangeTimestamp) &&
        Objects.equals(this.privateOfficeRemarks, orgResoMetadataProperty.privateOfficeRemarks) &&
        Objects.equals(this.privateRemarks, orgResoMetadataProperty.privateRemarks) &&
        Objects.equals(this.professionalManagementExpense, orgResoMetadataProperty.professionalManagementExpense) &&
        Objects.equals(this.propertyAttachedYN, orgResoMetadataProperty.propertyAttachedYN) &&
        Objects.equals(this.propertyCondition, orgResoMetadataProperty.propertyCondition) &&
        Objects.equals(this.propertySubType, orgResoMetadataProperty.propertySubType) &&
        Objects.equals(this.propertyType, orgResoMetadataProperty.propertyType) &&
        Objects.equals(this.publicRemarks, orgResoMetadataProperty.publicRemarks) &&
        Objects.equals(this.publicSurveyRange, orgResoMetadataProperty.publicSurveyRange) &&
        Objects.equals(this.publicSurveySection, orgResoMetadataProperty.publicSurveySection) &&
        Objects.equals(this.publicSurveyTownship, orgResoMetadataProperty.publicSurveyTownship) &&
        Objects.equals(this.purchaseContractDate, orgResoMetadataProperty.purchaseContractDate) &&
        Objects.equals(this.rvParkingDimensions, orgResoMetadataProperty.rvParkingDimensions) &&
        Objects.equals(this.rangeArea, orgResoMetadataProperty.rangeArea) &&
        Objects.equals(this.rentControlYN, orgResoMetadataProperty.rentControlYN) &&
        Objects.equals(this.rentIncludes, orgResoMetadataProperty.rentIncludes) &&
        Objects.equals(this.roadFrontageType, orgResoMetadataProperty.roadFrontageType) &&
        Objects.equals(this.roadResponsibility, orgResoMetadataProperty.roadResponsibility) &&
        Objects.equals(this.roadSurfaceType, orgResoMetadataProperty.roadSurfaceType) &&
        Objects.equals(this.roof, orgResoMetadataProperty.roof) &&
        Objects.equals(this.roomType, orgResoMetadataProperty.roomType) &&
        Objects.equals(this.roomsTotal, orgResoMetadataProperty.roomsTotal) &&
        Objects.equals(this.seatingCapacity, orgResoMetadataProperty.seatingCapacity) &&
        Objects.equals(this.securityFeatures, orgResoMetadataProperty.securityFeatures) &&
        Objects.equals(this.seniorCommunityYN, orgResoMetadataProperty.seniorCommunityYN) &&
        Objects.equals(this.serialU, orgResoMetadataProperty.serialU) &&
        Objects.equals(this.serialX, orgResoMetadataProperty.serialX) &&
        Objects.equals(this.serialXX, orgResoMetadataProperty.serialXX) &&
        Objects.equals(this.sewer, orgResoMetadataProperty.sewer) &&
        Objects.equals(this.showingAdvanceNotice, orgResoMetadataProperty.showingAdvanceNotice) &&
        Objects.equals(this.showingAttendedYN, orgResoMetadataProperty.showingAttendedYN) &&
        Objects.equals(this.showingContactName, orgResoMetadataProperty.showingContactName) &&
        Objects.equals(this.showingContactPhone, orgResoMetadataProperty.showingContactPhone) &&
        Objects.equals(this.showingContactPhoneExt, orgResoMetadataProperty.showingContactPhoneExt) &&
        Objects.equals(this.showingContactType, orgResoMetadataProperty.showingContactType) &&
        Objects.equals(this.showingDays, orgResoMetadataProperty.showingDays) &&
        Objects.equals(this.showingEndTime, orgResoMetadataProperty.showingEndTime) &&
        Objects.equals(this.showingInstructions, orgResoMetadataProperty.showingInstructions) &&
        Objects.equals(this.showingRequirements, orgResoMetadataProperty.showingRequirements) &&
        Objects.equals(this.showingStartTime, orgResoMetadataProperty.showingStartTime) &&
        Objects.equals(this.signOnPropertyYN, orgResoMetadataProperty.signOnPropertyYN) &&
        Objects.equals(this.skirt, orgResoMetadataProperty.skirt) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataProperty.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataProperty.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataProperty.sourceSystemName) &&
        Objects.equals(this.spaFeatures, orgResoMetadataProperty.spaFeatures) &&
        Objects.equals(this.spaYN, orgResoMetadataProperty.spaYN) &&
        Objects.equals(this.specialLicenses, orgResoMetadataProperty.specialLicenses) &&
        Objects.equals(this.specialListingConditions, orgResoMetadataProperty.specialListingConditions) &&
        Objects.equals(this.standardStatus, orgResoMetadataProperty.standardStatus) &&
        Objects.equals(this.stateOrProvince, orgResoMetadataProperty.stateOrProvince) &&
        Objects.equals(this.stateRegion, orgResoMetadataProperty.stateRegion) &&
        Objects.equals(this.statusChangeTimestamp, orgResoMetadataProperty.statusChangeTimestamp) &&
        Objects.equals(this.stories, orgResoMetadataProperty.stories) &&
        Objects.equals(this.storiesTotal, orgResoMetadataProperty.storiesTotal) &&
        Objects.equals(this.streetAdditionalInfo, orgResoMetadataProperty.streetAdditionalInfo) &&
        Objects.equals(this.streetDirPrefix, orgResoMetadataProperty.streetDirPrefix) &&
        Objects.equals(this.streetDirSuffix, orgResoMetadataProperty.streetDirSuffix) &&
        Objects.equals(this.streetName, orgResoMetadataProperty.streetName) &&
        Objects.equals(this.streetNumber, orgResoMetadataProperty.streetNumber) &&
        Objects.equals(this.streetNumberNumeric, orgResoMetadataProperty.streetNumberNumeric) &&
        Objects.equals(this.streetSuffix, orgResoMetadataProperty.streetSuffix) &&
        Objects.equals(this.streetSuffixModifier, orgResoMetadataProperty.streetSuffixModifier) &&
        Objects.equals(this.structureType, orgResoMetadataProperty.structureType) &&
        Objects.equals(this.subAgencyCompensation, orgResoMetadataProperty.subAgencyCompensation) &&
        Objects.equals(this.subAgencyCompensationType, orgResoMetadataProperty.subAgencyCompensationType) &&
        Objects.equals(this.subdivisionName, orgResoMetadataProperty.subdivisionName) &&
        Objects.equals(this.suppliesExpense, orgResoMetadataProperty.suppliesExpense) &&
        Objects.equals(this.syndicateTo, orgResoMetadataProperty.syndicateTo) &&
        Objects.equals(this.syndicationRemarks, orgResoMetadataProperty.syndicationRemarks) &&
        Objects.equals(this.taxAnnualAmount, orgResoMetadataProperty.taxAnnualAmount) &&
        Objects.equals(this.taxAssessedValue, orgResoMetadataProperty.taxAssessedValue) &&
        Objects.equals(this.taxBlock, orgResoMetadataProperty.taxBlock) &&
        Objects.equals(this.taxBookNumber, orgResoMetadataProperty.taxBookNumber) &&
        Objects.equals(this.taxLegalDescription, orgResoMetadataProperty.taxLegalDescription) &&
        Objects.equals(this.taxLot, orgResoMetadataProperty.taxLot) &&
        Objects.equals(this.taxMapNumber, orgResoMetadataProperty.taxMapNumber) &&
        Objects.equals(this.taxOtherAnnualAssessmentAmount, orgResoMetadataProperty.taxOtherAnnualAssessmentAmount) &&
        Objects.equals(this.taxParcelLetter, orgResoMetadataProperty.taxParcelLetter) &&
        Objects.equals(this.taxStatusCurrent, orgResoMetadataProperty.taxStatusCurrent) &&
        Objects.equals(this.taxTract, orgResoMetadataProperty.taxTract) &&
        Objects.equals(this.taxYear, orgResoMetadataProperty.taxYear) &&
        Objects.equals(this.tenantPays, orgResoMetadataProperty.tenantPays) &&
        Objects.equals(this.topography, orgResoMetadataProperty.topography) &&
        Objects.equals(this.totalActualRent, orgResoMetadataProperty.totalActualRent) &&
        Objects.equals(this.township, orgResoMetadataProperty.township) &&
        Objects.equals(this.transactionBrokerCompensation, orgResoMetadataProperty.transactionBrokerCompensation) &&
        Objects.equals(this.transactionBrokerCompensationType, orgResoMetadataProperty.transactionBrokerCompensationType) &&
        Objects.equals(this.trashExpense, orgResoMetadataProperty.trashExpense) &&
        Objects.equals(this.unitNumber, orgResoMetadataProperty.unitNumber) &&
        Objects.equals(this.unitTypeType, orgResoMetadataProperty.unitTypeType) &&
        Objects.equals(this.unitsFurnished, orgResoMetadataProperty.unitsFurnished) &&
        Objects.equals(this.universalPropertyId, orgResoMetadataProperty.universalPropertyId) &&
        Objects.equals(this.universalPropertySubId, orgResoMetadataProperty.universalPropertySubId) &&
        Objects.equals(this.unparsedAddress, orgResoMetadataProperty.unparsedAddress) &&
        Objects.equals(this.utilities, orgResoMetadataProperty.utilities) &&
        Objects.equals(this.vacancyAllowance, orgResoMetadataProperty.vacancyAllowance) &&
        Objects.equals(this.vacancyAllowanceRate, orgResoMetadataProperty.vacancyAllowanceRate) &&
        Objects.equals(this.vegetation, orgResoMetadataProperty.vegetation) &&
        Objects.equals(this.videosChangeTimestamp, orgResoMetadataProperty.videosChangeTimestamp) &&
        Objects.equals(this.videosCount, orgResoMetadataProperty.videosCount) &&
        Objects.equals(this.view, orgResoMetadataProperty.view) &&
        Objects.equals(this.viewYN, orgResoMetadataProperty.viewYN) &&
        Objects.equals(this.virtualTourURLBranded, orgResoMetadataProperty.virtualTourURLBranded) &&
        Objects.equals(this.virtualTourURLUnbranded, orgResoMetadataProperty.virtualTourURLUnbranded) &&
        Objects.equals(this.walkScore, orgResoMetadataProperty.walkScore) &&
        Objects.equals(this.waterBodyName, orgResoMetadataProperty.waterBodyName) &&
        Objects.equals(this.waterSewerExpense, orgResoMetadataProperty.waterSewerExpense) &&
        Objects.equals(this.waterSource, orgResoMetadataProperty.waterSource) &&
        Objects.equals(this.waterfrontFeatures, orgResoMetadataProperty.waterfrontFeatures) &&
        Objects.equals(this.waterfrontYN, orgResoMetadataProperty.waterfrontYN) &&
        Objects.equals(this.windowFeatures, orgResoMetadataProperty.windowFeatures) &&
        Objects.equals(this.withdrawnDate, orgResoMetadataProperty.withdrawnDate) &&
        Objects.equals(this.woodedArea, orgResoMetadataProperty.woodedArea) &&
        Objects.equals(this.workmansCompensationExpense, orgResoMetadataProperty.workmansCompensationExpense) &&
        Objects.equals(this.yearBuilt, orgResoMetadataProperty.yearBuilt) &&
        Objects.equals(this.yearBuiltDetails, orgResoMetadataProperty.yearBuiltDetails) &&
        Objects.equals(this.yearBuiltEffective, orgResoMetadataProperty.yearBuiltEffective) &&
        Objects.equals(this.yearBuiltSource, orgResoMetadataProperty.yearBuiltSource) &&
        Objects.equals(this.yearEstablished, orgResoMetadataProperty.yearEstablished) &&
        Objects.equals(this.yearsCurrentOwner, orgResoMetadataProperty.yearsCurrentOwner) &&
        Objects.equals(this.zoning, orgResoMetadataProperty.zoning) &&
        Objects.equals(this.zoningDescription, orgResoMetadataProperty.zoningDescription) &&
        Objects.equals(this.originatingSystem, orgResoMetadataProperty.originatingSystem) &&
        Objects.equals(this.buyerAgent, orgResoMetadataProperty.buyerAgent) &&
        Objects.equals(this.buyerOffice, orgResoMetadataProperty.buyerOffice) &&
        Objects.equals(this.coBuyerAgent, orgResoMetadataProperty.coBuyerAgent) &&
        Objects.equals(this.coBuyerOffice, orgResoMetadataProperty.coBuyerOffice) &&
        Objects.equals(this.coListAgent, orgResoMetadataProperty.coListAgent) &&
        Objects.equals(this.coListOffice, orgResoMetadataProperty.coListOffice) &&
        Objects.equals(this.listAgent, orgResoMetadataProperty.listAgent) &&
        Objects.equals(this.listOffice, orgResoMetadataProperty.listOffice) &&
        Objects.equals(this.buyerTeam, orgResoMetadataProperty.buyerTeam) &&
        Objects.equals(this.listTeam, orgResoMetadataProperty.listTeam) &&
        Objects.equals(this.sourceSystem, orgResoMetadataProperty.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataProperty.historyTransactional) &&
        Objects.equals(this.historyTransactionalAtOdataCount, orgResoMetadataProperty.historyTransactionalAtOdataCount) &&
        Objects.equals(this.media, orgResoMetadataProperty.media) &&
        Objects.equals(this.mediaAtOdataCount, orgResoMetadataProperty.mediaAtOdataCount) &&
        Objects.equals(this.socialMedia, orgResoMetadataProperty.socialMedia) &&
        Objects.equals(this.socialMediaAtOdataCount, orgResoMetadataProperty.socialMediaAtOdataCount) &&
        Objects.equals(this.openHouse, orgResoMetadataProperty.openHouse) &&
        Objects.equals(this.openHouseAtOdataCount, orgResoMetadataProperty.openHouseAtOdataCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(aboveGradeFinishedArea, aboveGradeFinishedAreaSource, aboveGradeFinishedAreaUnits, accessCode, accessibilityFeatures, additionalParcelsDescription, additionalParcelsYN, anchorsCoTenants, appliances, architecturalStyle, associationAmenities, associationFee, associationFee2, associationFee2Frequency, associationFeeFrequency, associationFeeIncludes, associationName, associationName2, associationPhone, associationPhone2, associationYN, attachedGarageYN, availabilityDate, basement, basementYN, bathroomsFull, bathroomsHalf, bathroomsOneQuarter, bathroomsPartial, bathroomsThreeQuarter, bathroomsTotalInteger, bedroomsPossible, bedroomsTotal, belowGradeFinishedArea, belowGradeFinishedAreaSource, belowGradeFinishedAreaUnits, bodyType, builderModel, builderName, buildingAreaSource, buildingAreaTotal, buildingAreaUnits, buildingFeatures, buildingName, businessName, businessType, buyerAgencyCompensation, buyerAgencyCompensationType, buyerAgentAOR, buyerAgentDesignation, buyerAgentDirectPhone, buyerAgentEmail, buyerAgentFax, buyerAgentFirstName, buyerAgentFullName, buyerAgentHomePhone, buyerAgentKey, buyerAgentKeyNumeric, buyerAgentLastName, buyerAgentMiddleName, buyerAgentMlsId, buyerAgentMobilePhone, buyerAgentNamePrefix, buyerAgentNameSuffix, buyerAgentOfficePhone, buyerAgentOfficePhoneExt, buyerAgentPager, buyerAgentPreferredPhone, buyerAgentPreferredPhoneExt, buyerAgentStateLicense, buyerAgentTollFreePhone, buyerAgentURL, buyerAgentVoiceMail, buyerAgentVoiceMailExt, buyerFinancing, buyerOfficeAOR, buyerOfficeEmail, buyerOfficeFax, buyerOfficeKey, buyerOfficeKeyNumeric, buyerOfficeMlsId, buyerOfficeName, buyerOfficePhone, buyerOfficePhoneExt, buyerOfficeURL, buyerTeamKey, buyerTeamKeyNumeric, buyerTeamName, cableTvExpense, cancellationDate, capRate, carportSpaces, carportYN, carrierRoute, city, cityRegion, closeDate, closePrice, coBuyerAgentAOR, coBuyerAgentDesignation, coBuyerAgentDirectPhone, coBuyerAgentEmail, coBuyerAgentFax, coBuyerAgentFirstName, coBuyerAgentFullName, coBuyerAgentHomePhone, coBuyerAgentKey, coBuyerAgentKeyNumeric, coBuyerAgentLastName, coBuyerAgentMiddleName, coBuyerAgentMlsId, coBuyerAgentMobilePhone, coBuyerAgentNamePrefix, coBuyerAgentNameSuffix, coBuyerAgentOfficePhone, coBuyerAgentOfficePhoneExt, coBuyerAgentPager, coBuyerAgentPreferredPhone, coBuyerAgentPreferredPhoneExt, coBuyerAgentStateLicense, coBuyerAgentTollFreePhone, coBuyerAgentURL, coBuyerAgentVoiceMail, coBuyerAgentVoiceMailExt, coBuyerOfficeAOR, coBuyerOfficeEmail, coBuyerOfficeFax, coBuyerOfficeKey, coBuyerOfficeKeyNumeric, coBuyerOfficeMlsId, coBuyerOfficeName, coBuyerOfficePhone, coBuyerOfficePhoneExt, coBuyerOfficeURL, coListAgentAOR, coListAgentDesignation, coListAgentDirectPhone, coListAgentEmail, coListAgentFax, coListAgentFirstName, coListAgentFullName, coListAgentHomePhone, coListAgentKey, coListAgentKeyNumeric, coListAgentLastName, coListAgentMiddleName, coListAgentMlsId, coListAgentMobilePhone, coListAgentNamePrefix, coListAgentNameSuffix, coListAgentOfficePhone, coListAgentOfficePhoneExt, coListAgentPager, coListAgentPreferredPhone, coListAgentPreferredPhoneExt, coListAgentStateLicense, coListAgentTollFreePhone, coListAgentURL, coListAgentVoiceMail, coListAgentVoiceMailExt, coListOfficeAOR, coListOfficeEmail, coListOfficeFax, coListOfficeKey, coListOfficeKeyNumeric, coListOfficeMlsId, coListOfficeName, coListOfficePhone, coListOfficePhoneExt, coListOfficeURL, commonInterest, commonWalls, communityFeatures, concessions, concessionsAmount, concessionsComments, constructionMaterials, continentRegion, contingency, contingentDate, contractStatusChangeDate, cooling, coolingYN, copyrightNotice, country, countryRegion, countyOrParish, coveredSpaces, cropsIncludedYN, crossStreet, cultivatedArea, cumulativeDaysOnMarket, currentFinancing, currentUse, doH1, doH2, doH3, daysOnMarket, developmentStatus, directionFaces, directions, disclaimer, disclosures, distanceToBusComments, distanceToBusNumeric, distanceToBusUnits, distanceToElectricComments, distanceToElectricNumeric, distanceToElectricUnits, distanceToFreewayComments, distanceToFreewayNumeric, distanceToFreewayUnits, distanceToGasComments, distanceToGasNumeric, distanceToGasUnits, distanceToPhoneServiceComments, distanceToPhoneServiceNumeric, distanceToPhoneServiceUnits, distanceToPlaceofWorshipComments, distanceToPlaceofWorshipNumeric, distanceToPlaceofWorshipUnits, distanceToSchoolBusComments, distanceToSchoolBusNumeric, distanceToSchoolBusUnits, distanceToSchoolsComments, distanceToSchoolsNumeric, distanceToSchoolsUnits, distanceToSewerComments, distanceToSewerNumeric, distanceToSewerUnits, distanceToShoppingComments, distanceToShoppingNumeric, distanceToShoppingUnits, distanceToStreetComments, distanceToStreetNumeric, distanceToStreetUnits, distanceToWaterComments, distanceToWaterNumeric, distanceToWaterUnits, documentsAvailable, documentsChangeTimestamp, documentsCount, doorFeatures, dualVariableCompensationYN, electric, electricExpense, electricOnPropertyYN, elementarySchool, elementarySchoolDistrict, elevation, elevationUnits, entryLevel, entryLocation, exclusions, existingLeaseType, expirationDate, exteriorFeatures, farmCreditServiceInclYN, farmLandAreaSource, farmLandAreaUnits, fencing, financialDataSource, fireplaceFeatures, fireplaceYN, fireplacesTotal, flooring, foundationArea, foundationDetails, frontageLength, frontageType, fuelExpense, furnished, furnitureReplacementExpense, garageSpaces, garageYN, gardenerExpense, grazingPermitsBlmYN, grazingPermitsForestServiceYN, grazingPermitsPrivateYN, greenBuildingVerificationType, greenEnergyEfficient, greenEnergyGeneration, greenIndoorAirQuality, greenLocation, greenSustainability, greenWaterConservation, grossIncome, grossScheduledIncome, habitableResidenceYN, heating, heatingYN, highSchool, highSchoolDistrict, homeWarrantyYN, horseAmenities, horseYN, hoursDaysOfOperation, hoursDaysOfOperationDescription, inclusions, incomeIncludes, insuranceExpense, interiorFeatures, internetAddressDisplayYN, internetAutomatedValuationDisplayYN, internetConsumerCommentYN, internetEntireListingDisplayYN, irrigationSource, irrigationWaterRightsAcres, irrigationWaterRightsYN, laborInformation, landLeaseAmount, landLeaseAmountFrequency, landLeaseExpirationDate, landLeaseYN, latitude, laundryFeatures, leasableArea, leasableAreaUnits, leaseAmount, leaseAmountFrequency, leaseAssignableYN, leaseConsideredYN, leaseExpiration, leaseRenewalCompensation, leaseRenewalOptionYN, leaseTerm, levels, license1, license2, license3, licensesExpense, listAOR, listAgentAOR, listAgentDesignation, listAgentDirectPhone, listAgentEmail, listAgentFax, listAgentFirstName, listAgentFullName, listAgentHomePhone, listAgentKey, listAgentKeyNumeric, listAgentLastName, listAgentMiddleName, listAgentMlsId, listAgentMobilePhone, listAgentNamePrefix, listAgentNameSuffix, listAgentOfficePhone, listAgentOfficePhoneExt, listAgentPager, listAgentPreferredPhone, listAgentPreferredPhoneExt, listAgentStateLicense, listAgentTollFreePhone, listAgentURL, listAgentVoiceMail, listAgentVoiceMailExt, listOfficeAOR, listOfficeEmail, listOfficeFax, listOfficeKey, listOfficeKeyNumeric, listOfficeMlsId, listOfficeName, listOfficePhone, listOfficePhoneExt, listOfficeURL, listPrice, listPriceLow, listTeamKey, listTeamKeyNumeric, listTeamName, listingAgreement, listingContractDate, listingId, listingKey, listingKeyNumeric, listingService, listingTerms, livingArea, livingAreaSource, livingAreaUnits, lockBoxLocation, lockBoxSerialNumber, lockBoxType, longitude, lotDimensionsSource, lotFeatures, lotSizeAcres, lotSizeArea, lotSizeDimensions, lotSizeSource, lotSizeSquareFeet, lotSizeUnits, mlSAreaMajor, mlSAreaMinor, mainLevelBathrooms, mainLevelBedrooms, maintenanceExpense, majorChangeTimestamp, majorChangeType, make, managerExpense, mapCoordinate, mapCoordinateSource, mapURL, middleOrJuniorSchool, middleOrJuniorSchoolDistrict, mlsStatus, mobileDimUnits, mobileHomeRemainsYN, mobileLength, mobileWidth, model, modificationTimestamp, netOperatingIncome, newConstructionYN, newTaxesExpense, numberOfBuildings, numberOfFullTimeEmployees, numberOfLots, numberOfPads, numberOfPartTimeEmployees, numberOfSeparateElectricMeters, numberOfSeparateGasMeters, numberOfSeparateWaterMeters, numberOfUnitsInCommunity, numberOfUnitsLeased, numberOfUnitsMoMo, numberOfUnitsTotal, numberOfUnitsVacant, occupantName, occupantPhone, occupantType, offMarketDate, offMarketTimestamp, onMarketDate, onMarketTimestamp, openParkingSpaces, openParkingYN, operatingExpense, operatingExpenseIncludes, originalEntryTimestamp, originalListPrice, originatingSystemID, originatingSystemKey, originatingSystemName, otherEquipment, otherExpense, otherParking, otherStructures, ownerName, ownerPays, ownerPhone, ownership, ownershipType, parcelNumber, parkManagerName, parkManagerPhone, parkName, parkingFeatures, parkingTotal, pastureArea, patioAndPorchFeatures, pendingTimestamp, pestControlExpense, petsAllowed, photosChangeTimestamp, photosCount, poolExpense, poolFeatures, poolPrivateYN, possession, possibleUse, postalCity, postalCode, postalCodePlus4, powerProductionType, previousListPrice, priceChangeTimestamp, privateOfficeRemarks, privateRemarks, professionalManagementExpense, propertyAttachedYN, propertyCondition, propertySubType, propertyType, publicRemarks, publicSurveyRange, publicSurveySection, publicSurveyTownship, purchaseContractDate, rvParkingDimensions, rangeArea, rentControlYN, rentIncludes, roadFrontageType, roadResponsibility, roadSurfaceType, roof, roomType, roomsTotal, seatingCapacity, securityFeatures, seniorCommunityYN, serialU, serialX, serialXX, sewer, showingAdvanceNotice, showingAttendedYN, showingContactName, showingContactPhone, showingContactPhoneExt, showingContactType, showingDays, showingEndTime, showingInstructions, showingRequirements, showingStartTime, signOnPropertyYN, skirt, sourceSystemID, sourceSystemKey, sourceSystemName, spaFeatures, spaYN, specialLicenses, specialListingConditions, standardStatus, stateOrProvince, stateRegion, statusChangeTimestamp, stories, storiesTotal, streetAdditionalInfo, streetDirPrefix, streetDirSuffix, streetName, streetNumber, streetNumberNumeric, streetSuffix, streetSuffixModifier, structureType, subAgencyCompensation, subAgencyCompensationType, subdivisionName, suppliesExpense, syndicateTo, syndicationRemarks, taxAnnualAmount, taxAssessedValue, taxBlock, taxBookNumber, taxLegalDescription, taxLot, taxMapNumber, taxOtherAnnualAssessmentAmount, taxParcelLetter, taxStatusCurrent, taxTract, taxYear, tenantPays, topography, totalActualRent, township, transactionBrokerCompensation, transactionBrokerCompensationType, trashExpense, unitNumber, unitTypeType, unitsFurnished, universalPropertyId, universalPropertySubId, unparsedAddress, utilities, vacancyAllowance, vacancyAllowanceRate, vegetation, videosChangeTimestamp, videosCount, view, viewYN, virtualTourURLBranded, virtualTourURLUnbranded, walkScore, waterBodyName, waterSewerExpense, waterSource, waterfrontFeatures, waterfrontYN, windowFeatures, withdrawnDate, woodedArea, workmansCompensationExpense, yearBuilt, yearBuiltDetails, yearBuiltEffective, yearBuiltSource, yearEstablished, yearsCurrentOwner, zoning, zoningDescription, originatingSystem, buyerAgent, buyerOffice, coBuyerAgent, coBuyerOffice, coListAgent, coListOffice, listAgent, listOffice, buyerTeam, listTeam, sourceSystem, historyTransactional, historyTransactionalAtOdataCount, media, mediaAtOdataCount, socialMedia, socialMediaAtOdataCount, openHouse, openHouseAtOdataCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataProperty {\n");
    
    sb.append("    aboveGradeFinishedArea: ").append(toIndentedString(aboveGradeFinishedArea)).append("\n");
    sb.append("    aboveGradeFinishedAreaSource: ").append(toIndentedString(aboveGradeFinishedAreaSource)).append("\n");
    sb.append("    aboveGradeFinishedAreaUnits: ").append(toIndentedString(aboveGradeFinishedAreaUnits)).append("\n");
    sb.append("    accessCode: ").append(toIndentedString(accessCode)).append("\n");
    sb.append("    accessibilityFeatures: ").append(toIndentedString(accessibilityFeatures)).append("\n");
    sb.append("    additionalParcelsDescription: ").append(toIndentedString(additionalParcelsDescription)).append("\n");
    sb.append("    additionalParcelsYN: ").append(toIndentedString(additionalParcelsYN)).append("\n");
    sb.append("    anchorsCoTenants: ").append(toIndentedString(anchorsCoTenants)).append("\n");
    sb.append("    appliances: ").append(toIndentedString(appliances)).append("\n");
    sb.append("    architecturalStyle: ").append(toIndentedString(architecturalStyle)).append("\n");
    sb.append("    associationAmenities: ").append(toIndentedString(associationAmenities)).append("\n");
    sb.append("    associationFee: ").append(toIndentedString(associationFee)).append("\n");
    sb.append("    associationFee2: ").append(toIndentedString(associationFee2)).append("\n");
    sb.append("    associationFee2Frequency: ").append(toIndentedString(associationFee2Frequency)).append("\n");
    sb.append("    associationFeeFrequency: ").append(toIndentedString(associationFeeFrequency)).append("\n");
    sb.append("    associationFeeIncludes: ").append(toIndentedString(associationFeeIncludes)).append("\n");
    sb.append("    associationName: ").append(toIndentedString(associationName)).append("\n");
    sb.append("    associationName2: ").append(toIndentedString(associationName2)).append("\n");
    sb.append("    associationPhone: ").append(toIndentedString(associationPhone)).append("\n");
    sb.append("    associationPhone2: ").append(toIndentedString(associationPhone2)).append("\n");
    sb.append("    associationYN: ").append(toIndentedString(associationYN)).append("\n");
    sb.append("    attachedGarageYN: ").append(toIndentedString(attachedGarageYN)).append("\n");
    sb.append("    availabilityDate: ").append(toIndentedString(availabilityDate)).append("\n");
    sb.append("    basement: ").append(toIndentedString(basement)).append("\n");
    sb.append("    basementYN: ").append(toIndentedString(basementYN)).append("\n");
    sb.append("    bathroomsFull: ").append(toIndentedString(bathroomsFull)).append("\n");
    sb.append("    bathroomsHalf: ").append(toIndentedString(bathroomsHalf)).append("\n");
    sb.append("    bathroomsOneQuarter: ").append(toIndentedString(bathroomsOneQuarter)).append("\n");
    sb.append("    bathroomsPartial: ").append(toIndentedString(bathroomsPartial)).append("\n");
    sb.append("    bathroomsThreeQuarter: ").append(toIndentedString(bathroomsThreeQuarter)).append("\n");
    sb.append("    bathroomsTotalInteger: ").append(toIndentedString(bathroomsTotalInteger)).append("\n");
    sb.append("    bedroomsPossible: ").append(toIndentedString(bedroomsPossible)).append("\n");
    sb.append("    bedroomsTotal: ").append(toIndentedString(bedroomsTotal)).append("\n");
    sb.append("    belowGradeFinishedArea: ").append(toIndentedString(belowGradeFinishedArea)).append("\n");
    sb.append("    belowGradeFinishedAreaSource: ").append(toIndentedString(belowGradeFinishedAreaSource)).append("\n");
    sb.append("    belowGradeFinishedAreaUnits: ").append(toIndentedString(belowGradeFinishedAreaUnits)).append("\n");
    sb.append("    bodyType: ").append(toIndentedString(bodyType)).append("\n");
    sb.append("    builderModel: ").append(toIndentedString(builderModel)).append("\n");
    sb.append("    builderName: ").append(toIndentedString(builderName)).append("\n");
    sb.append("    buildingAreaSource: ").append(toIndentedString(buildingAreaSource)).append("\n");
    sb.append("    buildingAreaTotal: ").append(toIndentedString(buildingAreaTotal)).append("\n");
    sb.append("    buildingAreaUnits: ").append(toIndentedString(buildingAreaUnits)).append("\n");
    sb.append("    buildingFeatures: ").append(toIndentedString(buildingFeatures)).append("\n");
    sb.append("    buildingName: ").append(toIndentedString(buildingName)).append("\n");
    sb.append("    businessName: ").append(toIndentedString(businessName)).append("\n");
    sb.append("    businessType: ").append(toIndentedString(businessType)).append("\n");
    sb.append("    buyerAgencyCompensation: ").append(toIndentedString(buyerAgencyCompensation)).append("\n");
    sb.append("    buyerAgencyCompensationType: ").append(toIndentedString(buyerAgencyCompensationType)).append("\n");
    sb.append("    buyerAgentAOR: ").append(toIndentedString(buyerAgentAOR)).append("\n");
    sb.append("    buyerAgentDesignation: ").append(toIndentedString(buyerAgentDesignation)).append("\n");
    sb.append("    buyerAgentDirectPhone: ").append(toIndentedString(buyerAgentDirectPhone)).append("\n");
    sb.append("    buyerAgentEmail: ").append(toIndentedString(buyerAgentEmail)).append("\n");
    sb.append("    buyerAgentFax: ").append(toIndentedString(buyerAgentFax)).append("\n");
    sb.append("    buyerAgentFirstName: ").append(toIndentedString(buyerAgentFirstName)).append("\n");
    sb.append("    buyerAgentFullName: ").append(toIndentedString(buyerAgentFullName)).append("\n");
    sb.append("    buyerAgentHomePhone: ").append(toIndentedString(buyerAgentHomePhone)).append("\n");
    sb.append("    buyerAgentKey: ").append(toIndentedString(buyerAgentKey)).append("\n");
    sb.append("    buyerAgentKeyNumeric: ").append(toIndentedString(buyerAgentKeyNumeric)).append("\n");
    sb.append("    buyerAgentLastName: ").append(toIndentedString(buyerAgentLastName)).append("\n");
    sb.append("    buyerAgentMiddleName: ").append(toIndentedString(buyerAgentMiddleName)).append("\n");
    sb.append("    buyerAgentMlsId: ").append(toIndentedString(buyerAgentMlsId)).append("\n");
    sb.append("    buyerAgentMobilePhone: ").append(toIndentedString(buyerAgentMobilePhone)).append("\n");
    sb.append("    buyerAgentNamePrefix: ").append(toIndentedString(buyerAgentNamePrefix)).append("\n");
    sb.append("    buyerAgentNameSuffix: ").append(toIndentedString(buyerAgentNameSuffix)).append("\n");
    sb.append("    buyerAgentOfficePhone: ").append(toIndentedString(buyerAgentOfficePhone)).append("\n");
    sb.append("    buyerAgentOfficePhoneExt: ").append(toIndentedString(buyerAgentOfficePhoneExt)).append("\n");
    sb.append("    buyerAgentPager: ").append(toIndentedString(buyerAgentPager)).append("\n");
    sb.append("    buyerAgentPreferredPhone: ").append(toIndentedString(buyerAgentPreferredPhone)).append("\n");
    sb.append("    buyerAgentPreferredPhoneExt: ").append(toIndentedString(buyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    buyerAgentStateLicense: ").append(toIndentedString(buyerAgentStateLicense)).append("\n");
    sb.append("    buyerAgentTollFreePhone: ").append(toIndentedString(buyerAgentTollFreePhone)).append("\n");
    sb.append("    buyerAgentURL: ").append(toIndentedString(buyerAgentURL)).append("\n");
    sb.append("    buyerAgentVoiceMail: ").append(toIndentedString(buyerAgentVoiceMail)).append("\n");
    sb.append("    buyerAgentVoiceMailExt: ").append(toIndentedString(buyerAgentVoiceMailExt)).append("\n");
    sb.append("    buyerFinancing: ").append(toIndentedString(buyerFinancing)).append("\n");
    sb.append("    buyerOfficeAOR: ").append(toIndentedString(buyerOfficeAOR)).append("\n");
    sb.append("    buyerOfficeEmail: ").append(toIndentedString(buyerOfficeEmail)).append("\n");
    sb.append("    buyerOfficeFax: ").append(toIndentedString(buyerOfficeFax)).append("\n");
    sb.append("    buyerOfficeKey: ").append(toIndentedString(buyerOfficeKey)).append("\n");
    sb.append("    buyerOfficeKeyNumeric: ").append(toIndentedString(buyerOfficeKeyNumeric)).append("\n");
    sb.append("    buyerOfficeMlsId: ").append(toIndentedString(buyerOfficeMlsId)).append("\n");
    sb.append("    buyerOfficeName: ").append(toIndentedString(buyerOfficeName)).append("\n");
    sb.append("    buyerOfficePhone: ").append(toIndentedString(buyerOfficePhone)).append("\n");
    sb.append("    buyerOfficePhoneExt: ").append(toIndentedString(buyerOfficePhoneExt)).append("\n");
    sb.append("    buyerOfficeURL: ").append(toIndentedString(buyerOfficeURL)).append("\n");
    sb.append("    buyerTeamKey: ").append(toIndentedString(buyerTeamKey)).append("\n");
    sb.append("    buyerTeamKeyNumeric: ").append(toIndentedString(buyerTeamKeyNumeric)).append("\n");
    sb.append("    buyerTeamName: ").append(toIndentedString(buyerTeamName)).append("\n");
    sb.append("    cableTvExpense: ").append(toIndentedString(cableTvExpense)).append("\n");
    sb.append("    cancellationDate: ").append(toIndentedString(cancellationDate)).append("\n");
    sb.append("    capRate: ").append(toIndentedString(capRate)).append("\n");
    sb.append("    carportSpaces: ").append(toIndentedString(carportSpaces)).append("\n");
    sb.append("    carportYN: ").append(toIndentedString(carportYN)).append("\n");
    sb.append("    carrierRoute: ").append(toIndentedString(carrierRoute)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    cityRegion: ").append(toIndentedString(cityRegion)).append("\n");
    sb.append("    closeDate: ").append(toIndentedString(closeDate)).append("\n");
    sb.append("    closePrice: ").append(toIndentedString(closePrice)).append("\n");
    sb.append("    coBuyerAgentAOR: ").append(toIndentedString(coBuyerAgentAOR)).append("\n");
    sb.append("    coBuyerAgentDesignation: ").append(toIndentedString(coBuyerAgentDesignation)).append("\n");
    sb.append("    coBuyerAgentDirectPhone: ").append(toIndentedString(coBuyerAgentDirectPhone)).append("\n");
    sb.append("    coBuyerAgentEmail: ").append(toIndentedString(coBuyerAgentEmail)).append("\n");
    sb.append("    coBuyerAgentFax: ").append(toIndentedString(coBuyerAgentFax)).append("\n");
    sb.append("    coBuyerAgentFirstName: ").append(toIndentedString(coBuyerAgentFirstName)).append("\n");
    sb.append("    coBuyerAgentFullName: ").append(toIndentedString(coBuyerAgentFullName)).append("\n");
    sb.append("    coBuyerAgentHomePhone: ").append(toIndentedString(coBuyerAgentHomePhone)).append("\n");
    sb.append("    coBuyerAgentKey: ").append(toIndentedString(coBuyerAgentKey)).append("\n");
    sb.append("    coBuyerAgentKeyNumeric: ").append(toIndentedString(coBuyerAgentKeyNumeric)).append("\n");
    sb.append("    coBuyerAgentLastName: ").append(toIndentedString(coBuyerAgentLastName)).append("\n");
    sb.append("    coBuyerAgentMiddleName: ").append(toIndentedString(coBuyerAgentMiddleName)).append("\n");
    sb.append("    coBuyerAgentMlsId: ").append(toIndentedString(coBuyerAgentMlsId)).append("\n");
    sb.append("    coBuyerAgentMobilePhone: ").append(toIndentedString(coBuyerAgentMobilePhone)).append("\n");
    sb.append("    coBuyerAgentNamePrefix: ").append(toIndentedString(coBuyerAgentNamePrefix)).append("\n");
    sb.append("    coBuyerAgentNameSuffix: ").append(toIndentedString(coBuyerAgentNameSuffix)).append("\n");
    sb.append("    coBuyerAgentOfficePhone: ").append(toIndentedString(coBuyerAgentOfficePhone)).append("\n");
    sb.append("    coBuyerAgentOfficePhoneExt: ").append(toIndentedString(coBuyerAgentOfficePhoneExt)).append("\n");
    sb.append("    coBuyerAgentPager: ").append(toIndentedString(coBuyerAgentPager)).append("\n");
    sb.append("    coBuyerAgentPreferredPhone: ").append(toIndentedString(coBuyerAgentPreferredPhone)).append("\n");
    sb.append("    coBuyerAgentPreferredPhoneExt: ").append(toIndentedString(coBuyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    coBuyerAgentStateLicense: ").append(toIndentedString(coBuyerAgentStateLicense)).append("\n");
    sb.append("    coBuyerAgentTollFreePhone: ").append(toIndentedString(coBuyerAgentTollFreePhone)).append("\n");
    sb.append("    coBuyerAgentURL: ").append(toIndentedString(coBuyerAgentURL)).append("\n");
    sb.append("    coBuyerAgentVoiceMail: ").append(toIndentedString(coBuyerAgentVoiceMail)).append("\n");
    sb.append("    coBuyerAgentVoiceMailExt: ").append(toIndentedString(coBuyerAgentVoiceMailExt)).append("\n");
    sb.append("    coBuyerOfficeAOR: ").append(toIndentedString(coBuyerOfficeAOR)).append("\n");
    sb.append("    coBuyerOfficeEmail: ").append(toIndentedString(coBuyerOfficeEmail)).append("\n");
    sb.append("    coBuyerOfficeFax: ").append(toIndentedString(coBuyerOfficeFax)).append("\n");
    sb.append("    coBuyerOfficeKey: ").append(toIndentedString(coBuyerOfficeKey)).append("\n");
    sb.append("    coBuyerOfficeKeyNumeric: ").append(toIndentedString(coBuyerOfficeKeyNumeric)).append("\n");
    sb.append("    coBuyerOfficeMlsId: ").append(toIndentedString(coBuyerOfficeMlsId)).append("\n");
    sb.append("    coBuyerOfficeName: ").append(toIndentedString(coBuyerOfficeName)).append("\n");
    sb.append("    coBuyerOfficePhone: ").append(toIndentedString(coBuyerOfficePhone)).append("\n");
    sb.append("    coBuyerOfficePhoneExt: ").append(toIndentedString(coBuyerOfficePhoneExt)).append("\n");
    sb.append("    coBuyerOfficeURL: ").append(toIndentedString(coBuyerOfficeURL)).append("\n");
    sb.append("    coListAgentAOR: ").append(toIndentedString(coListAgentAOR)).append("\n");
    sb.append("    coListAgentDesignation: ").append(toIndentedString(coListAgentDesignation)).append("\n");
    sb.append("    coListAgentDirectPhone: ").append(toIndentedString(coListAgentDirectPhone)).append("\n");
    sb.append("    coListAgentEmail: ").append(toIndentedString(coListAgentEmail)).append("\n");
    sb.append("    coListAgentFax: ").append(toIndentedString(coListAgentFax)).append("\n");
    sb.append("    coListAgentFirstName: ").append(toIndentedString(coListAgentFirstName)).append("\n");
    sb.append("    coListAgentFullName: ").append(toIndentedString(coListAgentFullName)).append("\n");
    sb.append("    coListAgentHomePhone: ").append(toIndentedString(coListAgentHomePhone)).append("\n");
    sb.append("    coListAgentKey: ").append(toIndentedString(coListAgentKey)).append("\n");
    sb.append("    coListAgentKeyNumeric: ").append(toIndentedString(coListAgentKeyNumeric)).append("\n");
    sb.append("    coListAgentLastName: ").append(toIndentedString(coListAgentLastName)).append("\n");
    sb.append("    coListAgentMiddleName: ").append(toIndentedString(coListAgentMiddleName)).append("\n");
    sb.append("    coListAgentMlsId: ").append(toIndentedString(coListAgentMlsId)).append("\n");
    sb.append("    coListAgentMobilePhone: ").append(toIndentedString(coListAgentMobilePhone)).append("\n");
    sb.append("    coListAgentNamePrefix: ").append(toIndentedString(coListAgentNamePrefix)).append("\n");
    sb.append("    coListAgentNameSuffix: ").append(toIndentedString(coListAgentNameSuffix)).append("\n");
    sb.append("    coListAgentOfficePhone: ").append(toIndentedString(coListAgentOfficePhone)).append("\n");
    sb.append("    coListAgentOfficePhoneExt: ").append(toIndentedString(coListAgentOfficePhoneExt)).append("\n");
    sb.append("    coListAgentPager: ").append(toIndentedString(coListAgentPager)).append("\n");
    sb.append("    coListAgentPreferredPhone: ").append(toIndentedString(coListAgentPreferredPhone)).append("\n");
    sb.append("    coListAgentPreferredPhoneExt: ").append(toIndentedString(coListAgentPreferredPhoneExt)).append("\n");
    sb.append("    coListAgentStateLicense: ").append(toIndentedString(coListAgentStateLicense)).append("\n");
    sb.append("    coListAgentTollFreePhone: ").append(toIndentedString(coListAgentTollFreePhone)).append("\n");
    sb.append("    coListAgentURL: ").append(toIndentedString(coListAgentURL)).append("\n");
    sb.append("    coListAgentVoiceMail: ").append(toIndentedString(coListAgentVoiceMail)).append("\n");
    sb.append("    coListAgentVoiceMailExt: ").append(toIndentedString(coListAgentVoiceMailExt)).append("\n");
    sb.append("    coListOfficeAOR: ").append(toIndentedString(coListOfficeAOR)).append("\n");
    sb.append("    coListOfficeEmail: ").append(toIndentedString(coListOfficeEmail)).append("\n");
    sb.append("    coListOfficeFax: ").append(toIndentedString(coListOfficeFax)).append("\n");
    sb.append("    coListOfficeKey: ").append(toIndentedString(coListOfficeKey)).append("\n");
    sb.append("    coListOfficeKeyNumeric: ").append(toIndentedString(coListOfficeKeyNumeric)).append("\n");
    sb.append("    coListOfficeMlsId: ").append(toIndentedString(coListOfficeMlsId)).append("\n");
    sb.append("    coListOfficeName: ").append(toIndentedString(coListOfficeName)).append("\n");
    sb.append("    coListOfficePhone: ").append(toIndentedString(coListOfficePhone)).append("\n");
    sb.append("    coListOfficePhoneExt: ").append(toIndentedString(coListOfficePhoneExt)).append("\n");
    sb.append("    coListOfficeURL: ").append(toIndentedString(coListOfficeURL)).append("\n");
    sb.append("    commonInterest: ").append(toIndentedString(commonInterest)).append("\n");
    sb.append("    commonWalls: ").append(toIndentedString(commonWalls)).append("\n");
    sb.append("    communityFeatures: ").append(toIndentedString(communityFeatures)).append("\n");
    sb.append("    concessions: ").append(toIndentedString(concessions)).append("\n");
    sb.append("    concessionsAmount: ").append(toIndentedString(concessionsAmount)).append("\n");
    sb.append("    concessionsComments: ").append(toIndentedString(concessionsComments)).append("\n");
    sb.append("    constructionMaterials: ").append(toIndentedString(constructionMaterials)).append("\n");
    sb.append("    continentRegion: ").append(toIndentedString(continentRegion)).append("\n");
    sb.append("    contingency: ").append(toIndentedString(contingency)).append("\n");
    sb.append("    contingentDate: ").append(toIndentedString(contingentDate)).append("\n");
    sb.append("    contractStatusChangeDate: ").append(toIndentedString(contractStatusChangeDate)).append("\n");
    sb.append("    cooling: ").append(toIndentedString(cooling)).append("\n");
    sb.append("    coolingYN: ").append(toIndentedString(coolingYN)).append("\n");
    sb.append("    copyrightNotice: ").append(toIndentedString(copyrightNotice)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    countryRegion: ").append(toIndentedString(countryRegion)).append("\n");
    sb.append("    countyOrParish: ").append(toIndentedString(countyOrParish)).append("\n");
    sb.append("    coveredSpaces: ").append(toIndentedString(coveredSpaces)).append("\n");
    sb.append("    cropsIncludedYN: ").append(toIndentedString(cropsIncludedYN)).append("\n");
    sb.append("    crossStreet: ").append(toIndentedString(crossStreet)).append("\n");
    sb.append("    cultivatedArea: ").append(toIndentedString(cultivatedArea)).append("\n");
    sb.append("    cumulativeDaysOnMarket: ").append(toIndentedString(cumulativeDaysOnMarket)).append("\n");
    sb.append("    currentFinancing: ").append(toIndentedString(currentFinancing)).append("\n");
    sb.append("    currentUse: ").append(toIndentedString(currentUse)).append("\n");
    sb.append("    doH1: ").append(toIndentedString(doH1)).append("\n");
    sb.append("    doH2: ").append(toIndentedString(doH2)).append("\n");
    sb.append("    doH3: ").append(toIndentedString(doH3)).append("\n");
    sb.append("    daysOnMarket: ").append(toIndentedString(daysOnMarket)).append("\n");
    sb.append("    developmentStatus: ").append(toIndentedString(developmentStatus)).append("\n");
    sb.append("    directionFaces: ").append(toIndentedString(directionFaces)).append("\n");
    sb.append("    directions: ").append(toIndentedString(directions)).append("\n");
    sb.append("    disclaimer: ").append(toIndentedString(disclaimer)).append("\n");
    sb.append("    disclosures: ").append(toIndentedString(disclosures)).append("\n");
    sb.append("    distanceToBusComments: ").append(toIndentedString(distanceToBusComments)).append("\n");
    sb.append("    distanceToBusNumeric: ").append(toIndentedString(distanceToBusNumeric)).append("\n");
    sb.append("    distanceToBusUnits: ").append(toIndentedString(distanceToBusUnits)).append("\n");
    sb.append("    distanceToElectricComments: ").append(toIndentedString(distanceToElectricComments)).append("\n");
    sb.append("    distanceToElectricNumeric: ").append(toIndentedString(distanceToElectricNumeric)).append("\n");
    sb.append("    distanceToElectricUnits: ").append(toIndentedString(distanceToElectricUnits)).append("\n");
    sb.append("    distanceToFreewayComments: ").append(toIndentedString(distanceToFreewayComments)).append("\n");
    sb.append("    distanceToFreewayNumeric: ").append(toIndentedString(distanceToFreewayNumeric)).append("\n");
    sb.append("    distanceToFreewayUnits: ").append(toIndentedString(distanceToFreewayUnits)).append("\n");
    sb.append("    distanceToGasComments: ").append(toIndentedString(distanceToGasComments)).append("\n");
    sb.append("    distanceToGasNumeric: ").append(toIndentedString(distanceToGasNumeric)).append("\n");
    sb.append("    distanceToGasUnits: ").append(toIndentedString(distanceToGasUnits)).append("\n");
    sb.append("    distanceToPhoneServiceComments: ").append(toIndentedString(distanceToPhoneServiceComments)).append("\n");
    sb.append("    distanceToPhoneServiceNumeric: ").append(toIndentedString(distanceToPhoneServiceNumeric)).append("\n");
    sb.append("    distanceToPhoneServiceUnits: ").append(toIndentedString(distanceToPhoneServiceUnits)).append("\n");
    sb.append("    distanceToPlaceofWorshipComments: ").append(toIndentedString(distanceToPlaceofWorshipComments)).append("\n");
    sb.append("    distanceToPlaceofWorshipNumeric: ").append(toIndentedString(distanceToPlaceofWorshipNumeric)).append("\n");
    sb.append("    distanceToPlaceofWorshipUnits: ").append(toIndentedString(distanceToPlaceofWorshipUnits)).append("\n");
    sb.append("    distanceToSchoolBusComments: ").append(toIndentedString(distanceToSchoolBusComments)).append("\n");
    sb.append("    distanceToSchoolBusNumeric: ").append(toIndentedString(distanceToSchoolBusNumeric)).append("\n");
    sb.append("    distanceToSchoolBusUnits: ").append(toIndentedString(distanceToSchoolBusUnits)).append("\n");
    sb.append("    distanceToSchoolsComments: ").append(toIndentedString(distanceToSchoolsComments)).append("\n");
    sb.append("    distanceToSchoolsNumeric: ").append(toIndentedString(distanceToSchoolsNumeric)).append("\n");
    sb.append("    distanceToSchoolsUnits: ").append(toIndentedString(distanceToSchoolsUnits)).append("\n");
    sb.append("    distanceToSewerComments: ").append(toIndentedString(distanceToSewerComments)).append("\n");
    sb.append("    distanceToSewerNumeric: ").append(toIndentedString(distanceToSewerNumeric)).append("\n");
    sb.append("    distanceToSewerUnits: ").append(toIndentedString(distanceToSewerUnits)).append("\n");
    sb.append("    distanceToShoppingComments: ").append(toIndentedString(distanceToShoppingComments)).append("\n");
    sb.append("    distanceToShoppingNumeric: ").append(toIndentedString(distanceToShoppingNumeric)).append("\n");
    sb.append("    distanceToShoppingUnits: ").append(toIndentedString(distanceToShoppingUnits)).append("\n");
    sb.append("    distanceToStreetComments: ").append(toIndentedString(distanceToStreetComments)).append("\n");
    sb.append("    distanceToStreetNumeric: ").append(toIndentedString(distanceToStreetNumeric)).append("\n");
    sb.append("    distanceToStreetUnits: ").append(toIndentedString(distanceToStreetUnits)).append("\n");
    sb.append("    distanceToWaterComments: ").append(toIndentedString(distanceToWaterComments)).append("\n");
    sb.append("    distanceToWaterNumeric: ").append(toIndentedString(distanceToWaterNumeric)).append("\n");
    sb.append("    distanceToWaterUnits: ").append(toIndentedString(distanceToWaterUnits)).append("\n");
    sb.append("    documentsAvailable: ").append(toIndentedString(documentsAvailable)).append("\n");
    sb.append("    documentsChangeTimestamp: ").append(toIndentedString(documentsChangeTimestamp)).append("\n");
    sb.append("    documentsCount: ").append(toIndentedString(documentsCount)).append("\n");
    sb.append("    doorFeatures: ").append(toIndentedString(doorFeatures)).append("\n");
    sb.append("    dualVariableCompensationYN: ").append(toIndentedString(dualVariableCompensationYN)).append("\n");
    sb.append("    electric: ").append(toIndentedString(electric)).append("\n");
    sb.append("    electricExpense: ").append(toIndentedString(electricExpense)).append("\n");
    sb.append("    electricOnPropertyYN: ").append(toIndentedString(electricOnPropertyYN)).append("\n");
    sb.append("    elementarySchool: ").append(toIndentedString(elementarySchool)).append("\n");
    sb.append("    elementarySchoolDistrict: ").append(toIndentedString(elementarySchoolDistrict)).append("\n");
    sb.append("    elevation: ").append(toIndentedString(elevation)).append("\n");
    sb.append("    elevationUnits: ").append(toIndentedString(elevationUnits)).append("\n");
    sb.append("    entryLevel: ").append(toIndentedString(entryLevel)).append("\n");
    sb.append("    entryLocation: ").append(toIndentedString(entryLocation)).append("\n");
    sb.append("    exclusions: ").append(toIndentedString(exclusions)).append("\n");
    sb.append("    existingLeaseType: ").append(toIndentedString(existingLeaseType)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    exteriorFeatures: ").append(toIndentedString(exteriorFeatures)).append("\n");
    sb.append("    farmCreditServiceInclYN: ").append(toIndentedString(farmCreditServiceInclYN)).append("\n");
    sb.append("    farmLandAreaSource: ").append(toIndentedString(farmLandAreaSource)).append("\n");
    sb.append("    farmLandAreaUnits: ").append(toIndentedString(farmLandAreaUnits)).append("\n");
    sb.append("    fencing: ").append(toIndentedString(fencing)).append("\n");
    sb.append("    financialDataSource: ").append(toIndentedString(financialDataSource)).append("\n");
    sb.append("    fireplaceFeatures: ").append(toIndentedString(fireplaceFeatures)).append("\n");
    sb.append("    fireplaceYN: ").append(toIndentedString(fireplaceYN)).append("\n");
    sb.append("    fireplacesTotal: ").append(toIndentedString(fireplacesTotal)).append("\n");
    sb.append("    flooring: ").append(toIndentedString(flooring)).append("\n");
    sb.append("    foundationArea: ").append(toIndentedString(foundationArea)).append("\n");
    sb.append("    foundationDetails: ").append(toIndentedString(foundationDetails)).append("\n");
    sb.append("    frontageLength: ").append(toIndentedString(frontageLength)).append("\n");
    sb.append("    frontageType: ").append(toIndentedString(frontageType)).append("\n");
    sb.append("    fuelExpense: ").append(toIndentedString(fuelExpense)).append("\n");
    sb.append("    furnished: ").append(toIndentedString(furnished)).append("\n");
    sb.append("    furnitureReplacementExpense: ").append(toIndentedString(furnitureReplacementExpense)).append("\n");
    sb.append("    garageSpaces: ").append(toIndentedString(garageSpaces)).append("\n");
    sb.append("    garageYN: ").append(toIndentedString(garageYN)).append("\n");
    sb.append("    gardenerExpense: ").append(toIndentedString(gardenerExpense)).append("\n");
    sb.append("    grazingPermitsBlmYN: ").append(toIndentedString(grazingPermitsBlmYN)).append("\n");
    sb.append("    grazingPermitsForestServiceYN: ").append(toIndentedString(grazingPermitsForestServiceYN)).append("\n");
    sb.append("    grazingPermitsPrivateYN: ").append(toIndentedString(grazingPermitsPrivateYN)).append("\n");
    sb.append("    greenBuildingVerificationType: ").append(toIndentedString(greenBuildingVerificationType)).append("\n");
    sb.append("    greenEnergyEfficient: ").append(toIndentedString(greenEnergyEfficient)).append("\n");
    sb.append("    greenEnergyGeneration: ").append(toIndentedString(greenEnergyGeneration)).append("\n");
    sb.append("    greenIndoorAirQuality: ").append(toIndentedString(greenIndoorAirQuality)).append("\n");
    sb.append("    greenLocation: ").append(toIndentedString(greenLocation)).append("\n");
    sb.append("    greenSustainability: ").append(toIndentedString(greenSustainability)).append("\n");
    sb.append("    greenWaterConservation: ").append(toIndentedString(greenWaterConservation)).append("\n");
    sb.append("    grossIncome: ").append(toIndentedString(grossIncome)).append("\n");
    sb.append("    grossScheduledIncome: ").append(toIndentedString(grossScheduledIncome)).append("\n");
    sb.append("    habitableResidenceYN: ").append(toIndentedString(habitableResidenceYN)).append("\n");
    sb.append("    heating: ").append(toIndentedString(heating)).append("\n");
    sb.append("    heatingYN: ").append(toIndentedString(heatingYN)).append("\n");
    sb.append("    highSchool: ").append(toIndentedString(highSchool)).append("\n");
    sb.append("    highSchoolDistrict: ").append(toIndentedString(highSchoolDistrict)).append("\n");
    sb.append("    homeWarrantyYN: ").append(toIndentedString(homeWarrantyYN)).append("\n");
    sb.append("    horseAmenities: ").append(toIndentedString(horseAmenities)).append("\n");
    sb.append("    horseYN: ").append(toIndentedString(horseYN)).append("\n");
    sb.append("    hoursDaysOfOperation: ").append(toIndentedString(hoursDaysOfOperation)).append("\n");
    sb.append("    hoursDaysOfOperationDescription: ").append(toIndentedString(hoursDaysOfOperationDescription)).append("\n");
    sb.append("    inclusions: ").append(toIndentedString(inclusions)).append("\n");
    sb.append("    incomeIncludes: ").append(toIndentedString(incomeIncludes)).append("\n");
    sb.append("    insuranceExpense: ").append(toIndentedString(insuranceExpense)).append("\n");
    sb.append("    interiorFeatures: ").append(toIndentedString(interiorFeatures)).append("\n");
    sb.append("    internetAddressDisplayYN: ").append(toIndentedString(internetAddressDisplayYN)).append("\n");
    sb.append("    internetAutomatedValuationDisplayYN: ").append(toIndentedString(internetAutomatedValuationDisplayYN)).append("\n");
    sb.append("    internetConsumerCommentYN: ").append(toIndentedString(internetConsumerCommentYN)).append("\n");
    sb.append("    internetEntireListingDisplayYN: ").append(toIndentedString(internetEntireListingDisplayYN)).append("\n");
    sb.append("    irrigationSource: ").append(toIndentedString(irrigationSource)).append("\n");
    sb.append("    irrigationWaterRightsAcres: ").append(toIndentedString(irrigationWaterRightsAcres)).append("\n");
    sb.append("    irrigationWaterRightsYN: ").append(toIndentedString(irrigationWaterRightsYN)).append("\n");
    sb.append("    laborInformation: ").append(toIndentedString(laborInformation)).append("\n");
    sb.append("    landLeaseAmount: ").append(toIndentedString(landLeaseAmount)).append("\n");
    sb.append("    landLeaseAmountFrequency: ").append(toIndentedString(landLeaseAmountFrequency)).append("\n");
    sb.append("    landLeaseExpirationDate: ").append(toIndentedString(landLeaseExpirationDate)).append("\n");
    sb.append("    landLeaseYN: ").append(toIndentedString(landLeaseYN)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    laundryFeatures: ").append(toIndentedString(laundryFeatures)).append("\n");
    sb.append("    leasableArea: ").append(toIndentedString(leasableArea)).append("\n");
    sb.append("    leasableAreaUnits: ").append(toIndentedString(leasableAreaUnits)).append("\n");
    sb.append("    leaseAmount: ").append(toIndentedString(leaseAmount)).append("\n");
    sb.append("    leaseAmountFrequency: ").append(toIndentedString(leaseAmountFrequency)).append("\n");
    sb.append("    leaseAssignableYN: ").append(toIndentedString(leaseAssignableYN)).append("\n");
    sb.append("    leaseConsideredYN: ").append(toIndentedString(leaseConsideredYN)).append("\n");
    sb.append("    leaseExpiration: ").append(toIndentedString(leaseExpiration)).append("\n");
    sb.append("    leaseRenewalCompensation: ").append(toIndentedString(leaseRenewalCompensation)).append("\n");
    sb.append("    leaseRenewalOptionYN: ").append(toIndentedString(leaseRenewalOptionYN)).append("\n");
    sb.append("    leaseTerm: ").append(toIndentedString(leaseTerm)).append("\n");
    sb.append("    levels: ").append(toIndentedString(levels)).append("\n");
    sb.append("    license1: ").append(toIndentedString(license1)).append("\n");
    sb.append("    license2: ").append(toIndentedString(license2)).append("\n");
    sb.append("    license3: ").append(toIndentedString(license3)).append("\n");
    sb.append("    licensesExpense: ").append(toIndentedString(licensesExpense)).append("\n");
    sb.append("    listAOR: ").append(toIndentedString(listAOR)).append("\n");
    sb.append("    listAgentAOR: ").append(toIndentedString(listAgentAOR)).append("\n");
    sb.append("    listAgentDesignation: ").append(toIndentedString(listAgentDesignation)).append("\n");
    sb.append("    listAgentDirectPhone: ").append(toIndentedString(listAgentDirectPhone)).append("\n");
    sb.append("    listAgentEmail: ").append(toIndentedString(listAgentEmail)).append("\n");
    sb.append("    listAgentFax: ").append(toIndentedString(listAgentFax)).append("\n");
    sb.append("    listAgentFirstName: ").append(toIndentedString(listAgentFirstName)).append("\n");
    sb.append("    listAgentFullName: ").append(toIndentedString(listAgentFullName)).append("\n");
    sb.append("    listAgentHomePhone: ").append(toIndentedString(listAgentHomePhone)).append("\n");
    sb.append("    listAgentKey: ").append(toIndentedString(listAgentKey)).append("\n");
    sb.append("    listAgentKeyNumeric: ").append(toIndentedString(listAgentKeyNumeric)).append("\n");
    sb.append("    listAgentLastName: ").append(toIndentedString(listAgentLastName)).append("\n");
    sb.append("    listAgentMiddleName: ").append(toIndentedString(listAgentMiddleName)).append("\n");
    sb.append("    listAgentMlsId: ").append(toIndentedString(listAgentMlsId)).append("\n");
    sb.append("    listAgentMobilePhone: ").append(toIndentedString(listAgentMobilePhone)).append("\n");
    sb.append("    listAgentNamePrefix: ").append(toIndentedString(listAgentNamePrefix)).append("\n");
    sb.append("    listAgentNameSuffix: ").append(toIndentedString(listAgentNameSuffix)).append("\n");
    sb.append("    listAgentOfficePhone: ").append(toIndentedString(listAgentOfficePhone)).append("\n");
    sb.append("    listAgentOfficePhoneExt: ").append(toIndentedString(listAgentOfficePhoneExt)).append("\n");
    sb.append("    listAgentPager: ").append(toIndentedString(listAgentPager)).append("\n");
    sb.append("    listAgentPreferredPhone: ").append(toIndentedString(listAgentPreferredPhone)).append("\n");
    sb.append("    listAgentPreferredPhoneExt: ").append(toIndentedString(listAgentPreferredPhoneExt)).append("\n");
    sb.append("    listAgentStateLicense: ").append(toIndentedString(listAgentStateLicense)).append("\n");
    sb.append("    listAgentTollFreePhone: ").append(toIndentedString(listAgentTollFreePhone)).append("\n");
    sb.append("    listAgentURL: ").append(toIndentedString(listAgentURL)).append("\n");
    sb.append("    listAgentVoiceMail: ").append(toIndentedString(listAgentVoiceMail)).append("\n");
    sb.append("    listAgentVoiceMailExt: ").append(toIndentedString(listAgentVoiceMailExt)).append("\n");
    sb.append("    listOfficeAOR: ").append(toIndentedString(listOfficeAOR)).append("\n");
    sb.append("    listOfficeEmail: ").append(toIndentedString(listOfficeEmail)).append("\n");
    sb.append("    listOfficeFax: ").append(toIndentedString(listOfficeFax)).append("\n");
    sb.append("    listOfficeKey: ").append(toIndentedString(listOfficeKey)).append("\n");
    sb.append("    listOfficeKeyNumeric: ").append(toIndentedString(listOfficeKeyNumeric)).append("\n");
    sb.append("    listOfficeMlsId: ").append(toIndentedString(listOfficeMlsId)).append("\n");
    sb.append("    listOfficeName: ").append(toIndentedString(listOfficeName)).append("\n");
    sb.append("    listOfficePhone: ").append(toIndentedString(listOfficePhone)).append("\n");
    sb.append("    listOfficePhoneExt: ").append(toIndentedString(listOfficePhoneExt)).append("\n");
    sb.append("    listOfficeURL: ").append(toIndentedString(listOfficeURL)).append("\n");
    sb.append("    listPrice: ").append(toIndentedString(listPrice)).append("\n");
    sb.append("    listPriceLow: ").append(toIndentedString(listPriceLow)).append("\n");
    sb.append("    listTeamKey: ").append(toIndentedString(listTeamKey)).append("\n");
    sb.append("    listTeamKeyNumeric: ").append(toIndentedString(listTeamKeyNumeric)).append("\n");
    sb.append("    listTeamName: ").append(toIndentedString(listTeamName)).append("\n");
    sb.append("    listingAgreement: ").append(toIndentedString(listingAgreement)).append("\n");
    sb.append("    listingContractDate: ").append(toIndentedString(listingContractDate)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    listingService: ").append(toIndentedString(listingService)).append("\n");
    sb.append("    listingTerms: ").append(toIndentedString(listingTerms)).append("\n");
    sb.append("    livingArea: ").append(toIndentedString(livingArea)).append("\n");
    sb.append("    livingAreaSource: ").append(toIndentedString(livingAreaSource)).append("\n");
    sb.append("    livingAreaUnits: ").append(toIndentedString(livingAreaUnits)).append("\n");
    sb.append("    lockBoxLocation: ").append(toIndentedString(lockBoxLocation)).append("\n");
    sb.append("    lockBoxSerialNumber: ").append(toIndentedString(lockBoxSerialNumber)).append("\n");
    sb.append("    lockBoxType: ").append(toIndentedString(lockBoxType)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    lotDimensionsSource: ").append(toIndentedString(lotDimensionsSource)).append("\n");
    sb.append("    lotFeatures: ").append(toIndentedString(lotFeatures)).append("\n");
    sb.append("    lotSizeAcres: ").append(toIndentedString(lotSizeAcres)).append("\n");
    sb.append("    lotSizeArea: ").append(toIndentedString(lotSizeArea)).append("\n");
    sb.append("    lotSizeDimensions: ").append(toIndentedString(lotSizeDimensions)).append("\n");
    sb.append("    lotSizeSource: ").append(toIndentedString(lotSizeSource)).append("\n");
    sb.append("    lotSizeSquareFeet: ").append(toIndentedString(lotSizeSquareFeet)).append("\n");
    sb.append("    lotSizeUnits: ").append(toIndentedString(lotSizeUnits)).append("\n");
    sb.append("    mlSAreaMajor: ").append(toIndentedString(mlSAreaMajor)).append("\n");
    sb.append("    mlSAreaMinor: ").append(toIndentedString(mlSAreaMinor)).append("\n");
    sb.append("    mainLevelBathrooms: ").append(toIndentedString(mainLevelBathrooms)).append("\n");
    sb.append("    mainLevelBedrooms: ").append(toIndentedString(mainLevelBedrooms)).append("\n");
    sb.append("    maintenanceExpense: ").append(toIndentedString(maintenanceExpense)).append("\n");
    sb.append("    majorChangeTimestamp: ").append(toIndentedString(majorChangeTimestamp)).append("\n");
    sb.append("    majorChangeType: ").append(toIndentedString(majorChangeType)).append("\n");
    sb.append("    make: ").append(toIndentedString(make)).append("\n");
    sb.append("    managerExpense: ").append(toIndentedString(managerExpense)).append("\n");
    sb.append("    mapCoordinate: ").append(toIndentedString(mapCoordinate)).append("\n");
    sb.append("    mapCoordinateSource: ").append(toIndentedString(mapCoordinateSource)).append("\n");
    sb.append("    mapURL: ").append(toIndentedString(mapURL)).append("\n");
    sb.append("    middleOrJuniorSchool: ").append(toIndentedString(middleOrJuniorSchool)).append("\n");
    sb.append("    middleOrJuniorSchoolDistrict: ").append(toIndentedString(middleOrJuniorSchoolDistrict)).append("\n");
    sb.append("    mlsStatus: ").append(toIndentedString(mlsStatus)).append("\n");
    sb.append("    mobileDimUnits: ").append(toIndentedString(mobileDimUnits)).append("\n");
    sb.append("    mobileHomeRemainsYN: ").append(toIndentedString(mobileHomeRemainsYN)).append("\n");
    sb.append("    mobileLength: ").append(toIndentedString(mobileLength)).append("\n");
    sb.append("    mobileWidth: ").append(toIndentedString(mobileWidth)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    netOperatingIncome: ").append(toIndentedString(netOperatingIncome)).append("\n");
    sb.append("    newConstructionYN: ").append(toIndentedString(newConstructionYN)).append("\n");
    sb.append("    newTaxesExpense: ").append(toIndentedString(newTaxesExpense)).append("\n");
    sb.append("    numberOfBuildings: ").append(toIndentedString(numberOfBuildings)).append("\n");
    sb.append("    numberOfFullTimeEmployees: ").append(toIndentedString(numberOfFullTimeEmployees)).append("\n");
    sb.append("    numberOfLots: ").append(toIndentedString(numberOfLots)).append("\n");
    sb.append("    numberOfPads: ").append(toIndentedString(numberOfPads)).append("\n");
    sb.append("    numberOfPartTimeEmployees: ").append(toIndentedString(numberOfPartTimeEmployees)).append("\n");
    sb.append("    numberOfSeparateElectricMeters: ").append(toIndentedString(numberOfSeparateElectricMeters)).append("\n");
    sb.append("    numberOfSeparateGasMeters: ").append(toIndentedString(numberOfSeparateGasMeters)).append("\n");
    sb.append("    numberOfSeparateWaterMeters: ").append(toIndentedString(numberOfSeparateWaterMeters)).append("\n");
    sb.append("    numberOfUnitsInCommunity: ").append(toIndentedString(numberOfUnitsInCommunity)).append("\n");
    sb.append("    numberOfUnitsLeased: ").append(toIndentedString(numberOfUnitsLeased)).append("\n");
    sb.append("    numberOfUnitsMoMo: ").append(toIndentedString(numberOfUnitsMoMo)).append("\n");
    sb.append("    numberOfUnitsTotal: ").append(toIndentedString(numberOfUnitsTotal)).append("\n");
    sb.append("    numberOfUnitsVacant: ").append(toIndentedString(numberOfUnitsVacant)).append("\n");
    sb.append("    occupantName: ").append(toIndentedString(occupantName)).append("\n");
    sb.append("    occupantPhone: ").append(toIndentedString(occupantPhone)).append("\n");
    sb.append("    occupantType: ").append(toIndentedString(occupantType)).append("\n");
    sb.append("    offMarketDate: ").append(toIndentedString(offMarketDate)).append("\n");
    sb.append("    offMarketTimestamp: ").append(toIndentedString(offMarketTimestamp)).append("\n");
    sb.append("    onMarketDate: ").append(toIndentedString(onMarketDate)).append("\n");
    sb.append("    onMarketTimestamp: ").append(toIndentedString(onMarketTimestamp)).append("\n");
    sb.append("    openParkingSpaces: ").append(toIndentedString(openParkingSpaces)).append("\n");
    sb.append("    openParkingYN: ").append(toIndentedString(openParkingYN)).append("\n");
    sb.append("    operatingExpense: ").append(toIndentedString(operatingExpense)).append("\n");
    sb.append("    operatingExpenseIncludes: ").append(toIndentedString(operatingExpenseIncludes)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originalListPrice: ").append(toIndentedString(originalListPrice)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    otherEquipment: ").append(toIndentedString(otherEquipment)).append("\n");
    sb.append("    otherExpense: ").append(toIndentedString(otherExpense)).append("\n");
    sb.append("    otherParking: ").append(toIndentedString(otherParking)).append("\n");
    sb.append("    otherStructures: ").append(toIndentedString(otherStructures)).append("\n");
    sb.append("    ownerName: ").append(toIndentedString(ownerName)).append("\n");
    sb.append("    ownerPays: ").append(toIndentedString(ownerPays)).append("\n");
    sb.append("    ownerPhone: ").append(toIndentedString(ownerPhone)).append("\n");
    sb.append("    ownership: ").append(toIndentedString(ownership)).append("\n");
    sb.append("    ownershipType: ").append(toIndentedString(ownershipType)).append("\n");
    sb.append("    parcelNumber: ").append(toIndentedString(parcelNumber)).append("\n");
    sb.append("    parkManagerName: ").append(toIndentedString(parkManagerName)).append("\n");
    sb.append("    parkManagerPhone: ").append(toIndentedString(parkManagerPhone)).append("\n");
    sb.append("    parkName: ").append(toIndentedString(parkName)).append("\n");
    sb.append("    parkingFeatures: ").append(toIndentedString(parkingFeatures)).append("\n");
    sb.append("    parkingTotal: ").append(toIndentedString(parkingTotal)).append("\n");
    sb.append("    pastureArea: ").append(toIndentedString(pastureArea)).append("\n");
    sb.append("    patioAndPorchFeatures: ").append(toIndentedString(patioAndPorchFeatures)).append("\n");
    sb.append("    pendingTimestamp: ").append(toIndentedString(pendingTimestamp)).append("\n");
    sb.append("    pestControlExpense: ").append(toIndentedString(pestControlExpense)).append("\n");
    sb.append("    petsAllowed: ").append(toIndentedString(petsAllowed)).append("\n");
    sb.append("    photosChangeTimestamp: ").append(toIndentedString(photosChangeTimestamp)).append("\n");
    sb.append("    photosCount: ").append(toIndentedString(photosCount)).append("\n");
    sb.append("    poolExpense: ").append(toIndentedString(poolExpense)).append("\n");
    sb.append("    poolFeatures: ").append(toIndentedString(poolFeatures)).append("\n");
    sb.append("    poolPrivateYN: ").append(toIndentedString(poolPrivateYN)).append("\n");
    sb.append("    possession: ").append(toIndentedString(possession)).append("\n");
    sb.append("    possibleUse: ").append(toIndentedString(possibleUse)).append("\n");
    sb.append("    postalCity: ").append(toIndentedString(postalCity)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    postalCodePlus4: ").append(toIndentedString(postalCodePlus4)).append("\n");
    sb.append("    powerProductionType: ").append(toIndentedString(powerProductionType)).append("\n");
    sb.append("    previousListPrice: ").append(toIndentedString(previousListPrice)).append("\n");
    sb.append("    priceChangeTimestamp: ").append(toIndentedString(priceChangeTimestamp)).append("\n");
    sb.append("    privateOfficeRemarks: ").append(toIndentedString(privateOfficeRemarks)).append("\n");
    sb.append("    privateRemarks: ").append(toIndentedString(privateRemarks)).append("\n");
    sb.append("    professionalManagementExpense: ").append(toIndentedString(professionalManagementExpense)).append("\n");
    sb.append("    propertyAttachedYN: ").append(toIndentedString(propertyAttachedYN)).append("\n");
    sb.append("    propertyCondition: ").append(toIndentedString(propertyCondition)).append("\n");
    sb.append("    propertySubType: ").append(toIndentedString(propertySubType)).append("\n");
    sb.append("    propertyType: ").append(toIndentedString(propertyType)).append("\n");
    sb.append("    publicRemarks: ").append(toIndentedString(publicRemarks)).append("\n");
    sb.append("    publicSurveyRange: ").append(toIndentedString(publicSurveyRange)).append("\n");
    sb.append("    publicSurveySection: ").append(toIndentedString(publicSurveySection)).append("\n");
    sb.append("    publicSurveyTownship: ").append(toIndentedString(publicSurveyTownship)).append("\n");
    sb.append("    purchaseContractDate: ").append(toIndentedString(purchaseContractDate)).append("\n");
    sb.append("    rvParkingDimensions: ").append(toIndentedString(rvParkingDimensions)).append("\n");
    sb.append("    rangeArea: ").append(toIndentedString(rangeArea)).append("\n");
    sb.append("    rentControlYN: ").append(toIndentedString(rentControlYN)).append("\n");
    sb.append("    rentIncludes: ").append(toIndentedString(rentIncludes)).append("\n");
    sb.append("    roadFrontageType: ").append(toIndentedString(roadFrontageType)).append("\n");
    sb.append("    roadResponsibility: ").append(toIndentedString(roadResponsibility)).append("\n");
    sb.append("    roadSurfaceType: ").append(toIndentedString(roadSurfaceType)).append("\n");
    sb.append("    roof: ").append(toIndentedString(roof)).append("\n");
    sb.append("    roomType: ").append(toIndentedString(roomType)).append("\n");
    sb.append("    roomsTotal: ").append(toIndentedString(roomsTotal)).append("\n");
    sb.append("    seatingCapacity: ").append(toIndentedString(seatingCapacity)).append("\n");
    sb.append("    securityFeatures: ").append(toIndentedString(securityFeatures)).append("\n");
    sb.append("    seniorCommunityYN: ").append(toIndentedString(seniorCommunityYN)).append("\n");
    sb.append("    serialU: ").append(toIndentedString(serialU)).append("\n");
    sb.append("    serialX: ").append(toIndentedString(serialX)).append("\n");
    sb.append("    serialXX: ").append(toIndentedString(serialXX)).append("\n");
    sb.append("    sewer: ").append(toIndentedString(sewer)).append("\n");
    sb.append("    showingAdvanceNotice: ").append(toIndentedString(showingAdvanceNotice)).append("\n");
    sb.append("    showingAttendedYN: ").append(toIndentedString(showingAttendedYN)).append("\n");
    sb.append("    showingContactName: ").append(toIndentedString(showingContactName)).append("\n");
    sb.append("    showingContactPhone: ").append(toIndentedString(showingContactPhone)).append("\n");
    sb.append("    showingContactPhoneExt: ").append(toIndentedString(showingContactPhoneExt)).append("\n");
    sb.append("    showingContactType: ").append(toIndentedString(showingContactType)).append("\n");
    sb.append("    showingDays: ").append(toIndentedString(showingDays)).append("\n");
    sb.append("    showingEndTime: ").append(toIndentedString(showingEndTime)).append("\n");
    sb.append("    showingInstructions: ").append(toIndentedString(showingInstructions)).append("\n");
    sb.append("    showingRequirements: ").append(toIndentedString(showingRequirements)).append("\n");
    sb.append("    showingStartTime: ").append(toIndentedString(showingStartTime)).append("\n");
    sb.append("    signOnPropertyYN: ").append(toIndentedString(signOnPropertyYN)).append("\n");
    sb.append("    skirt: ").append(toIndentedString(skirt)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    spaFeatures: ").append(toIndentedString(spaFeatures)).append("\n");
    sb.append("    spaYN: ").append(toIndentedString(spaYN)).append("\n");
    sb.append("    specialLicenses: ").append(toIndentedString(specialLicenses)).append("\n");
    sb.append("    specialListingConditions: ").append(toIndentedString(specialListingConditions)).append("\n");
    sb.append("    standardStatus: ").append(toIndentedString(standardStatus)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    stateRegion: ").append(toIndentedString(stateRegion)).append("\n");
    sb.append("    statusChangeTimestamp: ").append(toIndentedString(statusChangeTimestamp)).append("\n");
    sb.append("    stories: ").append(toIndentedString(stories)).append("\n");
    sb.append("    storiesTotal: ").append(toIndentedString(storiesTotal)).append("\n");
    sb.append("    streetAdditionalInfo: ").append(toIndentedString(streetAdditionalInfo)).append("\n");
    sb.append("    streetDirPrefix: ").append(toIndentedString(streetDirPrefix)).append("\n");
    sb.append("    streetDirSuffix: ").append(toIndentedString(streetDirSuffix)).append("\n");
    sb.append("    streetName: ").append(toIndentedString(streetName)).append("\n");
    sb.append("    streetNumber: ").append(toIndentedString(streetNumber)).append("\n");
    sb.append("    streetNumberNumeric: ").append(toIndentedString(streetNumberNumeric)).append("\n");
    sb.append("    streetSuffix: ").append(toIndentedString(streetSuffix)).append("\n");
    sb.append("    streetSuffixModifier: ").append(toIndentedString(streetSuffixModifier)).append("\n");
    sb.append("    structureType: ").append(toIndentedString(structureType)).append("\n");
    sb.append("    subAgencyCompensation: ").append(toIndentedString(subAgencyCompensation)).append("\n");
    sb.append("    subAgencyCompensationType: ").append(toIndentedString(subAgencyCompensationType)).append("\n");
    sb.append("    subdivisionName: ").append(toIndentedString(subdivisionName)).append("\n");
    sb.append("    suppliesExpense: ").append(toIndentedString(suppliesExpense)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("    syndicationRemarks: ").append(toIndentedString(syndicationRemarks)).append("\n");
    sb.append("    taxAnnualAmount: ").append(toIndentedString(taxAnnualAmount)).append("\n");
    sb.append("    taxAssessedValue: ").append(toIndentedString(taxAssessedValue)).append("\n");
    sb.append("    taxBlock: ").append(toIndentedString(taxBlock)).append("\n");
    sb.append("    taxBookNumber: ").append(toIndentedString(taxBookNumber)).append("\n");
    sb.append("    taxLegalDescription: ").append(toIndentedString(taxLegalDescription)).append("\n");
    sb.append("    taxLot: ").append(toIndentedString(taxLot)).append("\n");
    sb.append("    taxMapNumber: ").append(toIndentedString(taxMapNumber)).append("\n");
    sb.append("    taxOtherAnnualAssessmentAmount: ").append(toIndentedString(taxOtherAnnualAssessmentAmount)).append("\n");
    sb.append("    taxParcelLetter: ").append(toIndentedString(taxParcelLetter)).append("\n");
    sb.append("    taxStatusCurrent: ").append(toIndentedString(taxStatusCurrent)).append("\n");
    sb.append("    taxTract: ").append(toIndentedString(taxTract)).append("\n");
    sb.append("    taxYear: ").append(toIndentedString(taxYear)).append("\n");
    sb.append("    tenantPays: ").append(toIndentedString(tenantPays)).append("\n");
    sb.append("    topography: ").append(toIndentedString(topography)).append("\n");
    sb.append("    totalActualRent: ").append(toIndentedString(totalActualRent)).append("\n");
    sb.append("    township: ").append(toIndentedString(township)).append("\n");
    sb.append("    transactionBrokerCompensation: ").append(toIndentedString(transactionBrokerCompensation)).append("\n");
    sb.append("    transactionBrokerCompensationType: ").append(toIndentedString(transactionBrokerCompensationType)).append("\n");
    sb.append("    trashExpense: ").append(toIndentedString(trashExpense)).append("\n");
    sb.append("    unitNumber: ").append(toIndentedString(unitNumber)).append("\n");
    sb.append("    unitTypeType: ").append(toIndentedString(unitTypeType)).append("\n");
    sb.append("    unitsFurnished: ").append(toIndentedString(unitsFurnished)).append("\n");
    sb.append("    universalPropertyId: ").append(toIndentedString(universalPropertyId)).append("\n");
    sb.append("    universalPropertySubId: ").append(toIndentedString(universalPropertySubId)).append("\n");
    sb.append("    unparsedAddress: ").append(toIndentedString(unparsedAddress)).append("\n");
    sb.append("    utilities: ").append(toIndentedString(utilities)).append("\n");
    sb.append("    vacancyAllowance: ").append(toIndentedString(vacancyAllowance)).append("\n");
    sb.append("    vacancyAllowanceRate: ").append(toIndentedString(vacancyAllowanceRate)).append("\n");
    sb.append("    vegetation: ").append(toIndentedString(vegetation)).append("\n");
    sb.append("    videosChangeTimestamp: ").append(toIndentedString(videosChangeTimestamp)).append("\n");
    sb.append("    videosCount: ").append(toIndentedString(videosCount)).append("\n");
    sb.append("    view: ").append(toIndentedString(view)).append("\n");
    sb.append("    viewYN: ").append(toIndentedString(viewYN)).append("\n");
    sb.append("    virtualTourURLBranded: ").append(toIndentedString(virtualTourURLBranded)).append("\n");
    sb.append("    virtualTourURLUnbranded: ").append(toIndentedString(virtualTourURLUnbranded)).append("\n");
    sb.append("    walkScore: ").append(toIndentedString(walkScore)).append("\n");
    sb.append("    waterBodyName: ").append(toIndentedString(waterBodyName)).append("\n");
    sb.append("    waterSewerExpense: ").append(toIndentedString(waterSewerExpense)).append("\n");
    sb.append("    waterSource: ").append(toIndentedString(waterSource)).append("\n");
    sb.append("    waterfrontFeatures: ").append(toIndentedString(waterfrontFeatures)).append("\n");
    sb.append("    waterfrontYN: ").append(toIndentedString(waterfrontYN)).append("\n");
    sb.append("    windowFeatures: ").append(toIndentedString(windowFeatures)).append("\n");
    sb.append("    withdrawnDate: ").append(toIndentedString(withdrawnDate)).append("\n");
    sb.append("    woodedArea: ").append(toIndentedString(woodedArea)).append("\n");
    sb.append("    workmansCompensationExpense: ").append(toIndentedString(workmansCompensationExpense)).append("\n");
    sb.append("    yearBuilt: ").append(toIndentedString(yearBuilt)).append("\n");
    sb.append("    yearBuiltDetails: ").append(toIndentedString(yearBuiltDetails)).append("\n");
    sb.append("    yearBuiltEffective: ").append(toIndentedString(yearBuiltEffective)).append("\n");
    sb.append("    yearBuiltSource: ").append(toIndentedString(yearBuiltSource)).append("\n");
    sb.append("    yearEstablished: ").append(toIndentedString(yearEstablished)).append("\n");
    sb.append("    yearsCurrentOwner: ").append(toIndentedString(yearsCurrentOwner)).append("\n");
    sb.append("    zoning: ").append(toIndentedString(zoning)).append("\n");
    sb.append("    zoningDescription: ").append(toIndentedString(zoningDescription)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    buyerAgent: ").append(toIndentedString(buyerAgent)).append("\n");
    sb.append("    buyerOffice: ").append(toIndentedString(buyerOffice)).append("\n");
    sb.append("    coBuyerAgent: ").append(toIndentedString(coBuyerAgent)).append("\n");
    sb.append("    coBuyerOffice: ").append(toIndentedString(coBuyerOffice)).append("\n");
    sb.append("    coListAgent: ").append(toIndentedString(coListAgent)).append("\n");
    sb.append("    coListOffice: ").append(toIndentedString(coListOffice)).append("\n");
    sb.append("    listAgent: ").append(toIndentedString(listAgent)).append("\n");
    sb.append("    listOffice: ").append(toIndentedString(listOffice)).append("\n");
    sb.append("    buyerTeam: ").append(toIndentedString(buyerTeam)).append("\n");
    sb.append("    listTeam: ").append(toIndentedString(listTeam)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    historyTransactionalAtOdataCount: ").append(toIndentedString(historyTransactionalAtOdataCount)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    mediaAtOdataCount: ").append(toIndentedString(mediaAtOdataCount)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("    socialMediaAtOdataCount: ").append(toIndentedString(socialMediaAtOdataCount)).append("\n");
    sb.append("    openHouse: ").append(toIndentedString(openHouse)).append("\n");
    sb.append("    openHouseAtOdataCount: ").append(toIndentedString(openHouseAtOdataCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
