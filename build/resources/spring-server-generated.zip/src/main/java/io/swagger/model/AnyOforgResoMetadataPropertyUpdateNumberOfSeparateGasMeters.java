package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters
*/
public interface AnyOforgResoMetadataPropertyUpdateNumberOfSeparateGasMeters {

}
