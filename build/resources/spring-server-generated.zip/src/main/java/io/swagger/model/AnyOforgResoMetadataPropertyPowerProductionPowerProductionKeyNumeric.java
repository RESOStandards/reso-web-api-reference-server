package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionPowerProductionKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyPowerProductionPowerProductionKeyNumeric {

}
