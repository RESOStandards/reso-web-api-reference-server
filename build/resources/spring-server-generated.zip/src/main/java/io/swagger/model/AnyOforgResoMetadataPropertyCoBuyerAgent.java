package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCoBuyerAgent
*/
public interface AnyOforgResoMetadataPropertyCoBuyerAgent {

}
