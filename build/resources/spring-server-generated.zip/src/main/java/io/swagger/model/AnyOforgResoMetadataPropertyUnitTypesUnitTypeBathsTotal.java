package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUnitTypeBathsTotal
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUnitTypeBathsTotal {

}
