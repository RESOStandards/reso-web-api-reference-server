package io.swagger.model;


/**
* AnyOforgResoMetadataQueueResourceRecordKeyNumeric
*/
public interface AnyOforgResoMetadataQueueResourceRecordKeyNumeric {

}
