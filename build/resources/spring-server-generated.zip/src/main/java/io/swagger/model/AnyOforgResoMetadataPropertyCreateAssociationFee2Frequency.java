package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency
*/
public interface AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency {

}
