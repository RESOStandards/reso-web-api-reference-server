package io.swagger.model;


/**
* AnyOforgResoMetadataShowingCreateShowingSourceSystem
*/
public interface AnyOforgResoMetadataShowingCreateShowingSourceSystem {

}
