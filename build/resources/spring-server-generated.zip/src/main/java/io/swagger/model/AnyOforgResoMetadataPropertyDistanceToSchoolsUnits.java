package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToSchoolsUnits
*/
public interface AnyOforgResoMetadataPropertyDistanceToSchoolsUnits {

}
