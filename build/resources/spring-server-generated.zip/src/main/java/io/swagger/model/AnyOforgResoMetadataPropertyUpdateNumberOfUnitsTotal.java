package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal
*/
public interface AnyOforgResoMetadataPropertyUpdateNumberOfUnitsTotal {

}
