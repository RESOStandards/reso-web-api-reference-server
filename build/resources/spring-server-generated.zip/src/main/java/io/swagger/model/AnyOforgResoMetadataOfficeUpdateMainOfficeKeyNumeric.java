package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric {

}
