package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateWoodedArea
*/
public interface AnyOforgResoMetadataPropertyCreateWoodedArea {

}
