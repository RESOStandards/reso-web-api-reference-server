package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBuildingAreaSource
*/
public interface AnyOforgResoMetadataPropertyBuildingAreaSource {

}
