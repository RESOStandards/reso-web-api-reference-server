package io.swagger.model;


/**
* AnyOforgResoMetadataMemberCreateOffice
*/
public interface AnyOforgResoMetadataMemberCreateOffice {

}
