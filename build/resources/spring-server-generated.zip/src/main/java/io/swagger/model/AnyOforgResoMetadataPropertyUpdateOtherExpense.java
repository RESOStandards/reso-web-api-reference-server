package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateOtherExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateOtherExpense {

}
