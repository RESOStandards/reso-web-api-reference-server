package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsRoomLength
*/
public interface AnyOforgResoMetadataPropertyRoomsRoomLength {

}
