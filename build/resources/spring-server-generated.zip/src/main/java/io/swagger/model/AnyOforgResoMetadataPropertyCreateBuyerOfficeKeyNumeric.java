package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric {

}
