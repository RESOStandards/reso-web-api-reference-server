package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateConcessions
*/
public interface AnyOforgResoMetadataPropertyCreateConcessions {

}
