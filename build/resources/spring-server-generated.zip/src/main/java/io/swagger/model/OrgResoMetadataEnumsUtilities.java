package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.Utilities
 */
public enum OrgResoMetadataEnumsUtilities {
  CABLEAVAILABLE("CableAvailable"),
    CABLECONNECTED("CableConnected"),
    CABLENOTAVAILABLE("CableNotAvailable"),
    ELECTRICITYAVAILABLE("ElectricityAvailable"),
    ELECTRICITYCONNECTED("ElectricityConnected"),
    ELECTRICITYNOTAVAILABLE("ElectricityNotAvailable"),
    NATURALGASAVAILABLE("NaturalGasAvailable"),
    NATURALGASCONNECTED("NaturalGasConnected"),
    NATURALGASNOTAVAILABLE("NaturalGasNotAvailable"),
    NONE("None"),
    OTHER("Other"),
    PHONEAVAILABLE("PhoneAvailable"),
    PHONECONNECTED("PhoneConnected"),
    PHONENOTAVAILABLE("PhoneNotAvailable"),
    PROPANE("Propane"),
    SEEREMARKS("SeeRemarks"),
    SEWERAVAILABLE("SewerAvailable"),
    SEWERCONNECTED("SewerConnected"),
    SEWERNOTAVAILABLE("SewerNotAvailable"),
    UNDERGROUNDUTILITIES("UndergroundUtilities"),
    WATERAVAILABLE("WaterAvailable"),
    WATERCONNECTED("WaterConnected"),
    WATERNOTAVAILABLE("WaterNotAvailable");

  private String value;

  OrgResoMetadataEnumsUtilities(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsUtilities fromValue(String text) {
    for (OrgResoMetadataEnumsUtilities b : OrgResoMetadataEnumsUtilities.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
