package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateObjectSourceSystem
*/
public interface AnyOforgResoMetadataInternetTrackingCreateObjectSourceSystem {

}
