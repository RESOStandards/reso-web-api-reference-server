package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince
*/
public interface AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince {

}
