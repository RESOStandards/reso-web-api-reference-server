package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCountry
*/
public interface AnyOforgResoMetadataPropertyCreateCountry {

}
