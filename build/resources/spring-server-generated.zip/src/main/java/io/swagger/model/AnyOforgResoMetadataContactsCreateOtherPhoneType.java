package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateOtherPhoneType
*/
public interface AnyOforgResoMetadataContactsCreateOtherPhoneType {

}
