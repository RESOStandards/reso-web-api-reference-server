package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToSewerUnits
*/
public interface AnyOforgResoMetadataPropertyDistanceToSewerUnits {

}
