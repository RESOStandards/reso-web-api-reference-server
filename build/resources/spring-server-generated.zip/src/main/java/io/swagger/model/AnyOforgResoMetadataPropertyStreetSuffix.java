package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyStreetSuffix
*/
public interface AnyOforgResoMetadataPropertyStreetSuffix {

}
