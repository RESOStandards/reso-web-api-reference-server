package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeUpdateOfficeStatus
*/
public interface AnyOforgResoMetadataOfficeUpdateOfficeStatus {

}
