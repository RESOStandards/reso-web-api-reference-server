package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToWaterNumeric {

}
