package io.swagger.model;


/**
* AnyOforgResoMetadataSocialMediaCreateResourceName
*/
public interface AnyOforgResoMetadataSocialMediaCreateResourceName {

}
