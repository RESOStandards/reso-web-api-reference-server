package io.swagger.model;


/**
* AnyOforgResoMetadataMemberMemberMlsSecurityClass
*/
public interface AnyOforgResoMetadataMemberMemberMlsSecurityClass {

}
