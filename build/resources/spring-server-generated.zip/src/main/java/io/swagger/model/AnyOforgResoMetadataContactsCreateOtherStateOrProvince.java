package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateOtherStateOrProvince
*/
public interface AnyOforgResoMetadataContactsCreateOtherStateOrProvince {

}
