package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToFreewayUnits
*/
public interface AnyOforgResoMetadataPropertyDistanceToFreewayUnits {

}
