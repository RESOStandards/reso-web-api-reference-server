package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseOriginatingSystem
*/
public interface AnyOforgResoMetadataOpenHouseOriginatingSystem {

}
