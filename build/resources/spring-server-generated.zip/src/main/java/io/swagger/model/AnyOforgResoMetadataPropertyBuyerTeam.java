package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBuyerTeam
*/
public interface AnyOforgResoMetadataPropertyBuyerTeam {

}
