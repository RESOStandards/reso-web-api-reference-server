package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateUnitsFurnished
*/
public interface AnyOforgResoMetadataPropertyCreateUnitsFurnished {

}
