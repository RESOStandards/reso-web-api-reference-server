package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyMainLevelBathrooms
*/
public interface AnyOforgResoMetadataPropertyMainLevelBathrooms {

}
