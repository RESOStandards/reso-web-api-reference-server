package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationCreateListingKeyNumeric {

}
