package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateCultivatedArea
*/
public interface AnyOforgResoMetadataPropertyUpdateCultivatedArea {

}
