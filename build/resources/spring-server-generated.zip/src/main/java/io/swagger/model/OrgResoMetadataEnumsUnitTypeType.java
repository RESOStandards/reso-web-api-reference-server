package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.UnitTypeType
 */
public enum OrgResoMetadataEnumsUnitTypeType {
  APARTMENTS("Apartments"),
    EFFICIENCY("Efficiency"),
    FOURBEDROOMORMORE("FourBedroomOrMore"),
    LOFT("Loft"),
    MANAGERSUNIT("ManagersUnit"),
    ONEBEDROOM("OneBedroom"),
    PENTHOUSE("Penthouse"),
    STUDIO("Studio"),
    THREEBEDROOM("ThreeBedroom"),
    TWOBEDROOM("TwoBedroom");

  private String value;

  OrgResoMetadataEnumsUnitTypeType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsUnitTypeType fromValue(String text) {
    for (OrgResoMetadataEnumsUnitTypeType b : OrgResoMetadataEnumsUnitTypeType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
