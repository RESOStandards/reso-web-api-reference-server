package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeOfficeCountyOrParish
*/
public interface AnyOforgResoMetadataOfficeOfficeCountyOrParish {

}
