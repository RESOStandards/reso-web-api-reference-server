package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLeaseTerm
*/
public interface AnyOforgResoMetadataPropertyLeaseTerm {

}
