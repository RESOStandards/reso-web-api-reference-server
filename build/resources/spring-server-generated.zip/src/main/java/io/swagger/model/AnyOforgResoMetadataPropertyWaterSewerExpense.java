package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyWaterSewerExpense
*/
public interface AnyOforgResoMetadataPropertyWaterSewerExpense {

}
