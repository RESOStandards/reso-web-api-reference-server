package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreatePoolExpense
*/
public interface AnyOforgResoMetadataPropertyCreatePoolExpense {

}
