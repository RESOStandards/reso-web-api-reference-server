package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense
*/
public interface AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense {

}
