package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount
*/
public interface AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount {

}
