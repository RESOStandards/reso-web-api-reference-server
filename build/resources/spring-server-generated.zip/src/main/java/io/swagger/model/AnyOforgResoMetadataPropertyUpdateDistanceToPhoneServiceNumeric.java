package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToPhoneServiceNumeric {

}
