package io.swagger.model;


/**
* AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric
*/
public interface AnyOforgResoMetadataQueueUpdateQueueTransactionKeyNumeric {

}
