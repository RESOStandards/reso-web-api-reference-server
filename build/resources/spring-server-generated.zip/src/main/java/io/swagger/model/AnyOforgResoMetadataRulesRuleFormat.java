package io.swagger.model;


/**
* AnyOforgResoMetadataRulesRuleFormat
*/
public interface AnyOforgResoMetadataRulesRuleFormat {

}
