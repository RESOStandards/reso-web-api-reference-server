package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees
*/
public interface AnyOforgResoMetadataPropertyUpdateNumberOfFullTimeEmployees {

}
