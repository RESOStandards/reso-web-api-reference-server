package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyOriginalListPrice
*/
public interface AnyOforgResoMetadataPropertyOriginalListPrice {

}
