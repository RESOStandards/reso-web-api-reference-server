package io.swagger.model;


/**
* AnyOforgResoMetadataOtherPhoneResourceName
*/
public interface AnyOforgResoMetadataOtherPhoneResourceName {

}
