package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateLongitude
*/
public interface AnyOforgResoMetadataPropertyUpdateLongitude {

}
