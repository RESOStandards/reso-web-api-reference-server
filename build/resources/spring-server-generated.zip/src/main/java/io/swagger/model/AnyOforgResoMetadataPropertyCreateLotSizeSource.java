package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLotSizeSource
*/
public interface AnyOforgResoMetadataPropertyCreateLotSizeSource {

}
