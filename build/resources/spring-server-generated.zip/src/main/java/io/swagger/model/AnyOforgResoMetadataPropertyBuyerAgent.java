package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBuyerAgent
*/
public interface AnyOforgResoMetadataPropertyBuyerAgent {

}
