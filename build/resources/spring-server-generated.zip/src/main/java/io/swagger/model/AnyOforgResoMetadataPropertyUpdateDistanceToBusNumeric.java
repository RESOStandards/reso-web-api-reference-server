package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToBusNumeric {

}
