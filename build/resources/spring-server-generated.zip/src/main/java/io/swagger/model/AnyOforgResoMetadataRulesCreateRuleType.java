package io.swagger.model;


/**
* AnyOforgResoMetadataRulesCreateRuleType
*/
public interface AnyOforgResoMetadataRulesCreateRuleType {

}
