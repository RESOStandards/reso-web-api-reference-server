package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric
*/
public interface AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric {

}
