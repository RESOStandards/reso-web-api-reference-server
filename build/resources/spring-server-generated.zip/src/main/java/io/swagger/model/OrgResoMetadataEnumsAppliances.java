package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.Appliances
 */
public enum OrgResoMetadataEnumsAppliances {
  BARFRIDGE("BarFridge"),
    BUILTINELECTRICOVEN("BuiltInElectricOven"),
    BUILTINELECTRICRANGE("BuiltInElectricRange"),
    BUILTINFREEZER("BuiltInFreezer"),
    BUILTINGASOVEN("BuiltInGasOven"),
    BUILTINGASRANGE("BuiltInGasRange"),
    BUILTINRANGE("BuiltInRange"),
    BUILTINREFRIGERATOR("BuiltInRefrigerator"),
    CONVECTIONOVEN("ConvectionOven"),
    COOKTOP("Cooktop"),
    DISHWASHER("Dishwasher"),
    DISPOSAL("Disposal"),
    DOUBLEOVEN("DoubleOven"),
    DOWNDRAFT("DownDraft"),
    DRYER("Dryer"),
    ELECTRICCOOKTOP("ElectricCooktop"),
    ELECTRICOVEN("ElectricOven"),
    ELECTRICRANGE("ElectricRange"),
    ELECTRICWATERHEATER("ElectricWaterHeater"),
    ENERGYSTARQUALIFIEDAPPLIANCES("EnergyStarQualifiedAppliances"),
    ENERGYSTARQUALIFIEDDISHWASHER("EnergyStarQualifiedDishwasher"),
    ENERGYSTARQUALIFIEDDRYER("EnergyStarQualifiedDryer"),
    ENERGYSTARQUALIFIEDFREEZER("EnergyStarQualifiedFreezer"),
    ENERGYSTARQUALIFIEDREFRIGERATOR("EnergyStarQualifiedRefrigerator"),
    ENERGYSTARQUALIFIEDWASHER("EnergyStarQualifiedWasher"),
    ENERGYSTARQUALIFIEDWATERHEATER("EnergyStarQualifiedWaterHeater"),
    EXHAUSTFAN("ExhaustFan"),
    FREESTANDINGELECTRICOVEN("FreeStandingElectricOven"),
    FREESTANDINGELECTRICRANGE("FreeStandingElectricRange"),
    FREESTANDINGFREEZER("FreeStandingFreezer"),
    FREESTANDINGGASOVEN("FreeStandingGasOven"),
    FREESTANDINGGASRANGE("FreeStandingGasRange"),
    FREESTANDINGRANGE("FreeStandingRange"),
    FREESTANDINGREFRIGERATOR("FreeStandingRefrigerator"),
    FREEZER("Freezer"),
    GASCOOKTOP("GasCooktop"),
    GASOVEN("GasOven"),
    GASRANGE("GasRange"),
    GASWATERHEATER("GasWaterHeater"),
    HUMIDIFIER("Humidifier"),
    ICEMAKER("IceMaker"),
    INDOORGRILL("IndoorGrill"),
    INDUCTIONCOOKTOP("InductionCooktop"),
    INSTANTHOTWATER("InstantHotWater"),
    MICROWAVE("Microwave"),
    NONE("None"),
    OTHER("Other"),
    OVEN("Oven"),
    PLUMBEDFORICEMAKER("PlumbedForIceMaker"),
    PORTABLEDISHWASHER("PortableDishwasher"),
    PROPANECOOKTOP("PropaneCooktop"),
    RANGE("Range"),
    RANGEHOOD("RangeHood"),
    REFRIGERATOR("Refrigerator"),
    SELFCLEANINGOVEN("SelfCleaningOven"),
    SOLARHOTWATER("SolarHotWater"),
    STAINLESSSTEELAPPLIANCES("StainlessSteelAppliances"),
    TANKLESSWATERHEATER("TanklessWaterHeater"),
    TRASHCOMPACTOR("TrashCompactor"),
    VENTEDEXHAUSTFAN("VentedExhaustFan"),
    WARMINGDRAWER("WarmingDrawer"),
    WASHER("Washer"),
    WASHERDRYER("WasherDryer"),
    WASHERDRYERSTACKED("WasherDryerStacked"),
    WATERHEATER("WaterHeater"),
    WATERPURIFIER("WaterPurifier"),
    WATERPURIFIEROWNED("WaterPurifierOwned"),
    WATERPURIFIERRENTED("WaterPurifierRented"),
    WATERSOFTENER("WaterSoftener"),
    WATERSOFTENEROWNED("WaterSoftenerOwned"),
    WATERSOFTENERRENTED("WaterSoftenerRented"),
    WINECOOLER("WineCooler"),
    WINEREFRIGERATOR("WineRefrigerator");

  private String value;

  OrgResoMetadataEnumsAppliances(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsAppliances fromValue(String text) {
    for (OrgResoMetadataEnumsAppliances b : OrgResoMetadataEnumsAppliances.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
