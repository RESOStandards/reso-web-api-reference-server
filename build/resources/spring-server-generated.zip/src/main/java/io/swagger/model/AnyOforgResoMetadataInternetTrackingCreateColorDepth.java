package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateColorDepth
*/
public interface AnyOforgResoMetadataInternetTrackingCreateColorDepth {

}
