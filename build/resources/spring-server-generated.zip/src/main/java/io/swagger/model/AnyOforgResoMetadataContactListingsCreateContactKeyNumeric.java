package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingsCreateContactKeyNumeric
*/
public interface AnyOforgResoMetadataContactListingsCreateContactKeyNumeric {

}
