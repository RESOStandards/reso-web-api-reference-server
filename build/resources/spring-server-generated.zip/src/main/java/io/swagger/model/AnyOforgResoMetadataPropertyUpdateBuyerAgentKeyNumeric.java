package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateBuyerAgentKeyNumeric {

}
