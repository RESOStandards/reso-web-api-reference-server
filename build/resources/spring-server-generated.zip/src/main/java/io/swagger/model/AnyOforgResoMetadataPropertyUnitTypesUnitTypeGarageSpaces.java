package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUnitTypeGarageSpaces
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUnitTypeGarageSpaces {

}
