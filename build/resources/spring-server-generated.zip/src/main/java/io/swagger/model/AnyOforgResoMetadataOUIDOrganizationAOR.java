package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDOrganizationAOR
*/
public interface AnyOforgResoMetadataOUIDOrganizationAOR {

}
