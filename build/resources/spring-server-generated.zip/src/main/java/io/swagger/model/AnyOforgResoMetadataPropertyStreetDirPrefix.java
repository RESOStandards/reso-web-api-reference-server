package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyStreetDirPrefix
*/
public interface AnyOforgResoMetadataPropertyStreetDirPrefix {

}
