package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDUpdateOrganizationMemberCount
*/
public interface AnyOforgResoMetadataOUIDUpdateOrganizationMemberCount {

}
