package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUnitTypeTotalRent
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUnitTypeTotalRent {

}
