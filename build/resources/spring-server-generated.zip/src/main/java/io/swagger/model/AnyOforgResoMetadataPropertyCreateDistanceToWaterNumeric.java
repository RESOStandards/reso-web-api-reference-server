package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric {

}
