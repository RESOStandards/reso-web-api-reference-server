package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyNumberOfUnitsTotal
*/
public interface AnyOforgResoMetadataPropertyNumberOfUnitsTotal {

}
