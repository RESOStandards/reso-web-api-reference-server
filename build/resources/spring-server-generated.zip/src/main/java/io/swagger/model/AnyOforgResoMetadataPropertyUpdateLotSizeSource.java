package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateLotSizeSource
*/
public interface AnyOforgResoMetadataPropertyUpdateLotSizeSource {

}
