package io.swagger.model;


/**
* AnyOforgResoMetadataMemberMemberCountry
*/
public interface AnyOforgResoMetadataMemberMemberCountry {

}
