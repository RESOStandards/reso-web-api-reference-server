package io.swagger.model;


/**
* AnyOforgResoMetadataRulesCreateOriginatingSystem
*/
public interface AnyOforgResoMetadataRulesCreateOriginatingSystem {

}
