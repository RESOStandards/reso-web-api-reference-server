package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateRangeArea
*/
public interface AnyOforgResoMetadataPropertyUpdateRangeArea {

}
