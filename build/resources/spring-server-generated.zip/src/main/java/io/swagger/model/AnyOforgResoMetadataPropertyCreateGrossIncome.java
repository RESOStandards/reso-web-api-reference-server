package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateGrossIncome
*/
public interface AnyOforgResoMetadataPropertyCreateGrossIncome {

}
