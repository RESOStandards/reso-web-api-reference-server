package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.StateOrProvince
 */
public enum OrgResoMetadataEnumsStateOrProvince {
  AB("AB"),
    AK("AK"),
    AL("AL"),
    AR("AR"),
    AZ("AZ"),
    BC("BC"),
    CA("CA"),
    CO("CO"),
    CT("CT"),
    DC("DC"),
    DE("DE"),
    FL("FL"),
    GA("GA"),
    HI("HI"),
    IA("IA"),
    ID("ID"),
    IL("IL"),
    IN("IN"),
    KS("KS"),
    KY("KY"),
    LA("LA"),
    MA("MA"),
    MB("MB"),
    MD("MD"),
    ME("ME"),
    MI("MI"),
    MN("MN"),
    MO("MO"),
    MS("MS"),
    MT("MT"),
    NB("NB"),
    NC("NC"),
    ND("ND"),
    NE("NE"),
    NF("NF"),
    NH("NH"),
    NJ("NJ"),
    NM("NM"),
    NS("NS"),
    NT("NT"),
    NU("NU"),
    NV("NV"),
    NY("NY"),
    OH("OH"),
    OK("OK"),
    ON("ON"),
    OR("OR"),
    PA("PA"),
    PE("PE"),
    QC("QC"),
    RI("RI"),
    SC("SC"),
    SD("SD"),
    SK("SK"),
    TN("TN"),
    TX("TX"),
    UT("UT"),
    VA("VA"),
    VI("VI"),
    VT("VT"),
    WA("WA"),
    WI("WI"),
    WV("WV"),
    WY("WY"),
    YT("YT");

  private String value;

  OrgResoMetadataEnumsStateOrProvince(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsStateOrProvince fromValue(String text) {
    for (OrgResoMetadataEnumsStateOrProvince b : OrgResoMetadataEnumsStateOrProvince.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
