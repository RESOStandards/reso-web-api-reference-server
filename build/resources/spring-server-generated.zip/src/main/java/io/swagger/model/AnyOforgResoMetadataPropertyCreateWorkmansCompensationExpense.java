package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense
*/
public interface AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense {

}
