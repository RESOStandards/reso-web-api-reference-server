package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyWalkScore
*/
public interface AnyOforgResoMetadataPropertyWalkScore {

}
