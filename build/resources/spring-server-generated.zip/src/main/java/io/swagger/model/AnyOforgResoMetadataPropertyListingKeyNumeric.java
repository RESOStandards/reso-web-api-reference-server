package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyListingKeyNumeric {

}
