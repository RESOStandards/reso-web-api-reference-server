package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters
*/
public interface AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters {

}
