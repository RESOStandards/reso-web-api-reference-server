package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLatitude
*/
public interface AnyOforgResoMetadataPropertyLatitude {

}
