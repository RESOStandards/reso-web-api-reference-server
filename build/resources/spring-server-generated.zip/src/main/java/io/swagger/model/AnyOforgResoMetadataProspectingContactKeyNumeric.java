package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingContactKeyNumeric
*/
public interface AnyOforgResoMetadataProspectingContactKeyNumeric {

}
