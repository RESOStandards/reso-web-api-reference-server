package io.swagger.model;


/**
* AnyOforgResoMetadataMemberUpdateMemberStateOrProvince
*/
public interface AnyOforgResoMetadataMemberUpdateMemberStateOrProvince {

}
