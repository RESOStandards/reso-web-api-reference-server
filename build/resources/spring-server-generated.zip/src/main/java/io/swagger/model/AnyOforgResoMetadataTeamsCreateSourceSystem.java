package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateSourceSystem
*/
public interface AnyOforgResoMetadataTeamsCreateSourceSystem {

}
