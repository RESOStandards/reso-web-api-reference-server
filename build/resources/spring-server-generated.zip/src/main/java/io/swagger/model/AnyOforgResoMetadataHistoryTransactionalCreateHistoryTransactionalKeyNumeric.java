package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalCreateHistoryTransactionalKeyNumeric
*/
public interface AnyOforgResoMetadataHistoryTransactionalCreateHistoryTransactionalKeyNumeric {

}
