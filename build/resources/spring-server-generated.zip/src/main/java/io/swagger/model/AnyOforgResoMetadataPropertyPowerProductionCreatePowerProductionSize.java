package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize
*/
public interface AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize {

}
