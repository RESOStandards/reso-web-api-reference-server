package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeSyndicateAgentOption
*/
public interface AnyOforgResoMetadataOfficeSyndicateAgentOption {

}
