package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBuildingAreaTotal
*/
public interface AnyOforgResoMetadataPropertyCreateBuildingAreaTotal {

}
