package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingActorLatitude
*/
public interface AnyOforgResoMetadataInternetTrackingActorLatitude {

}
