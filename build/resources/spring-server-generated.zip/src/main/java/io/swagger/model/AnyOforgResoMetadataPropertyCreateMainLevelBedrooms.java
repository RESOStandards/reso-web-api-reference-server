package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateMainLevelBedrooms
*/
public interface AnyOforgResoMetadataPropertyCreateMainLevelBedrooms {

}
