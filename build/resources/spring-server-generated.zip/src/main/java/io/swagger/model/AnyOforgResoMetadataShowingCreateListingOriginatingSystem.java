package io.swagger.model;


/**
* AnyOforgResoMetadataShowingCreateListingOriginatingSystem
*/
public interface AnyOforgResoMetadataShowingCreateListingOriginatingSystem {

}
