package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLeasableArea
*/
public interface AnyOforgResoMetadataPropertyCreateLeasableArea {

}
