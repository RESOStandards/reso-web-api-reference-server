package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingsContactKeyNumeric
*/
public interface AnyOforgResoMetadataContactListingsContactKeyNumeric {

}
