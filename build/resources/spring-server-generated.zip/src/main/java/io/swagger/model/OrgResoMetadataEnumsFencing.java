package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.Fencing
 */
public enum OrgResoMetadataEnumsFencing {
  BACKYARD("BackYard"),
    BARBEDWIRE("BarbedWire"),
    BLOCK("Block"),
    BRICK("Brick"),
    CHAINLINK("ChainLink"),
    CROSSFENCED("CrossFenced"),
    ELECTRIC("Electric"),
    FENCED("Fenced"),
    FRONTYARD("FrontYard"),
    FULL("Full"),
    GATE("Gate"),
    INVISIBLE("Invisible"),
    MASONRY("Masonry"),
    NONE("None"),
    OTHER("Other"),
    PARTIAL("Partial"),
    PARTIALCROSS("PartialCross"),
    PERIMETER("Perimeter"),
    PIPE("Pipe"),
    PRIVACY("Privacy"),
    SECURITY("Security"),
    SEEREMARKS("SeeRemarks"),
    SLUMPSTONE("SlumpStone"),
    SPLITRAIL("SplitRail"),
    STONE("Stone"),
    VINYL("Vinyl"),
    WIRE("Wire"),
    WOOD("Wood"),
    WROUGHTIRON("WroughtIron");

  private String value;

  OrgResoMetadataEnumsFencing(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsFencing fromValue(String text) {
    for (OrgResoMetadataEnumsFencing b : OrgResoMetadataEnumsFencing.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
