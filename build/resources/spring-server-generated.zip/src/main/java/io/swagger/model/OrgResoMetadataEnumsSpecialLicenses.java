package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.SpecialLicenses
 */
public enum OrgResoMetadataEnumsSpecialLicenses {
  BEERWINE("BeerWine"),
    CLASSH("ClassH"),
    ENTERTAINMENT("Entertainment"),
    FRANCHISE("Franchise"),
    GAMBLING("Gambling"),
    LIQUOR("Liquor"),
    LIQUOR5YEARSORLESS("Liquor5YearsOrLess"),
    LIQUOR5YEARSORMORE("Liquor5YearsOrMore"),
    LIQUOROFFSALE("LiquorOffSale"),
    LIQUORONSALE("LiquorOnSale"),
    NONE("None"),
    OTHER("Other"),
    PROFESSIONAL("Professional");

  private String value;

  OrgResoMetadataEnumsSpecialLicenses(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsSpecialLicenses fromValue(String text) {
    for (OrgResoMetadataEnumsSpecialLicenses b : OrgResoMetadataEnumsSpecialLicenses.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
