package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.PropertySubType
 */
public enum OrgResoMetadataEnumsPropertySubType {
  AGRICULTURE("Agriculture"),
    APARTMENT("Apartment"),
    BOATSLIP("BoatSlip"),
    BUSINESS("Business"),
    CABIN("Cabin"),
    CONDOMINIUM("Condominium"),
    DEEDEDPARKING("DeededParking"),
    DUPLEX("Duplex"),
    FARM("Farm"),
    HOTELMOTEL("HotelMotel"),
    INDUSTRIAL("Industrial"),
    MANUFACTUREDHOME("ManufacturedHome"),
    MANUFACTUREDONLAND("ManufacturedOnLand"),
    MIXEDUSE("MixedUse"),
    MOBILEHOME("MobileHome"),
    MULTIFAMILY("MultiFamily"),
    OFFICE("Office"),
    OWNYOUROWN("OwnYourOwn"),
    QUADRUPLEX("Quadruplex"),
    RANCH("Ranch"),
    RETAIL("Retail"),
    SINGLEFAMILYRESIDENCE("SingleFamilyResidence"),
    STOCKCOOPERATIVE("StockCooperative"),
    TIMESHARE("Timeshare"),
    TOWNHOUSE("Townhouse"),
    TRIPLEX("Triplex"),
    UNIMPROVEDLAND("UnimprovedLand"),
    WAREHOUSE("Warehouse");

  private String value;

  OrgResoMetadataEnumsPropertySubType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsPropertySubType fromValue(String text) {
    for (OrgResoMetadataEnumsPropertySubType b : OrgResoMetadataEnumsPropertySubType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
