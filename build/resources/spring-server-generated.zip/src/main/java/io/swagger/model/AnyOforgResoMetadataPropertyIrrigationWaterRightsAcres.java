package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres
*/
public interface AnyOforgResoMetadataPropertyIrrigationWaterRightsAcres {

}
