package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOtherPhoneCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOtherPhoneCreate   {
  @JsonProperty("ClassName")
  private AnyOforgResoMetadataOtherPhoneCreateClassName className = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OtherPhoneExt")
  private String otherPhoneExt = null;

  @JsonProperty("OtherPhoneKey")
  private String otherPhoneKey = null;

  @JsonProperty("OtherPhoneKeyNumeric")
  private AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric otherPhoneKeyNumeric = null;

  @JsonProperty("OtherPhoneNumber")
  private String otherPhoneNumber = null;

  @JsonProperty("OtherPhoneType")
  private AnyOforgResoMetadataOtherPhoneCreateOtherPhoneType otherPhoneType = null;

  @JsonProperty("ResourceName")
  private AnyOforgResoMetadataOtherPhoneCreateResourceName resourceName = null;

  @JsonProperty("ResourceRecordID")
  private String resourceRecordID = null;

  @JsonProperty("ResourceRecordKey")
  private String resourceRecordKey = null;

  @JsonProperty("ResourceRecordKeyNumeric")
  private AnyOforgResoMetadataOtherPhoneCreateResourceRecordKeyNumeric resourceRecordKeyNumeric = null;

  public OrgResoMetadataOtherPhoneCreate className(AnyOforgResoMetadataOtherPhoneCreateClassName className) {
    this.className = className;
    return this;
  }

  /**
   * Get className
   * @return className
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneCreateClassName getClassName() {
    return className;
  }

  public void setClassName(AnyOforgResoMetadataOtherPhoneCreateClassName className) {
    this.className = className;
  }

  public OrgResoMetadataOtherPhoneCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOtherPhoneCreate otherPhoneExt(String otherPhoneExt) {
    this.otherPhoneExt = otherPhoneExt;
    return this;
  }

  /**
   * Get otherPhoneExt
   * @return otherPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOtherPhoneExt() {
    return otherPhoneExt;
  }

  public void setOtherPhoneExt(String otherPhoneExt) {
    this.otherPhoneExt = otherPhoneExt;
  }

  public OrgResoMetadataOtherPhoneCreate otherPhoneKey(String otherPhoneKey) {
    this.otherPhoneKey = otherPhoneKey;
    return this;
  }

  /**
   * Get otherPhoneKey
   * @return otherPhoneKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getOtherPhoneKey() {
    return otherPhoneKey;
  }

  public void setOtherPhoneKey(String otherPhoneKey) {
    this.otherPhoneKey = otherPhoneKey;
  }

  public OrgResoMetadataOtherPhoneCreate otherPhoneKeyNumeric(AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric otherPhoneKeyNumeric) {
    this.otherPhoneKeyNumeric = otherPhoneKeyNumeric;
    return this;
  }

  /**
   * Get otherPhoneKeyNumeric
   * @return otherPhoneKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric getOtherPhoneKeyNumeric() {
    return otherPhoneKeyNumeric;
  }

  public void setOtherPhoneKeyNumeric(AnyOforgResoMetadataOtherPhoneCreateOtherPhoneKeyNumeric otherPhoneKeyNumeric) {
    this.otherPhoneKeyNumeric = otherPhoneKeyNumeric;
  }

  public OrgResoMetadataOtherPhoneCreate otherPhoneNumber(String otherPhoneNumber) {
    this.otherPhoneNumber = otherPhoneNumber;
    return this;
  }

  /**
   * Get otherPhoneNumber
   * @return otherPhoneNumber
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOtherPhoneNumber() {
    return otherPhoneNumber;
  }

  public void setOtherPhoneNumber(String otherPhoneNumber) {
    this.otherPhoneNumber = otherPhoneNumber;
  }

  public OrgResoMetadataOtherPhoneCreate otherPhoneType(AnyOforgResoMetadataOtherPhoneCreateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
    return this;
  }

  /**
   * Get otherPhoneType
   * @return otherPhoneType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneCreateOtherPhoneType getOtherPhoneType() {
    return otherPhoneType;
  }

  public void setOtherPhoneType(AnyOforgResoMetadataOtherPhoneCreateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
  }

  public OrgResoMetadataOtherPhoneCreate resourceName(AnyOforgResoMetadataOtherPhoneCreateResourceName resourceName) {
    this.resourceName = resourceName;
    return this;
  }

  /**
   * Get resourceName
   * @return resourceName
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneCreateResourceName getResourceName() {
    return resourceName;
  }

  public void setResourceName(AnyOforgResoMetadataOtherPhoneCreateResourceName resourceName) {
    this.resourceName = resourceName;
  }

  public OrgResoMetadataOtherPhoneCreate resourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
    return this;
  }

  /**
   * Get resourceRecordID
   * @return resourceRecordID
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordID() {
    return resourceRecordID;
  }

  public void setResourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
  }

  public OrgResoMetadataOtherPhoneCreate resourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
    return this;
  }

  /**
   * Get resourceRecordKey
   * @return resourceRecordKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordKey() {
    return resourceRecordKey;
  }

  public void setResourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
  }

  public OrgResoMetadataOtherPhoneCreate resourceRecordKeyNumeric(AnyOforgResoMetadataOtherPhoneCreateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
    return this;
  }

  /**
   * Get resourceRecordKeyNumeric
   * @return resourceRecordKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOtherPhoneCreateResourceRecordKeyNumeric getResourceRecordKeyNumeric() {
    return resourceRecordKeyNumeric;
  }

  public void setResourceRecordKeyNumeric(AnyOforgResoMetadataOtherPhoneCreateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOtherPhoneCreate orgResoMetadataOtherPhoneCreate = (OrgResoMetadataOtherPhoneCreate) o;
    return Objects.equals(this.className, orgResoMetadataOtherPhoneCreate.className) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOtherPhoneCreate.modificationTimestamp) &&
        Objects.equals(this.otherPhoneExt, orgResoMetadataOtherPhoneCreate.otherPhoneExt) &&
        Objects.equals(this.otherPhoneKey, orgResoMetadataOtherPhoneCreate.otherPhoneKey) &&
        Objects.equals(this.otherPhoneKeyNumeric, orgResoMetadataOtherPhoneCreate.otherPhoneKeyNumeric) &&
        Objects.equals(this.otherPhoneNumber, orgResoMetadataOtherPhoneCreate.otherPhoneNumber) &&
        Objects.equals(this.otherPhoneType, orgResoMetadataOtherPhoneCreate.otherPhoneType) &&
        Objects.equals(this.resourceName, orgResoMetadataOtherPhoneCreate.resourceName) &&
        Objects.equals(this.resourceRecordID, orgResoMetadataOtherPhoneCreate.resourceRecordID) &&
        Objects.equals(this.resourceRecordKey, orgResoMetadataOtherPhoneCreate.resourceRecordKey) &&
        Objects.equals(this.resourceRecordKeyNumeric, orgResoMetadataOtherPhoneCreate.resourceRecordKeyNumeric);
  }

  @Override
  public int hashCode() {
    return Objects.hash(className, modificationTimestamp, otherPhoneExt, otherPhoneKey, otherPhoneKeyNumeric, otherPhoneNumber, otherPhoneType, resourceName, resourceRecordID, resourceRecordKey, resourceRecordKeyNumeric);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOtherPhoneCreate {\n");
    
    sb.append("    className: ").append(toIndentedString(className)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    otherPhoneExt: ").append(toIndentedString(otherPhoneExt)).append("\n");
    sb.append("    otherPhoneKey: ").append(toIndentedString(otherPhoneKey)).append("\n");
    sb.append("    otherPhoneKeyNumeric: ").append(toIndentedString(otherPhoneKeyNumeric)).append("\n");
    sb.append("    otherPhoneNumber: ").append(toIndentedString(otherPhoneNumber)).append("\n");
    sb.append("    otherPhoneType: ").append(toIndentedString(otherPhoneType)).append("\n");
    sb.append("    resourceName: ").append(toIndentedString(resourceName)).append("\n");
    sb.append("    resourceRecordID: ").append(toIndentedString(resourceRecordID)).append("\n");
    sb.append("    resourceRecordKey: ").append(toIndentedString(resourceRecordKey)).append("\n");
    sb.append("    resourceRecordKeyNumeric: ").append(toIndentedString(resourceRecordKeyNumeric)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
