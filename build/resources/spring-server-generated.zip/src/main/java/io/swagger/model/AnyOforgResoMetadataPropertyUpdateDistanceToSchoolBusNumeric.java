package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusNumeric {

}
