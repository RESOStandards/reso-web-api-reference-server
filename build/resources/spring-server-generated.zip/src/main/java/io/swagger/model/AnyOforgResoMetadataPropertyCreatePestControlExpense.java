package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreatePestControlExpense
*/
public interface AnyOforgResoMetadataPropertyCreatePestControlExpense {

}
