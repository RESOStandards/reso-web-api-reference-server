package io.swagger.model;


/**
* AnyOforgResoMetadataMemberOriginatingSystem
*/
public interface AnyOforgResoMetadataMemberOriginatingSystem {

}
