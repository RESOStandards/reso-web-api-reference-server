package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateTeamLeadKeyNumeric
*/
public interface AnyOforgResoMetadataTeamsCreateTeamLeadKeyNumeric {

}
