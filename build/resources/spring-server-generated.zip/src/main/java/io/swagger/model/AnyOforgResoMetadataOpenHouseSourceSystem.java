package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseSourceSystem
*/
public interface AnyOforgResoMetadataOpenHouseSourceSystem {

}
