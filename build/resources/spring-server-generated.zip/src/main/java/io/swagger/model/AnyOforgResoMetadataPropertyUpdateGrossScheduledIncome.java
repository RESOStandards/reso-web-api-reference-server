package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome
*/
public interface AnyOforgResoMetadataPropertyUpdateGrossScheduledIncome {

}
