package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice
*/
public interface AnyOforgResoMetadataPropertyUpdateShowingAdvanceNotice {

}
