package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.ImageOf
 */
public enum OrgResoMetadataEnumsImageOf {
  AERIALVIEW("AerialView"),
    ATRIUM("Atrium"),
    ATTIC("Attic"),
    BACKOFSTRUCTURE("BackOfStructure"),
    BALCONY("Balcony"),
    BAR("Bar"),
    BARN("Barn"),
    BASEMENT("Basement"),
    BATHROOM("Bathroom"),
    BEDROOM("Bedroom"),
    BONUSROOM("BonusRoom"),
    BREAKFASTAREA("BreakfastArea"),
    CLOSET("Closet"),
    COMMUNITY("Community"),
    COURTYARD("Courtyard"),
    DECK("Deck"),
    DEN("Den"),
    DININGAREA("DiningArea"),
    DININGROOM("DiningRoom"),
    DOCK("Dock"),
    ENTRY("Entry"),
    EXERCISEROOM("ExerciseRoom"),
    FAMILYROOM("FamilyRoom"),
    FENCE("Fence"),
    FIREPLACE("Fireplace"),
    FLOORPLAN("FloorPlan"),
    FRONTOFSTRUCTURE("FrontOfStructure"),
    GAMEROOM("GameRoom"),
    GARAGE("Garage"),
    GARDEN("Garden"),
    GOLFCOURSE("GolfCourse"),
    GREATROOM("GreatRoom"),
    GUESTQUARTERS("GuestQuarters"),
    GYM("Gym"),
    HOBBYROOM("HobbyRoom"),
    INLAW("Inlaw"),
    KITCHEN("Kitchen"),
    LAKE("Lake"),
    LAUNDRY("Laundry"),
    LIBRARY("Library"),
    LIVINGROOM("LivingRoom"),
    LOADINGDOCK("LoadingDock"),
    LOBBY("Lobby"),
    LOFT("Loft"),
    LOT("Lot"),
    MASTERBATHROOM("MasterBathroom"),
    MASTERBEDROOM("MasterBedroom"),
    MEDIAROOM("MediaRoom"),
    MUDROOM("MudRoom"),
    NURSERY("Nursery"),
    OFFICE("Office"),
    OTHER("Other"),
    OUTBUILDINGS("OutBuildings"),
    PANTRY("Pantry"),
    PARKING("Parking"),
    PATIO("Patio"),
    PIER("Pier"),
    PLATMAP("PlatMap"),
    POND("Pond"),
    POOL("Pool"),
    RECEPTION("Reception"),
    RECREATIONROOM("RecreationRoom"),
    SAUNA("Sauna"),
    SHOWROOM("Showroom"),
    SIDEOFSTRUCTURE("SideOfStructure"),
    SITTINGROOM("SittingRoom"),
    SPA("Spa"),
    STABLE("Stable"),
    STORAGE("Storage"),
    STUDIO("Studio"),
    STUDY("Study"),
    SUNROOM("SunRoom"),
    VIEW("View"),
    WATERFRONT("Waterfront"),
    WINECELLAR("WineCellar"),
    WORKSHOP("Workshop"),
    YARD("Yard");

  private String value;

  OrgResoMetadataEnumsImageOf(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsImageOf fromValue(String text) {
    for (OrgResoMetadataEnumsImageOf b : OrgResoMetadataEnumsImageOf.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
