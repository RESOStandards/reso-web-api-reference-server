package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyTaxYear
*/
public interface AnyOforgResoMetadataPropertyTaxYear {

}
