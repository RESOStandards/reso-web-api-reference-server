package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateEventTarget
*/
public interface AnyOforgResoMetadataInternetTrackingCreateEventTarget {

}
