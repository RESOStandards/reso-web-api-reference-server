package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.Flooring
 */
public enum OrgResoMetadataEnumsFlooring {
  ADOBE("Adobe"),
    BAMBOO("Bamboo"),
    BRICK("Brick"),
    CARPET("Carpet"),
    CERAMICTILE("CeramicTile"),
    CLAY("Clay"),
    COMBINATION("Combination"),
    CONCRETE("Concrete"),
    CORK("Cork"),
    CRIGREENLABELPLUSCERTIFIEDCARPET("CriGreenLabelPlusCertifiedCarpet"),
    DIRT("Dirt"),
    FLOORSCORECERTIFIEDFLOORING("FloorscoreCertifiedFlooring"),
    FSCORSFICERTIFIEDSOURCEHARDWOOD("FscOrSfiCertifiedSourceHardwood"),
    GRANITE("Granite"),
    HARDWOOD("Hardwood"),
    LAMINATE("Laminate"),
    LINOLEUM("Linoleum"),
    MARBLE("Marble"),
    NONE("None"),
    OTHER("Other"),
    PAINTEDSTAINED("PaintedStained"),
    PARQUET("Parquet"),
    PAVERS("Pavers"),
    RECLAIMEDWOOD("ReclaimedWood"),
    SEEREMARKS("SeeRemarks"),
    SIMULATEDWOOD("SimulatedWood"),
    SLATE("Slate"),
    SOFTWOOD("Softwood"),
    STAMPED("Stamped"),
    STONE("Stone"),
    SUSTAINABLE("Sustainable"),
    TERRAZZO("Terrazzo"),
    TILE("Tile"),
    VARIES("Varies"),
    VINYL("Vinyl"),
    WOOD("Wood");

  private String value;

  OrgResoMetadataEnumsFlooring(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsFlooring fromValue(String text) {
    for (OrgResoMetadataEnumsFlooring b : OrgResoMetadataEnumsFlooring.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
