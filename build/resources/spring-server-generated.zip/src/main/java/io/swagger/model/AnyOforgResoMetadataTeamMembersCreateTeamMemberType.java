package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersCreateTeamMemberType
*/
public interface AnyOforgResoMetadataTeamMembersCreateTeamMemberType {

}
