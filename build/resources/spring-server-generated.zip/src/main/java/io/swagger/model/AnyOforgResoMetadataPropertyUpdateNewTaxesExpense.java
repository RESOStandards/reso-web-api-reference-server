package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateNewTaxesExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateNewTaxesExpense {

}
