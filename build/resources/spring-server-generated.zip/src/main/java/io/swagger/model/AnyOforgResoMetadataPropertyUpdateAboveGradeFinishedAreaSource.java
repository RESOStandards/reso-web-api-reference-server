package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource
*/
public interface AnyOforgResoMetadataPropertyUpdateAboveGradeFinishedAreaSource {

}
