package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchCreateSourceSystem
*/
public interface AnyOforgResoMetadataSavedSearchCreateSourceSystem {

}
