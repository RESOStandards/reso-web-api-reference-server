package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres
*/
public interface AnyOforgResoMetadataPropertyUpdateIrrigationWaterRightsAcres {

}
