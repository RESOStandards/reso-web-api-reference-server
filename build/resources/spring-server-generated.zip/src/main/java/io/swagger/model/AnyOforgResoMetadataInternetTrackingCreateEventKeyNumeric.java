package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateEventKeyNumeric
*/
public interface AnyOforgResoMetadataInternetTrackingCreateEventKeyNumeric {

}
