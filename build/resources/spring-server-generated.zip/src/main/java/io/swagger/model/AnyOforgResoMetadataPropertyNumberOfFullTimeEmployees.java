package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees
*/
public interface AnyOforgResoMetadataPropertyNumberOfFullTimeEmployees {

}
