package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateListingAgreement
*/
public interface AnyOforgResoMetadataPropertyCreateListingAgreement {

}
