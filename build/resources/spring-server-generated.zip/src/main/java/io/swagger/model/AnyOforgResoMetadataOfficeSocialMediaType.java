package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeSocialMediaType
*/
public interface AnyOforgResoMetadataOfficeSocialMediaType {

}
