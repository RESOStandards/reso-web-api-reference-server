package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingNotesContact
*/
public interface AnyOforgResoMetadataContactListingNotesContact {

}
