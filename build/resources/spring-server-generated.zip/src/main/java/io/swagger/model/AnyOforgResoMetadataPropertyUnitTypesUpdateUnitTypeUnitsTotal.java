package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUpdateUnitTypeUnitsTotal
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUpdateUnitTypeUnitsTotal {

}
