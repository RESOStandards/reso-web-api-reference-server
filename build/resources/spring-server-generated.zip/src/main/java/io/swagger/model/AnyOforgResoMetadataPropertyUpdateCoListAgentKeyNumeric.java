package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateCoListAgentKeyNumeric {

}
