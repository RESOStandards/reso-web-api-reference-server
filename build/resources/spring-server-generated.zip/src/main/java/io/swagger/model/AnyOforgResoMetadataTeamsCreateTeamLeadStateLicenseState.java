package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateTeamLeadStateLicenseState
*/
public interface AnyOforgResoMetadataTeamsCreateTeamLeadStateLicenseState {

}
