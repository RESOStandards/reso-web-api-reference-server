package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingUpdateOwnerMemberKeyNumeric
*/
public interface AnyOforgResoMetadataProspectingUpdateOwnerMemberKeyNumeric {

}
