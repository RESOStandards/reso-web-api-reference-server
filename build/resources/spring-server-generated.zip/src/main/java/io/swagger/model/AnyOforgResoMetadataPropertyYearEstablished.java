package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyYearEstablished
*/
public interface AnyOforgResoMetadataPropertyYearEstablished {

}
