package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateBuyerTeamKeyNumeric {

}
