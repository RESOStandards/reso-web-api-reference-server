package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma
*/
public interface AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma {

}
