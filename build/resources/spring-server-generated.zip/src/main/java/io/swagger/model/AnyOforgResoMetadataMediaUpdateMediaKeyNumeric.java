package io.swagger.model;


/**
* AnyOforgResoMetadataMediaUpdateMediaKeyNumeric
*/
public interface AnyOforgResoMetadataMediaUpdateMediaKeyNumeric {

}
