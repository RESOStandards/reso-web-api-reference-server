package io.swagger.model;


/**
* AnyOforgResoMetadataContactsContactKeyNumeric
*/
public interface AnyOforgResoMetadataContactsContactKeyNumeric {

}
