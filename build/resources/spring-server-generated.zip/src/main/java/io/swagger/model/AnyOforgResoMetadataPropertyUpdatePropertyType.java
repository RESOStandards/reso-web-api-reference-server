package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdatePropertyType
*/
public interface AnyOforgResoMetadataPropertyUpdatePropertyType {

}
