package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.ChangeType
 */
public enum OrgResoMetadataEnumsChangeType {
  ACTIVE("Active"),
    ACTIVEUNDERCONTRACT("ActiveUnderContract"),
    BACKONMARKET("BackOnMarket"),
    CANCELED("Canceled"),
    CLOSED("Closed"),
    DELETED("Deleted"),
    EXPIRED("Expired"),
    HOLD("Hold"),
    NEWLISTING("NewListing"),
    PENDING("Pending"),
    PRICECHANGE("PriceChange"),
    WITHDRAWN("Withdrawn");

  private String value;

  OrgResoMetadataEnumsChangeType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsChangeType fromValue(String text) {
    for (OrgResoMetadataEnumsChangeType b : OrgResoMetadataEnumsChangeType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
