package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataPropertyPowerProductionCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataPropertyPowerProductionCreate   {
  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyPowerProductionCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("PowerProductionAnnual")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnual powerProductionAnnual = null;

  @JsonProperty("PowerProductionAnnualStatus")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus powerProductionAnnualStatus = null;

  @JsonProperty("PowerProductionKey")
  private String powerProductionKey = null;

  @JsonProperty("PowerProductionKeyNumeric")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionKeyNumeric powerProductionKeyNumeric = null;

  @JsonProperty("PowerProductionSize")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize powerProductionSize = null;

  @JsonProperty("PowerProductionType")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionType powerProductionType = null;

  @JsonProperty("PowerProductionYearInstall")
  private AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionYearInstall powerProductionYearInstall = null;

  @JsonProperty("Listing")
  private AnyOforgResoMetadataPropertyPowerProductionCreateListing listing = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  public OrgResoMetadataPropertyPowerProductionCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataPropertyPowerProductionCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataPropertyPowerProductionCreate listingKeyNumeric(AnyOforgResoMetadataPropertyPowerProductionCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyPowerProductionCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataPropertyPowerProductionCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionAnnual(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnual powerProductionAnnual) {
    this.powerProductionAnnual = powerProductionAnnual;
    return this;
  }

  /**
   * Get powerProductionAnnual
   * @return powerProductionAnnual
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnual getPowerProductionAnnual() {
    return powerProductionAnnual;
  }

  public void setPowerProductionAnnual(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnual powerProductionAnnual) {
    this.powerProductionAnnual = powerProductionAnnual;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionAnnualStatus(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus powerProductionAnnualStatus) {
    this.powerProductionAnnualStatus = powerProductionAnnualStatus;
    return this;
  }

  /**
   * Get powerProductionAnnualStatus
   * @return powerProductionAnnualStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus getPowerProductionAnnualStatus() {
    return powerProductionAnnualStatus;
  }

  public void setPowerProductionAnnualStatus(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionAnnualStatus powerProductionAnnualStatus) {
    this.powerProductionAnnualStatus = powerProductionAnnualStatus;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionKey(String powerProductionKey) {
    this.powerProductionKey = powerProductionKey;
    return this;
  }

  /**
   * Get powerProductionKey
   * @return powerProductionKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getPowerProductionKey() {
    return powerProductionKey;
  }

  public void setPowerProductionKey(String powerProductionKey) {
    this.powerProductionKey = powerProductionKey;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionKeyNumeric(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionKeyNumeric powerProductionKeyNumeric) {
    this.powerProductionKeyNumeric = powerProductionKeyNumeric;
    return this;
  }

  /**
   * Get powerProductionKeyNumeric
   * @return powerProductionKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionKeyNumeric getPowerProductionKeyNumeric() {
    return powerProductionKeyNumeric;
  }

  public void setPowerProductionKeyNumeric(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionKeyNumeric powerProductionKeyNumeric) {
    this.powerProductionKeyNumeric = powerProductionKeyNumeric;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionSize(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize powerProductionSize) {
    this.powerProductionSize = powerProductionSize;
    return this;
  }

  /**
   * Get powerProductionSize
   * @return powerProductionSize
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize getPowerProductionSize() {
    return powerProductionSize;
  }

  public void setPowerProductionSize(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionSize powerProductionSize) {
    this.powerProductionSize = powerProductionSize;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionType(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionType powerProductionType) {
    this.powerProductionType = powerProductionType;
    return this;
  }

  /**
   * Get powerProductionType
   * @return powerProductionType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionType getPowerProductionType() {
    return powerProductionType;
  }

  public void setPowerProductionType(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionType powerProductionType) {
    this.powerProductionType = powerProductionType;
  }

  public OrgResoMetadataPropertyPowerProductionCreate powerProductionYearInstall(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionYearInstall powerProductionYearInstall) {
    this.powerProductionYearInstall = powerProductionYearInstall;
    return this;
  }

  /**
   * Get powerProductionYearInstall
   * @return powerProductionYearInstall
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionYearInstall getPowerProductionYearInstall() {
    return powerProductionYearInstall;
  }

  public void setPowerProductionYearInstall(AnyOforgResoMetadataPropertyPowerProductionCreatePowerProductionYearInstall powerProductionYearInstall) {
    this.powerProductionYearInstall = powerProductionYearInstall;
  }

  public OrgResoMetadataPropertyPowerProductionCreate listing(AnyOforgResoMetadataPropertyPowerProductionCreateListing listing) {
    this.listing = listing;
    return this;
  }

  /**
   * Get listing
   * @return listing
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyPowerProductionCreateListing getListing() {
    return listing;
  }

  public void setListing(AnyOforgResoMetadataPropertyPowerProductionCreateListing listing) {
    this.listing = listing;
  }

  public OrgResoMetadataPropertyPowerProductionCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataPropertyPowerProductionCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataPropertyPowerProductionCreate orgResoMetadataPropertyPowerProductionCreate = (OrgResoMetadataPropertyPowerProductionCreate) o;
    return Objects.equals(this.listingId, orgResoMetadataPropertyPowerProductionCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataPropertyPowerProductionCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataPropertyPowerProductionCreate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataPropertyPowerProductionCreate.modificationTimestamp) &&
        Objects.equals(this.powerProductionAnnual, orgResoMetadataPropertyPowerProductionCreate.powerProductionAnnual) &&
        Objects.equals(this.powerProductionAnnualStatus, orgResoMetadataPropertyPowerProductionCreate.powerProductionAnnualStatus) &&
        Objects.equals(this.powerProductionKey, orgResoMetadataPropertyPowerProductionCreate.powerProductionKey) &&
        Objects.equals(this.powerProductionKeyNumeric, orgResoMetadataPropertyPowerProductionCreate.powerProductionKeyNumeric) &&
        Objects.equals(this.powerProductionSize, orgResoMetadataPropertyPowerProductionCreate.powerProductionSize) &&
        Objects.equals(this.powerProductionType, orgResoMetadataPropertyPowerProductionCreate.powerProductionType) &&
        Objects.equals(this.powerProductionYearInstall, orgResoMetadataPropertyPowerProductionCreate.powerProductionYearInstall) &&
        Objects.equals(this.listing, orgResoMetadataPropertyPowerProductionCreate.listing) &&
        Objects.equals(this.historyTransactional, orgResoMetadataPropertyPowerProductionCreate.historyTransactional);
  }

  @Override
  public int hashCode() {
    return Objects.hash(listingId, listingKey, listingKeyNumeric, modificationTimestamp, powerProductionAnnual, powerProductionAnnualStatus, powerProductionKey, powerProductionKeyNumeric, powerProductionSize, powerProductionType, powerProductionYearInstall, listing, historyTransactional);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataPropertyPowerProductionCreate {\n");
    
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    powerProductionAnnual: ").append(toIndentedString(powerProductionAnnual)).append("\n");
    sb.append("    powerProductionAnnualStatus: ").append(toIndentedString(powerProductionAnnualStatus)).append("\n");
    sb.append("    powerProductionKey: ").append(toIndentedString(powerProductionKey)).append("\n");
    sb.append("    powerProductionKeyNumeric: ").append(toIndentedString(powerProductionKeyNumeric)).append("\n");
    sb.append("    powerProductionSize: ").append(toIndentedString(powerProductionSize)).append("\n");
    sb.append("    powerProductionType: ").append(toIndentedString(powerProductionType)).append("\n");
    sb.append("    powerProductionYearInstall: ").append(toIndentedString(powerProductionYearInstall)).append("\n");
    sb.append("    listing: ").append(toIndentedString(listing)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
