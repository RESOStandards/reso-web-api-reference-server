package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionPowerProductionYearInstall
*/
public interface AnyOforgResoMetadataPropertyPowerProductionPowerProductionYearInstall {

}
