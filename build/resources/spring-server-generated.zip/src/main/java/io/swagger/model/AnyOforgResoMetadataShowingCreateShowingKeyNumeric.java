package io.swagger.model;


/**
* AnyOforgResoMetadataShowingCreateShowingKeyNumeric
*/
public interface AnyOforgResoMetadataShowingCreateShowingKeyNumeric {

}
