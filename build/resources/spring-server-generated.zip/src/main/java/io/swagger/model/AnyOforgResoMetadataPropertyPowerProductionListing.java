package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionListing
*/
public interface AnyOforgResoMetadataPropertyPowerProductionListing {

}
