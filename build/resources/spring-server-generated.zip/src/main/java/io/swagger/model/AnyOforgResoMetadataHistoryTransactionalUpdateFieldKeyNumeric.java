package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalUpdateFieldKeyNumeric
*/
public interface AnyOforgResoMetadataHistoryTransactionalUpdateFieldKeyNumeric {

}
