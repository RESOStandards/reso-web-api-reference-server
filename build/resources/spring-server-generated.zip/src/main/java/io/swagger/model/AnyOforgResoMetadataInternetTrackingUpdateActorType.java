package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateActorType
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateActorType {

}
