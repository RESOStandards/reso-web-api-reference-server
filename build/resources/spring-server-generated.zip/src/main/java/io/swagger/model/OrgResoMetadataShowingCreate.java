package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.model.OrgResoMetadataSocialMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataShowingCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataShowingCreate   {
  @JsonProperty("AgentOriginatingSystemID")
  private String agentOriginatingSystemID = null;

  @JsonProperty("AgentOriginatingSystemName")
  private String agentOriginatingSystemName = null;

  @JsonProperty("AgentSourceSystemID")
  private String agentSourceSystemID = null;

  @JsonProperty("AgentSourceSystemName")
  private String agentSourceSystemName = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataShowingCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ListingOriginatingSystemID")
  private String listingOriginatingSystemID = null;

  @JsonProperty("ListingOriginatingSystemName")
  private String listingOriginatingSystemName = null;

  @JsonProperty("ListingSourceSystemID")
  private String listingSourceSystemID = null;

  @JsonProperty("ListingSourceSystemName")
  private String listingSourceSystemName = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemAgentKey")
  private String originatingSystemAgentKey = null;

  @JsonProperty("OriginatingSystemListingKey")
  private String originatingSystemListingKey = null;

  @JsonProperty("OriginatingSystemShowingKey")
  private String originatingSystemShowingKey = null;

  @JsonProperty("ShowingAgentKey")
  private String showingAgentKey = null;

  @JsonProperty("ShowingAgentKeyNumeric")
  private AnyOforgResoMetadataShowingCreateShowingAgentKeyNumeric showingAgentKeyNumeric = null;

  @JsonProperty("ShowingAgentMlsID")
  private String showingAgentMlsID = null;

  @JsonProperty("ShowingEndTimestamp")
  private OffsetDateTime showingEndTimestamp = null;

  @JsonProperty("ShowingId")
  private String showingId = null;

  @JsonProperty("ShowingKey")
  private String showingKey = null;

  @JsonProperty("ShowingKeyNumeric")
  private AnyOforgResoMetadataShowingCreateShowingKeyNumeric showingKeyNumeric = null;

  @JsonProperty("ShowingOriginatingSystemID")
  private String showingOriginatingSystemID = null;

  @JsonProperty("ShowingOriginatingSystemName")
  private String showingOriginatingSystemName = null;

  @JsonProperty("ShowingRequestedTimestamp")
  private OffsetDateTime showingRequestedTimestamp = null;

  @JsonProperty("ShowingSourceSystemID")
  private String showingSourceSystemID = null;

  @JsonProperty("ShowingSourceSystemName")
  private String showingSourceSystemName = null;

  @JsonProperty("ShowingStartTimestamp")
  private OffsetDateTime showingStartTimestamp = null;

  @JsonProperty("SourceSystemAgentKey")
  private String sourceSystemAgentKey = null;

  @JsonProperty("SourceSystemListingKey")
  private String sourceSystemListingKey = null;

  @JsonProperty("SourceSystemShowingKey")
  private String sourceSystemShowingKey = null;

  @JsonProperty("AgentOriginatingSystem")
  private AnyOforgResoMetadataShowingCreateAgentOriginatingSystem agentOriginatingSystem = null;

  @JsonProperty("AgentSourceSystem")
  private AnyOforgResoMetadataShowingCreateAgentSourceSystem agentSourceSystem = null;

  @JsonProperty("ShowingAgent")
  private AnyOforgResoMetadataShowingCreateShowingAgent showingAgent = null;

  @JsonProperty("Listing")
  private AnyOforgResoMetadataShowingCreateListing listing = null;

  @JsonProperty("ListingOriginatingSystem")
  private AnyOforgResoMetadataShowingCreateListingOriginatingSystem listingOriginatingSystem = null;

  @JsonProperty("ListingSourceSystem")
  private AnyOforgResoMetadataShowingCreateListingSourceSystem listingSourceSystem = null;

  @JsonProperty("ShowingOriginatingSystem")
  private AnyOforgResoMetadataShowingCreateShowingOriginatingSystem showingOriginatingSystem = null;

  @JsonProperty("ShowingSourceSystem")
  private AnyOforgResoMetadataShowingCreateShowingSourceSystem showingSourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMediaCreate> socialMedia = null;

  public OrgResoMetadataShowingCreate agentOriginatingSystemID(String agentOriginatingSystemID) {
    this.agentOriginatingSystemID = agentOriginatingSystemID;
    return this;
  }

  /**
   * Get agentOriginatingSystemID
   * @return agentOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getAgentOriginatingSystemID() {
    return agentOriginatingSystemID;
  }

  public void setAgentOriginatingSystemID(String agentOriginatingSystemID) {
    this.agentOriginatingSystemID = agentOriginatingSystemID;
  }

  public OrgResoMetadataShowingCreate agentOriginatingSystemName(String agentOriginatingSystemName) {
    this.agentOriginatingSystemName = agentOriginatingSystemName;
    return this;
  }

  /**
   * Get agentOriginatingSystemName
   * @return agentOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getAgentOriginatingSystemName() {
    return agentOriginatingSystemName;
  }

  public void setAgentOriginatingSystemName(String agentOriginatingSystemName) {
    this.agentOriginatingSystemName = agentOriginatingSystemName;
  }

  public OrgResoMetadataShowingCreate agentSourceSystemID(String agentSourceSystemID) {
    this.agentSourceSystemID = agentSourceSystemID;
    return this;
  }

  /**
   * Get agentSourceSystemID
   * @return agentSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getAgentSourceSystemID() {
    return agentSourceSystemID;
  }

  public void setAgentSourceSystemID(String agentSourceSystemID) {
    this.agentSourceSystemID = agentSourceSystemID;
  }

  public OrgResoMetadataShowingCreate agentSourceSystemName(String agentSourceSystemName) {
    this.agentSourceSystemName = agentSourceSystemName;
    return this;
  }

  /**
   * Get agentSourceSystemName
   * @return agentSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getAgentSourceSystemName() {
    return agentSourceSystemName;
  }

  public void setAgentSourceSystemName(String agentSourceSystemName) {
    this.agentSourceSystemName = agentSourceSystemName;
  }

  public OrgResoMetadataShowingCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataShowingCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataShowingCreate listingKeyNumeric(AnyOforgResoMetadataShowingCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataShowingCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataShowingCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataShowingCreate listingOriginatingSystemID(String listingOriginatingSystemID) {
    this.listingOriginatingSystemID = listingOriginatingSystemID;
    return this;
  }

  /**
   * Get listingOriginatingSystemID
   * @return listingOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListingOriginatingSystemID() {
    return listingOriginatingSystemID;
  }

  public void setListingOriginatingSystemID(String listingOriginatingSystemID) {
    this.listingOriginatingSystemID = listingOriginatingSystemID;
  }

  public OrgResoMetadataShowingCreate listingOriginatingSystemName(String listingOriginatingSystemName) {
    this.listingOriginatingSystemName = listingOriginatingSystemName;
    return this;
  }

  /**
   * Get listingOriginatingSystemName
   * @return listingOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingOriginatingSystemName() {
    return listingOriginatingSystemName;
  }

  public void setListingOriginatingSystemName(String listingOriginatingSystemName) {
    this.listingOriginatingSystemName = listingOriginatingSystemName;
  }

  public OrgResoMetadataShowingCreate listingSourceSystemID(String listingSourceSystemID) {
    this.listingSourceSystemID = listingSourceSystemID;
    return this;
  }

  /**
   * Get listingSourceSystemID
   * @return listingSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListingSourceSystemID() {
    return listingSourceSystemID;
  }

  public void setListingSourceSystemID(String listingSourceSystemID) {
    this.listingSourceSystemID = listingSourceSystemID;
  }

  public OrgResoMetadataShowingCreate listingSourceSystemName(String listingSourceSystemName) {
    this.listingSourceSystemName = listingSourceSystemName;
    return this;
  }

  /**
   * Get listingSourceSystemName
   * @return listingSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingSourceSystemName() {
    return listingSourceSystemName;
  }

  public void setListingSourceSystemName(String listingSourceSystemName) {
    this.listingSourceSystemName = listingSourceSystemName;
  }

  public OrgResoMetadataShowingCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataShowingCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataShowingCreate originatingSystemAgentKey(String originatingSystemAgentKey) {
    this.originatingSystemAgentKey = originatingSystemAgentKey;
    return this;
  }

  /**
   * Get originatingSystemAgentKey
   * @return originatingSystemAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemAgentKey() {
    return originatingSystemAgentKey;
  }

  public void setOriginatingSystemAgentKey(String originatingSystemAgentKey) {
    this.originatingSystemAgentKey = originatingSystemAgentKey;
  }

  public OrgResoMetadataShowingCreate originatingSystemListingKey(String originatingSystemListingKey) {
    this.originatingSystemListingKey = originatingSystemListingKey;
    return this;
  }

  /**
   * Get originatingSystemListingKey
   * @return originatingSystemListingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemListingKey() {
    return originatingSystemListingKey;
  }

  public void setOriginatingSystemListingKey(String originatingSystemListingKey) {
    this.originatingSystemListingKey = originatingSystemListingKey;
  }

  public OrgResoMetadataShowingCreate originatingSystemShowingKey(String originatingSystemShowingKey) {
    this.originatingSystemShowingKey = originatingSystemShowingKey;
    return this;
  }

  /**
   * Get originatingSystemShowingKey
   * @return originatingSystemShowingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemShowingKey() {
    return originatingSystemShowingKey;
  }

  public void setOriginatingSystemShowingKey(String originatingSystemShowingKey) {
    this.originatingSystemShowingKey = originatingSystemShowingKey;
  }

  public OrgResoMetadataShowingCreate showingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
    return this;
  }

  /**
   * Get showingAgentKey
   * @return showingAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingAgentKey() {
    return showingAgentKey;
  }

  public void setShowingAgentKey(String showingAgentKey) {
    this.showingAgentKey = showingAgentKey;
  }

  public OrgResoMetadataShowingCreate showingAgentKeyNumeric(AnyOforgResoMetadataShowingCreateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
    return this;
  }

  /**
   * Get showingAgentKeyNumeric
   * @return showingAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataShowingCreateShowingAgentKeyNumeric getShowingAgentKeyNumeric() {
    return showingAgentKeyNumeric;
  }

  public void setShowingAgentKeyNumeric(AnyOforgResoMetadataShowingCreateShowingAgentKeyNumeric showingAgentKeyNumeric) {
    this.showingAgentKeyNumeric = showingAgentKeyNumeric;
  }

  public OrgResoMetadataShowingCreate showingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
    return this;
  }

  /**
   * Get showingAgentMlsID
   * @return showingAgentMlsID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getShowingAgentMlsID() {
    return showingAgentMlsID;
  }

  public void setShowingAgentMlsID(String showingAgentMlsID) {
    this.showingAgentMlsID = showingAgentMlsID;
  }

  public OrgResoMetadataShowingCreate showingEndTimestamp(OffsetDateTime showingEndTimestamp) {
    this.showingEndTimestamp = showingEndTimestamp;
    return this;
  }

  /**
   * Get showingEndTimestamp
   * @return showingEndTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingEndTimestamp() {
    return showingEndTimestamp;
  }

  public void setShowingEndTimestamp(OffsetDateTime showingEndTimestamp) {
    this.showingEndTimestamp = showingEndTimestamp;
  }

  public OrgResoMetadataShowingCreate showingId(String showingId) {
    this.showingId = showingId;
    return this;
  }

  /**
   * Get showingId
   * @return showingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingId() {
    return showingId;
  }

  public void setShowingId(String showingId) {
    this.showingId = showingId;
  }

  public OrgResoMetadataShowingCreate showingKey(String showingKey) {
    this.showingKey = showingKey;
    return this;
  }

  /**
   * Get showingKey
   * @return showingKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getShowingKey() {
    return showingKey;
  }

  public void setShowingKey(String showingKey) {
    this.showingKey = showingKey;
  }

  public OrgResoMetadataShowingCreate showingKeyNumeric(AnyOforgResoMetadataShowingCreateShowingKeyNumeric showingKeyNumeric) {
    this.showingKeyNumeric = showingKeyNumeric;
    return this;
  }

  /**
   * Get showingKeyNumeric
   * @return showingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataShowingCreateShowingKeyNumeric getShowingKeyNumeric() {
    return showingKeyNumeric;
  }

  public void setShowingKeyNumeric(AnyOforgResoMetadataShowingCreateShowingKeyNumeric showingKeyNumeric) {
    this.showingKeyNumeric = showingKeyNumeric;
  }

  public OrgResoMetadataShowingCreate showingOriginatingSystemID(String showingOriginatingSystemID) {
    this.showingOriginatingSystemID = showingOriginatingSystemID;
    return this;
  }

  /**
   * Get showingOriginatingSystemID
   * @return showingOriginatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getShowingOriginatingSystemID() {
    return showingOriginatingSystemID;
  }

  public void setShowingOriginatingSystemID(String showingOriginatingSystemID) {
    this.showingOriginatingSystemID = showingOriginatingSystemID;
  }

  public OrgResoMetadataShowingCreate showingOriginatingSystemName(String showingOriginatingSystemName) {
    this.showingOriginatingSystemName = showingOriginatingSystemName;
    return this;
  }

  /**
   * Get showingOriginatingSystemName
   * @return showingOriginatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingOriginatingSystemName() {
    return showingOriginatingSystemName;
  }

  public void setShowingOriginatingSystemName(String showingOriginatingSystemName) {
    this.showingOriginatingSystemName = showingOriginatingSystemName;
  }

  public OrgResoMetadataShowingCreate showingRequestedTimestamp(OffsetDateTime showingRequestedTimestamp) {
    this.showingRequestedTimestamp = showingRequestedTimestamp;
    return this;
  }

  /**
   * Get showingRequestedTimestamp
   * @return showingRequestedTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingRequestedTimestamp() {
    return showingRequestedTimestamp;
  }

  public void setShowingRequestedTimestamp(OffsetDateTime showingRequestedTimestamp) {
    this.showingRequestedTimestamp = showingRequestedTimestamp;
  }

  public OrgResoMetadataShowingCreate showingSourceSystemID(String showingSourceSystemID) {
    this.showingSourceSystemID = showingSourceSystemID;
    return this;
  }

  /**
   * Get showingSourceSystemID
   * @return showingSourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getShowingSourceSystemID() {
    return showingSourceSystemID;
  }

  public void setShowingSourceSystemID(String showingSourceSystemID) {
    this.showingSourceSystemID = showingSourceSystemID;
  }

  public OrgResoMetadataShowingCreate showingSourceSystemName(String showingSourceSystemName) {
    this.showingSourceSystemName = showingSourceSystemName;
    return this;
  }

  /**
   * Get showingSourceSystemName
   * @return showingSourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getShowingSourceSystemName() {
    return showingSourceSystemName;
  }

  public void setShowingSourceSystemName(String showingSourceSystemName) {
    this.showingSourceSystemName = showingSourceSystemName;
  }

  public OrgResoMetadataShowingCreate showingStartTimestamp(OffsetDateTime showingStartTimestamp) {
    this.showingStartTimestamp = showingStartTimestamp;
    return this;
  }

  /**
   * Get showingStartTimestamp
   * @return showingStartTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingStartTimestamp() {
    return showingStartTimestamp;
  }

  public void setShowingStartTimestamp(OffsetDateTime showingStartTimestamp) {
    this.showingStartTimestamp = showingStartTimestamp;
  }

  public OrgResoMetadataShowingCreate sourceSystemAgentKey(String sourceSystemAgentKey) {
    this.sourceSystemAgentKey = sourceSystemAgentKey;
    return this;
  }

  /**
   * Get sourceSystemAgentKey
   * @return sourceSystemAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemAgentKey() {
    return sourceSystemAgentKey;
  }

  public void setSourceSystemAgentKey(String sourceSystemAgentKey) {
    this.sourceSystemAgentKey = sourceSystemAgentKey;
  }

  public OrgResoMetadataShowingCreate sourceSystemListingKey(String sourceSystemListingKey) {
    this.sourceSystemListingKey = sourceSystemListingKey;
    return this;
  }

  /**
   * Get sourceSystemListingKey
   * @return sourceSystemListingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemListingKey() {
    return sourceSystemListingKey;
  }

  public void setSourceSystemListingKey(String sourceSystemListingKey) {
    this.sourceSystemListingKey = sourceSystemListingKey;
  }

  public OrgResoMetadataShowingCreate sourceSystemShowingKey(String sourceSystemShowingKey) {
    this.sourceSystemShowingKey = sourceSystemShowingKey;
    return this;
  }

  /**
   * Get sourceSystemShowingKey
   * @return sourceSystemShowingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemShowingKey() {
    return sourceSystemShowingKey;
  }

  public void setSourceSystemShowingKey(String sourceSystemShowingKey) {
    this.sourceSystemShowingKey = sourceSystemShowingKey;
  }

  public OrgResoMetadataShowingCreate agentOriginatingSystem(AnyOforgResoMetadataShowingCreateAgentOriginatingSystem agentOriginatingSystem) {
    this.agentOriginatingSystem = agentOriginatingSystem;
    return this;
  }

  /**
   * Get agentOriginatingSystem
   * @return agentOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateAgentOriginatingSystem getAgentOriginatingSystem() {
    return agentOriginatingSystem;
  }

  public void setAgentOriginatingSystem(AnyOforgResoMetadataShowingCreateAgentOriginatingSystem agentOriginatingSystem) {
    this.agentOriginatingSystem = agentOriginatingSystem;
  }

  public OrgResoMetadataShowingCreate agentSourceSystem(AnyOforgResoMetadataShowingCreateAgentSourceSystem agentSourceSystem) {
    this.agentSourceSystem = agentSourceSystem;
    return this;
  }

  /**
   * Get agentSourceSystem
   * @return agentSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateAgentSourceSystem getAgentSourceSystem() {
    return agentSourceSystem;
  }

  public void setAgentSourceSystem(AnyOforgResoMetadataShowingCreateAgentSourceSystem agentSourceSystem) {
    this.agentSourceSystem = agentSourceSystem;
  }

  public OrgResoMetadataShowingCreate showingAgent(AnyOforgResoMetadataShowingCreateShowingAgent showingAgent) {
    this.showingAgent = showingAgent;
    return this;
  }

  /**
   * Get showingAgent
   * @return showingAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateShowingAgent getShowingAgent() {
    return showingAgent;
  }

  public void setShowingAgent(AnyOforgResoMetadataShowingCreateShowingAgent showingAgent) {
    this.showingAgent = showingAgent;
  }

  public OrgResoMetadataShowingCreate listing(AnyOforgResoMetadataShowingCreateListing listing) {
    this.listing = listing;
    return this;
  }

  /**
   * Get listing
   * @return listing
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateListing getListing() {
    return listing;
  }

  public void setListing(AnyOforgResoMetadataShowingCreateListing listing) {
    this.listing = listing;
  }

  public OrgResoMetadataShowingCreate listingOriginatingSystem(AnyOforgResoMetadataShowingCreateListingOriginatingSystem listingOriginatingSystem) {
    this.listingOriginatingSystem = listingOriginatingSystem;
    return this;
  }

  /**
   * Get listingOriginatingSystem
   * @return listingOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateListingOriginatingSystem getListingOriginatingSystem() {
    return listingOriginatingSystem;
  }

  public void setListingOriginatingSystem(AnyOforgResoMetadataShowingCreateListingOriginatingSystem listingOriginatingSystem) {
    this.listingOriginatingSystem = listingOriginatingSystem;
  }

  public OrgResoMetadataShowingCreate listingSourceSystem(AnyOforgResoMetadataShowingCreateListingSourceSystem listingSourceSystem) {
    this.listingSourceSystem = listingSourceSystem;
    return this;
  }

  /**
   * Get listingSourceSystem
   * @return listingSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateListingSourceSystem getListingSourceSystem() {
    return listingSourceSystem;
  }

  public void setListingSourceSystem(AnyOforgResoMetadataShowingCreateListingSourceSystem listingSourceSystem) {
    this.listingSourceSystem = listingSourceSystem;
  }

  public OrgResoMetadataShowingCreate showingOriginatingSystem(AnyOforgResoMetadataShowingCreateShowingOriginatingSystem showingOriginatingSystem) {
    this.showingOriginatingSystem = showingOriginatingSystem;
    return this;
  }

  /**
   * Get showingOriginatingSystem
   * @return showingOriginatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateShowingOriginatingSystem getShowingOriginatingSystem() {
    return showingOriginatingSystem;
  }

  public void setShowingOriginatingSystem(AnyOforgResoMetadataShowingCreateShowingOriginatingSystem showingOriginatingSystem) {
    this.showingOriginatingSystem = showingOriginatingSystem;
  }

  public OrgResoMetadataShowingCreate showingSourceSystem(AnyOforgResoMetadataShowingCreateShowingSourceSystem showingSourceSystem) {
    this.showingSourceSystem = showingSourceSystem;
    return this;
  }

  /**
   * Get showingSourceSystem
   * @return showingSourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataShowingCreateShowingSourceSystem getShowingSourceSystem() {
    return showingSourceSystem;
  }

  public void setShowingSourceSystem(AnyOforgResoMetadataShowingCreateShowingSourceSystem showingSourceSystem) {
    this.showingSourceSystem = showingSourceSystem;
  }

  public OrgResoMetadataShowingCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataShowingCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataShowingCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataShowingCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }

  public OrgResoMetadataShowingCreate socialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataShowingCreate addSocialMediaItem(OrgResoMetadataSocialMediaCreate socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMediaCreate>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMediaCreate> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataShowingCreate orgResoMetadataShowingCreate = (OrgResoMetadataShowingCreate) o;
    return Objects.equals(this.agentOriginatingSystemID, orgResoMetadataShowingCreate.agentOriginatingSystemID) &&
        Objects.equals(this.agentOriginatingSystemName, orgResoMetadataShowingCreate.agentOriginatingSystemName) &&
        Objects.equals(this.agentSourceSystemID, orgResoMetadataShowingCreate.agentSourceSystemID) &&
        Objects.equals(this.agentSourceSystemName, orgResoMetadataShowingCreate.agentSourceSystemName) &&
        Objects.equals(this.listingId, orgResoMetadataShowingCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataShowingCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataShowingCreate.listingKeyNumeric) &&
        Objects.equals(this.listingOriginatingSystemID, orgResoMetadataShowingCreate.listingOriginatingSystemID) &&
        Objects.equals(this.listingOriginatingSystemName, orgResoMetadataShowingCreate.listingOriginatingSystemName) &&
        Objects.equals(this.listingSourceSystemID, orgResoMetadataShowingCreate.listingSourceSystemID) &&
        Objects.equals(this.listingSourceSystemName, orgResoMetadataShowingCreate.listingSourceSystemName) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataShowingCreate.modificationTimestamp) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataShowingCreate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemAgentKey, orgResoMetadataShowingCreate.originatingSystemAgentKey) &&
        Objects.equals(this.originatingSystemListingKey, orgResoMetadataShowingCreate.originatingSystemListingKey) &&
        Objects.equals(this.originatingSystemShowingKey, orgResoMetadataShowingCreate.originatingSystemShowingKey) &&
        Objects.equals(this.showingAgentKey, orgResoMetadataShowingCreate.showingAgentKey) &&
        Objects.equals(this.showingAgentKeyNumeric, orgResoMetadataShowingCreate.showingAgentKeyNumeric) &&
        Objects.equals(this.showingAgentMlsID, orgResoMetadataShowingCreate.showingAgentMlsID) &&
        Objects.equals(this.showingEndTimestamp, orgResoMetadataShowingCreate.showingEndTimestamp) &&
        Objects.equals(this.showingId, orgResoMetadataShowingCreate.showingId) &&
        Objects.equals(this.showingKey, orgResoMetadataShowingCreate.showingKey) &&
        Objects.equals(this.showingKeyNumeric, orgResoMetadataShowingCreate.showingKeyNumeric) &&
        Objects.equals(this.showingOriginatingSystemID, orgResoMetadataShowingCreate.showingOriginatingSystemID) &&
        Objects.equals(this.showingOriginatingSystemName, orgResoMetadataShowingCreate.showingOriginatingSystemName) &&
        Objects.equals(this.showingRequestedTimestamp, orgResoMetadataShowingCreate.showingRequestedTimestamp) &&
        Objects.equals(this.showingSourceSystemID, orgResoMetadataShowingCreate.showingSourceSystemID) &&
        Objects.equals(this.showingSourceSystemName, orgResoMetadataShowingCreate.showingSourceSystemName) &&
        Objects.equals(this.showingStartTimestamp, orgResoMetadataShowingCreate.showingStartTimestamp) &&
        Objects.equals(this.sourceSystemAgentKey, orgResoMetadataShowingCreate.sourceSystemAgentKey) &&
        Objects.equals(this.sourceSystemListingKey, orgResoMetadataShowingCreate.sourceSystemListingKey) &&
        Objects.equals(this.sourceSystemShowingKey, orgResoMetadataShowingCreate.sourceSystemShowingKey) &&
        Objects.equals(this.agentOriginatingSystem, orgResoMetadataShowingCreate.agentOriginatingSystem) &&
        Objects.equals(this.agentSourceSystem, orgResoMetadataShowingCreate.agentSourceSystem) &&
        Objects.equals(this.showingAgent, orgResoMetadataShowingCreate.showingAgent) &&
        Objects.equals(this.listing, orgResoMetadataShowingCreate.listing) &&
        Objects.equals(this.listingOriginatingSystem, orgResoMetadataShowingCreate.listingOriginatingSystem) &&
        Objects.equals(this.listingSourceSystem, orgResoMetadataShowingCreate.listingSourceSystem) &&
        Objects.equals(this.showingOriginatingSystem, orgResoMetadataShowingCreate.showingOriginatingSystem) &&
        Objects.equals(this.showingSourceSystem, orgResoMetadataShowingCreate.showingSourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataShowingCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataShowingCreate.media) &&
        Objects.equals(this.socialMedia, orgResoMetadataShowingCreate.socialMedia);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agentOriginatingSystemID, agentOriginatingSystemName, agentSourceSystemID, agentSourceSystemName, listingId, listingKey, listingKeyNumeric, listingOriginatingSystemID, listingOriginatingSystemName, listingSourceSystemID, listingSourceSystemName, modificationTimestamp, originalEntryTimestamp, originatingSystemAgentKey, originatingSystemListingKey, originatingSystemShowingKey, showingAgentKey, showingAgentKeyNumeric, showingAgentMlsID, showingEndTimestamp, showingId, showingKey, showingKeyNumeric, showingOriginatingSystemID, showingOriginatingSystemName, showingRequestedTimestamp, showingSourceSystemID, showingSourceSystemName, showingStartTimestamp, sourceSystemAgentKey, sourceSystemListingKey, sourceSystemShowingKey, agentOriginatingSystem, agentSourceSystem, showingAgent, listing, listingOriginatingSystem, listingSourceSystem, showingOriginatingSystem, showingSourceSystem, historyTransactional, media, socialMedia);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataShowingCreate {\n");
    
    sb.append("    agentOriginatingSystemID: ").append(toIndentedString(agentOriginatingSystemID)).append("\n");
    sb.append("    agentOriginatingSystemName: ").append(toIndentedString(agentOriginatingSystemName)).append("\n");
    sb.append("    agentSourceSystemID: ").append(toIndentedString(agentSourceSystemID)).append("\n");
    sb.append("    agentSourceSystemName: ").append(toIndentedString(agentSourceSystemName)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    listingOriginatingSystemID: ").append(toIndentedString(listingOriginatingSystemID)).append("\n");
    sb.append("    listingOriginatingSystemName: ").append(toIndentedString(listingOriginatingSystemName)).append("\n");
    sb.append("    listingSourceSystemID: ").append(toIndentedString(listingSourceSystemID)).append("\n");
    sb.append("    listingSourceSystemName: ").append(toIndentedString(listingSourceSystemName)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemAgentKey: ").append(toIndentedString(originatingSystemAgentKey)).append("\n");
    sb.append("    originatingSystemListingKey: ").append(toIndentedString(originatingSystemListingKey)).append("\n");
    sb.append("    originatingSystemShowingKey: ").append(toIndentedString(originatingSystemShowingKey)).append("\n");
    sb.append("    showingAgentKey: ").append(toIndentedString(showingAgentKey)).append("\n");
    sb.append("    showingAgentKeyNumeric: ").append(toIndentedString(showingAgentKeyNumeric)).append("\n");
    sb.append("    showingAgentMlsID: ").append(toIndentedString(showingAgentMlsID)).append("\n");
    sb.append("    showingEndTimestamp: ").append(toIndentedString(showingEndTimestamp)).append("\n");
    sb.append("    showingId: ").append(toIndentedString(showingId)).append("\n");
    sb.append("    showingKey: ").append(toIndentedString(showingKey)).append("\n");
    sb.append("    showingKeyNumeric: ").append(toIndentedString(showingKeyNumeric)).append("\n");
    sb.append("    showingOriginatingSystemID: ").append(toIndentedString(showingOriginatingSystemID)).append("\n");
    sb.append("    showingOriginatingSystemName: ").append(toIndentedString(showingOriginatingSystemName)).append("\n");
    sb.append("    showingRequestedTimestamp: ").append(toIndentedString(showingRequestedTimestamp)).append("\n");
    sb.append("    showingSourceSystemID: ").append(toIndentedString(showingSourceSystemID)).append("\n");
    sb.append("    showingSourceSystemName: ").append(toIndentedString(showingSourceSystemName)).append("\n");
    sb.append("    showingStartTimestamp: ").append(toIndentedString(showingStartTimestamp)).append("\n");
    sb.append("    sourceSystemAgentKey: ").append(toIndentedString(sourceSystemAgentKey)).append("\n");
    sb.append("    sourceSystemListingKey: ").append(toIndentedString(sourceSystemListingKey)).append("\n");
    sb.append("    sourceSystemShowingKey: ").append(toIndentedString(sourceSystemShowingKey)).append("\n");
    sb.append("    agentOriginatingSystem: ").append(toIndentedString(agentOriginatingSystem)).append("\n");
    sb.append("    agentSourceSystem: ").append(toIndentedString(agentSourceSystem)).append("\n");
    sb.append("    showingAgent: ").append(toIndentedString(showingAgent)).append("\n");
    sb.append("    listing: ").append(toIndentedString(listing)).append("\n");
    sb.append("    listingOriginatingSystem: ").append(toIndentedString(listingOriginatingSystem)).append("\n");
    sb.append("    listingSourceSystem: ").append(toIndentedString(listingSourceSystem)).append("\n");
    sb.append("    showingOriginatingSystem: ").append(toIndentedString(showingOriginatingSystem)).append("\n");
    sb.append("    showingSourceSystem: ").append(toIndentedString(showingSourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
