package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsUpdateRoomWidth
*/
public interface AnyOforgResoMetadataPropertyRoomsUpdateRoomWidth {

}
