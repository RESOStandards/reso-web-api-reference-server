package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCountyOrParish
*/
public interface AnyOforgResoMetadataPropertyCreateCountyOrParish {

}
