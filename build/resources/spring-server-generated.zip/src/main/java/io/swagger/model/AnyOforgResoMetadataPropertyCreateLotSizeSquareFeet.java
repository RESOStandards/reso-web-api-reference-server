package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet
*/
public interface AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet {

}
