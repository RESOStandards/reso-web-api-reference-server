package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateGarageSpaces
*/
public interface AnyOforgResoMetadataPropertyCreateGarageSpaces {

}
