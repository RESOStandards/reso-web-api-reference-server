package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataTeamMembersCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataTeamMembersCreate   {
  @JsonProperty("MemberKey")
  private String memberKey = null;

  @JsonProperty("MemberKeyNumeric")
  private AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric memberKeyNumeric = null;

  @JsonProperty("MemberLoginId")
  private String memberLoginId = null;

  @JsonProperty("MemberMlsId")
  private String memberMlsId = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("TeamImpersonationLevel")
  private AnyOforgResoMetadataTeamMembersCreateTeamImpersonationLevel teamImpersonationLevel = null;

  @JsonProperty("TeamKey")
  private String teamKey = null;

  @JsonProperty("TeamKeyNumeric")
  private AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric teamKeyNumeric = null;

  @JsonProperty("TeamMemberKey")
  private String teamMemberKey = null;

  @JsonProperty("TeamMemberKeyNumeric")
  private AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric teamMemberKeyNumeric = null;

  @JsonProperty("TeamMemberNationalAssociationId")
  private String teamMemberNationalAssociationId = null;

  @JsonProperty("TeamMemberStateLicense")
  private String teamMemberStateLicense = null;

  @JsonProperty("TeamMemberType")
  private AnyOforgResoMetadataTeamMembersCreateTeamMemberType teamMemberType = null;

  @JsonProperty("Member")
  private AnyOforgResoMetadataTeamMembersCreateMember member = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataTeamMembersCreateOriginatingSystem originatingSystem = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataTeamMembersCreateSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  public OrgResoMetadataTeamMembersCreate memberKey(String memberKey) {
    this.memberKey = memberKey;
    return this;
  }

  /**
   * Get memberKey
   * @return memberKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getMemberKey() {
    return memberKey;
  }

  public void setMemberKey(String memberKey) {
    this.memberKey = memberKey;
  }

  public OrgResoMetadataTeamMembersCreate memberKeyNumeric(AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric memberKeyNumeric) {
    this.memberKeyNumeric = memberKeyNumeric;
    return this;
  }

  /**
   * Get memberKeyNumeric
   * @return memberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric getMemberKeyNumeric() {
    return memberKeyNumeric;
  }

  public void setMemberKeyNumeric(AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric memberKeyNumeric) {
    this.memberKeyNumeric = memberKeyNumeric;
  }

  public OrgResoMetadataTeamMembersCreate memberLoginId(String memberLoginId) {
    this.memberLoginId = memberLoginId;
    return this;
  }

  /**
   * Get memberLoginId
   * @return memberLoginId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMemberLoginId() {
    return memberLoginId;
  }

  public void setMemberLoginId(String memberLoginId) {
    this.memberLoginId = memberLoginId;
  }

  public OrgResoMetadataTeamMembersCreate memberMlsId(String memberMlsId) {
    this.memberMlsId = memberMlsId;
    return this;
  }

  /**
   * Get memberMlsId
   * @return memberMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMemberMlsId() {
    return memberMlsId;
  }

  public void setMemberMlsId(String memberMlsId) {
    this.memberMlsId = memberMlsId;
  }

  public OrgResoMetadataTeamMembersCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataTeamMembersCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataTeamMembersCreate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataTeamMembersCreate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataTeamMembersCreate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataTeamMembersCreate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataTeamMembersCreate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataTeamMembersCreate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataTeamMembersCreate teamImpersonationLevel(AnyOforgResoMetadataTeamMembersCreateTeamImpersonationLevel teamImpersonationLevel) {
    this.teamImpersonationLevel = teamImpersonationLevel;
    return this;
  }

  /**
   * Get teamImpersonationLevel
   * @return teamImpersonationLevel
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateTeamImpersonationLevel getTeamImpersonationLevel() {
    return teamImpersonationLevel;
  }

  public void setTeamImpersonationLevel(AnyOforgResoMetadataTeamMembersCreateTeamImpersonationLevel teamImpersonationLevel) {
    this.teamImpersonationLevel = teamImpersonationLevel;
  }

  public OrgResoMetadataTeamMembersCreate teamKey(String teamKey) {
    this.teamKey = teamKey;
    return this;
  }

  /**
   * Get teamKey
   * @return teamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTeamKey() {
    return teamKey;
  }

  public void setTeamKey(String teamKey) {
    this.teamKey = teamKey;
  }

  public OrgResoMetadataTeamMembersCreate teamKeyNumeric(AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
    return this;
  }

  /**
   * Get teamKeyNumeric
   * @return teamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric getTeamKeyNumeric() {
    return teamKeyNumeric;
  }

  public void setTeamKeyNumeric(AnyOforgResoMetadataTeamMembersCreateTeamKeyNumeric teamKeyNumeric) {
    this.teamKeyNumeric = teamKeyNumeric;
  }

  public OrgResoMetadataTeamMembersCreate teamMemberKey(String teamMemberKey) {
    this.teamMemberKey = teamMemberKey;
    return this;
  }

  /**
   * Get teamMemberKey
   * @return teamMemberKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getTeamMemberKey() {
    return teamMemberKey;
  }

  public void setTeamMemberKey(String teamMemberKey) {
    this.teamMemberKey = teamMemberKey;
  }

  public OrgResoMetadataTeamMembersCreate teamMemberKeyNumeric(AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric teamMemberKeyNumeric) {
    this.teamMemberKeyNumeric = teamMemberKeyNumeric;
    return this;
  }

  /**
   * Get teamMemberKeyNumeric
   * @return teamMemberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric getTeamMemberKeyNumeric() {
    return teamMemberKeyNumeric;
  }

  public void setTeamMemberKeyNumeric(AnyOforgResoMetadataTeamMembersCreateTeamMemberKeyNumeric teamMemberKeyNumeric) {
    this.teamMemberKeyNumeric = teamMemberKeyNumeric;
  }

  public OrgResoMetadataTeamMembersCreate teamMemberNationalAssociationId(String teamMemberNationalAssociationId) {
    this.teamMemberNationalAssociationId = teamMemberNationalAssociationId;
    return this;
  }

  /**
   * Get teamMemberNationalAssociationId
   * @return teamMemberNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTeamMemberNationalAssociationId() {
    return teamMemberNationalAssociationId;
  }

  public void setTeamMemberNationalAssociationId(String teamMemberNationalAssociationId) {
    this.teamMemberNationalAssociationId = teamMemberNationalAssociationId;
  }

  public OrgResoMetadataTeamMembersCreate teamMemberStateLicense(String teamMemberStateLicense) {
    this.teamMemberStateLicense = teamMemberStateLicense;
    return this;
  }

  /**
   * Get teamMemberStateLicense
   * @return teamMemberStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTeamMemberStateLicense() {
    return teamMemberStateLicense;
  }

  public void setTeamMemberStateLicense(String teamMemberStateLicense) {
    this.teamMemberStateLicense = teamMemberStateLicense;
  }

  public OrgResoMetadataTeamMembersCreate teamMemberType(AnyOforgResoMetadataTeamMembersCreateTeamMemberType teamMemberType) {
    this.teamMemberType = teamMemberType;
    return this;
  }

  /**
   * Get teamMemberType
   * @return teamMemberType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateTeamMemberType getTeamMemberType() {
    return teamMemberType;
  }

  public void setTeamMemberType(AnyOforgResoMetadataTeamMembersCreateTeamMemberType teamMemberType) {
    this.teamMemberType = teamMemberType;
  }

  public OrgResoMetadataTeamMembersCreate member(AnyOforgResoMetadataTeamMembersCreateMember member) {
    this.member = member;
    return this;
  }

  /**
   * Get member
   * @return member
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateMember getMember() {
    return member;
  }

  public void setMember(AnyOforgResoMetadataTeamMembersCreateMember member) {
    this.member = member;
  }

  public OrgResoMetadataTeamMembersCreate originatingSystem(AnyOforgResoMetadataTeamMembersCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataTeamMembersCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataTeamMembersCreate sourceSystem(AnyOforgResoMetadataTeamMembersCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataTeamMembersCreateSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataTeamMembersCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataTeamMembersCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataTeamMembersCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataTeamMembersCreate orgResoMetadataTeamMembersCreate = (OrgResoMetadataTeamMembersCreate) o;
    return Objects.equals(this.memberKey, orgResoMetadataTeamMembersCreate.memberKey) &&
        Objects.equals(this.memberKeyNumeric, orgResoMetadataTeamMembersCreate.memberKeyNumeric) &&
        Objects.equals(this.memberLoginId, orgResoMetadataTeamMembersCreate.memberLoginId) &&
        Objects.equals(this.memberMlsId, orgResoMetadataTeamMembersCreate.memberMlsId) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataTeamMembersCreate.modificationTimestamp) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataTeamMembersCreate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataTeamMembersCreate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataTeamMembersCreate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataTeamMembersCreate.originatingSystemName) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataTeamMembersCreate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataTeamMembersCreate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataTeamMembersCreate.sourceSystemName) &&
        Objects.equals(this.teamImpersonationLevel, orgResoMetadataTeamMembersCreate.teamImpersonationLevel) &&
        Objects.equals(this.teamKey, orgResoMetadataTeamMembersCreate.teamKey) &&
        Objects.equals(this.teamKeyNumeric, orgResoMetadataTeamMembersCreate.teamKeyNumeric) &&
        Objects.equals(this.teamMemberKey, orgResoMetadataTeamMembersCreate.teamMemberKey) &&
        Objects.equals(this.teamMemberKeyNumeric, orgResoMetadataTeamMembersCreate.teamMemberKeyNumeric) &&
        Objects.equals(this.teamMemberNationalAssociationId, orgResoMetadataTeamMembersCreate.teamMemberNationalAssociationId) &&
        Objects.equals(this.teamMemberStateLicense, orgResoMetadataTeamMembersCreate.teamMemberStateLicense) &&
        Objects.equals(this.teamMemberType, orgResoMetadataTeamMembersCreate.teamMemberType) &&
        Objects.equals(this.member, orgResoMetadataTeamMembersCreate.member) &&
        Objects.equals(this.originatingSystem, orgResoMetadataTeamMembersCreate.originatingSystem) &&
        Objects.equals(this.sourceSystem, orgResoMetadataTeamMembersCreate.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataTeamMembersCreate.historyTransactional);
  }

  @Override
  public int hashCode() {
    return Objects.hash(memberKey, memberKeyNumeric, memberLoginId, memberMlsId, modificationTimestamp, originalEntryTimestamp, originatingSystemID, originatingSystemKey, originatingSystemName, sourceSystemID, sourceSystemKey, sourceSystemName, teamImpersonationLevel, teamKey, teamKeyNumeric, teamMemberKey, teamMemberKeyNumeric, teamMemberNationalAssociationId, teamMemberStateLicense, teamMemberType, member, originatingSystem, sourceSystem, historyTransactional);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataTeamMembersCreate {\n");
    
    sb.append("    memberKey: ").append(toIndentedString(memberKey)).append("\n");
    sb.append("    memberKeyNumeric: ").append(toIndentedString(memberKeyNumeric)).append("\n");
    sb.append("    memberLoginId: ").append(toIndentedString(memberLoginId)).append("\n");
    sb.append("    memberMlsId: ").append(toIndentedString(memberMlsId)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    teamImpersonationLevel: ").append(toIndentedString(teamImpersonationLevel)).append("\n");
    sb.append("    teamKey: ").append(toIndentedString(teamKey)).append("\n");
    sb.append("    teamKeyNumeric: ").append(toIndentedString(teamKeyNumeric)).append("\n");
    sb.append("    teamMemberKey: ").append(toIndentedString(teamMemberKey)).append("\n");
    sb.append("    teamMemberKeyNumeric: ").append(toIndentedString(teamMemberKeyNumeric)).append("\n");
    sb.append("    teamMemberNationalAssociationId: ").append(toIndentedString(teamMemberNationalAssociationId)).append("\n");
    sb.append("    teamMemberStateLicense: ").append(toIndentedString(teamMemberStateLicense)).append("\n");
    sb.append("    teamMemberType: ").append(toIndentedString(teamMemberType)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
