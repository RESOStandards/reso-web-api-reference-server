package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateInsuranceExpense
*/
public interface AnyOforgResoMetadataPropertyCreateInsuranceExpense {

}
