package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.MemberDesignation
 */
public enum OrgResoMetadataEnumsMemberDesignation {
  ACCREDITEDBUYERSREPRESENTATIVE("AccreditedBuyersRepresentative"),
    ACCREDITEDLANDCONSULTANT("AccreditedLandConsultant"),
    ATHOMEWITHDIVERSITY("AtHomeWithDiversity"),
    CERTIFIEDCOMMERCIALINVESTMENTMEMBER("CertifiedCommercialInvestmentMember"),
    CERTIFIEDDISTRESSEDPROPERTYEXPERT("CertifiedDistressedPropertyExpert"),
    CERTIFIEDINTERNATIONALPROPERTYSPECIALIST("CertifiedInternationalPropertySpecialist"),
    CERTIFIEDPROPERTYMANAGER("CertifiedPropertyManager"),
    CERTIFIEDREALESTATEBROKERAGEMANAGER("CertifiedRealEstateBrokerageManager"),
    CERTIFIEDREALESTATETEAMSPECIALIST("CertifiedRealEstateTeamSpecialist"),
    CERTIFIEDRESIDENTIALSPECIALIST("CertifiedResidentialSpecialist"),
    COUNSELOROFREALESTATE("CounselorOfRealEstate"),
    EPRO("ePRO"),
    GENERALACCREDITEDAPPRAISER("GeneralAccreditedAppraiser"),
    GRADUATEREALTORINSTITUTE("GraduateRealtorInstitute"),
    MILITARYRELOCATIONPROFESSIONAL("MilitaryRelocationProfessional"),
    NARSGREENDESIGNATION("NARsGreenDesignation"),
    PERFORMANCEMANAGEMENTNETWORK("PerformanceManagementNetwork"),
    PRICINGSTRATEGYADVISOR("PricingStrategyAdvisor"),
    REALESTATENEGOTIATIONEXPERT("RealEstateNegotiationExpert"),
    REALTORASSOCIATIONCERTIFIEDEXECUTIVE("RealtorAssociationCertifiedExecutive"),
    RESIDENTIALACCREDITEDAPPRAISER("ResidentialAccreditedAppraiser"),
    RESORTANDSECONDHOMEPROPERTYSPECIALIST("ResortAndSecondHomePropertySpecialist"),
    SELLERREPRESENTATIVESPECIALIST("SellerRepresentativeSpecialist"),
    SENIORSREALESTATESPECIALIST("SeniorsRealEstateSpecialist"),
    SHORTSALESANDFORECLOSURERESOURCE("ShortSalesAndForeclosureResource"),
    SOCIETYOFINDUSTRIALANDOFFICEREALTORS("SocietyOfIndustrialAndOfficeRealtors"),
    TRANSNATIONALREFERRALCERTIFICATION("TransnationalReferralCertification");

  private String value;

  OrgResoMetadataEnumsMemberDesignation(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsMemberDesignation fromValue(String text) {
    for (OrgResoMetadataEnumsMemberDesignation b : OrgResoMetadataEnumsMemberDesignation.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
