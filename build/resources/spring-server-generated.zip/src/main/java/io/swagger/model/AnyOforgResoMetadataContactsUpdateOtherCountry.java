package io.swagger.model;


/**
* AnyOforgResoMetadataContactsUpdateOtherCountry
*/
public interface AnyOforgResoMetadataContactsUpdateOtherCountry {

}
