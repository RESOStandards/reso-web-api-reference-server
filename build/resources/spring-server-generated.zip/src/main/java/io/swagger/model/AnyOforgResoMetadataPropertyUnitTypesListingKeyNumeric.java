package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUnitTypesListingKeyNumeric {

}
