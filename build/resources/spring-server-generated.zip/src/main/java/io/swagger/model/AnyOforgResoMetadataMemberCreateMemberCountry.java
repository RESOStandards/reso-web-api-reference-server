package io.swagger.model;


/**
* AnyOforgResoMetadataMemberCreateMemberCountry
*/
public interface AnyOforgResoMetadataMemberCreateMemberCountry {

}
