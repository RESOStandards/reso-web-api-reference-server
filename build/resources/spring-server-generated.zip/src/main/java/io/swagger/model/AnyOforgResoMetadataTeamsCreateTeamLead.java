package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateTeamLead
*/
public interface AnyOforgResoMetadataTeamsCreateTeamLead {

}
