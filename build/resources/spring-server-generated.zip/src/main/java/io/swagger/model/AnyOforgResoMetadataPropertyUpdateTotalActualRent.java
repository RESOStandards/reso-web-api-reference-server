package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateTotalActualRent
*/
public interface AnyOforgResoMetadataPropertyUpdateTotalActualRent {

}
