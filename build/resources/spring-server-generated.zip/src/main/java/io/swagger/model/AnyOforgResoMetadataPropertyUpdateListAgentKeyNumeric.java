package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateListAgentKeyNumeric {

}
