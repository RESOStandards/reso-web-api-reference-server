package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGardenerExpense
*/
public interface AnyOforgResoMetadataPropertyGardenerExpense {

}
