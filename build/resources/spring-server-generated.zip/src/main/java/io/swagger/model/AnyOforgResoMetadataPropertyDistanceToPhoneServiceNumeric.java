package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric
*/
public interface AnyOforgResoMetadataPropertyDistanceToPhoneServiceNumeric {

}
