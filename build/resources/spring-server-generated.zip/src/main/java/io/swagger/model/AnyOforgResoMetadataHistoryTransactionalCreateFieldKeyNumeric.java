package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalCreateFieldKeyNumeric
*/
public interface AnyOforgResoMetadataHistoryTransactionalCreateFieldKeyNumeric {

}
