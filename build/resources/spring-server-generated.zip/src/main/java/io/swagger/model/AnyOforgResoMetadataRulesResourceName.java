package io.swagger.model;


/**
* AnyOforgResoMetadataRulesResourceName
*/
public interface AnyOforgResoMetadataRulesResourceName {

}
