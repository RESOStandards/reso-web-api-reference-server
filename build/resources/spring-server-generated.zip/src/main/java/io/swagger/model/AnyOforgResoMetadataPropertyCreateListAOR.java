package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateListAOR
*/
public interface AnyOforgResoMetadataPropertyCreateListAOR {

}
