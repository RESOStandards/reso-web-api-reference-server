package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationUpdateGreenVerificationSource {

}
