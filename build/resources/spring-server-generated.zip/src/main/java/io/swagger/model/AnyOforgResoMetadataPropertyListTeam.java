package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListTeam
*/
public interface AnyOforgResoMetadataPropertyListTeam {

}
