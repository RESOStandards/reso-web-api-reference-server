package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeOfficeBranchType
*/
public interface AnyOforgResoMetadataOfficeOfficeBranchType {

}
