package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCultivatedArea
*/
public interface AnyOforgResoMetadataPropertyCultivatedArea {

}
