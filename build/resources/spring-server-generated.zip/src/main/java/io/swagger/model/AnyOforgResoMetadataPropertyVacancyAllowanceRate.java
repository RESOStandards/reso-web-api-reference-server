package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyVacancyAllowanceRate
*/
public interface AnyOforgResoMetadataPropertyVacancyAllowanceRate {

}
