package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.FeeFrequency
 */
public enum OrgResoMetadataEnumsFeeFrequency {
  ANNUALLY("Annually"),
    BIMONTHLY("BiMonthly"),
    BIWEEKLY("BiWeekly"),
    DAILY("Daily"),
    MONTHLY("Monthly"),
    ONETIME("OneTime"),
    QUARTERLY("Quarterly"),
    SEASONAL("Seasonal"),
    SEMIANNUALLY("SemiAnnually"),
    SEMIMONTHLY("SemiMonthly"),
    WEEKLY("Weekly");

  private String value;

  OrgResoMetadataEnumsFeeFrequency(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsFeeFrequency fromValue(String text) {
    for (OrgResoMetadataEnumsFeeFrequency b : OrgResoMetadataEnumsFeeFrequency.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
