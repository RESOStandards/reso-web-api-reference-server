package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesUnitTypeActualRent
*/
public interface AnyOforgResoMetadataPropertyUnitTypesUnitTypeActualRent {

}
