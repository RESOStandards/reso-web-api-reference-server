package io.swagger.model;


/**
* AnyOforgResoMetadataSocialMediaUpdateResourceName
*/
public interface AnyOforgResoMetadataSocialMediaUpdateResourceName {

}
