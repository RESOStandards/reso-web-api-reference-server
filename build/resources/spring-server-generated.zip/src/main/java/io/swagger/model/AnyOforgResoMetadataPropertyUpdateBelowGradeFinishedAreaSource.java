package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource
*/
public interface AnyOforgResoMetadataPropertyUpdateBelowGradeFinishedAreaSource {

}
