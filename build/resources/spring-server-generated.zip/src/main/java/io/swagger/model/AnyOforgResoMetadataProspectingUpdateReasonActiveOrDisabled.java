package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingUpdateReasonActiveOrDisabled
*/
public interface AnyOforgResoMetadataProspectingUpdateReasonActiveOrDisabled {

}
