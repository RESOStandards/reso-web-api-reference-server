package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyListOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyListOfficeKeyNumeric {

}
