package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateYearBuiltSource
*/
public interface AnyOforgResoMetadataPropertyUpdateYearBuiltSource {

}
