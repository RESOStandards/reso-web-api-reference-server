package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType
*/
public interface AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType {

}
