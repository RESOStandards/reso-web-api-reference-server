package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateSeatingCapacity
*/
public interface AnyOforgResoMetadataPropertyUpdateSeatingCapacity {

}
