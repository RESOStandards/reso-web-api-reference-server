package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdatePoolExpense
*/
public interface AnyOforgResoMetadataPropertyUpdatePoolExpense {

}
