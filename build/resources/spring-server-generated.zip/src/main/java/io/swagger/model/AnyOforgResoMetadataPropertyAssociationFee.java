package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyAssociationFee
*/
public interface AnyOforgResoMetadataPropertyAssociationFee {

}
