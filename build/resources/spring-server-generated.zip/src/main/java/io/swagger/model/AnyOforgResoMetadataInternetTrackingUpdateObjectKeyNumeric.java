package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateObjectKeyNumeric
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateObjectKeyNumeric {

}
