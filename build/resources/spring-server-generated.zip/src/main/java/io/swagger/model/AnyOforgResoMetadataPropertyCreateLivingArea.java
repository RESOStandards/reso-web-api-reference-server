package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLivingArea
*/
public interface AnyOforgResoMetadataPropertyCreateLivingArea {

}
