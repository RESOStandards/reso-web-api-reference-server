package io.swagger.model;


/**
* AnyOforgResoMetadataRulesCreateRuleFormat
*/
public interface AnyOforgResoMetadataRulesCreateRuleFormat {

}
