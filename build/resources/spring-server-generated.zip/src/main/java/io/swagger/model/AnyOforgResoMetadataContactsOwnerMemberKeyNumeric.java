package io.swagger.model;


/**
* AnyOforgResoMetadataContactsOwnerMemberKeyNumeric
*/
public interface AnyOforgResoMetadataContactsOwnerMemberKeyNumeric {

}
