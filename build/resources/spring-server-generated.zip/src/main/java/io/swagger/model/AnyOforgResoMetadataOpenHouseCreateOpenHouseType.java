package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseCreateOpenHouseType
*/
public interface AnyOforgResoMetadataOpenHouseCreateOpenHouseType {

}
