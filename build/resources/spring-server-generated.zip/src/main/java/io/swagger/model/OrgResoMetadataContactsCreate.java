package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsContactType;
import io.swagger.model.OrgResoMetadataEnumsLanguages;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.model.OrgResoMetadataSocialMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataContactsCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataContactsCreate  implements AnyOforgResoMetadataContactListingNotesCreateContact, AnyOforgResoMetadataContactListingsCreateContact, AnyOforgResoMetadataProspectingCreateContact {
  @JsonProperty("Anniversary")
  private LocalDate anniversary = null;

  @JsonProperty("AssistantEmail")
  private String assistantEmail = null;

  @JsonProperty("AssistantName")
  private String assistantName = null;

  @JsonProperty("AssistantPhone")
  private String assistantPhone = null;

  @JsonProperty("AssistantPhoneExt")
  private String assistantPhoneExt = null;

  @JsonProperty("Birthdate")
  private LocalDate birthdate = null;

  @JsonProperty("BusinessFax")
  private String businessFax = null;

  @JsonProperty("Children")
  private String children = null;

  @JsonProperty("Company")
  private String company = null;

  @JsonProperty("ContactKey")
  private String contactKey = null;

  @JsonProperty("ContactKeyNumeric")
  private AnyOforgResoMetadataContactsCreateContactKeyNumeric contactKeyNumeric = null;

  @JsonProperty("ContactLoginId")
  private String contactLoginId = null;

  @JsonProperty("ContactPassword")
  private String contactPassword = null;

  @JsonProperty("ContactStatus")
  private AnyOforgResoMetadataContactsCreateContactStatus contactStatus = null;

  @JsonProperty("ContactType")
  @Valid
  private List<OrgResoMetadataEnumsContactType> contactType = null;

  @JsonProperty("Department")
  private String department = null;

  @JsonProperty("DirectPhone")
  private String directPhone = null;

  @JsonProperty("Email")
  private String email = null;

  @JsonProperty("Email2")
  private String email2 = null;

  @JsonProperty("Email3")
  private String email3 = null;

  @JsonProperty("FirstName")
  private String firstName = null;

  @JsonProperty("FullName")
  private String fullName = null;

  @JsonProperty("HomeAddress1")
  private String homeAddress1 = null;

  @JsonProperty("HomeAddress2")
  private String homeAddress2 = null;

  @JsonProperty("HomeCarrierRoute")
  private String homeCarrierRoute = null;

  @JsonProperty("HomeCity")
  private String homeCity = null;

  @JsonProperty("HomeCountry")
  private AnyOforgResoMetadataContactsCreateHomeCountry homeCountry = null;

  @JsonProperty("HomeCountyOrParish")
  private AnyOforgResoMetadataContactsCreateHomeCountyOrParish homeCountyOrParish = null;

  @JsonProperty("HomeFax")
  private String homeFax = null;

  @JsonProperty("HomePhone")
  private String homePhone = null;

  @JsonProperty("HomePostalCode")
  private String homePostalCode = null;

  @JsonProperty("HomePostalCodePlus4")
  private String homePostalCodePlus4 = null;

  @JsonProperty("HomeStateOrProvince")
  private AnyOforgResoMetadataContactsCreateHomeStateOrProvince homeStateOrProvince = null;

  @JsonProperty("JobTitle")
  private String jobTitle = null;

  @JsonProperty("Language")
  @Valid
  private List<OrgResoMetadataEnumsLanguages> language = null;

  @JsonProperty("LastName")
  private String lastName = null;

  @JsonProperty("LeadSource")
  private String leadSource = null;

  @JsonProperty("MiddleName")
  private String middleName = null;

  @JsonProperty("MobilePhone")
  private String mobilePhone = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NamePrefix")
  private String namePrefix = null;

  @JsonProperty("NameSuffix")
  private String nameSuffix = null;

  @JsonProperty("Nickname")
  private String nickname = null;

  @JsonProperty("Notes")
  private String notes = null;

  @JsonProperty("OfficePhone")
  private String officePhone = null;

  @JsonProperty("OfficePhoneExt")
  private String officePhoneExt = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemContactKey")
  private String originatingSystemContactKey = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OtherAddress1")
  private String otherAddress1 = null;

  @JsonProperty("OtherAddress2")
  private String otherAddress2 = null;

  @JsonProperty("OtherCarrierRoute")
  private String otherCarrierRoute = null;

  @JsonProperty("OtherCity")
  private String otherCity = null;

  @JsonProperty("OtherCountry")
  private AnyOforgResoMetadataContactsCreateOtherCountry otherCountry = null;

  @JsonProperty("OtherCountyOrParish")
  private AnyOforgResoMetadataContactsCreateOtherCountyOrParish otherCountyOrParish = null;

  @JsonProperty("OtherPhoneType")
  private AnyOforgResoMetadataContactsCreateOtherPhoneType otherPhoneType = null;

  @JsonProperty("OtherPostalCode")
  private String otherPostalCode = null;

  @JsonProperty("OtherPostalCodePlus4")
  private String otherPostalCodePlus4 = null;

  @JsonProperty("OtherStateOrProvince")
  private AnyOforgResoMetadataContactsCreateOtherStateOrProvince otherStateOrProvince = null;

  @JsonProperty("OwnerMemberID")
  private String ownerMemberID = null;

  @JsonProperty("OwnerMemberKey")
  private String ownerMemberKey = null;

  @JsonProperty("OwnerMemberKeyNumeric")
  private AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric = null;

  @JsonProperty("Pager")
  private String pager = null;

  @JsonProperty("PhoneTTYTDD")
  private String phoneTTYTDD = null;

  @JsonProperty("PreferredAddress")
  private AnyOforgResoMetadataContactsCreatePreferredAddress preferredAddress = null;

  @JsonProperty("PreferredPhone")
  private AnyOforgResoMetadataContactsCreatePreferredPhone preferredPhone = null;

  @JsonProperty("ReferredBy")
  private String referredBy = null;

  @JsonProperty("SocialMediaType")
  private AnyOforgResoMetadataContactsCreateSocialMediaType socialMediaType = null;

  @JsonProperty("SourceSystemContactKey")
  private String sourceSystemContactKey = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SpousePartnerName")
  private String spousePartnerName = null;

  @JsonProperty("TollFreePhone")
  private String tollFreePhone = null;

  @JsonProperty("VoiceMail")
  private String voiceMail = null;

  @JsonProperty("VoiceMailExt")
  private String voiceMailExt = null;

  @JsonProperty("WorkAddress1")
  private String workAddress1 = null;

  @JsonProperty("WorkAddress2")
  private String workAddress2 = null;

  @JsonProperty("WorkCarrierRoute")
  private String workCarrierRoute = null;

  @JsonProperty("WorkCity")
  private String workCity = null;

  @JsonProperty("WorkCountry")
  private AnyOforgResoMetadataContactsCreateWorkCountry workCountry = null;

  @JsonProperty("WorkCountyOrParish")
  private AnyOforgResoMetadataContactsCreateWorkCountyOrParish workCountyOrParish = null;

  @JsonProperty("WorkPostalCode")
  private String workPostalCode = null;

  @JsonProperty("WorkPostalCodePlus4")
  private String workPostalCodePlus4 = null;

  @JsonProperty("WorkStateOrProvince")
  private AnyOforgResoMetadataContactsCreateWorkStateOrProvince workStateOrProvince = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataContactsCreateOriginatingSystem originatingSystem = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataContactsCreateSourceSystem sourceSystem = null;

  @JsonProperty("OwnerMember")
  private AnyOforgResoMetadataContactsCreateOwnerMember ownerMember = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMediaCreate> socialMedia = null;

  public OrgResoMetadataContactsCreate anniversary(LocalDate anniversary) {
    this.anniversary = anniversary;
    return this;
  }

  /**
   * Get anniversary
   * @return anniversary
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getAnniversary() {
    return anniversary;
  }

  public void setAnniversary(LocalDate anniversary) {
    this.anniversary = anniversary;
  }

  public OrgResoMetadataContactsCreate assistantEmail(String assistantEmail) {
    this.assistantEmail = assistantEmail;
    return this;
  }

  /**
   * Get assistantEmail
   * @return assistantEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getAssistantEmail() {
    return assistantEmail;
  }

  public void setAssistantEmail(String assistantEmail) {
    this.assistantEmail = assistantEmail;
  }

  public OrgResoMetadataContactsCreate assistantName(String assistantName) {
    this.assistantName = assistantName;
    return this;
  }

  /**
   * Get assistantName
   * @return assistantName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getAssistantName() {
    return assistantName;
  }

  public void setAssistantName(String assistantName) {
    this.assistantName = assistantName;
  }

  public OrgResoMetadataContactsCreate assistantPhone(String assistantPhone) {
    this.assistantPhone = assistantPhone;
    return this;
  }

  /**
   * Get assistantPhone
   * @return assistantPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssistantPhone() {
    return assistantPhone;
  }

  public void setAssistantPhone(String assistantPhone) {
    this.assistantPhone = assistantPhone;
  }

  public OrgResoMetadataContactsCreate assistantPhoneExt(String assistantPhoneExt) {
    this.assistantPhoneExt = assistantPhoneExt;
    return this;
  }

  /**
   * Get assistantPhoneExt
   * @return assistantPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getAssistantPhoneExt() {
    return assistantPhoneExt;
  }

  public void setAssistantPhoneExt(String assistantPhoneExt) {
    this.assistantPhoneExt = assistantPhoneExt;
  }

  public OrgResoMetadataContactsCreate birthdate(LocalDate birthdate) {
    this.birthdate = birthdate;
    return this;
  }

  /**
   * Get birthdate
   * @return birthdate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getBirthdate() {
    return birthdate;
  }

  public void setBirthdate(LocalDate birthdate) {
    this.birthdate = birthdate;
  }

  public OrgResoMetadataContactsCreate businessFax(String businessFax) {
    this.businessFax = businessFax;
    return this;
  }

  /**
   * Get businessFax
   * @return businessFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBusinessFax() {
    return businessFax;
  }

  public void setBusinessFax(String businessFax) {
    this.businessFax = businessFax;
  }

  public OrgResoMetadataContactsCreate children(String children) {
    this.children = children;
    return this;
  }

  /**
   * Get children
   * @return children
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getChildren() {
    return children;
  }

  public void setChildren(String children) {
    this.children = children;
  }

  public OrgResoMetadataContactsCreate company(String company) {
    this.company = company;
    return this;
  }

  /**
   * Get company
   * @return company
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCompany() {
    return company;
  }

  public void setCompany(String company) {
    this.company = company;
  }

  public OrgResoMetadataContactsCreate contactKey(String contactKey) {
    this.contactKey = contactKey;
    return this;
  }

  /**
   * Get contactKey
   * @return contactKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getContactKey() {
    return contactKey;
  }

  public void setContactKey(String contactKey) {
    this.contactKey = contactKey;
  }

  public OrgResoMetadataContactsCreate contactKeyNumeric(AnyOforgResoMetadataContactsCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
    return this;
  }

  /**
   * Get contactKeyNumeric
   * @return contactKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactsCreateContactKeyNumeric getContactKeyNumeric() {
    return contactKeyNumeric;
  }

  public void setContactKeyNumeric(AnyOforgResoMetadataContactsCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
  }

  public OrgResoMetadataContactsCreate contactLoginId(String contactLoginId) {
    this.contactLoginId = contactLoginId;
    return this;
  }

  /**
   * Get contactLoginId
   * @return contactLoginId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getContactLoginId() {
    return contactLoginId;
  }

  public void setContactLoginId(String contactLoginId) {
    this.contactLoginId = contactLoginId;
  }

  public OrgResoMetadataContactsCreate contactPassword(String contactPassword) {
    this.contactPassword = contactPassword;
    return this;
  }

  /**
   * Get contactPassword
   * @return contactPassword
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getContactPassword() {
    return contactPassword;
  }

  public void setContactPassword(String contactPassword) {
    this.contactPassword = contactPassword;
  }

  public OrgResoMetadataContactsCreate contactStatus(AnyOforgResoMetadataContactsCreateContactStatus contactStatus) {
    this.contactStatus = contactStatus;
    return this;
  }

  /**
   * Get contactStatus
   * @return contactStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateContactStatus getContactStatus() {
    return contactStatus;
  }

  public void setContactStatus(AnyOforgResoMetadataContactsCreateContactStatus contactStatus) {
    this.contactStatus = contactStatus;
  }

  public OrgResoMetadataContactsCreate contactType(List<OrgResoMetadataEnumsContactType> contactType) {
    this.contactType = contactType;
    return this;
  }

  public OrgResoMetadataContactsCreate addContactTypeItem(OrgResoMetadataEnumsContactType contactTypeItem) {
    if (this.contactType == null) {
      this.contactType = new ArrayList<OrgResoMetadataEnumsContactType>();
    }
    this.contactType.add(contactTypeItem);
    return this;
  }

  /**
   * Get contactType
   * @return contactType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsContactType> getContactType() {
    return contactType;
  }

  public void setContactType(List<OrgResoMetadataEnumsContactType> contactType) {
    this.contactType = contactType;
  }

  public OrgResoMetadataContactsCreate department(String department) {
    this.department = department;
    return this;
  }

  /**
   * Get department
   * @return department
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getDepartment() {
    return department;
  }

  public void setDepartment(String department) {
    this.department = department;
  }

  public OrgResoMetadataContactsCreate directPhone(String directPhone) {
    this.directPhone = directPhone;
    return this;
  }

  /**
   * Get directPhone
   * @return directPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getDirectPhone() {
    return directPhone;
  }

  public void setDirectPhone(String directPhone) {
    this.directPhone = directPhone;
  }

  public OrgResoMetadataContactsCreate email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public OrgResoMetadataContactsCreate email2(String email2) {
    this.email2 = email2;
    return this;
  }

  /**
   * Get email2
   * @return email2
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getEmail2() {
    return email2;
  }

  public void setEmail2(String email2) {
    this.email2 = email2;
  }

  public OrgResoMetadataContactsCreate email3(String email3) {
    this.email3 = email3;
    return this;
  }

  /**
   * Get email3
   * @return email3
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getEmail3() {
    return email3;
  }

  public void setEmail3(String email3) {
    this.email3 = email3;
  }

  public OrgResoMetadataContactsCreate firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * Get firstName
   * @return firstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public OrgResoMetadataContactsCreate fullName(String fullName) {
    this.fullName = fullName;
    return this;
  }

  /**
   * Get fullName
   * @return fullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public OrgResoMetadataContactsCreate homeAddress1(String homeAddress1) {
    this.homeAddress1 = homeAddress1;
    return this;
  }

  /**
   * Get homeAddress1
   * @return homeAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getHomeAddress1() {
    return homeAddress1;
  }

  public void setHomeAddress1(String homeAddress1) {
    this.homeAddress1 = homeAddress1;
  }

  public OrgResoMetadataContactsCreate homeAddress2(String homeAddress2) {
    this.homeAddress2 = homeAddress2;
    return this;
  }

  /**
   * Get homeAddress2
   * @return homeAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getHomeAddress2() {
    return homeAddress2;
  }

  public void setHomeAddress2(String homeAddress2) {
    this.homeAddress2 = homeAddress2;
  }

  public OrgResoMetadataContactsCreate homeCarrierRoute(String homeCarrierRoute) {
    this.homeCarrierRoute = homeCarrierRoute;
    return this;
  }

  /**
   * Get homeCarrierRoute
   * @return homeCarrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getHomeCarrierRoute() {
    return homeCarrierRoute;
  }

  public void setHomeCarrierRoute(String homeCarrierRoute) {
    this.homeCarrierRoute = homeCarrierRoute;
  }

  public OrgResoMetadataContactsCreate homeCity(String homeCity) {
    this.homeCity = homeCity;
    return this;
  }

  /**
   * Get homeCity
   * @return homeCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getHomeCity() {
    return homeCity;
  }

  public void setHomeCity(String homeCity) {
    this.homeCity = homeCity;
  }

  public OrgResoMetadataContactsCreate homeCountry(AnyOforgResoMetadataContactsCreateHomeCountry homeCountry) {
    this.homeCountry = homeCountry;
    return this;
  }

  /**
   * Get homeCountry
   * @return homeCountry
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateHomeCountry getHomeCountry() {
    return homeCountry;
  }

  public void setHomeCountry(AnyOforgResoMetadataContactsCreateHomeCountry homeCountry) {
    this.homeCountry = homeCountry;
  }

  public OrgResoMetadataContactsCreate homeCountyOrParish(AnyOforgResoMetadataContactsCreateHomeCountyOrParish homeCountyOrParish) {
    this.homeCountyOrParish = homeCountyOrParish;
    return this;
  }

  /**
   * Get homeCountyOrParish
   * @return homeCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateHomeCountyOrParish getHomeCountyOrParish() {
    return homeCountyOrParish;
  }

  public void setHomeCountyOrParish(AnyOforgResoMetadataContactsCreateHomeCountyOrParish homeCountyOrParish) {
    this.homeCountyOrParish = homeCountyOrParish;
  }

  public OrgResoMetadataContactsCreate homeFax(String homeFax) {
    this.homeFax = homeFax;
    return this;
  }

  /**
   * Get homeFax
   * @return homeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getHomeFax() {
    return homeFax;
  }

  public void setHomeFax(String homeFax) {
    this.homeFax = homeFax;
  }

  public OrgResoMetadataContactsCreate homePhone(String homePhone) {
    this.homePhone = homePhone;
    return this;
  }

  /**
   * Get homePhone
   * @return homePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getHomePhone() {
    return homePhone;
  }

  public void setHomePhone(String homePhone) {
    this.homePhone = homePhone;
  }

  public OrgResoMetadataContactsCreate homePostalCode(String homePostalCode) {
    this.homePostalCode = homePostalCode;
    return this;
  }

  /**
   * Get homePostalCode
   * @return homePostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getHomePostalCode() {
    return homePostalCode;
  }

  public void setHomePostalCode(String homePostalCode) {
    this.homePostalCode = homePostalCode;
  }

  public OrgResoMetadataContactsCreate homePostalCodePlus4(String homePostalCodePlus4) {
    this.homePostalCodePlus4 = homePostalCodePlus4;
    return this;
  }

  /**
   * Get homePostalCodePlus4
   * @return homePostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getHomePostalCodePlus4() {
    return homePostalCodePlus4;
  }

  public void setHomePostalCodePlus4(String homePostalCodePlus4) {
    this.homePostalCodePlus4 = homePostalCodePlus4;
  }

  public OrgResoMetadataContactsCreate homeStateOrProvince(AnyOforgResoMetadataContactsCreateHomeStateOrProvince homeStateOrProvince) {
    this.homeStateOrProvince = homeStateOrProvince;
    return this;
  }

  /**
   * Get homeStateOrProvince
   * @return homeStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateHomeStateOrProvince getHomeStateOrProvince() {
    return homeStateOrProvince;
  }

  public void setHomeStateOrProvince(AnyOforgResoMetadataContactsCreateHomeStateOrProvince homeStateOrProvince) {
    this.homeStateOrProvince = homeStateOrProvince;
  }

  public OrgResoMetadataContactsCreate jobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
    return this;
  }

  /**
   * Get jobTitle
   * @return jobTitle
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getJobTitle() {
    return jobTitle;
  }

  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  public OrgResoMetadataContactsCreate language(List<OrgResoMetadataEnumsLanguages> language) {
    this.language = language;
    return this;
  }

  public OrgResoMetadataContactsCreate addLanguageItem(OrgResoMetadataEnumsLanguages languageItem) {
    if (this.language == null) {
      this.language = new ArrayList<OrgResoMetadataEnumsLanguages>();
    }
    this.language.add(languageItem);
    return this;
  }

  /**
   * Get language
   * @return language
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLanguages> getLanguage() {
    return language;
  }

  public void setLanguage(List<OrgResoMetadataEnumsLanguages> language) {
    this.language = language;
  }

  public OrgResoMetadataContactsCreate lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  /**
   * Get lastName
   * @return lastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public OrgResoMetadataContactsCreate leadSource(String leadSource) {
    this.leadSource = leadSource;
    return this;
  }

  /**
   * Get leadSource
   * @return leadSource
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getLeadSource() {
    return leadSource;
  }

  public void setLeadSource(String leadSource) {
    this.leadSource = leadSource;
  }

  public OrgResoMetadataContactsCreate middleName(String middleName) {
    this.middleName = middleName;
    return this;
  }

  /**
   * Get middleName
   * @return middleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getMiddleName() {
    return middleName;
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  public OrgResoMetadataContactsCreate mobilePhone(String mobilePhone) {
    this.mobilePhone = mobilePhone;
    return this;
  }

  /**
   * Get mobilePhone
   * @return mobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getMobilePhone() {
    return mobilePhone;
  }

  public void setMobilePhone(String mobilePhone) {
    this.mobilePhone = mobilePhone;
  }

  public OrgResoMetadataContactsCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataContactsCreate namePrefix(String namePrefix) {
    this.namePrefix = namePrefix;
    return this;
  }

  /**
   * Get namePrefix
   * @return namePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getNamePrefix() {
    return namePrefix;
  }

  public void setNamePrefix(String namePrefix) {
    this.namePrefix = namePrefix;
  }

  public OrgResoMetadataContactsCreate nameSuffix(String nameSuffix) {
    this.nameSuffix = nameSuffix;
    return this;
  }

  /**
   * Get nameSuffix
   * @return nameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getNameSuffix() {
    return nameSuffix;
  }

  public void setNameSuffix(String nameSuffix) {
    this.nameSuffix = nameSuffix;
  }

  public OrgResoMetadataContactsCreate nickname(String nickname) {
    this.nickname = nickname;
    return this;
  }

  /**
   * Get nickname
   * @return nickname
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getNickname() {
    return nickname;
  }

  public void setNickname(String nickname) {
    this.nickname = nickname;
  }

  public OrgResoMetadataContactsCreate notes(String notes) {
    this.notes = notes;
    return this;
  }

  /**
   * Get notes
   * @return notes
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public OrgResoMetadataContactsCreate officePhone(String officePhone) {
    this.officePhone = officePhone;
    return this;
  }

  /**
   * Get officePhone
   * @return officePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficePhone() {
    return officePhone;
  }

  public void setOfficePhone(String officePhone) {
    this.officePhone = officePhone;
  }

  public OrgResoMetadataContactsCreate officePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
    return this;
  }

  /**
   * Get officePhoneExt
   * @return officePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePhoneExt() {
    return officePhoneExt;
  }

  public void setOfficePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
  }

  public OrgResoMetadataContactsCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataContactsCreate originatingSystemContactKey(String originatingSystemContactKey) {
    this.originatingSystemContactKey = originatingSystemContactKey;
    return this;
  }

  /**
   * Get originatingSystemContactKey
   * @return originatingSystemContactKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemContactKey() {
    return originatingSystemContactKey;
  }

  public void setOriginatingSystemContactKey(String originatingSystemContactKey) {
    this.originatingSystemContactKey = originatingSystemContactKey;
  }

  public OrgResoMetadataContactsCreate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataContactsCreate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataContactsCreate otherAddress1(String otherAddress1) {
    this.otherAddress1 = otherAddress1;
    return this;
  }

  /**
   * Get otherAddress1
   * @return otherAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOtherAddress1() {
    return otherAddress1;
  }

  public void setOtherAddress1(String otherAddress1) {
    this.otherAddress1 = otherAddress1;
  }

  public OrgResoMetadataContactsCreate otherAddress2(String otherAddress2) {
    this.otherAddress2 = otherAddress2;
    return this;
  }

  /**
   * Get otherAddress2
   * @return otherAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOtherAddress2() {
    return otherAddress2;
  }

  public void setOtherAddress2(String otherAddress2) {
    this.otherAddress2 = otherAddress2;
  }

  public OrgResoMetadataContactsCreate otherCarrierRoute(String otherCarrierRoute) {
    this.otherCarrierRoute = otherCarrierRoute;
    return this;
  }

  /**
   * Get otherCarrierRoute
   * @return otherCarrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getOtherCarrierRoute() {
    return otherCarrierRoute;
  }

  public void setOtherCarrierRoute(String otherCarrierRoute) {
    this.otherCarrierRoute = otherCarrierRoute;
  }

  public OrgResoMetadataContactsCreate otherCity(String otherCity) {
    this.otherCity = otherCity;
    return this;
  }

  /**
   * Get otherCity
   * @return otherCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOtherCity() {
    return otherCity;
  }

  public void setOtherCity(String otherCity) {
    this.otherCity = otherCity;
  }

  public OrgResoMetadataContactsCreate otherCountry(AnyOforgResoMetadataContactsCreateOtherCountry otherCountry) {
    this.otherCountry = otherCountry;
    return this;
  }

  /**
   * Get otherCountry
   * @return otherCountry
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOtherCountry getOtherCountry() {
    return otherCountry;
  }

  public void setOtherCountry(AnyOforgResoMetadataContactsCreateOtherCountry otherCountry) {
    this.otherCountry = otherCountry;
  }

  public OrgResoMetadataContactsCreate otherCountyOrParish(AnyOforgResoMetadataContactsCreateOtherCountyOrParish otherCountyOrParish) {
    this.otherCountyOrParish = otherCountyOrParish;
    return this;
  }

  /**
   * Get otherCountyOrParish
   * @return otherCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOtherCountyOrParish getOtherCountyOrParish() {
    return otherCountyOrParish;
  }

  public void setOtherCountyOrParish(AnyOforgResoMetadataContactsCreateOtherCountyOrParish otherCountyOrParish) {
    this.otherCountyOrParish = otherCountyOrParish;
  }

  public OrgResoMetadataContactsCreate otherPhoneType(AnyOforgResoMetadataContactsCreateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
    return this;
  }

  /**
   * Get otherPhoneType
   * @return otherPhoneType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOtherPhoneType getOtherPhoneType() {
    return otherPhoneType;
  }

  public void setOtherPhoneType(AnyOforgResoMetadataContactsCreateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
  }

  public OrgResoMetadataContactsCreate otherPostalCode(String otherPostalCode) {
    this.otherPostalCode = otherPostalCode;
    return this;
  }

  /**
   * Get otherPostalCode
   * @return otherPostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOtherPostalCode() {
    return otherPostalCode;
  }

  public void setOtherPostalCode(String otherPostalCode) {
    this.otherPostalCode = otherPostalCode;
  }

  public OrgResoMetadataContactsCreate otherPostalCodePlus4(String otherPostalCodePlus4) {
    this.otherPostalCodePlus4 = otherPostalCodePlus4;
    return this;
  }

  /**
   * Get otherPostalCodePlus4
   * @return otherPostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getOtherPostalCodePlus4() {
    return otherPostalCodePlus4;
  }

  public void setOtherPostalCodePlus4(String otherPostalCodePlus4) {
    this.otherPostalCodePlus4 = otherPostalCodePlus4;
  }

  public OrgResoMetadataContactsCreate otherStateOrProvince(AnyOforgResoMetadataContactsCreateOtherStateOrProvince otherStateOrProvince) {
    this.otherStateOrProvince = otherStateOrProvince;
    return this;
  }

  /**
   * Get otherStateOrProvince
   * @return otherStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOtherStateOrProvince getOtherStateOrProvince() {
    return otherStateOrProvince;
  }

  public void setOtherStateOrProvince(AnyOforgResoMetadataContactsCreateOtherStateOrProvince otherStateOrProvince) {
    this.otherStateOrProvince = otherStateOrProvince;
  }

  public OrgResoMetadataContactsCreate ownerMemberID(String ownerMemberID) {
    this.ownerMemberID = ownerMemberID;
    return this;
  }

  /**
   * Get ownerMemberID
   * @return ownerMemberID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOwnerMemberID() {
    return ownerMemberID;
  }

  public void setOwnerMemberID(String ownerMemberID) {
    this.ownerMemberID = ownerMemberID;
  }

  public OrgResoMetadataContactsCreate ownerMemberKey(String ownerMemberKey) {
    this.ownerMemberKey = ownerMemberKey;
    return this;
  }

  /**
   * Get ownerMemberKey
   * @return ownerMemberKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOwnerMemberKey() {
    return ownerMemberKey;
  }

  public void setOwnerMemberKey(String ownerMemberKey) {
    this.ownerMemberKey = ownerMemberKey;
  }

  public OrgResoMetadataContactsCreate ownerMemberKeyNumeric(AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric) {
    this.ownerMemberKeyNumeric = ownerMemberKeyNumeric;
    return this;
  }

  /**
   * Get ownerMemberKeyNumeric
   * @return ownerMemberKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric getOwnerMemberKeyNumeric() {
    return ownerMemberKeyNumeric;
  }

  public void setOwnerMemberKeyNumeric(AnyOforgResoMetadataContactsCreateOwnerMemberKeyNumeric ownerMemberKeyNumeric) {
    this.ownerMemberKeyNumeric = ownerMemberKeyNumeric;
  }

  public OrgResoMetadataContactsCreate pager(String pager) {
    this.pager = pager;
    return this;
  }

  /**
   * Get pager
   * @return pager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getPager() {
    return pager;
  }

  public void setPager(String pager) {
    this.pager = pager;
  }

  public OrgResoMetadataContactsCreate phoneTTYTDD(String phoneTTYTDD) {
    this.phoneTTYTDD = phoneTTYTDD;
    return this;
  }

  /**
   * Get phoneTTYTDD
   * @return phoneTTYTDD
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getPhoneTTYTDD() {
    return phoneTTYTDD;
  }

  public void setPhoneTTYTDD(String phoneTTYTDD) {
    this.phoneTTYTDD = phoneTTYTDD;
  }

  public OrgResoMetadataContactsCreate preferredAddress(AnyOforgResoMetadataContactsCreatePreferredAddress preferredAddress) {
    this.preferredAddress = preferredAddress;
    return this;
  }

  /**
   * Get preferredAddress
   * @return preferredAddress
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreatePreferredAddress getPreferredAddress() {
    return preferredAddress;
  }

  public void setPreferredAddress(AnyOforgResoMetadataContactsCreatePreferredAddress preferredAddress) {
    this.preferredAddress = preferredAddress;
  }

  public OrgResoMetadataContactsCreate preferredPhone(AnyOforgResoMetadataContactsCreatePreferredPhone preferredPhone) {
    this.preferredPhone = preferredPhone;
    return this;
  }

  /**
   * Get preferredPhone
   * @return preferredPhone
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreatePreferredPhone getPreferredPhone() {
    return preferredPhone;
  }

  public void setPreferredPhone(AnyOforgResoMetadataContactsCreatePreferredPhone preferredPhone) {
    this.preferredPhone = preferredPhone;
  }

  public OrgResoMetadataContactsCreate referredBy(String referredBy) {
    this.referredBy = referredBy;
    return this;
  }

  /**
   * Get referredBy
   * @return referredBy
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getReferredBy() {
    return referredBy;
  }

  public void setReferredBy(String referredBy) {
    this.referredBy = referredBy;
  }

  public OrgResoMetadataContactsCreate socialMediaType(AnyOforgResoMetadataContactsCreateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
    return this;
  }

  /**
   * Get socialMediaType
   * @return socialMediaType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateSocialMediaType getSocialMediaType() {
    return socialMediaType;
  }

  public void setSocialMediaType(AnyOforgResoMetadataContactsCreateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
  }

  public OrgResoMetadataContactsCreate sourceSystemContactKey(String sourceSystemContactKey) {
    this.sourceSystemContactKey = sourceSystemContactKey;
    return this;
  }

  /**
   * Get sourceSystemContactKey
   * @return sourceSystemContactKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemContactKey() {
    return sourceSystemContactKey;
  }

  public void setSourceSystemContactKey(String sourceSystemContactKey) {
    this.sourceSystemContactKey = sourceSystemContactKey;
  }

  public OrgResoMetadataContactsCreate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataContactsCreate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataContactsCreate spousePartnerName(String spousePartnerName) {
    this.spousePartnerName = spousePartnerName;
    return this;
  }

  /**
   * Get spousePartnerName
   * @return spousePartnerName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getSpousePartnerName() {
    return spousePartnerName;
  }

  public void setSpousePartnerName(String spousePartnerName) {
    this.spousePartnerName = spousePartnerName;
  }

  public OrgResoMetadataContactsCreate tollFreePhone(String tollFreePhone) {
    this.tollFreePhone = tollFreePhone;
    return this;
  }

  /**
   * Get tollFreePhone
   * @return tollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getTollFreePhone() {
    return tollFreePhone;
  }

  public void setTollFreePhone(String tollFreePhone) {
    this.tollFreePhone = tollFreePhone;
  }

  public OrgResoMetadataContactsCreate voiceMail(String voiceMail) {
    this.voiceMail = voiceMail;
    return this;
  }

  /**
   * Get voiceMail
   * @return voiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getVoiceMail() {
    return voiceMail;
  }

  public void setVoiceMail(String voiceMail) {
    this.voiceMail = voiceMail;
  }

  public OrgResoMetadataContactsCreate voiceMailExt(String voiceMailExt) {
    this.voiceMailExt = voiceMailExt;
    return this;
  }

  /**
   * Get voiceMailExt
   * @return voiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getVoiceMailExt() {
    return voiceMailExt;
  }

  public void setVoiceMailExt(String voiceMailExt) {
    this.voiceMailExt = voiceMailExt;
  }

  public OrgResoMetadataContactsCreate workAddress1(String workAddress1) {
    this.workAddress1 = workAddress1;
    return this;
  }

  /**
   * Get workAddress1
   * @return workAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWorkAddress1() {
    return workAddress1;
  }

  public void setWorkAddress1(String workAddress1) {
    this.workAddress1 = workAddress1;
  }

  public OrgResoMetadataContactsCreate workAddress2(String workAddress2) {
    this.workAddress2 = workAddress2;
    return this;
  }

  /**
   * Get workAddress2
   * @return workAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWorkAddress2() {
    return workAddress2;
  }

  public void setWorkAddress2(String workAddress2) {
    this.workAddress2 = workAddress2;
  }

  public OrgResoMetadataContactsCreate workCarrierRoute(String workCarrierRoute) {
    this.workCarrierRoute = workCarrierRoute;
    return this;
  }

  /**
   * Get workCarrierRoute
   * @return workCarrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getWorkCarrierRoute() {
    return workCarrierRoute;
  }

  public void setWorkCarrierRoute(String workCarrierRoute) {
    this.workCarrierRoute = workCarrierRoute;
  }

  public OrgResoMetadataContactsCreate workCity(String workCity) {
    this.workCity = workCity;
    return this;
  }

  /**
   * Get workCity
   * @return workCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWorkCity() {
    return workCity;
  }

  public void setWorkCity(String workCity) {
    this.workCity = workCity;
  }

  public OrgResoMetadataContactsCreate workCountry(AnyOforgResoMetadataContactsCreateWorkCountry workCountry) {
    this.workCountry = workCountry;
    return this;
  }

  /**
   * Get workCountry
   * @return workCountry
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateWorkCountry getWorkCountry() {
    return workCountry;
  }

  public void setWorkCountry(AnyOforgResoMetadataContactsCreateWorkCountry workCountry) {
    this.workCountry = workCountry;
  }

  public OrgResoMetadataContactsCreate workCountyOrParish(AnyOforgResoMetadataContactsCreateWorkCountyOrParish workCountyOrParish) {
    this.workCountyOrParish = workCountyOrParish;
    return this;
  }

  /**
   * Get workCountyOrParish
   * @return workCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateWorkCountyOrParish getWorkCountyOrParish() {
    return workCountyOrParish;
  }

  public void setWorkCountyOrParish(AnyOforgResoMetadataContactsCreateWorkCountyOrParish workCountyOrParish) {
    this.workCountyOrParish = workCountyOrParish;
  }

  public OrgResoMetadataContactsCreate workPostalCode(String workPostalCode) {
    this.workPostalCode = workPostalCode;
    return this;
  }

  /**
   * Get workPostalCode
   * @return workPostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getWorkPostalCode() {
    return workPostalCode;
  }

  public void setWorkPostalCode(String workPostalCode) {
    this.workPostalCode = workPostalCode;
  }

  public OrgResoMetadataContactsCreate workPostalCodePlus4(String workPostalCodePlus4) {
    this.workPostalCodePlus4 = workPostalCodePlus4;
    return this;
  }

  /**
   * Get workPostalCodePlus4
   * @return workPostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getWorkPostalCodePlus4() {
    return workPostalCodePlus4;
  }

  public void setWorkPostalCodePlus4(String workPostalCodePlus4) {
    this.workPostalCodePlus4 = workPostalCodePlus4;
  }

  public OrgResoMetadataContactsCreate workStateOrProvince(AnyOforgResoMetadataContactsCreateWorkStateOrProvince workStateOrProvince) {
    this.workStateOrProvince = workStateOrProvince;
    return this;
  }

  /**
   * Get workStateOrProvince
   * @return workStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateWorkStateOrProvince getWorkStateOrProvince() {
    return workStateOrProvince;
  }

  public void setWorkStateOrProvince(AnyOforgResoMetadataContactsCreateWorkStateOrProvince workStateOrProvince) {
    this.workStateOrProvince = workStateOrProvince;
  }

  public OrgResoMetadataContactsCreate originatingSystem(AnyOforgResoMetadataContactsCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataContactsCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataContactsCreate sourceSystem(AnyOforgResoMetadataContactsCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataContactsCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataContactsCreate ownerMember(AnyOforgResoMetadataContactsCreateOwnerMember ownerMember) {
    this.ownerMember = ownerMember;
    return this;
  }

  /**
   * Get ownerMember
   * @return ownerMember
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactsCreateOwnerMember getOwnerMember() {
    return ownerMember;
  }

  public void setOwnerMember(AnyOforgResoMetadataContactsCreateOwnerMember ownerMember) {
    this.ownerMember = ownerMember;
  }

  public OrgResoMetadataContactsCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataContactsCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataContactsCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataContactsCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }

  public OrgResoMetadataContactsCreate socialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataContactsCreate addSocialMediaItem(OrgResoMetadataSocialMediaCreate socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMediaCreate>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMediaCreate> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataContactsCreate orgResoMetadataContactsCreate = (OrgResoMetadataContactsCreate) o;
    return Objects.equals(this.anniversary, orgResoMetadataContactsCreate.anniversary) &&
        Objects.equals(this.assistantEmail, orgResoMetadataContactsCreate.assistantEmail) &&
        Objects.equals(this.assistantName, orgResoMetadataContactsCreate.assistantName) &&
        Objects.equals(this.assistantPhone, orgResoMetadataContactsCreate.assistantPhone) &&
        Objects.equals(this.assistantPhoneExt, orgResoMetadataContactsCreate.assistantPhoneExt) &&
        Objects.equals(this.birthdate, orgResoMetadataContactsCreate.birthdate) &&
        Objects.equals(this.businessFax, orgResoMetadataContactsCreate.businessFax) &&
        Objects.equals(this.children, orgResoMetadataContactsCreate.children) &&
        Objects.equals(this.company, orgResoMetadataContactsCreate.company) &&
        Objects.equals(this.contactKey, orgResoMetadataContactsCreate.contactKey) &&
        Objects.equals(this.contactKeyNumeric, orgResoMetadataContactsCreate.contactKeyNumeric) &&
        Objects.equals(this.contactLoginId, orgResoMetadataContactsCreate.contactLoginId) &&
        Objects.equals(this.contactPassword, orgResoMetadataContactsCreate.contactPassword) &&
        Objects.equals(this.contactStatus, orgResoMetadataContactsCreate.contactStatus) &&
        Objects.equals(this.contactType, orgResoMetadataContactsCreate.contactType) &&
        Objects.equals(this.department, orgResoMetadataContactsCreate.department) &&
        Objects.equals(this.directPhone, orgResoMetadataContactsCreate.directPhone) &&
        Objects.equals(this.email, orgResoMetadataContactsCreate.email) &&
        Objects.equals(this.email2, orgResoMetadataContactsCreate.email2) &&
        Objects.equals(this.email3, orgResoMetadataContactsCreate.email3) &&
        Objects.equals(this.firstName, orgResoMetadataContactsCreate.firstName) &&
        Objects.equals(this.fullName, orgResoMetadataContactsCreate.fullName) &&
        Objects.equals(this.homeAddress1, orgResoMetadataContactsCreate.homeAddress1) &&
        Objects.equals(this.homeAddress2, orgResoMetadataContactsCreate.homeAddress2) &&
        Objects.equals(this.homeCarrierRoute, orgResoMetadataContactsCreate.homeCarrierRoute) &&
        Objects.equals(this.homeCity, orgResoMetadataContactsCreate.homeCity) &&
        Objects.equals(this.homeCountry, orgResoMetadataContactsCreate.homeCountry) &&
        Objects.equals(this.homeCountyOrParish, orgResoMetadataContactsCreate.homeCountyOrParish) &&
        Objects.equals(this.homeFax, orgResoMetadataContactsCreate.homeFax) &&
        Objects.equals(this.homePhone, orgResoMetadataContactsCreate.homePhone) &&
        Objects.equals(this.homePostalCode, orgResoMetadataContactsCreate.homePostalCode) &&
        Objects.equals(this.homePostalCodePlus4, orgResoMetadataContactsCreate.homePostalCodePlus4) &&
        Objects.equals(this.homeStateOrProvince, orgResoMetadataContactsCreate.homeStateOrProvince) &&
        Objects.equals(this.jobTitle, orgResoMetadataContactsCreate.jobTitle) &&
        Objects.equals(this.language, orgResoMetadataContactsCreate.language) &&
        Objects.equals(this.lastName, orgResoMetadataContactsCreate.lastName) &&
        Objects.equals(this.leadSource, orgResoMetadataContactsCreate.leadSource) &&
        Objects.equals(this.middleName, orgResoMetadataContactsCreate.middleName) &&
        Objects.equals(this.mobilePhone, orgResoMetadataContactsCreate.mobilePhone) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataContactsCreate.modificationTimestamp) &&
        Objects.equals(this.namePrefix, orgResoMetadataContactsCreate.namePrefix) &&
        Objects.equals(this.nameSuffix, orgResoMetadataContactsCreate.nameSuffix) &&
        Objects.equals(this.nickname, orgResoMetadataContactsCreate.nickname) &&
        Objects.equals(this.notes, orgResoMetadataContactsCreate.notes) &&
        Objects.equals(this.officePhone, orgResoMetadataContactsCreate.officePhone) &&
        Objects.equals(this.officePhoneExt, orgResoMetadataContactsCreate.officePhoneExt) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataContactsCreate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemContactKey, orgResoMetadataContactsCreate.originatingSystemContactKey) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataContactsCreate.originatingSystemID) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataContactsCreate.originatingSystemName) &&
        Objects.equals(this.otherAddress1, orgResoMetadataContactsCreate.otherAddress1) &&
        Objects.equals(this.otherAddress2, orgResoMetadataContactsCreate.otherAddress2) &&
        Objects.equals(this.otherCarrierRoute, orgResoMetadataContactsCreate.otherCarrierRoute) &&
        Objects.equals(this.otherCity, orgResoMetadataContactsCreate.otherCity) &&
        Objects.equals(this.otherCountry, orgResoMetadataContactsCreate.otherCountry) &&
        Objects.equals(this.otherCountyOrParish, orgResoMetadataContactsCreate.otherCountyOrParish) &&
        Objects.equals(this.otherPhoneType, orgResoMetadataContactsCreate.otherPhoneType) &&
        Objects.equals(this.otherPostalCode, orgResoMetadataContactsCreate.otherPostalCode) &&
        Objects.equals(this.otherPostalCodePlus4, orgResoMetadataContactsCreate.otherPostalCodePlus4) &&
        Objects.equals(this.otherStateOrProvince, orgResoMetadataContactsCreate.otherStateOrProvince) &&
        Objects.equals(this.ownerMemberID, orgResoMetadataContactsCreate.ownerMemberID) &&
        Objects.equals(this.ownerMemberKey, orgResoMetadataContactsCreate.ownerMemberKey) &&
        Objects.equals(this.ownerMemberKeyNumeric, orgResoMetadataContactsCreate.ownerMemberKeyNumeric) &&
        Objects.equals(this.pager, orgResoMetadataContactsCreate.pager) &&
        Objects.equals(this.phoneTTYTDD, orgResoMetadataContactsCreate.phoneTTYTDD) &&
        Objects.equals(this.preferredAddress, orgResoMetadataContactsCreate.preferredAddress) &&
        Objects.equals(this.preferredPhone, orgResoMetadataContactsCreate.preferredPhone) &&
        Objects.equals(this.referredBy, orgResoMetadataContactsCreate.referredBy) &&
        Objects.equals(this.socialMediaType, orgResoMetadataContactsCreate.socialMediaType) &&
        Objects.equals(this.sourceSystemContactKey, orgResoMetadataContactsCreate.sourceSystemContactKey) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataContactsCreate.sourceSystemID) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataContactsCreate.sourceSystemName) &&
        Objects.equals(this.spousePartnerName, orgResoMetadataContactsCreate.spousePartnerName) &&
        Objects.equals(this.tollFreePhone, orgResoMetadataContactsCreate.tollFreePhone) &&
        Objects.equals(this.voiceMail, orgResoMetadataContactsCreate.voiceMail) &&
        Objects.equals(this.voiceMailExt, orgResoMetadataContactsCreate.voiceMailExt) &&
        Objects.equals(this.workAddress1, orgResoMetadataContactsCreate.workAddress1) &&
        Objects.equals(this.workAddress2, orgResoMetadataContactsCreate.workAddress2) &&
        Objects.equals(this.workCarrierRoute, orgResoMetadataContactsCreate.workCarrierRoute) &&
        Objects.equals(this.workCity, orgResoMetadataContactsCreate.workCity) &&
        Objects.equals(this.workCountry, orgResoMetadataContactsCreate.workCountry) &&
        Objects.equals(this.workCountyOrParish, orgResoMetadataContactsCreate.workCountyOrParish) &&
        Objects.equals(this.workPostalCode, orgResoMetadataContactsCreate.workPostalCode) &&
        Objects.equals(this.workPostalCodePlus4, orgResoMetadataContactsCreate.workPostalCodePlus4) &&
        Objects.equals(this.workStateOrProvince, orgResoMetadataContactsCreate.workStateOrProvince) &&
        Objects.equals(this.originatingSystem, orgResoMetadataContactsCreate.originatingSystem) &&
        Objects.equals(this.sourceSystem, orgResoMetadataContactsCreate.sourceSystem) &&
        Objects.equals(this.ownerMember, orgResoMetadataContactsCreate.ownerMember) &&
        Objects.equals(this.historyTransactional, orgResoMetadataContactsCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataContactsCreate.media) &&
        Objects.equals(this.socialMedia, orgResoMetadataContactsCreate.socialMedia);
  }

  @Override
  public int hashCode() {
    return Objects.hash(anniversary, assistantEmail, assistantName, assistantPhone, assistantPhoneExt, birthdate, businessFax, children, company, contactKey, contactKeyNumeric, contactLoginId, contactPassword, contactStatus, contactType, department, directPhone, email, email2, email3, firstName, fullName, homeAddress1, homeAddress2, homeCarrierRoute, homeCity, homeCountry, homeCountyOrParish, homeFax, homePhone, homePostalCode, homePostalCodePlus4, homeStateOrProvince, jobTitle, language, lastName, leadSource, middleName, mobilePhone, modificationTimestamp, namePrefix, nameSuffix, nickname, notes, officePhone, officePhoneExt, originalEntryTimestamp, originatingSystemContactKey, originatingSystemID, originatingSystemName, otherAddress1, otherAddress2, otherCarrierRoute, otherCity, otherCountry, otherCountyOrParish, otherPhoneType, otherPostalCode, otherPostalCodePlus4, otherStateOrProvince, ownerMemberID, ownerMemberKey, ownerMemberKeyNumeric, pager, phoneTTYTDD, preferredAddress, preferredPhone, referredBy, socialMediaType, sourceSystemContactKey, sourceSystemID, sourceSystemName, spousePartnerName, tollFreePhone, voiceMail, voiceMailExt, workAddress1, workAddress2, workCarrierRoute, workCity, workCountry, workCountyOrParish, workPostalCode, workPostalCodePlus4, workStateOrProvince, originatingSystem, sourceSystem, ownerMember, historyTransactional, media, socialMedia);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataContactsCreate {\n");
    
    sb.append("    anniversary: ").append(toIndentedString(anniversary)).append("\n");
    sb.append("    assistantEmail: ").append(toIndentedString(assistantEmail)).append("\n");
    sb.append("    assistantName: ").append(toIndentedString(assistantName)).append("\n");
    sb.append("    assistantPhone: ").append(toIndentedString(assistantPhone)).append("\n");
    sb.append("    assistantPhoneExt: ").append(toIndentedString(assistantPhoneExt)).append("\n");
    sb.append("    birthdate: ").append(toIndentedString(birthdate)).append("\n");
    sb.append("    businessFax: ").append(toIndentedString(businessFax)).append("\n");
    sb.append("    children: ").append(toIndentedString(children)).append("\n");
    sb.append("    company: ").append(toIndentedString(company)).append("\n");
    sb.append("    contactKey: ").append(toIndentedString(contactKey)).append("\n");
    sb.append("    contactKeyNumeric: ").append(toIndentedString(contactKeyNumeric)).append("\n");
    sb.append("    contactLoginId: ").append(toIndentedString(contactLoginId)).append("\n");
    sb.append("    contactPassword: ").append(toIndentedString(contactPassword)).append("\n");
    sb.append("    contactStatus: ").append(toIndentedString(contactStatus)).append("\n");
    sb.append("    contactType: ").append(toIndentedString(contactType)).append("\n");
    sb.append("    department: ").append(toIndentedString(department)).append("\n");
    sb.append("    directPhone: ").append(toIndentedString(directPhone)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    email2: ").append(toIndentedString(email2)).append("\n");
    sb.append("    email3: ").append(toIndentedString(email3)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    fullName: ").append(toIndentedString(fullName)).append("\n");
    sb.append("    homeAddress1: ").append(toIndentedString(homeAddress1)).append("\n");
    sb.append("    homeAddress2: ").append(toIndentedString(homeAddress2)).append("\n");
    sb.append("    homeCarrierRoute: ").append(toIndentedString(homeCarrierRoute)).append("\n");
    sb.append("    homeCity: ").append(toIndentedString(homeCity)).append("\n");
    sb.append("    homeCountry: ").append(toIndentedString(homeCountry)).append("\n");
    sb.append("    homeCountyOrParish: ").append(toIndentedString(homeCountyOrParish)).append("\n");
    sb.append("    homeFax: ").append(toIndentedString(homeFax)).append("\n");
    sb.append("    homePhone: ").append(toIndentedString(homePhone)).append("\n");
    sb.append("    homePostalCode: ").append(toIndentedString(homePostalCode)).append("\n");
    sb.append("    homePostalCodePlus4: ").append(toIndentedString(homePostalCodePlus4)).append("\n");
    sb.append("    homeStateOrProvince: ").append(toIndentedString(homeStateOrProvince)).append("\n");
    sb.append("    jobTitle: ").append(toIndentedString(jobTitle)).append("\n");
    sb.append("    language: ").append(toIndentedString(language)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    leadSource: ").append(toIndentedString(leadSource)).append("\n");
    sb.append("    middleName: ").append(toIndentedString(middleName)).append("\n");
    sb.append("    mobilePhone: ").append(toIndentedString(mobilePhone)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    namePrefix: ").append(toIndentedString(namePrefix)).append("\n");
    sb.append("    nameSuffix: ").append(toIndentedString(nameSuffix)).append("\n");
    sb.append("    nickname: ").append(toIndentedString(nickname)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    officePhone: ").append(toIndentedString(officePhone)).append("\n");
    sb.append("    officePhoneExt: ").append(toIndentedString(officePhoneExt)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemContactKey: ").append(toIndentedString(originatingSystemContactKey)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    otherAddress1: ").append(toIndentedString(otherAddress1)).append("\n");
    sb.append("    otherAddress2: ").append(toIndentedString(otherAddress2)).append("\n");
    sb.append("    otherCarrierRoute: ").append(toIndentedString(otherCarrierRoute)).append("\n");
    sb.append("    otherCity: ").append(toIndentedString(otherCity)).append("\n");
    sb.append("    otherCountry: ").append(toIndentedString(otherCountry)).append("\n");
    sb.append("    otherCountyOrParish: ").append(toIndentedString(otherCountyOrParish)).append("\n");
    sb.append("    otherPhoneType: ").append(toIndentedString(otherPhoneType)).append("\n");
    sb.append("    otherPostalCode: ").append(toIndentedString(otherPostalCode)).append("\n");
    sb.append("    otherPostalCodePlus4: ").append(toIndentedString(otherPostalCodePlus4)).append("\n");
    sb.append("    otherStateOrProvince: ").append(toIndentedString(otherStateOrProvince)).append("\n");
    sb.append("    ownerMemberID: ").append(toIndentedString(ownerMemberID)).append("\n");
    sb.append("    ownerMemberKey: ").append(toIndentedString(ownerMemberKey)).append("\n");
    sb.append("    ownerMemberKeyNumeric: ").append(toIndentedString(ownerMemberKeyNumeric)).append("\n");
    sb.append("    pager: ").append(toIndentedString(pager)).append("\n");
    sb.append("    phoneTTYTDD: ").append(toIndentedString(phoneTTYTDD)).append("\n");
    sb.append("    preferredAddress: ").append(toIndentedString(preferredAddress)).append("\n");
    sb.append("    preferredPhone: ").append(toIndentedString(preferredPhone)).append("\n");
    sb.append("    referredBy: ").append(toIndentedString(referredBy)).append("\n");
    sb.append("    socialMediaType: ").append(toIndentedString(socialMediaType)).append("\n");
    sb.append("    sourceSystemContactKey: ").append(toIndentedString(sourceSystemContactKey)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    spousePartnerName: ").append(toIndentedString(spousePartnerName)).append("\n");
    sb.append("    tollFreePhone: ").append(toIndentedString(tollFreePhone)).append("\n");
    sb.append("    voiceMail: ").append(toIndentedString(voiceMail)).append("\n");
    sb.append("    voiceMailExt: ").append(toIndentedString(voiceMailExt)).append("\n");
    sb.append("    workAddress1: ").append(toIndentedString(workAddress1)).append("\n");
    sb.append("    workAddress2: ").append(toIndentedString(workAddress2)).append("\n");
    sb.append("    workCarrierRoute: ").append(toIndentedString(workCarrierRoute)).append("\n");
    sb.append("    workCity: ").append(toIndentedString(workCity)).append("\n");
    sb.append("    workCountry: ").append(toIndentedString(workCountry)).append("\n");
    sb.append("    workCountyOrParish: ").append(toIndentedString(workCountyOrParish)).append("\n");
    sb.append("    workPostalCode: ").append(toIndentedString(workPostalCode)).append("\n");
    sb.append("    workPostalCodePlus4: ").append(toIndentedString(workPostalCodePlus4)).append("\n");
    sb.append("    workStateOrProvince: ").append(toIndentedString(workStateOrProvince)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    ownerMember: ").append(toIndentedString(ownerMember)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
