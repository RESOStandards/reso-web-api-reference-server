package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateFireplacesTotal
*/
public interface AnyOforgResoMetadataPropertyCreateFireplacesTotal {

}
