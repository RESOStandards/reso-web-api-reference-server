package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyMobileWidth
*/
public interface AnyOforgResoMetadataPropertyMobileWidth {

}
