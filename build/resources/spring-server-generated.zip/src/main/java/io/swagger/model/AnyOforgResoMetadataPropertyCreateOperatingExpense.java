package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateOperatingExpense
*/
public interface AnyOforgResoMetadataPropertyCreateOperatingExpense {

}
