package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger
*/
public interface AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger {

}
