package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateMobileLength
*/
public interface AnyOforgResoMetadataPropertyUpdateMobileLength {

}
