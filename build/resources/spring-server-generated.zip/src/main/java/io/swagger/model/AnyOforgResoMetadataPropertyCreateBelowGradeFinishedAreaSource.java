package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource
*/
public interface AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource {

}
