package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateWaterSewerExpense
*/
public interface AnyOforgResoMetadataPropertyUpdateWaterSewerExpense {

}
