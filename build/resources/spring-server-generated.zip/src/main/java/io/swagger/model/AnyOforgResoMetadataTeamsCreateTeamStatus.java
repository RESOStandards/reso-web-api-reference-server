package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsCreateTeamStatus
*/
public interface AnyOforgResoMetadataTeamsCreateTeamStatus {

}
