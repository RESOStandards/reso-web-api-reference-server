package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateOwnershipType
*/
public interface AnyOforgResoMetadataPropertyUpdateOwnershipType {

}
