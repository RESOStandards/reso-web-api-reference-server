package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateScreenWidth
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateScreenWidth {

}
