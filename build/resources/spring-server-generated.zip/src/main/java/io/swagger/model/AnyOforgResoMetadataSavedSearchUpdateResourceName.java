package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchUpdateResourceName
*/
public interface AnyOforgResoMetadataSavedSearchUpdateResourceName {

}
