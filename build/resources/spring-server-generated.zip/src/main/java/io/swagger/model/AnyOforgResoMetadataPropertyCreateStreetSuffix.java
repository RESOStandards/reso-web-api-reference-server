package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateStreetSuffix
*/
public interface AnyOforgResoMetadataPropertyCreateStreetSuffix {

}
