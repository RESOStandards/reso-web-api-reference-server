package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseListingKeyNumeric
*/
public interface AnyOforgResoMetadataOpenHouseListingKeyNumeric {

}
