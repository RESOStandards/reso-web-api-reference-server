package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.NotedBy
 */
public enum OrgResoMetadataEnumsNotedBy {
  AGENT("Agent"),
    CONTACT("Contact");

  private String value;

  OrgResoMetadataEnumsNotedBy(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsNotedBy fromValue(String text) {
    for (OrgResoMetadataEnumsNotedBy b : OrgResoMetadataEnumsNotedBy.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
