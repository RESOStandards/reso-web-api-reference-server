package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseCreateSourceSystem
*/
public interface AnyOforgResoMetadataOpenHouseCreateSourceSystem {

}
