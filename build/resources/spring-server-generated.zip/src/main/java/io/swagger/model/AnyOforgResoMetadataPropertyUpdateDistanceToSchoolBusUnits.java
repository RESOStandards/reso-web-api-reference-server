package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToSchoolBusUnits {

}
