package io.swagger.model;


/**
* AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric
*/
public interface AnyOforgResoMetadataTeamMembersCreateMemberKeyNumeric {

}
