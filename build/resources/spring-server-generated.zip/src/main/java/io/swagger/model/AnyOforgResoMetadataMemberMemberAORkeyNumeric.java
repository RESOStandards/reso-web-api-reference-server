package io.swagger.model;


/**
* AnyOforgResoMetadataMemberMemberAORkeyNumeric
*/
public interface AnyOforgResoMetadataMemberMemberAORkeyNumeric {

}
