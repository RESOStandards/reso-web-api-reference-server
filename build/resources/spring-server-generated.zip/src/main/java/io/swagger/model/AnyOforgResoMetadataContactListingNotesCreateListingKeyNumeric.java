package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingNotesCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataContactListingNotesCreateListingKeyNumeric {

}
