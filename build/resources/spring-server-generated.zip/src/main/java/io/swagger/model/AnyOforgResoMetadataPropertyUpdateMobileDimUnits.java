package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateMobileDimUnits
*/
public interface AnyOforgResoMetadataPropertyUpdateMobileDimUnits {

}
