package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsAccessibilityFeatures;
import io.swagger.model.OrgResoMetadataEnumsAppliances;
import io.swagger.model.OrgResoMetadataEnumsArchitecturalStyle;
import io.swagger.model.OrgResoMetadataEnumsAssociationAmenities;
import io.swagger.model.OrgResoMetadataEnumsAssociationFeeIncludes;
import io.swagger.model.OrgResoMetadataEnumsBasement;
import io.swagger.model.OrgResoMetadataEnumsBodyType;
import io.swagger.model.OrgResoMetadataEnumsBuildingFeatures;
import io.swagger.model.OrgResoMetadataEnumsBusinessType;
import io.swagger.model.OrgResoMetadataEnumsBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsBuyerFinancing;
import io.swagger.model.OrgResoMetadataEnumsCoBuyerAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCoListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsCommonWalls;
import io.swagger.model.OrgResoMetadataEnumsCommunityFeatures;
import io.swagger.model.OrgResoMetadataEnumsConstructionMaterials;
import io.swagger.model.OrgResoMetadataEnumsCooling;
import io.swagger.model.OrgResoMetadataEnumsCurrentFinancing;
import io.swagger.model.OrgResoMetadataEnumsCurrentUse;
import io.swagger.model.OrgResoMetadataEnumsDevelopmentStatus;
import io.swagger.model.OrgResoMetadataEnumsDisclosures;
import io.swagger.model.OrgResoMetadataEnumsDocumentsAvailable;
import io.swagger.model.OrgResoMetadataEnumsDoorFeatures;
import io.swagger.model.OrgResoMetadataEnumsElectric;
import io.swagger.model.OrgResoMetadataEnumsExistingLeaseType;
import io.swagger.model.OrgResoMetadataEnumsExteriorFeatures;
import io.swagger.model.OrgResoMetadataEnumsFencing;
import io.swagger.model.OrgResoMetadataEnumsFinancialDataSource;
import io.swagger.model.OrgResoMetadataEnumsFireplaceFeatures;
import io.swagger.model.OrgResoMetadataEnumsFlooring;
import io.swagger.model.OrgResoMetadataEnumsFoundationDetails;
import io.swagger.model.OrgResoMetadataEnumsFrontageType;
import io.swagger.model.OrgResoMetadataEnumsGreenBuildingVerificationType;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyEfficient;
import io.swagger.model.OrgResoMetadataEnumsGreenEnergyGeneration;
import io.swagger.model.OrgResoMetadataEnumsGreenIndoorAirQuality;
import io.swagger.model.OrgResoMetadataEnumsGreenLocation;
import io.swagger.model.OrgResoMetadataEnumsGreenSustainability;
import io.swagger.model.OrgResoMetadataEnumsGreenWaterConservation;
import io.swagger.model.OrgResoMetadataEnumsHeating;
import io.swagger.model.OrgResoMetadataEnumsHorseAmenities;
import io.swagger.model.OrgResoMetadataEnumsHoursDaysOfOperation;
import io.swagger.model.OrgResoMetadataEnumsIncomeIncludes;
import io.swagger.model.OrgResoMetadataEnumsInteriorOrRoomFeatures;
import io.swagger.model.OrgResoMetadataEnumsIrrigationSource;
import io.swagger.model.OrgResoMetadataEnumsLaborInformation;
import io.swagger.model.OrgResoMetadataEnumsLaundryFeatures;
import io.swagger.model.OrgResoMetadataEnumsLeaseRenewalCompensation;
import io.swagger.model.OrgResoMetadataEnumsLevels;
import io.swagger.model.OrgResoMetadataEnumsListAgentDesignation;
import io.swagger.model.OrgResoMetadataEnumsListingTerms;
import io.swagger.model.OrgResoMetadataEnumsLockBoxType;
import io.swagger.model.OrgResoMetadataEnumsLotFeatures;
import io.swagger.model.OrgResoMetadataEnumsOperatingExpenseIncludes;
import io.swagger.model.OrgResoMetadataEnumsOtherEquipment;
import io.swagger.model.OrgResoMetadataEnumsOtherStructures;
import io.swagger.model.OrgResoMetadataEnumsOwnerPays;
import io.swagger.model.OrgResoMetadataEnumsParkingFeatures;
import io.swagger.model.OrgResoMetadataEnumsPatioAndPorchFeatures;
import io.swagger.model.OrgResoMetadataEnumsPetsAllowed;
import io.swagger.model.OrgResoMetadataEnumsPoolFeatures;
import io.swagger.model.OrgResoMetadataEnumsPossession;
import io.swagger.model.OrgResoMetadataEnumsPossibleUse;
import io.swagger.model.OrgResoMetadataEnumsPowerProductionType;
import io.swagger.model.OrgResoMetadataEnumsPropertyCondition;
import io.swagger.model.OrgResoMetadataEnumsRentIncludes;
import io.swagger.model.OrgResoMetadataEnumsRoadFrontageType;
import io.swagger.model.OrgResoMetadataEnumsRoadResponsibility;
import io.swagger.model.OrgResoMetadataEnumsRoadSurfaceType;
import io.swagger.model.OrgResoMetadataEnumsRoof;
import io.swagger.model.OrgResoMetadataEnumsRoomType;
import io.swagger.model.OrgResoMetadataEnumsSecurityFeatures;
import io.swagger.model.OrgResoMetadataEnumsSewer;
import io.swagger.model.OrgResoMetadataEnumsShowingContactType;
import io.swagger.model.OrgResoMetadataEnumsShowingDays;
import io.swagger.model.OrgResoMetadataEnumsShowingRequirements;
import io.swagger.model.OrgResoMetadataEnumsSkirt;
import io.swagger.model.OrgResoMetadataEnumsSpaFeatures;
import io.swagger.model.OrgResoMetadataEnumsSpecialLicenses;
import io.swagger.model.OrgResoMetadataEnumsSpecialListingConditions;
import io.swagger.model.OrgResoMetadataEnumsStructureType;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.model.OrgResoMetadataEnumsTaxStatusCurrent;
import io.swagger.model.OrgResoMetadataEnumsTenantPays;
import io.swagger.model.OrgResoMetadataEnumsUnitTypeType;
import io.swagger.model.OrgResoMetadataEnumsUtilities;
import io.swagger.model.OrgResoMetadataEnumsVegetation;
import io.swagger.model.OrgResoMetadataEnumsView;
import io.swagger.model.OrgResoMetadataEnumsWaterSource;
import io.swagger.model.OrgResoMetadataEnumsWaterfrontFeatures;
import io.swagger.model.OrgResoMetadataEnumsWindowFeatures;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.model.OrgResoMetadataMediaCreate;
import io.swagger.model.OrgResoMetadataOpenHouseCreate;
import io.swagger.model.OrgResoMetadataSocialMediaCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataPropertyCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataPropertyCreate  implements AnyOforgResoMetadataContactListingsCreateListing, AnyOforgResoMetadataOpenHouseCreateListing, AnyOforgResoMetadataPropertyGreenVerificationCreateListing, AnyOforgResoMetadataPropertyPowerProductionCreateListing, AnyOforgResoMetadataPropertyRoomsCreateListing, AnyOforgResoMetadataPropertyUnitTypesCreateListing, AnyOforgResoMetadataShowingCreateListing {
  @JsonProperty("AboveGradeFinishedArea")
  private AnyOforgResoMetadataPropertyCreateAboveGradeFinishedArea aboveGradeFinishedArea = null;

  @JsonProperty("AboveGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource = null;

  @JsonProperty("AboveGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits = null;

  @JsonProperty("AccessCode")
  private String accessCode = null;

  @JsonProperty("AccessibilityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures = null;

  @JsonProperty("AdditionalParcelsDescription")
  private String additionalParcelsDescription = null;

  @JsonProperty("AdditionalParcelsYN")
  private Boolean additionalParcelsYN = null;

  @JsonProperty("AnchorsCoTenants")
  private String anchorsCoTenants = null;

  @JsonProperty("Appliances")
  @Valid
  private List<OrgResoMetadataEnumsAppliances> appliances = null;

  @JsonProperty("ArchitecturalStyle")
  @Valid
  private List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle = null;

  @JsonProperty("AssociationAmenities")
  @Valid
  private List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities = null;

  @JsonProperty("AssociationFee")
  private AnyOforgResoMetadataPropertyCreateAssociationFee associationFee = null;

  @JsonProperty("AssociationFee2")
  private AnyOforgResoMetadataPropertyCreateAssociationFee2 associationFee2 = null;

  @JsonProperty("AssociationFee2Frequency")
  private AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency associationFee2Frequency = null;

  @JsonProperty("AssociationFeeFrequency")
  private AnyOforgResoMetadataPropertyCreateAssociationFeeFrequency associationFeeFrequency = null;

  @JsonProperty("AssociationFeeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes = null;

  @JsonProperty("AssociationName")
  private String associationName = null;

  @JsonProperty("AssociationName2")
  private String associationName2 = null;

  @JsonProperty("AssociationPhone")
  private String associationPhone = null;

  @JsonProperty("AssociationPhone2")
  private String associationPhone2 = null;

  @JsonProperty("AssociationYN")
  private Boolean associationYN = null;

  @JsonProperty("AttachedGarageYN")
  private Boolean attachedGarageYN = null;

  @JsonProperty("AvailabilityDate")
  private LocalDate availabilityDate = null;

  @JsonProperty("Basement")
  @Valid
  private List<OrgResoMetadataEnumsBasement> basement = null;

  @JsonProperty("BasementYN")
  private Boolean basementYN = null;

  @JsonProperty("BathroomsFull")
  private AnyOforgResoMetadataPropertyCreateBathroomsFull bathroomsFull = null;

  @JsonProperty("BathroomsHalf")
  private AnyOforgResoMetadataPropertyCreateBathroomsHalf bathroomsHalf = null;

  @JsonProperty("BathroomsOneQuarter")
  private AnyOforgResoMetadataPropertyCreateBathroomsOneQuarter bathroomsOneQuarter = null;

  @JsonProperty("BathroomsPartial")
  private AnyOforgResoMetadataPropertyCreateBathroomsPartial bathroomsPartial = null;

  @JsonProperty("BathroomsThreeQuarter")
  private AnyOforgResoMetadataPropertyCreateBathroomsThreeQuarter bathroomsThreeQuarter = null;

  @JsonProperty("BathroomsTotalInteger")
  private AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger bathroomsTotalInteger = null;

  @JsonProperty("BedroomsPossible")
  private AnyOforgResoMetadataPropertyCreateBedroomsPossible bedroomsPossible = null;

  @JsonProperty("BedroomsTotal")
  private AnyOforgResoMetadataPropertyCreateBedroomsTotal bedroomsTotal = null;

  @JsonProperty("BelowGradeFinishedArea")
  private AnyOforgResoMetadataPropertyCreateBelowGradeFinishedArea belowGradeFinishedArea = null;

  @JsonProperty("BelowGradeFinishedAreaSource")
  private AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource = null;

  @JsonProperty("BelowGradeFinishedAreaUnits")
  private AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits = null;

  @JsonProperty("BodyType")
  @Valid
  private List<OrgResoMetadataEnumsBodyType> bodyType = null;

  @JsonProperty("BuilderModel")
  private String builderModel = null;

  @JsonProperty("BuilderName")
  private String builderName = null;

  @JsonProperty("BuildingAreaSource")
  private AnyOforgResoMetadataPropertyCreateBuildingAreaSource buildingAreaSource = null;

  @JsonProperty("BuildingAreaTotal")
  private AnyOforgResoMetadataPropertyCreateBuildingAreaTotal buildingAreaTotal = null;

  @JsonProperty("BuildingAreaUnits")
  private AnyOforgResoMetadataPropertyCreateBuildingAreaUnits buildingAreaUnits = null;

  @JsonProperty("BuildingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures = null;

  @JsonProperty("BuildingName")
  private String buildingName = null;

  @JsonProperty("BusinessName")
  private String businessName = null;

  @JsonProperty("BusinessType")
  @Valid
  private List<OrgResoMetadataEnumsBusinessType> businessType = null;

  @JsonProperty("BuyerAgencyCompensation")
  private String buyerAgencyCompensation = null;

  @JsonProperty("BuyerAgencyCompensationType")
  private AnyOforgResoMetadataPropertyCreateBuyerAgencyCompensationType buyerAgencyCompensationType = null;

  @JsonProperty("BuyerAgentAOR")
  private AnyOforgResoMetadataPropertyCreateBuyerAgentAOR buyerAgentAOR = null;

  @JsonProperty("BuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation = null;

  @JsonProperty("BuyerAgentDirectPhone")
  private String buyerAgentDirectPhone = null;

  @JsonProperty("BuyerAgentEmail")
  private String buyerAgentEmail = null;

  @JsonProperty("BuyerAgentFax")
  private String buyerAgentFax = null;

  @JsonProperty("BuyerAgentFirstName")
  private String buyerAgentFirstName = null;

  @JsonProperty("BuyerAgentFullName")
  private String buyerAgentFullName = null;

  @JsonProperty("BuyerAgentHomePhone")
  private String buyerAgentHomePhone = null;

  @JsonProperty("BuyerAgentKey")
  private String buyerAgentKey = null;

  @JsonProperty("BuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric buyerAgentKeyNumeric = null;

  @JsonProperty("BuyerAgentLastName")
  private String buyerAgentLastName = null;

  @JsonProperty("BuyerAgentMiddleName")
  private String buyerAgentMiddleName = null;

  @JsonProperty("BuyerAgentMlsId")
  private String buyerAgentMlsId = null;

  @JsonProperty("BuyerAgentMobilePhone")
  private String buyerAgentMobilePhone = null;

  @JsonProperty("BuyerAgentNamePrefix")
  private String buyerAgentNamePrefix = null;

  @JsonProperty("BuyerAgentNameSuffix")
  private String buyerAgentNameSuffix = null;

  @JsonProperty("BuyerAgentOfficePhone")
  private String buyerAgentOfficePhone = null;

  @JsonProperty("BuyerAgentOfficePhoneExt")
  private String buyerAgentOfficePhoneExt = null;

  @JsonProperty("BuyerAgentPager")
  private String buyerAgentPager = null;

  @JsonProperty("BuyerAgentPreferredPhone")
  private String buyerAgentPreferredPhone = null;

  @JsonProperty("BuyerAgentPreferredPhoneExt")
  private String buyerAgentPreferredPhoneExt = null;

  @JsonProperty("BuyerAgentStateLicense")
  private String buyerAgentStateLicense = null;

  @JsonProperty("BuyerAgentTollFreePhone")
  private String buyerAgentTollFreePhone = null;

  @JsonProperty("BuyerAgentURL")
  private String buyerAgentURL = null;

  @JsonProperty("BuyerAgentVoiceMail")
  private String buyerAgentVoiceMail = null;

  @JsonProperty("BuyerAgentVoiceMailExt")
  private String buyerAgentVoiceMailExt = null;

  @JsonProperty("BuyerFinancing")
  @Valid
  private List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing = null;

  @JsonProperty("BuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyCreateBuyerOfficeAOR buyerOfficeAOR = null;

  @JsonProperty("BuyerOfficeEmail")
  private String buyerOfficeEmail = null;

  @JsonProperty("BuyerOfficeFax")
  private String buyerOfficeFax = null;

  @JsonProperty("BuyerOfficeKey")
  private String buyerOfficeKey = null;

  @JsonProperty("BuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric = null;

  @JsonProperty("BuyerOfficeMlsId")
  private String buyerOfficeMlsId = null;

  @JsonProperty("BuyerOfficeName")
  private String buyerOfficeName = null;

  @JsonProperty("BuyerOfficePhone")
  private String buyerOfficePhone = null;

  @JsonProperty("BuyerOfficePhoneExt")
  private String buyerOfficePhoneExt = null;

  @JsonProperty("BuyerOfficeURL")
  private String buyerOfficeURL = null;

  @JsonProperty("BuyerTeamKey")
  private String buyerTeamKey = null;

  @JsonProperty("BuyerTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateBuyerTeamKeyNumeric buyerTeamKeyNumeric = null;

  @JsonProperty("BuyerTeamName")
  private String buyerTeamName = null;

  @JsonProperty("CableTvExpense")
  private AnyOforgResoMetadataPropertyCreateCableTvExpense cableTvExpense = null;

  @JsonProperty("CancellationDate")
  private LocalDate cancellationDate = null;

  @JsonProperty("CapRate")
  private AnyOforgResoMetadataPropertyCreateCapRate capRate = null;

  @JsonProperty("CarportSpaces")
  private AnyOforgResoMetadataPropertyCreateCarportSpaces carportSpaces = null;

  @JsonProperty("CarportYN")
  private Boolean carportYN = null;

  @JsonProperty("CarrierRoute")
  private String carrierRoute = null;

  @JsonProperty("City")
  private AnyOforgResoMetadataPropertyCreateCity city = null;

  @JsonProperty("CityRegion")
  private String cityRegion = null;

  @JsonProperty("CloseDate")
  private LocalDate closeDate = null;

  @JsonProperty("ClosePrice")
  private AnyOforgResoMetadataPropertyCreateClosePrice closePrice = null;

  @JsonProperty("CoBuyerAgentAOR")
  private AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR coBuyerAgentAOR = null;

  @JsonProperty("CoBuyerAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation = null;

  @JsonProperty("CoBuyerAgentDirectPhone")
  private String coBuyerAgentDirectPhone = null;

  @JsonProperty("CoBuyerAgentEmail")
  private String coBuyerAgentEmail = null;

  @JsonProperty("CoBuyerAgentFax")
  private String coBuyerAgentFax = null;

  @JsonProperty("CoBuyerAgentFirstName")
  private String coBuyerAgentFirstName = null;

  @JsonProperty("CoBuyerAgentFullName")
  private String coBuyerAgentFullName = null;

  @JsonProperty("CoBuyerAgentHomePhone")
  private String coBuyerAgentHomePhone = null;

  @JsonProperty("CoBuyerAgentKey")
  private String coBuyerAgentKey = null;

  @JsonProperty("CoBuyerAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric = null;

  @JsonProperty("CoBuyerAgentLastName")
  private String coBuyerAgentLastName = null;

  @JsonProperty("CoBuyerAgentMiddleName")
  private String coBuyerAgentMiddleName = null;

  @JsonProperty("CoBuyerAgentMlsId")
  private String coBuyerAgentMlsId = null;

  @JsonProperty("CoBuyerAgentMobilePhone")
  private String coBuyerAgentMobilePhone = null;

  @JsonProperty("CoBuyerAgentNamePrefix")
  private String coBuyerAgentNamePrefix = null;

  @JsonProperty("CoBuyerAgentNameSuffix")
  private String coBuyerAgentNameSuffix = null;

  @JsonProperty("CoBuyerAgentOfficePhone")
  private String coBuyerAgentOfficePhone = null;

  @JsonProperty("CoBuyerAgentOfficePhoneExt")
  private String coBuyerAgentOfficePhoneExt = null;

  @JsonProperty("CoBuyerAgentPager")
  private String coBuyerAgentPager = null;

  @JsonProperty("CoBuyerAgentPreferredPhone")
  private String coBuyerAgentPreferredPhone = null;

  @JsonProperty("CoBuyerAgentPreferredPhoneExt")
  private String coBuyerAgentPreferredPhoneExt = null;

  @JsonProperty("CoBuyerAgentStateLicense")
  private String coBuyerAgentStateLicense = null;

  @JsonProperty("CoBuyerAgentTollFreePhone")
  private String coBuyerAgentTollFreePhone = null;

  @JsonProperty("CoBuyerAgentURL")
  private String coBuyerAgentURL = null;

  @JsonProperty("CoBuyerAgentVoiceMail")
  private String coBuyerAgentVoiceMail = null;

  @JsonProperty("CoBuyerAgentVoiceMailExt")
  private String coBuyerAgentVoiceMailExt = null;

  @JsonProperty("CoBuyerOfficeAOR")
  private AnyOforgResoMetadataPropertyCreateCoBuyerOfficeAOR coBuyerOfficeAOR = null;

  @JsonProperty("CoBuyerOfficeEmail")
  private String coBuyerOfficeEmail = null;

  @JsonProperty("CoBuyerOfficeFax")
  private String coBuyerOfficeFax = null;

  @JsonProperty("CoBuyerOfficeKey")
  private String coBuyerOfficeKey = null;

  @JsonProperty("CoBuyerOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric = null;

  @JsonProperty("CoBuyerOfficeMlsId")
  private String coBuyerOfficeMlsId = null;

  @JsonProperty("CoBuyerOfficeName")
  private String coBuyerOfficeName = null;

  @JsonProperty("CoBuyerOfficePhone")
  private String coBuyerOfficePhone = null;

  @JsonProperty("CoBuyerOfficePhoneExt")
  private String coBuyerOfficePhoneExt = null;

  @JsonProperty("CoBuyerOfficeURL")
  private String coBuyerOfficeURL = null;

  @JsonProperty("CoListAgentAOR")
  private AnyOforgResoMetadataPropertyCreateCoListAgentAOR coListAgentAOR = null;

  @JsonProperty("CoListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation = null;

  @JsonProperty("CoListAgentDirectPhone")
  private String coListAgentDirectPhone = null;

  @JsonProperty("CoListAgentEmail")
  private String coListAgentEmail = null;

  @JsonProperty("CoListAgentFax")
  private String coListAgentFax = null;

  @JsonProperty("CoListAgentFirstName")
  private String coListAgentFirstName = null;

  @JsonProperty("CoListAgentFullName")
  private String coListAgentFullName = null;

  @JsonProperty("CoListAgentHomePhone")
  private String coListAgentHomePhone = null;

  @JsonProperty("CoListAgentKey")
  private String coListAgentKey = null;

  @JsonProperty("CoListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateCoListAgentKeyNumeric coListAgentKeyNumeric = null;

  @JsonProperty("CoListAgentLastName")
  private String coListAgentLastName = null;

  @JsonProperty("CoListAgentMiddleName")
  private String coListAgentMiddleName = null;

  @JsonProperty("CoListAgentMlsId")
  private String coListAgentMlsId = null;

  @JsonProperty("CoListAgentMobilePhone")
  private String coListAgentMobilePhone = null;

  @JsonProperty("CoListAgentNamePrefix")
  private String coListAgentNamePrefix = null;

  @JsonProperty("CoListAgentNameSuffix")
  private String coListAgentNameSuffix = null;

  @JsonProperty("CoListAgentOfficePhone")
  private String coListAgentOfficePhone = null;

  @JsonProperty("CoListAgentOfficePhoneExt")
  private String coListAgentOfficePhoneExt = null;

  @JsonProperty("CoListAgentPager")
  private String coListAgentPager = null;

  @JsonProperty("CoListAgentPreferredPhone")
  private String coListAgentPreferredPhone = null;

  @JsonProperty("CoListAgentPreferredPhoneExt")
  private String coListAgentPreferredPhoneExt = null;

  @JsonProperty("CoListAgentStateLicense")
  private String coListAgentStateLicense = null;

  @JsonProperty("CoListAgentTollFreePhone")
  private String coListAgentTollFreePhone = null;

  @JsonProperty("CoListAgentURL")
  private String coListAgentURL = null;

  @JsonProperty("CoListAgentVoiceMail")
  private String coListAgentVoiceMail = null;

  @JsonProperty("CoListAgentVoiceMailExt")
  private String coListAgentVoiceMailExt = null;

  @JsonProperty("CoListOfficeAOR")
  private AnyOforgResoMetadataPropertyCreateCoListOfficeAOR coListOfficeAOR = null;

  @JsonProperty("CoListOfficeEmail")
  private String coListOfficeEmail = null;

  @JsonProperty("CoListOfficeFax")
  private String coListOfficeFax = null;

  @JsonProperty("CoListOfficeKey")
  private String coListOfficeKey = null;

  @JsonProperty("CoListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric coListOfficeKeyNumeric = null;

  @JsonProperty("CoListOfficeMlsId")
  private String coListOfficeMlsId = null;

  @JsonProperty("CoListOfficeName")
  private String coListOfficeName = null;

  @JsonProperty("CoListOfficePhone")
  private String coListOfficePhone = null;

  @JsonProperty("CoListOfficePhoneExt")
  private String coListOfficePhoneExt = null;

  @JsonProperty("CoListOfficeURL")
  private String coListOfficeURL = null;

  @JsonProperty("CommonInterest")
  private AnyOforgResoMetadataPropertyCreateCommonInterest commonInterest = null;

  @JsonProperty("CommonWalls")
  @Valid
  private List<OrgResoMetadataEnumsCommonWalls> commonWalls = null;

  @JsonProperty("CommunityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures = null;

  @JsonProperty("Concessions")
  private AnyOforgResoMetadataPropertyCreateConcessions concessions = null;

  @JsonProperty("ConcessionsAmount")
  private AnyOforgResoMetadataPropertyCreateConcessionsAmount concessionsAmount = null;

  @JsonProperty("ConcessionsComments")
  private String concessionsComments = null;

  @JsonProperty("ConstructionMaterials")
  @Valid
  private List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials = null;

  @JsonProperty("ContinentRegion")
  private String continentRegion = null;

  @JsonProperty("Contingency")
  private String contingency = null;

  @JsonProperty("ContingentDate")
  private LocalDate contingentDate = null;

  @JsonProperty("ContractStatusChangeDate")
  private LocalDate contractStatusChangeDate = null;

  @JsonProperty("Cooling")
  @Valid
  private List<OrgResoMetadataEnumsCooling> cooling = null;

  @JsonProperty("CoolingYN")
  private Boolean coolingYN = null;

  @JsonProperty("CopyrightNotice")
  private String copyrightNotice = null;

  @JsonProperty("Country")
  private AnyOforgResoMetadataPropertyCreateCountry country = null;

  @JsonProperty("CountryRegion")
  private String countryRegion = null;

  @JsonProperty("CountyOrParish")
  private AnyOforgResoMetadataPropertyCreateCountyOrParish countyOrParish = null;

  @JsonProperty("CoveredSpaces")
  private AnyOforgResoMetadataPropertyCreateCoveredSpaces coveredSpaces = null;

  @JsonProperty("CropsIncludedYN")
  private Boolean cropsIncludedYN = null;

  @JsonProperty("CrossStreet")
  private String crossStreet = null;

  @JsonProperty("CultivatedArea")
  private AnyOforgResoMetadataPropertyCreateCultivatedArea cultivatedArea = null;

  @JsonProperty("CumulativeDaysOnMarket")
  private AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket cumulativeDaysOnMarket = null;

  @JsonProperty("CurrentFinancing")
  @Valid
  private List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing = null;

  @JsonProperty("CurrentUse")
  @Valid
  private List<OrgResoMetadataEnumsCurrentUse> currentUse = null;

  @JsonProperty("DOH1")
  private String doH1 = null;

  @JsonProperty("DOH2")
  private String doH2 = null;

  @JsonProperty("DOH3")
  private String doH3 = null;

  @JsonProperty("DaysOnMarket")
  private AnyOforgResoMetadataPropertyCreateDaysOnMarket daysOnMarket = null;

  @JsonProperty("DevelopmentStatus")
  @Valid
  private List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus = null;

  @JsonProperty("DirectionFaces")
  private AnyOforgResoMetadataPropertyCreateDirectionFaces directionFaces = null;

  @JsonProperty("Directions")
  private String directions = null;

  @JsonProperty("Disclaimer")
  private String disclaimer = null;

  @JsonProperty("Disclosures")
  @Valid
  private List<OrgResoMetadataEnumsDisclosures> disclosures = null;

  @JsonProperty("DistanceToBusComments")
  private String distanceToBusComments = null;

  @JsonProperty("DistanceToBusNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToBusNumeric distanceToBusNumeric = null;

  @JsonProperty("DistanceToBusUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToBusUnits distanceToBusUnits = null;

  @JsonProperty("DistanceToElectricComments")
  private String distanceToElectricComments = null;

  @JsonProperty("DistanceToElectricNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric distanceToElectricNumeric = null;

  @JsonProperty("DistanceToElectricUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToElectricUnits distanceToElectricUnits = null;

  @JsonProperty("DistanceToFreewayComments")
  private String distanceToFreewayComments = null;

  @JsonProperty("DistanceToFreewayNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToFreewayNumeric distanceToFreewayNumeric = null;

  @JsonProperty("DistanceToFreewayUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToFreewayUnits distanceToFreewayUnits = null;

  @JsonProperty("DistanceToGasComments")
  private String distanceToGasComments = null;

  @JsonProperty("DistanceToGasNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToGasNumeric distanceToGasNumeric = null;

  @JsonProperty("DistanceToGasUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToGasUnits distanceToGasUnits = null;

  @JsonProperty("DistanceToPhoneServiceComments")
  private String distanceToPhoneServiceComments = null;

  @JsonProperty("DistanceToPhoneServiceNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric = null;

  @JsonProperty("DistanceToPhoneServiceUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits = null;

  @JsonProperty("DistanceToPlaceofWorshipComments")
  private String distanceToPlaceofWorshipComments = null;

  @JsonProperty("DistanceToPlaceofWorshipNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric = null;

  @JsonProperty("DistanceToPlaceofWorshipUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits = null;

  @JsonProperty("DistanceToSchoolBusComments")
  private String distanceToSchoolBusComments = null;

  @JsonProperty("DistanceToSchoolBusNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric = null;

  @JsonProperty("DistanceToSchoolBusUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusUnits distanceToSchoolBusUnits = null;

  @JsonProperty("DistanceToSchoolsComments")
  private String distanceToSchoolsComments = null;

  @JsonProperty("DistanceToSchoolsNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToSchoolsNumeric distanceToSchoolsNumeric = null;

  @JsonProperty("DistanceToSchoolsUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToSchoolsUnits distanceToSchoolsUnits = null;

  @JsonProperty("DistanceToSewerComments")
  private String distanceToSewerComments = null;

  @JsonProperty("DistanceToSewerNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric distanceToSewerNumeric = null;

  @JsonProperty("DistanceToSewerUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToSewerUnits distanceToSewerUnits = null;

  @JsonProperty("DistanceToShoppingComments")
  private String distanceToShoppingComments = null;

  @JsonProperty("DistanceToShoppingNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric distanceToShoppingNumeric = null;

  @JsonProperty("DistanceToShoppingUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToShoppingUnits distanceToShoppingUnits = null;

  @JsonProperty("DistanceToStreetComments")
  private String distanceToStreetComments = null;

  @JsonProperty("DistanceToStreetNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToStreetNumeric distanceToStreetNumeric = null;

  @JsonProperty("DistanceToStreetUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits distanceToStreetUnits = null;

  @JsonProperty("DistanceToWaterComments")
  private String distanceToWaterComments = null;

  @JsonProperty("DistanceToWaterNumeric")
  private AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric distanceToWaterNumeric = null;

  @JsonProperty("DistanceToWaterUnits")
  private AnyOforgResoMetadataPropertyCreateDistanceToWaterUnits distanceToWaterUnits = null;

  @JsonProperty("DocumentsAvailable")
  @Valid
  private List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable = null;

  @JsonProperty("DocumentsChangeTimestamp")
  private OffsetDateTime documentsChangeTimestamp = null;

  @JsonProperty("DocumentsCount")
  private AnyOforgResoMetadataPropertyCreateDocumentsCount documentsCount = null;

  @JsonProperty("DoorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsDoorFeatures> doorFeatures = null;

  @JsonProperty("DualVariableCompensationYN")
  private Boolean dualVariableCompensationYN = null;

  @JsonProperty("Electric")
  @Valid
  private List<OrgResoMetadataEnumsElectric> electric = null;

  @JsonProperty("ElectricExpense")
  private AnyOforgResoMetadataPropertyCreateElectricExpense electricExpense = null;

  @JsonProperty("ElectricOnPropertyYN")
  private Boolean electricOnPropertyYN = null;

  @JsonProperty("ElementarySchool")
  private AnyOforgResoMetadataPropertyCreateElementarySchool elementarySchool = null;

  @JsonProperty("ElementarySchoolDistrict")
  private AnyOforgResoMetadataPropertyCreateElementarySchoolDistrict elementarySchoolDistrict = null;

  @JsonProperty("Elevation")
  private AnyOforgResoMetadataPropertyCreateElevation elevation = null;

  @JsonProperty("ElevationUnits")
  private AnyOforgResoMetadataPropertyCreateElevationUnits elevationUnits = null;

  @JsonProperty("EntryLevel")
  private AnyOforgResoMetadataPropertyCreateEntryLevel entryLevel = null;

  @JsonProperty("EntryLocation")
  private String entryLocation = null;

  @JsonProperty("Exclusions")
  private String exclusions = null;

  @JsonProperty("ExistingLeaseType")
  @Valid
  private List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType = null;

  @JsonProperty("ExpirationDate")
  private LocalDate expirationDate = null;

  @JsonProperty("ExteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures = null;

  @JsonProperty("FarmCreditServiceInclYN")
  private Boolean farmCreditServiceInclYN = null;

  @JsonProperty("FarmLandAreaSource")
  private AnyOforgResoMetadataPropertyCreateFarmLandAreaSource farmLandAreaSource = null;

  @JsonProperty("FarmLandAreaUnits")
  private AnyOforgResoMetadataPropertyCreateFarmLandAreaUnits farmLandAreaUnits = null;

  @JsonProperty("Fencing")
  @Valid
  private List<OrgResoMetadataEnumsFencing> fencing = null;

  @JsonProperty("FinancialDataSource")
  @Valid
  private List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource = null;

  @JsonProperty("FireplaceFeatures")
  @Valid
  private List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures = null;

  @JsonProperty("FireplaceYN")
  private Boolean fireplaceYN = null;

  @JsonProperty("FireplacesTotal")
  private AnyOforgResoMetadataPropertyCreateFireplacesTotal fireplacesTotal = null;

  @JsonProperty("Flooring")
  @Valid
  private List<OrgResoMetadataEnumsFlooring> flooring = null;

  @JsonProperty("FoundationArea")
  private AnyOforgResoMetadataPropertyCreateFoundationArea foundationArea = null;

  @JsonProperty("FoundationDetails")
  @Valid
  private List<OrgResoMetadataEnumsFoundationDetails> foundationDetails = null;

  @JsonProperty("FrontageLength")
  private String frontageLength = null;

  @JsonProperty("FrontageType")
  @Valid
  private List<OrgResoMetadataEnumsFrontageType> frontageType = null;

  @JsonProperty("FuelExpense")
  private AnyOforgResoMetadataPropertyCreateFuelExpense fuelExpense = null;

  @JsonProperty("Furnished")
  private AnyOforgResoMetadataPropertyCreateFurnished furnished = null;

  @JsonProperty("FurnitureReplacementExpense")
  private AnyOforgResoMetadataPropertyCreateFurnitureReplacementExpense furnitureReplacementExpense = null;

  @JsonProperty("GarageSpaces")
  private AnyOforgResoMetadataPropertyCreateGarageSpaces garageSpaces = null;

  @JsonProperty("GarageYN")
  private Boolean garageYN = null;

  @JsonProperty("GardenerExpense")
  private AnyOforgResoMetadataPropertyCreateGardenerExpense gardenerExpense = null;

  @JsonProperty("GrazingPermitsBlmYN")
  private Boolean grazingPermitsBlmYN = null;

  @JsonProperty("GrazingPermitsForestServiceYN")
  private Boolean grazingPermitsForestServiceYN = null;

  @JsonProperty("GrazingPermitsPrivateYN")
  private Boolean grazingPermitsPrivateYN = null;

  @JsonProperty("GreenBuildingVerificationType")
  @Valid
  private List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType = null;

  @JsonProperty("GreenEnergyEfficient")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient = null;

  @JsonProperty("GreenEnergyGeneration")
  @Valid
  private List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration = null;

  @JsonProperty("GreenIndoorAirQuality")
  @Valid
  private List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality = null;

  @JsonProperty("GreenLocation")
  @Valid
  private List<OrgResoMetadataEnumsGreenLocation> greenLocation = null;

  @JsonProperty("GreenSustainability")
  @Valid
  private List<OrgResoMetadataEnumsGreenSustainability> greenSustainability = null;

  @JsonProperty("GreenWaterConservation")
  @Valid
  private List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation = null;

  @JsonProperty("GrossIncome")
  private AnyOforgResoMetadataPropertyCreateGrossIncome grossIncome = null;

  @JsonProperty("GrossScheduledIncome")
  private AnyOforgResoMetadataPropertyCreateGrossScheduledIncome grossScheduledIncome = null;

  @JsonProperty("HabitableResidenceYN")
  private Boolean habitableResidenceYN = null;

  @JsonProperty("Heating")
  @Valid
  private List<OrgResoMetadataEnumsHeating> heating = null;

  @JsonProperty("HeatingYN")
  private Boolean heatingYN = null;

  @JsonProperty("HighSchool")
  private AnyOforgResoMetadataPropertyCreateHighSchool highSchool = null;

  @JsonProperty("HighSchoolDistrict")
  private AnyOforgResoMetadataPropertyCreateHighSchoolDistrict highSchoolDistrict = null;

  @JsonProperty("HomeWarrantyYN")
  private Boolean homeWarrantyYN = null;

  @JsonProperty("HorseAmenities")
  @Valid
  private List<OrgResoMetadataEnumsHorseAmenities> horseAmenities = null;

  @JsonProperty("HorseYN")
  private Boolean horseYN = null;

  @JsonProperty("HoursDaysOfOperation")
  @Valid
  private List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation = null;

  @JsonProperty("HoursDaysOfOperationDescription")
  private String hoursDaysOfOperationDescription = null;

  @JsonProperty("Inclusions")
  private String inclusions = null;

  @JsonProperty("IncomeIncludes")
  @Valid
  private List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes = null;

  @JsonProperty("InsuranceExpense")
  private AnyOforgResoMetadataPropertyCreateInsuranceExpense insuranceExpense = null;

  @JsonProperty("InteriorFeatures")
  @Valid
  private List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures = null;

  @JsonProperty("InternetAddressDisplayYN")
  private Boolean internetAddressDisplayYN = null;

  @JsonProperty("InternetAutomatedValuationDisplayYN")
  private Boolean internetAutomatedValuationDisplayYN = null;

  @JsonProperty("InternetConsumerCommentYN")
  private Boolean internetConsumerCommentYN = null;

  @JsonProperty("InternetEntireListingDisplayYN")
  private Boolean internetEntireListingDisplayYN = null;

  @JsonProperty("IrrigationSource")
  @Valid
  private List<OrgResoMetadataEnumsIrrigationSource> irrigationSource = null;

  @JsonProperty("IrrigationWaterRightsAcres")
  private AnyOforgResoMetadataPropertyCreateIrrigationWaterRightsAcres irrigationWaterRightsAcres = null;

  @JsonProperty("IrrigationWaterRightsYN")
  private Boolean irrigationWaterRightsYN = null;

  @JsonProperty("LaborInformation")
  @Valid
  private List<OrgResoMetadataEnumsLaborInformation> laborInformation = null;

  @JsonProperty("LandLeaseAmount")
  private AnyOforgResoMetadataPropertyCreateLandLeaseAmount landLeaseAmount = null;

  @JsonProperty("LandLeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyCreateLandLeaseAmountFrequency landLeaseAmountFrequency = null;

  @JsonProperty("LandLeaseExpirationDate")
  private LocalDate landLeaseExpirationDate = null;

  @JsonProperty("LandLeaseYN")
  private Boolean landLeaseYN = null;

  @JsonProperty("Latitude")
  private AnyOforgResoMetadataPropertyCreateLatitude latitude = null;

  @JsonProperty("LaundryFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures = null;

  @JsonProperty("LeasableArea")
  private AnyOforgResoMetadataPropertyCreateLeasableArea leasableArea = null;

  @JsonProperty("LeasableAreaUnits")
  private AnyOforgResoMetadataPropertyCreateLeasableAreaUnits leasableAreaUnits = null;

  @JsonProperty("LeaseAmount")
  private AnyOforgResoMetadataPropertyCreateLeaseAmount leaseAmount = null;

  @JsonProperty("LeaseAmountFrequency")
  private AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency leaseAmountFrequency = null;

  @JsonProperty("LeaseAssignableYN")
  private Boolean leaseAssignableYN = null;

  @JsonProperty("LeaseConsideredYN")
  private Boolean leaseConsideredYN = null;

  @JsonProperty("LeaseExpiration")
  private LocalDate leaseExpiration = null;

  @JsonProperty("LeaseRenewalCompensation")
  @Valid
  private List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation = null;

  @JsonProperty("LeaseRenewalOptionYN")
  private Boolean leaseRenewalOptionYN = null;

  @JsonProperty("LeaseTerm")
  private AnyOforgResoMetadataPropertyCreateLeaseTerm leaseTerm = null;

  @JsonProperty("Levels")
  @Valid
  private List<OrgResoMetadataEnumsLevels> levels = null;

  @JsonProperty("License1")
  private String license1 = null;

  @JsonProperty("License2")
  private String license2 = null;

  @JsonProperty("License3")
  private String license3 = null;

  @JsonProperty("LicensesExpense")
  private AnyOforgResoMetadataPropertyCreateLicensesExpense licensesExpense = null;

  @JsonProperty("ListAOR")
  private AnyOforgResoMetadataPropertyCreateListAOR listAOR = null;

  @JsonProperty("ListAgentAOR")
  private AnyOforgResoMetadataPropertyCreateListAgentAOR listAgentAOR = null;

  @JsonProperty("ListAgentDesignation")
  @Valid
  private List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation = null;

  @JsonProperty("ListAgentDirectPhone")
  private String listAgentDirectPhone = null;

  @JsonProperty("ListAgentEmail")
  private String listAgentEmail = null;

  @JsonProperty("ListAgentFax")
  private String listAgentFax = null;

  @JsonProperty("ListAgentFirstName")
  private String listAgentFirstName = null;

  @JsonProperty("ListAgentFullName")
  private String listAgentFullName = null;

  @JsonProperty("ListAgentHomePhone")
  private String listAgentHomePhone = null;

  @JsonProperty("ListAgentKey")
  private String listAgentKey = null;

  @JsonProperty("ListAgentKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateListAgentKeyNumeric listAgentKeyNumeric = null;

  @JsonProperty("ListAgentLastName")
  private String listAgentLastName = null;

  @JsonProperty("ListAgentMiddleName")
  private String listAgentMiddleName = null;

  @JsonProperty("ListAgentMlsId")
  private String listAgentMlsId = null;

  @JsonProperty("ListAgentMobilePhone")
  private String listAgentMobilePhone = null;

  @JsonProperty("ListAgentNamePrefix")
  private String listAgentNamePrefix = null;

  @JsonProperty("ListAgentNameSuffix")
  private String listAgentNameSuffix = null;

  @JsonProperty("ListAgentOfficePhone")
  private String listAgentOfficePhone = null;

  @JsonProperty("ListAgentOfficePhoneExt")
  private String listAgentOfficePhoneExt = null;

  @JsonProperty("ListAgentPager")
  private String listAgentPager = null;

  @JsonProperty("ListAgentPreferredPhone")
  private String listAgentPreferredPhone = null;

  @JsonProperty("ListAgentPreferredPhoneExt")
  private String listAgentPreferredPhoneExt = null;

  @JsonProperty("ListAgentStateLicense")
  private String listAgentStateLicense = null;

  @JsonProperty("ListAgentTollFreePhone")
  private String listAgentTollFreePhone = null;

  @JsonProperty("ListAgentURL")
  private String listAgentURL = null;

  @JsonProperty("ListAgentVoiceMail")
  private String listAgentVoiceMail = null;

  @JsonProperty("ListAgentVoiceMailExt")
  private String listAgentVoiceMailExt = null;

  @JsonProperty("ListOfficeAOR")
  private AnyOforgResoMetadataPropertyCreateListOfficeAOR listOfficeAOR = null;

  @JsonProperty("ListOfficeEmail")
  private String listOfficeEmail = null;

  @JsonProperty("ListOfficeFax")
  private String listOfficeFax = null;

  @JsonProperty("ListOfficeKey")
  private String listOfficeKey = null;

  @JsonProperty("ListOfficeKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric listOfficeKeyNumeric = null;

  @JsonProperty("ListOfficeMlsId")
  private String listOfficeMlsId = null;

  @JsonProperty("ListOfficeName")
  private String listOfficeName = null;

  @JsonProperty("ListOfficePhone")
  private String listOfficePhone = null;

  @JsonProperty("ListOfficePhoneExt")
  private String listOfficePhoneExt = null;

  @JsonProperty("ListOfficeURL")
  private String listOfficeURL = null;

  @JsonProperty("ListPrice")
  private AnyOforgResoMetadataPropertyCreateListPrice listPrice = null;

  @JsonProperty("ListPriceLow")
  private AnyOforgResoMetadataPropertyCreateListPriceLow listPriceLow = null;

  @JsonProperty("ListTeamKey")
  private String listTeamKey = null;

  @JsonProperty("ListTeamKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateListTeamKeyNumeric listTeamKeyNumeric = null;

  @JsonProperty("ListTeamName")
  private String listTeamName = null;

  @JsonProperty("ListingAgreement")
  private AnyOforgResoMetadataPropertyCreateListingAgreement listingAgreement = null;

  @JsonProperty("ListingContractDate")
  private LocalDate listingContractDate = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ListingService")
  private AnyOforgResoMetadataPropertyCreateListingService listingService = null;

  @JsonProperty("ListingTerms")
  @Valid
  private List<OrgResoMetadataEnumsListingTerms> listingTerms = null;

  @JsonProperty("LivingArea")
  private AnyOforgResoMetadataPropertyCreateLivingArea livingArea = null;

  @JsonProperty("LivingAreaSource")
  private AnyOforgResoMetadataPropertyCreateLivingAreaSource livingAreaSource = null;

  @JsonProperty("LivingAreaUnits")
  private AnyOforgResoMetadataPropertyCreateLivingAreaUnits livingAreaUnits = null;

  @JsonProperty("LockBoxLocation")
  private String lockBoxLocation = null;

  @JsonProperty("LockBoxSerialNumber")
  private String lockBoxSerialNumber = null;

  @JsonProperty("LockBoxType")
  @Valid
  private List<OrgResoMetadataEnumsLockBoxType> lockBoxType = null;

  @JsonProperty("Longitude")
  private AnyOforgResoMetadataPropertyCreateLongitude longitude = null;

  @JsonProperty("LotDimensionsSource")
  private AnyOforgResoMetadataPropertyCreateLotDimensionsSource lotDimensionsSource = null;

  @JsonProperty("LotFeatures")
  @Valid
  private List<OrgResoMetadataEnumsLotFeatures> lotFeatures = null;

  @JsonProperty("LotSizeAcres")
  private AnyOforgResoMetadataPropertyCreateLotSizeAcres lotSizeAcres = null;

  @JsonProperty("LotSizeArea")
  private AnyOforgResoMetadataPropertyCreateLotSizeArea lotSizeArea = null;

  @JsonProperty("LotSizeDimensions")
  private String lotSizeDimensions = null;

  @JsonProperty("LotSizeSource")
  private AnyOforgResoMetadataPropertyCreateLotSizeSource lotSizeSource = null;

  @JsonProperty("LotSizeSquareFeet")
  private AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet lotSizeSquareFeet = null;

  @JsonProperty("LotSizeUnits")
  private AnyOforgResoMetadataPropertyCreateLotSizeUnits lotSizeUnits = null;

  @JsonProperty("MLSAreaMajor")
  private AnyOforgResoMetadataPropertyCreateMlSAreaMajor mlSAreaMajor = null;

  @JsonProperty("MLSAreaMinor")
  private AnyOforgResoMetadataPropertyCreateMlSAreaMinor mlSAreaMinor = null;

  @JsonProperty("MainLevelBathrooms")
  private AnyOforgResoMetadataPropertyCreateMainLevelBathrooms mainLevelBathrooms = null;

  @JsonProperty("MainLevelBedrooms")
  private AnyOforgResoMetadataPropertyCreateMainLevelBedrooms mainLevelBedrooms = null;

  @JsonProperty("MaintenanceExpense")
  private AnyOforgResoMetadataPropertyCreateMaintenanceExpense maintenanceExpense = null;

  @JsonProperty("MajorChangeTimestamp")
  private OffsetDateTime majorChangeTimestamp = null;

  @JsonProperty("MajorChangeType")
  private AnyOforgResoMetadataPropertyCreateMajorChangeType majorChangeType = null;

  @JsonProperty("Make")
  private String make = null;

  @JsonProperty("ManagerExpense")
  private AnyOforgResoMetadataPropertyCreateManagerExpense managerExpense = null;

  @JsonProperty("MapCoordinate")
  private String mapCoordinate = null;

  @JsonProperty("MapCoordinateSource")
  private String mapCoordinateSource = null;

  @JsonProperty("MapURL")
  private String mapURL = null;

  @JsonProperty("MiddleOrJuniorSchool")
  private AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchool middleOrJuniorSchool = null;

  @JsonProperty("MiddleOrJuniorSchoolDistrict")
  private AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict = null;

  @JsonProperty("MlsStatus")
  private AnyOforgResoMetadataPropertyCreateMlsStatus mlsStatus = null;

  @JsonProperty("MobileDimUnits")
  private AnyOforgResoMetadataPropertyCreateMobileDimUnits mobileDimUnits = null;

  @JsonProperty("MobileHomeRemainsYN")
  private Boolean mobileHomeRemainsYN = null;

  @JsonProperty("MobileLength")
  private AnyOforgResoMetadataPropertyCreateMobileLength mobileLength = null;

  @JsonProperty("MobileWidth")
  private AnyOforgResoMetadataPropertyCreateMobileWidth mobileWidth = null;

  @JsonProperty("Model")
  private String model = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("NetOperatingIncome")
  private AnyOforgResoMetadataPropertyCreateNetOperatingIncome netOperatingIncome = null;

  @JsonProperty("NewConstructionYN")
  private Boolean newConstructionYN = null;

  @JsonProperty("NewTaxesExpense")
  private AnyOforgResoMetadataPropertyCreateNewTaxesExpense newTaxesExpense = null;

  @JsonProperty("NumberOfBuildings")
  private AnyOforgResoMetadataPropertyCreateNumberOfBuildings numberOfBuildings = null;

  @JsonProperty("NumberOfFullTimeEmployees")
  private AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees numberOfFullTimeEmployees = null;

  @JsonProperty("NumberOfLots")
  private AnyOforgResoMetadataPropertyCreateNumberOfLots numberOfLots = null;

  @JsonProperty("NumberOfPads")
  private AnyOforgResoMetadataPropertyCreateNumberOfPads numberOfPads = null;

  @JsonProperty("NumberOfPartTimeEmployees")
  private AnyOforgResoMetadataPropertyCreateNumberOfPartTimeEmployees numberOfPartTimeEmployees = null;

  @JsonProperty("NumberOfSeparateElectricMeters")
  private AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters = null;

  @JsonProperty("NumberOfSeparateGasMeters")
  private AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters numberOfSeparateGasMeters = null;

  @JsonProperty("NumberOfSeparateWaterMeters")
  private AnyOforgResoMetadataPropertyCreateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters = null;

  @JsonProperty("NumberOfUnitsInCommunity")
  private AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity numberOfUnitsInCommunity = null;

  @JsonProperty("NumberOfUnitsLeased")
  private AnyOforgResoMetadataPropertyCreateNumberOfUnitsLeased numberOfUnitsLeased = null;

  @JsonProperty("NumberOfUnitsMoMo")
  private AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo numberOfUnitsMoMo = null;

  @JsonProperty("NumberOfUnitsTotal")
  private AnyOforgResoMetadataPropertyCreateNumberOfUnitsTotal numberOfUnitsTotal = null;

  @JsonProperty("NumberOfUnitsVacant")
  private AnyOforgResoMetadataPropertyCreateNumberOfUnitsVacant numberOfUnitsVacant = null;

  @JsonProperty("OccupantName")
  private String occupantName = null;

  @JsonProperty("OccupantPhone")
  private String occupantPhone = null;

  @JsonProperty("OccupantType")
  private AnyOforgResoMetadataPropertyCreateOccupantType occupantType = null;

  @JsonProperty("OffMarketDate")
  private LocalDate offMarketDate = null;

  @JsonProperty("OffMarketTimestamp")
  private OffsetDateTime offMarketTimestamp = null;

  @JsonProperty("OnMarketDate")
  private LocalDate onMarketDate = null;

  @JsonProperty("OnMarketTimestamp")
  private OffsetDateTime onMarketTimestamp = null;

  @JsonProperty("OpenParkingSpaces")
  private AnyOforgResoMetadataPropertyCreateOpenParkingSpaces openParkingSpaces = null;

  @JsonProperty("OpenParkingYN")
  private Boolean openParkingYN = null;

  @JsonProperty("OperatingExpense")
  private AnyOforgResoMetadataPropertyCreateOperatingExpense operatingExpense = null;

  @JsonProperty("OperatingExpenseIncludes")
  @Valid
  private List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginalListPrice")
  private AnyOforgResoMetadataPropertyCreateOriginalListPrice originalListPrice = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemKey")
  private String originatingSystemKey = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OtherEquipment")
  @Valid
  private List<OrgResoMetadataEnumsOtherEquipment> otherEquipment = null;

  @JsonProperty("OtherExpense")
  private AnyOforgResoMetadataPropertyCreateOtherExpense otherExpense = null;

  @JsonProperty("OtherParking")
  private String otherParking = null;

  @JsonProperty("OtherStructures")
  @Valid
  private List<OrgResoMetadataEnumsOtherStructures> otherStructures = null;

  @JsonProperty("OwnerName")
  private String ownerName = null;

  @JsonProperty("OwnerPays")
  @Valid
  private List<OrgResoMetadataEnumsOwnerPays> ownerPays = null;

  @JsonProperty("OwnerPhone")
  private String ownerPhone = null;

  @JsonProperty("Ownership")
  private String ownership = null;

  @JsonProperty("OwnershipType")
  private AnyOforgResoMetadataPropertyCreateOwnershipType ownershipType = null;

  @JsonProperty("ParcelNumber")
  private String parcelNumber = null;

  @JsonProperty("ParkManagerName")
  private String parkManagerName = null;

  @JsonProperty("ParkManagerPhone")
  private String parkManagerPhone = null;

  @JsonProperty("ParkName")
  private String parkName = null;

  @JsonProperty("ParkingFeatures")
  @Valid
  private List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures = null;

  @JsonProperty("ParkingTotal")
  private AnyOforgResoMetadataPropertyCreateParkingTotal parkingTotal = null;

  @JsonProperty("PastureArea")
  private AnyOforgResoMetadataPropertyCreatePastureArea pastureArea = null;

  @JsonProperty("PatioAndPorchFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures = null;

  @JsonProperty("PendingTimestamp")
  private OffsetDateTime pendingTimestamp = null;

  @JsonProperty("PestControlExpense")
  private AnyOforgResoMetadataPropertyCreatePestControlExpense pestControlExpense = null;

  @JsonProperty("PetsAllowed")
  @Valid
  private List<OrgResoMetadataEnumsPetsAllowed> petsAllowed = null;

  @JsonProperty("PhotosChangeTimestamp")
  private OffsetDateTime photosChangeTimestamp = null;

  @JsonProperty("PhotosCount")
  private AnyOforgResoMetadataPropertyCreatePhotosCount photosCount = null;

  @JsonProperty("PoolExpense")
  private AnyOforgResoMetadataPropertyCreatePoolExpense poolExpense = null;

  @JsonProperty("PoolFeatures")
  @Valid
  private List<OrgResoMetadataEnumsPoolFeatures> poolFeatures = null;

  @JsonProperty("PoolPrivateYN")
  private Boolean poolPrivateYN = null;

  @JsonProperty("Possession")
  @Valid
  private List<OrgResoMetadataEnumsPossession> possession = null;

  @JsonProperty("PossibleUse")
  @Valid
  private List<OrgResoMetadataEnumsPossibleUse> possibleUse = null;

  @JsonProperty("PostalCity")
  private AnyOforgResoMetadataPropertyCreatePostalCity postalCity = null;

  @JsonProperty("PostalCode")
  private String postalCode = null;

  @JsonProperty("PostalCodePlus4")
  private String postalCodePlus4 = null;

  @JsonProperty("PowerProductionType")
  @Valid
  private List<OrgResoMetadataEnumsPowerProductionType> powerProductionType = null;

  @JsonProperty("PreviousListPrice")
  private AnyOforgResoMetadataPropertyCreatePreviousListPrice previousListPrice = null;

  @JsonProperty("PriceChangeTimestamp")
  private OffsetDateTime priceChangeTimestamp = null;

  @JsonProperty("PrivateOfficeRemarks")
  private String privateOfficeRemarks = null;

  @JsonProperty("PrivateRemarks")
  private String privateRemarks = null;

  @JsonProperty("ProfessionalManagementExpense")
  private AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense professionalManagementExpense = null;

  @JsonProperty("PropertyAttachedYN")
  private Boolean propertyAttachedYN = null;

  @JsonProperty("PropertyCondition")
  @Valid
  private List<OrgResoMetadataEnumsPropertyCondition> propertyCondition = null;

  @JsonProperty("PropertySubType")
  private AnyOforgResoMetadataPropertyCreatePropertySubType propertySubType = null;

  @JsonProperty("PropertyType")
  private AnyOforgResoMetadataPropertyCreatePropertyType propertyType = null;

  @JsonProperty("PublicRemarks")
  private String publicRemarks = null;

  @JsonProperty("PublicSurveyRange")
  private String publicSurveyRange = null;

  @JsonProperty("PublicSurveySection")
  private String publicSurveySection = null;

  @JsonProperty("PublicSurveyTownship")
  private String publicSurveyTownship = null;

  @JsonProperty("PurchaseContractDate")
  private LocalDate purchaseContractDate = null;

  @JsonProperty("RVParkingDimensions")
  private String rvParkingDimensions = null;

  @JsonProperty("RangeArea")
  private AnyOforgResoMetadataPropertyCreateRangeArea rangeArea = null;

  @JsonProperty("RentControlYN")
  private Boolean rentControlYN = null;

  @JsonProperty("RentIncludes")
  @Valid
  private List<OrgResoMetadataEnumsRentIncludes> rentIncludes = null;

  @JsonProperty("RoadFrontageType")
  @Valid
  private List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType = null;

  @JsonProperty("RoadResponsibility")
  @Valid
  private List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility = null;

  @JsonProperty("RoadSurfaceType")
  @Valid
  private List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType = null;

  @JsonProperty("Roof")
  @Valid
  private List<OrgResoMetadataEnumsRoof> roof = null;

  @JsonProperty("RoomType")
  @Valid
  private List<OrgResoMetadataEnumsRoomType> roomType = null;

  @JsonProperty("RoomsTotal")
  private AnyOforgResoMetadataPropertyCreateRoomsTotal roomsTotal = null;

  @JsonProperty("SeatingCapacity")
  private AnyOforgResoMetadataPropertyCreateSeatingCapacity seatingCapacity = null;

  @JsonProperty("SecurityFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures = null;

  @JsonProperty("SeniorCommunityYN")
  private Boolean seniorCommunityYN = null;

  @JsonProperty("SerialU")
  private String serialU = null;

  @JsonProperty("SerialX")
  private String serialX = null;

  @JsonProperty("SerialXX")
  private String serialXX = null;

  @JsonProperty("Sewer")
  @Valid
  private List<OrgResoMetadataEnumsSewer> sewer = null;

  @JsonProperty("ShowingAdvanceNotice")
  private AnyOforgResoMetadataPropertyCreateShowingAdvanceNotice showingAdvanceNotice = null;

  @JsonProperty("ShowingAttendedYN")
  private Boolean showingAttendedYN = null;

  @JsonProperty("ShowingContactName")
  private String showingContactName = null;

  @JsonProperty("ShowingContactPhone")
  private String showingContactPhone = null;

  @JsonProperty("ShowingContactPhoneExt")
  private String showingContactPhoneExt = null;

  @JsonProperty("ShowingContactType")
  @Valid
  private List<OrgResoMetadataEnumsShowingContactType> showingContactType = null;

  @JsonProperty("ShowingDays")
  @Valid
  private List<OrgResoMetadataEnumsShowingDays> showingDays = null;

  @JsonProperty("ShowingEndTime")
  private OffsetDateTime showingEndTime = null;

  @JsonProperty("ShowingInstructions")
  private String showingInstructions = null;

  @JsonProperty("ShowingRequirements")
  @Valid
  private List<OrgResoMetadataEnumsShowingRequirements> showingRequirements = null;

  @JsonProperty("ShowingStartTime")
  private OffsetDateTime showingStartTime = null;

  @JsonProperty("SignOnPropertyYN")
  private Boolean signOnPropertyYN = null;

  @JsonProperty("Skirt")
  @Valid
  private List<OrgResoMetadataEnumsSkirt> skirt = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemKey")
  private String sourceSystemKey = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SpaFeatures")
  @Valid
  private List<OrgResoMetadataEnumsSpaFeatures> spaFeatures = null;

  @JsonProperty("SpaYN")
  private Boolean spaYN = null;

  @JsonProperty("SpecialLicenses")
  @Valid
  private List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses = null;

  @JsonProperty("SpecialListingConditions")
  @Valid
  private List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions = null;

  @JsonProperty("StandardStatus")
  private AnyOforgResoMetadataPropertyCreateStandardStatus standardStatus = null;

  @JsonProperty("StateOrProvince")
  private AnyOforgResoMetadataPropertyCreateStateOrProvince stateOrProvince = null;

  @JsonProperty("StateRegion")
  private String stateRegion = null;

  @JsonProperty("StatusChangeTimestamp")
  private OffsetDateTime statusChangeTimestamp = null;

  @JsonProperty("Stories")
  private AnyOforgResoMetadataPropertyCreateStories stories = null;

  @JsonProperty("StoriesTotal")
  private AnyOforgResoMetadataPropertyCreateStoriesTotal storiesTotal = null;

  @JsonProperty("StreetAdditionalInfo")
  private String streetAdditionalInfo = null;

  @JsonProperty("StreetDirPrefix")
  private AnyOforgResoMetadataPropertyCreateStreetDirPrefix streetDirPrefix = null;

  @JsonProperty("StreetDirSuffix")
  private AnyOforgResoMetadataPropertyCreateStreetDirSuffix streetDirSuffix = null;

  @JsonProperty("StreetName")
  private String streetName = null;

  @JsonProperty("StreetNumber")
  private String streetNumber = null;

  @JsonProperty("StreetNumberNumeric")
  private AnyOforgResoMetadataPropertyCreateStreetNumberNumeric streetNumberNumeric = null;

  @JsonProperty("StreetSuffix")
  private AnyOforgResoMetadataPropertyCreateStreetSuffix streetSuffix = null;

  @JsonProperty("StreetSuffixModifier")
  private String streetSuffixModifier = null;

  @JsonProperty("StructureType")
  @Valid
  private List<OrgResoMetadataEnumsStructureType> structureType = null;

  @JsonProperty("SubAgencyCompensation")
  private String subAgencyCompensation = null;

  @JsonProperty("SubAgencyCompensationType")
  private AnyOforgResoMetadataPropertyCreateSubAgencyCompensationType subAgencyCompensationType = null;

  @JsonProperty("SubdivisionName")
  private String subdivisionName = null;

  @JsonProperty("SuppliesExpense")
  private AnyOforgResoMetadataPropertyCreateSuppliesExpense suppliesExpense = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  @JsonProperty("SyndicationRemarks")
  private String syndicationRemarks = null;

  @JsonProperty("TaxAnnualAmount")
  private AnyOforgResoMetadataPropertyCreateTaxAnnualAmount taxAnnualAmount = null;

  @JsonProperty("TaxAssessedValue")
  private AnyOforgResoMetadataPropertyCreateTaxAssessedValue taxAssessedValue = null;

  @JsonProperty("TaxBlock")
  private String taxBlock = null;

  @JsonProperty("TaxBookNumber")
  private String taxBookNumber = null;

  @JsonProperty("TaxLegalDescription")
  private String taxLegalDescription = null;

  @JsonProperty("TaxLot")
  private String taxLot = null;

  @JsonProperty("TaxMapNumber")
  private String taxMapNumber = null;

  @JsonProperty("TaxOtherAnnualAssessmentAmount")
  private AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount = null;

  @JsonProperty("TaxParcelLetter")
  private String taxParcelLetter = null;

  @JsonProperty("TaxStatusCurrent")
  @Valid
  private List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent = null;

  @JsonProperty("TaxTract")
  private String taxTract = null;

  @JsonProperty("TaxYear")
  private AnyOforgResoMetadataPropertyCreateTaxYear taxYear = null;

  @JsonProperty("TenantPays")
  @Valid
  private List<OrgResoMetadataEnumsTenantPays> tenantPays = null;

  @JsonProperty("Topography")
  private String topography = null;

  @JsonProperty("TotalActualRent")
  private AnyOforgResoMetadataPropertyCreateTotalActualRent totalActualRent = null;

  @JsonProperty("Township")
  private String township = null;

  @JsonProperty("TransactionBrokerCompensation")
  private String transactionBrokerCompensation = null;

  @JsonProperty("TransactionBrokerCompensationType")
  private AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType transactionBrokerCompensationType = null;

  @JsonProperty("TrashExpense")
  private AnyOforgResoMetadataPropertyCreateTrashExpense trashExpense = null;

  @JsonProperty("UnitNumber")
  private String unitNumber = null;

  @JsonProperty("UnitTypeType")
  @Valid
  private List<OrgResoMetadataEnumsUnitTypeType> unitTypeType = null;

  @JsonProperty("UnitsFurnished")
  private AnyOforgResoMetadataPropertyCreateUnitsFurnished unitsFurnished = null;

  @JsonProperty("UniversalPropertyId")
  private String universalPropertyId = null;

  @JsonProperty("UniversalPropertySubId")
  private String universalPropertySubId = null;

  @JsonProperty("UnparsedAddress")
  private String unparsedAddress = null;

  @JsonProperty("Utilities")
  @Valid
  private List<OrgResoMetadataEnumsUtilities> utilities = null;

  @JsonProperty("VacancyAllowance")
  private AnyOforgResoMetadataPropertyCreateVacancyAllowance vacancyAllowance = null;

  @JsonProperty("VacancyAllowanceRate")
  private AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate vacancyAllowanceRate = null;

  @JsonProperty("Vegetation")
  @Valid
  private List<OrgResoMetadataEnumsVegetation> vegetation = null;

  @JsonProperty("VideosChangeTimestamp")
  private OffsetDateTime videosChangeTimestamp = null;

  @JsonProperty("VideosCount")
  private AnyOforgResoMetadataPropertyCreateVideosCount videosCount = null;

  @JsonProperty("View")
  @Valid
  private List<OrgResoMetadataEnumsView> view = null;

  @JsonProperty("ViewYN")
  private Boolean viewYN = null;

  @JsonProperty("VirtualTourURLBranded")
  private String virtualTourURLBranded = null;

  @JsonProperty("VirtualTourURLUnbranded")
  private String virtualTourURLUnbranded = null;

  @JsonProperty("WalkScore")
  private AnyOforgResoMetadataPropertyCreateWalkScore walkScore = null;

  @JsonProperty("WaterBodyName")
  private String waterBodyName = null;

  @JsonProperty("WaterSewerExpense")
  private AnyOforgResoMetadataPropertyCreateWaterSewerExpense waterSewerExpense = null;

  @JsonProperty("WaterSource")
  @Valid
  private List<OrgResoMetadataEnumsWaterSource> waterSource = null;

  @JsonProperty("WaterfrontFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures = null;

  @JsonProperty("WaterfrontYN")
  private Boolean waterfrontYN = null;

  @JsonProperty("WindowFeatures")
  @Valid
  private List<OrgResoMetadataEnumsWindowFeatures> windowFeatures = null;

  @JsonProperty("WithdrawnDate")
  private LocalDate withdrawnDate = null;

  @JsonProperty("WoodedArea")
  private AnyOforgResoMetadataPropertyCreateWoodedArea woodedArea = null;

  @JsonProperty("WorkmansCompensationExpense")
  private AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense workmansCompensationExpense = null;

  @JsonProperty("YearBuilt")
  private AnyOforgResoMetadataPropertyCreateYearBuilt yearBuilt = null;

  @JsonProperty("YearBuiltDetails")
  private String yearBuiltDetails = null;

  @JsonProperty("YearBuiltEffective")
  private AnyOforgResoMetadataPropertyCreateYearBuiltEffective yearBuiltEffective = null;

  @JsonProperty("YearBuiltSource")
  private AnyOforgResoMetadataPropertyCreateYearBuiltSource yearBuiltSource = null;

  @JsonProperty("YearEstablished")
  private AnyOforgResoMetadataPropertyCreateYearEstablished yearEstablished = null;

  @JsonProperty("YearsCurrentOwner")
  private AnyOforgResoMetadataPropertyCreateYearsCurrentOwner yearsCurrentOwner = null;

  @JsonProperty("Zoning")
  private String zoning = null;

  @JsonProperty("ZoningDescription")
  private String zoningDescription = null;

  @JsonProperty("OriginatingSystem")
  private AnyOforgResoMetadataPropertyCreateOriginatingSystem originatingSystem = null;

  @JsonProperty("BuyerAgent")
  private AnyOforgResoMetadataPropertyCreateBuyerAgent buyerAgent = null;

  @JsonProperty("BuyerOffice")
  private AnyOforgResoMetadataPropertyCreateBuyerOffice buyerOffice = null;

  @JsonProperty("CoBuyerAgent")
  private AnyOforgResoMetadataPropertyCreateCoBuyerAgent coBuyerAgent = null;

  @JsonProperty("CoBuyerOffice")
  private AnyOforgResoMetadataPropertyCreateCoBuyerOffice coBuyerOffice = null;

  @JsonProperty("CoListAgent")
  private AnyOforgResoMetadataPropertyCreateCoListAgent coListAgent = null;

  @JsonProperty("CoListOffice")
  private AnyOforgResoMetadataPropertyCreateCoListOffice coListOffice = null;

  @JsonProperty("ListAgent")
  private AnyOforgResoMetadataPropertyCreateListAgent listAgent = null;

  @JsonProperty("ListOffice")
  private AnyOforgResoMetadataPropertyCreateListOffice listOffice = null;

  @JsonProperty("BuyerTeam")
  private AnyOforgResoMetadataPropertyCreateBuyerTeam buyerTeam = null;

  @JsonProperty("ListTeam")
  private AnyOforgResoMetadataPropertyCreateListTeam listTeam = null;

  @JsonProperty("SourceSystem")
  private AnyOforgResoMetadataPropertyCreateSourceSystem sourceSystem = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  @JsonProperty("Media")
  @Valid
  private List<OrgResoMetadataMediaCreate> media = null;

  @JsonProperty("SocialMedia")
  @Valid
  private List<OrgResoMetadataSocialMediaCreate> socialMedia = null;

  @JsonProperty("OpenHouse")
  @Valid
  private List<OrgResoMetadataOpenHouseCreate> openHouse = null;

  public OrgResoMetadataPropertyCreate aboveGradeFinishedArea(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
    return this;
  }

  /**
   * Get aboveGradeFinishedArea
   * @return aboveGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateAboveGradeFinishedArea getAboveGradeFinishedArea() {
    return aboveGradeFinishedArea;
  }

  public void setAboveGradeFinishedArea(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedArea aboveGradeFinishedArea) {
    this.aboveGradeFinishedArea = aboveGradeFinishedArea;
  }

  public OrgResoMetadataPropertyCreate aboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaSource
   * @return aboveGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaSource getAboveGradeFinishedAreaSource() {
    return aboveGradeFinishedAreaSource;
  }

  public void setAboveGradeFinishedAreaSource(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaSource aboveGradeFinishedAreaSource) {
    this.aboveGradeFinishedAreaSource = aboveGradeFinishedAreaSource;
  }

  public OrgResoMetadataPropertyCreate aboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get aboveGradeFinishedAreaUnits
   * @return aboveGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaUnits getAboveGradeFinishedAreaUnits() {
    return aboveGradeFinishedAreaUnits;
  }

  public void setAboveGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyCreateAboveGradeFinishedAreaUnits aboveGradeFinishedAreaUnits) {
    this.aboveGradeFinishedAreaUnits = aboveGradeFinishedAreaUnits;
  }

  public OrgResoMetadataPropertyCreate accessCode(String accessCode) {
    this.accessCode = accessCode;
    return this;
  }

  /**
   * Get accessCode
   * @return accessCode
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getAccessCode() {
    return accessCode;
  }

  public void setAccessCode(String accessCode) {
    this.accessCode = accessCode;
  }

  public OrgResoMetadataPropertyCreate accessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addAccessibilityFeaturesItem(OrgResoMetadataEnumsAccessibilityFeatures accessibilityFeaturesItem) {
    if (this.accessibilityFeatures == null) {
      this.accessibilityFeatures = new ArrayList<OrgResoMetadataEnumsAccessibilityFeatures>();
    }
    this.accessibilityFeatures.add(accessibilityFeaturesItem);
    return this;
  }

  /**
   * Get accessibilityFeatures
   * @return accessibilityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAccessibilityFeatures> getAccessibilityFeatures() {
    return accessibilityFeatures;
  }

  public void setAccessibilityFeatures(List<OrgResoMetadataEnumsAccessibilityFeatures> accessibilityFeatures) {
    this.accessibilityFeatures = accessibilityFeatures;
  }

  public OrgResoMetadataPropertyCreate additionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
    return this;
  }

  /**
   * Get additionalParcelsDescription
   * @return additionalParcelsDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getAdditionalParcelsDescription() {
    return additionalParcelsDescription;
  }

  public void setAdditionalParcelsDescription(String additionalParcelsDescription) {
    this.additionalParcelsDescription = additionalParcelsDescription;
  }

  public OrgResoMetadataPropertyCreate additionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
    return this;
  }

  /**
   * Get additionalParcelsYN
   * @return additionalParcelsYN
   **/
  @Schema(description = "")
  
    public Boolean isAdditionalParcelsYN() {
    return additionalParcelsYN;
  }

  public void setAdditionalParcelsYN(Boolean additionalParcelsYN) {
    this.additionalParcelsYN = additionalParcelsYN;
  }

  public OrgResoMetadataPropertyCreate anchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
    return this;
  }

  /**
   * Get anchorsCoTenants
   * @return anchorsCoTenants
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getAnchorsCoTenants() {
    return anchorsCoTenants;
  }

  public void setAnchorsCoTenants(String anchorsCoTenants) {
    this.anchorsCoTenants = anchorsCoTenants;
  }

  public OrgResoMetadataPropertyCreate appliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
    return this;
  }

  public OrgResoMetadataPropertyCreate addAppliancesItem(OrgResoMetadataEnumsAppliances appliancesItem) {
    if (this.appliances == null) {
      this.appliances = new ArrayList<OrgResoMetadataEnumsAppliances>();
    }
    this.appliances.add(appliancesItem);
    return this;
  }

  /**
   * Get appliances
   * @return appliances
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAppliances> getAppliances() {
    return appliances;
  }

  public void setAppliances(List<OrgResoMetadataEnumsAppliances> appliances) {
    this.appliances = appliances;
  }

  public OrgResoMetadataPropertyCreate architecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
    return this;
  }

  public OrgResoMetadataPropertyCreate addArchitecturalStyleItem(OrgResoMetadataEnumsArchitecturalStyle architecturalStyleItem) {
    if (this.architecturalStyle == null) {
      this.architecturalStyle = new ArrayList<OrgResoMetadataEnumsArchitecturalStyle>();
    }
    this.architecturalStyle.add(architecturalStyleItem);
    return this;
  }

  /**
   * Get architecturalStyle
   * @return architecturalStyle
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsArchitecturalStyle> getArchitecturalStyle() {
    return architecturalStyle;
  }

  public void setArchitecturalStyle(List<OrgResoMetadataEnumsArchitecturalStyle> architecturalStyle) {
    this.architecturalStyle = architecturalStyle;
  }

  public OrgResoMetadataPropertyCreate associationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
    return this;
  }

  public OrgResoMetadataPropertyCreate addAssociationAmenitiesItem(OrgResoMetadataEnumsAssociationAmenities associationAmenitiesItem) {
    if (this.associationAmenities == null) {
      this.associationAmenities = new ArrayList<OrgResoMetadataEnumsAssociationAmenities>();
    }
    this.associationAmenities.add(associationAmenitiesItem);
    return this;
  }

  /**
   * Get associationAmenities
   * @return associationAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationAmenities> getAssociationAmenities() {
    return associationAmenities;
  }

  public void setAssociationAmenities(List<OrgResoMetadataEnumsAssociationAmenities> associationAmenities) {
    this.associationAmenities = associationAmenities;
  }

  public OrgResoMetadataPropertyCreate associationFee(AnyOforgResoMetadataPropertyCreateAssociationFee associationFee) {
    this.associationFee = associationFee;
    return this;
  }

  /**
   * Get associationFee
   * @return associationFee
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateAssociationFee getAssociationFee() {
    return associationFee;
  }

  public void setAssociationFee(AnyOforgResoMetadataPropertyCreateAssociationFee associationFee) {
    this.associationFee = associationFee;
  }

  public OrgResoMetadataPropertyCreate associationFee2(AnyOforgResoMetadataPropertyCreateAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
    return this;
  }

  /**
   * Get associationFee2
   * @return associationFee2
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateAssociationFee2 getAssociationFee2() {
    return associationFee2;
  }

  public void setAssociationFee2(AnyOforgResoMetadataPropertyCreateAssociationFee2 associationFee2) {
    this.associationFee2 = associationFee2;
  }

  public OrgResoMetadataPropertyCreate associationFee2Frequency(AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
    return this;
  }

  /**
   * Get associationFee2Frequency
   * @return associationFee2Frequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency getAssociationFee2Frequency() {
    return associationFee2Frequency;
  }

  public void setAssociationFee2Frequency(AnyOforgResoMetadataPropertyCreateAssociationFee2Frequency associationFee2Frequency) {
    this.associationFee2Frequency = associationFee2Frequency;
  }

  public OrgResoMetadataPropertyCreate associationFeeFrequency(AnyOforgResoMetadataPropertyCreateAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
    return this;
  }

  /**
   * Get associationFeeFrequency
   * @return associationFeeFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateAssociationFeeFrequency getAssociationFeeFrequency() {
    return associationFeeFrequency;
  }

  public void setAssociationFeeFrequency(AnyOforgResoMetadataPropertyCreateAssociationFeeFrequency associationFeeFrequency) {
    this.associationFeeFrequency = associationFeeFrequency;
  }

  public OrgResoMetadataPropertyCreate associationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
    return this;
  }

  public OrgResoMetadataPropertyCreate addAssociationFeeIncludesItem(OrgResoMetadataEnumsAssociationFeeIncludes associationFeeIncludesItem) {
    if (this.associationFeeIncludes == null) {
      this.associationFeeIncludes = new ArrayList<OrgResoMetadataEnumsAssociationFeeIncludes>();
    }
    this.associationFeeIncludes.add(associationFeeIncludesItem);
    return this;
  }

  /**
   * Get associationFeeIncludes
   * @return associationFeeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsAssociationFeeIncludes> getAssociationFeeIncludes() {
    return associationFeeIncludes;
  }

  public void setAssociationFeeIncludes(List<OrgResoMetadataEnumsAssociationFeeIncludes> associationFeeIncludes) {
    this.associationFeeIncludes = associationFeeIncludes;
  }

  public OrgResoMetadataPropertyCreate associationName(String associationName) {
    this.associationName = associationName;
    return this;
  }

  /**
   * Get associationName
   * @return associationName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName() {
    return associationName;
  }

  public void setAssociationName(String associationName) {
    this.associationName = associationName;
  }

  public OrgResoMetadataPropertyCreate associationName2(String associationName2) {
    this.associationName2 = associationName2;
    return this;
  }

  /**
   * Get associationName2
   * @return associationName2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getAssociationName2() {
    return associationName2;
  }

  public void setAssociationName2(String associationName2) {
    this.associationName2 = associationName2;
  }

  public OrgResoMetadataPropertyCreate associationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
    return this;
  }

  /**
   * Get associationPhone
   * @return associationPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone() {
    return associationPhone;
  }

  public void setAssociationPhone(String associationPhone) {
    this.associationPhone = associationPhone;
  }

  public OrgResoMetadataPropertyCreate associationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
    return this;
  }

  /**
   * Get associationPhone2
   * @return associationPhone2
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getAssociationPhone2() {
    return associationPhone2;
  }

  public void setAssociationPhone2(String associationPhone2) {
    this.associationPhone2 = associationPhone2;
  }

  public OrgResoMetadataPropertyCreate associationYN(Boolean associationYN) {
    this.associationYN = associationYN;
    return this;
  }

  /**
   * Get associationYN
   * @return associationYN
   **/
  @Schema(description = "")
  
    public Boolean isAssociationYN() {
    return associationYN;
  }

  public void setAssociationYN(Boolean associationYN) {
    this.associationYN = associationYN;
  }

  public OrgResoMetadataPropertyCreate attachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
    return this;
  }

  /**
   * Get attachedGarageYN
   * @return attachedGarageYN
   **/
  @Schema(description = "")
  
    public Boolean isAttachedGarageYN() {
    return attachedGarageYN;
  }

  public void setAttachedGarageYN(Boolean attachedGarageYN) {
    this.attachedGarageYN = attachedGarageYN;
  }

  public OrgResoMetadataPropertyCreate availabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
    return this;
  }

  /**
   * Get availabilityDate
   * @return availabilityDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getAvailabilityDate() {
    return availabilityDate;
  }

  public void setAvailabilityDate(LocalDate availabilityDate) {
    this.availabilityDate = availabilityDate;
  }

  public OrgResoMetadataPropertyCreate basement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBasementItem(OrgResoMetadataEnumsBasement basementItem) {
    if (this.basement == null) {
      this.basement = new ArrayList<OrgResoMetadataEnumsBasement>();
    }
    this.basement.add(basementItem);
    return this;
  }

  /**
   * Get basement
   * @return basement
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBasement> getBasement() {
    return basement;
  }

  public void setBasement(List<OrgResoMetadataEnumsBasement> basement) {
    this.basement = basement;
  }

  public OrgResoMetadataPropertyCreate basementYN(Boolean basementYN) {
    this.basementYN = basementYN;
    return this;
  }

  /**
   * Get basementYN
   * @return basementYN
   **/
  @Schema(description = "")
  
    public Boolean isBasementYN() {
    return basementYN;
  }

  public void setBasementYN(Boolean basementYN) {
    this.basementYN = basementYN;
  }

  public OrgResoMetadataPropertyCreate bathroomsFull(AnyOforgResoMetadataPropertyCreateBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
    return this;
  }

  /**
   * Get bathroomsFull
   * @return bathroomsFull
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsFull getBathroomsFull() {
    return bathroomsFull;
  }

  public void setBathroomsFull(AnyOforgResoMetadataPropertyCreateBathroomsFull bathroomsFull) {
    this.bathroomsFull = bathroomsFull;
  }

  public OrgResoMetadataPropertyCreate bathroomsHalf(AnyOforgResoMetadataPropertyCreateBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
    return this;
  }

  /**
   * Get bathroomsHalf
   * @return bathroomsHalf
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsHalf getBathroomsHalf() {
    return bathroomsHalf;
  }

  public void setBathroomsHalf(AnyOforgResoMetadataPropertyCreateBathroomsHalf bathroomsHalf) {
    this.bathroomsHalf = bathroomsHalf;
  }

  public OrgResoMetadataPropertyCreate bathroomsOneQuarter(AnyOforgResoMetadataPropertyCreateBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
    return this;
  }

  /**
   * Get bathroomsOneQuarter
   * @return bathroomsOneQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsOneQuarter getBathroomsOneQuarter() {
    return bathroomsOneQuarter;
  }

  public void setBathroomsOneQuarter(AnyOforgResoMetadataPropertyCreateBathroomsOneQuarter bathroomsOneQuarter) {
    this.bathroomsOneQuarter = bathroomsOneQuarter;
  }

  public OrgResoMetadataPropertyCreate bathroomsPartial(AnyOforgResoMetadataPropertyCreateBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
    return this;
  }

  /**
   * Get bathroomsPartial
   * @return bathroomsPartial
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsPartial getBathroomsPartial() {
    return bathroomsPartial;
  }

  public void setBathroomsPartial(AnyOforgResoMetadataPropertyCreateBathroomsPartial bathroomsPartial) {
    this.bathroomsPartial = bathroomsPartial;
  }

  public OrgResoMetadataPropertyCreate bathroomsThreeQuarter(AnyOforgResoMetadataPropertyCreateBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
    return this;
  }

  /**
   * Get bathroomsThreeQuarter
   * @return bathroomsThreeQuarter
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsThreeQuarter getBathroomsThreeQuarter() {
    return bathroomsThreeQuarter;
  }

  public void setBathroomsThreeQuarter(AnyOforgResoMetadataPropertyCreateBathroomsThreeQuarter bathroomsThreeQuarter) {
    this.bathroomsThreeQuarter = bathroomsThreeQuarter;
  }

  public OrgResoMetadataPropertyCreate bathroomsTotalInteger(AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
    return this;
  }

  /**
   * Get bathroomsTotalInteger
   * @return bathroomsTotalInteger
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger getBathroomsTotalInteger() {
    return bathroomsTotalInteger;
  }

  public void setBathroomsTotalInteger(AnyOforgResoMetadataPropertyCreateBathroomsTotalInteger bathroomsTotalInteger) {
    this.bathroomsTotalInteger = bathroomsTotalInteger;
  }

  public OrgResoMetadataPropertyCreate bedroomsPossible(AnyOforgResoMetadataPropertyCreateBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
    return this;
  }

  /**
   * Get bedroomsPossible
   * @return bedroomsPossible
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBedroomsPossible getBedroomsPossible() {
    return bedroomsPossible;
  }

  public void setBedroomsPossible(AnyOforgResoMetadataPropertyCreateBedroomsPossible bedroomsPossible) {
    this.bedroomsPossible = bedroomsPossible;
  }

  public OrgResoMetadataPropertyCreate bedroomsTotal(AnyOforgResoMetadataPropertyCreateBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
    return this;
  }

  /**
   * Get bedroomsTotal
   * @return bedroomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBedroomsTotal getBedroomsTotal() {
    return bedroomsTotal;
  }

  public void setBedroomsTotal(AnyOforgResoMetadataPropertyCreateBedroomsTotal bedroomsTotal) {
    this.bedroomsTotal = bedroomsTotal;
  }

  public OrgResoMetadataPropertyCreate belowGradeFinishedArea(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
    return this;
  }

  /**
   * Get belowGradeFinishedArea
   * @return belowGradeFinishedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBelowGradeFinishedArea getBelowGradeFinishedArea() {
    return belowGradeFinishedArea;
  }

  public void setBelowGradeFinishedArea(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedArea belowGradeFinishedArea) {
    this.belowGradeFinishedArea = belowGradeFinishedArea;
  }

  public OrgResoMetadataPropertyCreate belowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaSource
   * @return belowGradeFinishedAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource getBelowGradeFinishedAreaSource() {
    return belowGradeFinishedAreaSource;
  }

  public void setBelowGradeFinishedAreaSource(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaSource belowGradeFinishedAreaSource) {
    this.belowGradeFinishedAreaSource = belowGradeFinishedAreaSource;
  }

  public OrgResoMetadataPropertyCreate belowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
    return this;
  }

  /**
   * Get belowGradeFinishedAreaUnits
   * @return belowGradeFinishedAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits getBelowGradeFinishedAreaUnits() {
    return belowGradeFinishedAreaUnits;
  }

  public void setBelowGradeFinishedAreaUnits(AnyOforgResoMetadataPropertyCreateBelowGradeFinishedAreaUnits belowGradeFinishedAreaUnits) {
    this.belowGradeFinishedAreaUnits = belowGradeFinishedAreaUnits;
  }

  public OrgResoMetadataPropertyCreate bodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBodyTypeItem(OrgResoMetadataEnumsBodyType bodyTypeItem) {
    if (this.bodyType == null) {
      this.bodyType = new ArrayList<OrgResoMetadataEnumsBodyType>();
    }
    this.bodyType.add(bodyTypeItem);
    return this;
  }

  /**
   * Get bodyType
   * @return bodyType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBodyType> getBodyType() {
    return bodyType;
  }

  public void setBodyType(List<OrgResoMetadataEnumsBodyType> bodyType) {
    this.bodyType = bodyType;
  }

  public OrgResoMetadataPropertyCreate builderModel(String builderModel) {
    this.builderModel = builderModel;
    return this;
  }

  /**
   * Get builderModel
   * @return builderModel
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderModel() {
    return builderModel;
  }

  public void setBuilderModel(String builderModel) {
    this.builderModel = builderModel;
  }

  public OrgResoMetadataPropertyCreate builderName(String builderName) {
    this.builderName = builderName;
    return this;
  }

  /**
   * Get builderName
   * @return builderName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuilderName() {
    return builderName;
  }

  public void setBuilderName(String builderName) {
    this.builderName = builderName;
  }

  public OrgResoMetadataPropertyCreate buildingAreaSource(AnyOforgResoMetadataPropertyCreateBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
    return this;
  }

  /**
   * Get buildingAreaSource
   * @return buildingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuildingAreaSource getBuildingAreaSource() {
    return buildingAreaSource;
  }

  public void setBuildingAreaSource(AnyOforgResoMetadataPropertyCreateBuildingAreaSource buildingAreaSource) {
    this.buildingAreaSource = buildingAreaSource;
  }

  public OrgResoMetadataPropertyCreate buildingAreaTotal(AnyOforgResoMetadataPropertyCreateBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
    return this;
  }

  /**
   * Get buildingAreaTotal
   * @return buildingAreaTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuildingAreaTotal getBuildingAreaTotal() {
    return buildingAreaTotal;
  }

  public void setBuildingAreaTotal(AnyOforgResoMetadataPropertyCreateBuildingAreaTotal buildingAreaTotal) {
    this.buildingAreaTotal = buildingAreaTotal;
  }

  public OrgResoMetadataPropertyCreate buildingAreaUnits(AnyOforgResoMetadataPropertyCreateBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
    return this;
  }

  /**
   * Get buildingAreaUnits
   * @return buildingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuildingAreaUnits getBuildingAreaUnits() {
    return buildingAreaUnits;
  }

  public void setBuildingAreaUnits(AnyOforgResoMetadataPropertyCreateBuildingAreaUnits buildingAreaUnits) {
    this.buildingAreaUnits = buildingAreaUnits;
  }

  public OrgResoMetadataPropertyCreate buildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBuildingFeaturesItem(OrgResoMetadataEnumsBuildingFeatures buildingFeaturesItem) {
    if (this.buildingFeatures == null) {
      this.buildingFeatures = new ArrayList<OrgResoMetadataEnumsBuildingFeatures>();
    }
    this.buildingFeatures.add(buildingFeaturesItem);
    return this;
  }

  /**
   * Get buildingFeatures
   * @return buildingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuildingFeatures> getBuildingFeatures() {
    return buildingFeatures;
  }

  public void setBuildingFeatures(List<OrgResoMetadataEnumsBuildingFeatures> buildingFeatures) {
    this.buildingFeatures = buildingFeatures;
  }

  public OrgResoMetadataPropertyCreate buildingName(String buildingName) {
    this.buildingName = buildingName;
    return this;
  }

  /**
   * Get buildingName
   * @return buildingName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuildingName() {
    return buildingName;
  }

  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  public OrgResoMetadataPropertyCreate businessName(String businessName) {
    this.businessName = businessName;
    return this;
  }

  /**
   * Get businessName
   * @return businessName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBusinessName() {
    return businessName;
  }

  public void setBusinessName(String businessName) {
    this.businessName = businessName;
  }

  public OrgResoMetadataPropertyCreate businessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBusinessTypeItem(OrgResoMetadataEnumsBusinessType businessTypeItem) {
    if (this.businessType == null) {
      this.businessType = new ArrayList<OrgResoMetadataEnumsBusinessType>();
    }
    this.businessType.add(businessTypeItem);
    return this;
  }

  /**
   * Get businessType
   * @return businessType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBusinessType> getBusinessType() {
    return businessType;
  }

  public void setBusinessType(List<OrgResoMetadataEnumsBusinessType> businessType) {
    this.businessType = businessType;
  }

  public OrgResoMetadataPropertyCreate buyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
    return this;
  }

  /**
   * Get buyerAgencyCompensation
   * @return buyerAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgencyCompensation() {
    return buyerAgencyCompensation;
  }

  public void setBuyerAgencyCompensation(String buyerAgencyCompensation) {
    this.buyerAgencyCompensation = buyerAgencyCompensation;
  }

  public OrgResoMetadataPropertyCreate buyerAgencyCompensationType(AnyOforgResoMetadataPropertyCreateBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
    return this;
  }

  /**
   * Get buyerAgencyCompensationType
   * @return buyerAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerAgencyCompensationType getBuyerAgencyCompensationType() {
    return buyerAgencyCompensationType;
  }

  public void setBuyerAgencyCompensationType(AnyOforgResoMetadataPropertyCreateBuyerAgencyCompensationType buyerAgencyCompensationType) {
    this.buyerAgencyCompensationType = buyerAgencyCompensationType;
  }

  public OrgResoMetadataPropertyCreate buyerAgentAOR(AnyOforgResoMetadataPropertyCreateBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
    return this;
  }

  /**
   * Get buyerAgentAOR
   * @return buyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerAgentAOR getBuyerAgentAOR() {
    return buyerAgentAOR;
  }

  public void setBuyerAgentAOR(AnyOforgResoMetadataPropertyCreateBuyerAgentAOR buyerAgentAOR) {
    this.buyerAgentAOR = buyerAgentAOR;
  }

  public OrgResoMetadataPropertyCreate buyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBuyerAgentDesignationItem(OrgResoMetadataEnumsBuyerAgentDesignation buyerAgentDesignationItem) {
    if (this.buyerAgentDesignation == null) {
      this.buyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsBuyerAgentDesignation>();
    }
    this.buyerAgentDesignation.add(buyerAgentDesignationItem);
    return this;
  }

  /**
   * Get buyerAgentDesignation
   * @return buyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerAgentDesignation> getBuyerAgentDesignation() {
    return buyerAgentDesignation;
  }

  public void setBuyerAgentDesignation(List<OrgResoMetadataEnumsBuyerAgentDesignation> buyerAgentDesignation) {
    this.buyerAgentDesignation = buyerAgentDesignation;
  }

  public OrgResoMetadataPropertyCreate buyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
    return this;
  }

  /**
   * Get buyerAgentDirectPhone
   * @return buyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentDirectPhone() {
    return buyerAgentDirectPhone;
  }

  public void setBuyerAgentDirectPhone(String buyerAgentDirectPhone) {
    this.buyerAgentDirectPhone = buyerAgentDirectPhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
    return this;
  }

  /**
   * Get buyerAgentEmail
   * @return buyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerAgentEmail() {
    return buyerAgentEmail;
  }

  public void setBuyerAgentEmail(String buyerAgentEmail) {
    this.buyerAgentEmail = buyerAgentEmail;
  }

  public OrgResoMetadataPropertyCreate buyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
    return this;
  }

  /**
   * Get buyerAgentFax
   * @return buyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentFax() {
    return buyerAgentFax;
  }

  public void setBuyerAgentFax(String buyerAgentFax) {
    this.buyerAgentFax = buyerAgentFax;
  }

  public OrgResoMetadataPropertyCreate buyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
    return this;
  }

  /**
   * Get buyerAgentFirstName
   * @return buyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentFirstName() {
    return buyerAgentFirstName;
  }

  public void setBuyerAgentFirstName(String buyerAgentFirstName) {
    this.buyerAgentFirstName = buyerAgentFirstName;
  }

  public OrgResoMetadataPropertyCreate buyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
    return this;
  }

  /**
   * Get buyerAgentFullName
   * @return buyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getBuyerAgentFullName() {
    return buyerAgentFullName;
  }

  public void setBuyerAgentFullName(String buyerAgentFullName) {
    this.buyerAgentFullName = buyerAgentFullName;
  }

  public OrgResoMetadataPropertyCreate buyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
    return this;
  }

  /**
   * Get buyerAgentHomePhone
   * @return buyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentHomePhone() {
    return buyerAgentHomePhone;
  }

  public void setBuyerAgentHomePhone(String buyerAgentHomePhone) {
    this.buyerAgentHomePhone = buyerAgentHomePhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
    return this;
  }

  /**
   * Get buyerAgentKey
   * @return buyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerAgentKey() {
    return buyerAgentKey;
  }

  public void setBuyerAgentKey(String buyerAgentKey) {
    this.buyerAgentKey = buyerAgentKey;
  }

  public OrgResoMetadataPropertyCreate buyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get buyerAgentKeyNumeric
   * @return buyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric getBuyerAgentKeyNumeric() {
    return buyerAgentKeyNumeric;
  }

  public void setBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerAgentKeyNumeric buyerAgentKeyNumeric) {
    this.buyerAgentKeyNumeric = buyerAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate buyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
    return this;
  }

  /**
   * Get buyerAgentLastName
   * @return buyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentLastName() {
    return buyerAgentLastName;
  }

  public void setBuyerAgentLastName(String buyerAgentLastName) {
    this.buyerAgentLastName = buyerAgentLastName;
  }

  public OrgResoMetadataPropertyCreate buyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
    return this;
  }

  /**
   * Get buyerAgentMiddleName
   * @return buyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentMiddleName() {
    return buyerAgentMiddleName;
  }

  public void setBuyerAgentMiddleName(String buyerAgentMiddleName) {
    this.buyerAgentMiddleName = buyerAgentMiddleName;
  }

  public OrgResoMetadataPropertyCreate buyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
    return this;
  }

  /**
   * Get buyerAgentMlsId
   * @return buyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerAgentMlsId() {
    return buyerAgentMlsId;
  }

  public void setBuyerAgentMlsId(String buyerAgentMlsId) {
    this.buyerAgentMlsId = buyerAgentMlsId;
  }

  public OrgResoMetadataPropertyCreate buyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
    return this;
  }

  /**
   * Get buyerAgentMobilePhone
   * @return buyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentMobilePhone() {
    return buyerAgentMobilePhone;
  }

  public void setBuyerAgentMobilePhone(String buyerAgentMobilePhone) {
    this.buyerAgentMobilePhone = buyerAgentMobilePhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
    return this;
  }

  /**
   * Get buyerAgentNamePrefix
   * @return buyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNamePrefix() {
    return buyerAgentNamePrefix;
  }

  public void setBuyerAgentNamePrefix(String buyerAgentNamePrefix) {
    this.buyerAgentNamePrefix = buyerAgentNamePrefix;
  }

  public OrgResoMetadataPropertyCreate buyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
    return this;
  }

  /**
   * Get buyerAgentNameSuffix
   * @return buyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentNameSuffix() {
    return buyerAgentNameSuffix;
  }

  public void setBuyerAgentNameSuffix(String buyerAgentNameSuffix) {
    this.buyerAgentNameSuffix = buyerAgentNameSuffix;
  }

  public OrgResoMetadataPropertyCreate buyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
    return this;
  }

  /**
   * Get buyerAgentOfficePhone
   * @return buyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentOfficePhone() {
    return buyerAgentOfficePhone;
  }

  public void setBuyerAgentOfficePhone(String buyerAgentOfficePhone) {
    this.buyerAgentOfficePhone = buyerAgentOfficePhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerAgentOfficePhoneExt
   * @return buyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentOfficePhoneExt() {
    return buyerAgentOfficePhoneExt;
  }

  public void setBuyerAgentOfficePhoneExt(String buyerAgentOfficePhoneExt) {
    this.buyerAgentOfficePhoneExt = buyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate buyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
    return this;
  }

  /**
   * Get buyerAgentPager
   * @return buyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPager() {
    return buyerAgentPager;
  }

  public void setBuyerAgentPager(String buyerAgentPager) {
    this.buyerAgentPager = buyerAgentPager;
  }

  public OrgResoMetadataPropertyCreate buyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhone
   * @return buyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentPreferredPhone() {
    return buyerAgentPreferredPhone;
  }

  public void setBuyerAgentPreferredPhone(String buyerAgentPreferredPhone) {
    this.buyerAgentPreferredPhone = buyerAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get buyerAgentPreferredPhoneExt
   * @return buyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentPreferredPhoneExt() {
    return buyerAgentPreferredPhoneExt;
  }

  public void setBuyerAgentPreferredPhoneExt(String buyerAgentPreferredPhoneExt) {
    this.buyerAgentPreferredPhoneExt = buyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyCreate buyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
    return this;
  }

  /**
   * Get buyerAgentStateLicense
   * @return buyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerAgentStateLicense() {
    return buyerAgentStateLicense;
  }

  public void setBuyerAgentStateLicense(String buyerAgentStateLicense) {
    this.buyerAgentStateLicense = buyerAgentStateLicense;
  }

  public OrgResoMetadataPropertyCreate buyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get buyerAgentTollFreePhone
   * @return buyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentTollFreePhone() {
    return buyerAgentTollFreePhone;
  }

  public void setBuyerAgentTollFreePhone(String buyerAgentTollFreePhone) {
    this.buyerAgentTollFreePhone = buyerAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyCreate buyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
    return this;
  }

  /**
   * Get buyerAgentURL
   * @return buyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerAgentURL() {
    return buyerAgentURL;
  }

  public void setBuyerAgentURL(String buyerAgentURL) {
    this.buyerAgentURL = buyerAgentURL;
  }

  public OrgResoMetadataPropertyCreate buyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
    return this;
  }

  /**
   * Get buyerAgentVoiceMail
   * @return buyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerAgentVoiceMail() {
    return buyerAgentVoiceMail;
  }

  public void setBuyerAgentVoiceMail(String buyerAgentVoiceMail) {
    this.buyerAgentVoiceMail = buyerAgentVoiceMail;
  }

  public OrgResoMetadataPropertyCreate buyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get buyerAgentVoiceMailExt
   * @return buyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerAgentVoiceMailExt() {
    return buyerAgentVoiceMailExt;
  }

  public void setBuyerAgentVoiceMailExt(String buyerAgentVoiceMailExt) {
    this.buyerAgentVoiceMailExt = buyerAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyCreate buyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
    return this;
  }

  public OrgResoMetadataPropertyCreate addBuyerFinancingItem(OrgResoMetadataEnumsBuyerFinancing buyerFinancingItem) {
    if (this.buyerFinancing == null) {
      this.buyerFinancing = new ArrayList<OrgResoMetadataEnumsBuyerFinancing>();
    }
    this.buyerFinancing.add(buyerFinancingItem);
    return this;
  }

  /**
   * Get buyerFinancing
   * @return buyerFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsBuyerFinancing> getBuyerFinancing() {
    return buyerFinancing;
  }

  public void setBuyerFinancing(List<OrgResoMetadataEnumsBuyerFinancing> buyerFinancing) {
    this.buyerFinancing = buyerFinancing;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeAOR(AnyOforgResoMetadataPropertyCreateBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
    return this;
  }

  /**
   * Get buyerOfficeAOR
   * @return buyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerOfficeAOR getBuyerOfficeAOR() {
    return buyerOfficeAOR;
  }

  public void setBuyerOfficeAOR(AnyOforgResoMetadataPropertyCreateBuyerOfficeAOR buyerOfficeAOR) {
    this.buyerOfficeAOR = buyerOfficeAOR;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
    return this;
  }

  /**
   * Get buyerOfficeEmail
   * @return buyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getBuyerOfficeEmail() {
    return buyerOfficeEmail;
  }

  public void setBuyerOfficeEmail(String buyerOfficeEmail) {
    this.buyerOfficeEmail = buyerOfficeEmail;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
    return this;
  }

  /**
   * Get buyerOfficeFax
   * @return buyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficeFax() {
    return buyerOfficeFax;
  }

  public void setBuyerOfficeFax(String buyerOfficeFax) {
    this.buyerOfficeFax = buyerOfficeFax;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
    return this;
  }

  /**
   * Get buyerOfficeKey
   * @return buyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeKey() {
    return buyerOfficeKey;
  }

  public void setBuyerOfficeKey(String buyerOfficeKey) {
    this.buyerOfficeKey = buyerOfficeKey;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get buyerOfficeKeyNumeric
   * @return buyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric getBuyerOfficeKeyNumeric() {
    return buyerOfficeKeyNumeric;
  }

  public void setBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerOfficeKeyNumeric buyerOfficeKeyNumeric) {
    this.buyerOfficeKeyNumeric = buyerOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
    return this;
  }

  /**
   * Get buyerOfficeMlsId
   * @return buyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getBuyerOfficeMlsId() {
    return buyerOfficeMlsId;
  }

  public void setBuyerOfficeMlsId(String buyerOfficeMlsId) {
    this.buyerOfficeMlsId = buyerOfficeMlsId;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
    return this;
  }

  /**
   * Get buyerOfficeName
   * @return buyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerOfficeName() {
    return buyerOfficeName;
  }

  public void setBuyerOfficeName(String buyerOfficeName) {
    this.buyerOfficeName = buyerOfficeName;
  }

  public OrgResoMetadataPropertyCreate buyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
    return this;
  }

  /**
   * Get buyerOfficePhone
   * @return buyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getBuyerOfficePhone() {
    return buyerOfficePhone;
  }

  public void setBuyerOfficePhone(String buyerOfficePhone) {
    this.buyerOfficePhone = buyerOfficePhone;
  }

  public OrgResoMetadataPropertyCreate buyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
    return this;
  }

  /**
   * Get buyerOfficePhoneExt
   * @return buyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getBuyerOfficePhoneExt() {
    return buyerOfficePhoneExt;
  }

  public void setBuyerOfficePhoneExt(String buyerOfficePhoneExt) {
    this.buyerOfficePhoneExt = buyerOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate buyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
    return this;
  }

  /**
   * Get buyerOfficeURL
   * @return buyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getBuyerOfficeURL() {
    return buyerOfficeURL;
  }

  public void setBuyerOfficeURL(String buyerOfficeURL) {
    this.buyerOfficeURL = buyerOfficeURL;
  }

  public OrgResoMetadataPropertyCreate buyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
    return this;
  }

  /**
   * Get buyerTeamKey
   * @return buyerTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getBuyerTeamKey() {
    return buyerTeamKey;
  }

  public void setBuyerTeamKey(String buyerTeamKey) {
    this.buyerTeamKey = buyerTeamKey;
  }

  public OrgResoMetadataPropertyCreate buyerTeamKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
    return this;
  }

  /**
   * Get buyerTeamKeyNumeric
   * @return buyerTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerTeamKeyNumeric getBuyerTeamKeyNumeric() {
    return buyerTeamKeyNumeric;
  }

  public void setBuyerTeamKeyNumeric(AnyOforgResoMetadataPropertyCreateBuyerTeamKeyNumeric buyerTeamKeyNumeric) {
    this.buyerTeamKeyNumeric = buyerTeamKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate buyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
    return this;
  }

  /**
   * Get buyerTeamName
   * @return buyerTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getBuyerTeamName() {
    return buyerTeamName;
  }

  public void setBuyerTeamName(String buyerTeamName) {
    this.buyerTeamName = buyerTeamName;
  }

  public OrgResoMetadataPropertyCreate cableTvExpense(AnyOforgResoMetadataPropertyCreateCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
    return this;
  }

  /**
   * Get cableTvExpense
   * @return cableTvExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCableTvExpense getCableTvExpense() {
    return cableTvExpense;
  }

  public void setCableTvExpense(AnyOforgResoMetadataPropertyCreateCableTvExpense cableTvExpense) {
    this.cableTvExpense = cableTvExpense;
  }

  public OrgResoMetadataPropertyCreate cancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
    return this;
  }

  /**
   * Get cancellationDate
   * @return cancellationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCancellationDate() {
    return cancellationDate;
  }

  public void setCancellationDate(LocalDate cancellationDate) {
    this.cancellationDate = cancellationDate;
  }

  public OrgResoMetadataPropertyCreate capRate(AnyOforgResoMetadataPropertyCreateCapRate capRate) {
    this.capRate = capRate;
    return this;
  }

  /**
   * Get capRate
   * @return capRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCapRate getCapRate() {
    return capRate;
  }

  public void setCapRate(AnyOforgResoMetadataPropertyCreateCapRate capRate) {
    this.capRate = capRate;
  }

  public OrgResoMetadataPropertyCreate carportSpaces(AnyOforgResoMetadataPropertyCreateCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
    return this;
  }

  /**
   * Get carportSpaces
   * @return carportSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCarportSpaces getCarportSpaces() {
    return carportSpaces;
  }

  public void setCarportSpaces(AnyOforgResoMetadataPropertyCreateCarportSpaces carportSpaces) {
    this.carportSpaces = carportSpaces;
  }

  public OrgResoMetadataPropertyCreate carportYN(Boolean carportYN) {
    this.carportYN = carportYN;
    return this;
  }

  /**
   * Get carportYN
   * @return carportYN
   **/
  @Schema(description = "")
  
    public Boolean isCarportYN() {
    return carportYN;
  }

  public void setCarportYN(Boolean carportYN) {
    this.carportYN = carportYN;
  }

  public OrgResoMetadataPropertyCreate carrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
    return this;
  }

  /**
   * Get carrierRoute
   * @return carrierRoute
   **/
  @Schema(description = "")
  
  @Size(max=9)   public String getCarrierRoute() {
    return carrierRoute;
  }

  public void setCarrierRoute(String carrierRoute) {
    this.carrierRoute = carrierRoute;
  }

  public OrgResoMetadataPropertyCreate city(AnyOforgResoMetadataPropertyCreateCity city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCity getCity() {
    return city;
  }

  public void setCity(AnyOforgResoMetadataPropertyCreateCity city) {
    this.city = city;
  }

  public OrgResoMetadataPropertyCreate cityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
    return this;
  }

  /**
   * Get cityRegion
   * @return cityRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCityRegion() {
    return cityRegion;
  }

  public void setCityRegion(String cityRegion) {
    this.cityRegion = cityRegion;
  }

  public OrgResoMetadataPropertyCreate closeDate(LocalDate closeDate) {
    this.closeDate = closeDate;
    return this;
  }

  /**
   * Get closeDate
   * @return closeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(LocalDate closeDate) {
    this.closeDate = closeDate;
  }

  public OrgResoMetadataPropertyCreate closePrice(AnyOforgResoMetadataPropertyCreateClosePrice closePrice) {
    this.closePrice = closePrice;
    return this;
  }

  /**
   * Get closePrice
   * @return closePrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateClosePrice getClosePrice() {
    return closePrice;
  }

  public void setClosePrice(AnyOforgResoMetadataPropertyCreateClosePrice closePrice) {
    this.closePrice = closePrice;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentAOR(AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
    return this;
  }

  /**
   * Get coBuyerAgentAOR
   * @return coBuyerAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR getCoBuyerAgentAOR() {
    return coBuyerAgentAOR;
  }

  public void setCoBuyerAgentAOR(AnyOforgResoMetadataPropertyCreateCoBuyerAgentAOR coBuyerAgentAOR) {
    this.coBuyerAgentAOR = coBuyerAgentAOR;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCoBuyerAgentDesignationItem(OrgResoMetadataEnumsCoBuyerAgentDesignation coBuyerAgentDesignationItem) {
    if (this.coBuyerAgentDesignation == null) {
      this.coBuyerAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoBuyerAgentDesignation>();
    }
    this.coBuyerAgentDesignation.add(coBuyerAgentDesignationItem);
    return this;
  }

  /**
   * Get coBuyerAgentDesignation
   * @return coBuyerAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoBuyerAgentDesignation> getCoBuyerAgentDesignation() {
    return coBuyerAgentDesignation;
  }

  public void setCoBuyerAgentDesignation(List<OrgResoMetadataEnumsCoBuyerAgentDesignation> coBuyerAgentDesignation) {
    this.coBuyerAgentDesignation = coBuyerAgentDesignation;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
    return this;
  }

  /**
   * Get coBuyerAgentDirectPhone
   * @return coBuyerAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentDirectPhone() {
    return coBuyerAgentDirectPhone;
  }

  public void setCoBuyerAgentDirectPhone(String coBuyerAgentDirectPhone) {
    this.coBuyerAgentDirectPhone = coBuyerAgentDirectPhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
    return this;
  }

  /**
   * Get coBuyerAgentEmail
   * @return coBuyerAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerAgentEmail() {
    return coBuyerAgentEmail;
  }

  public void setCoBuyerAgentEmail(String coBuyerAgentEmail) {
    this.coBuyerAgentEmail = coBuyerAgentEmail;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
    return this;
  }

  /**
   * Get coBuyerAgentFax
   * @return coBuyerAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentFax() {
    return coBuyerAgentFax;
  }

  public void setCoBuyerAgentFax(String coBuyerAgentFax) {
    this.coBuyerAgentFax = coBuyerAgentFax;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
    return this;
  }

  /**
   * Get coBuyerAgentFirstName
   * @return coBuyerAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentFirstName() {
    return coBuyerAgentFirstName;
  }

  public void setCoBuyerAgentFirstName(String coBuyerAgentFirstName) {
    this.coBuyerAgentFirstName = coBuyerAgentFirstName;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
    return this;
  }

  /**
   * Get coBuyerAgentFullName
   * @return coBuyerAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoBuyerAgentFullName() {
    return coBuyerAgentFullName;
  }

  public void setCoBuyerAgentFullName(String coBuyerAgentFullName) {
    this.coBuyerAgentFullName = coBuyerAgentFullName;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
    return this;
  }

  /**
   * Get coBuyerAgentHomePhone
   * @return coBuyerAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentHomePhone() {
    return coBuyerAgentHomePhone;
  }

  public void setCoBuyerAgentHomePhone(String coBuyerAgentHomePhone) {
    this.coBuyerAgentHomePhone = coBuyerAgentHomePhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
    return this;
  }

  /**
   * Get coBuyerAgentKey
   * @return coBuyerAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerAgentKey() {
    return coBuyerAgentKey;
  }

  public void setCoBuyerAgentKey(String coBuyerAgentKey) {
    this.coBuyerAgentKey = coBuyerAgentKey;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerAgentKeyNumeric
   * @return coBuyerAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric getCoBuyerAgentKeyNumeric() {
    return coBuyerAgentKeyNumeric;
  }

  public void setCoBuyerAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric coBuyerAgentKeyNumeric) {
    this.coBuyerAgentKeyNumeric = coBuyerAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
    return this;
  }

  /**
   * Get coBuyerAgentLastName
   * @return coBuyerAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentLastName() {
    return coBuyerAgentLastName;
  }

  public void setCoBuyerAgentLastName(String coBuyerAgentLastName) {
    this.coBuyerAgentLastName = coBuyerAgentLastName;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
    return this;
  }

  /**
   * Get coBuyerAgentMiddleName
   * @return coBuyerAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentMiddleName() {
    return coBuyerAgentMiddleName;
  }

  public void setCoBuyerAgentMiddleName(String coBuyerAgentMiddleName) {
    this.coBuyerAgentMiddleName = coBuyerAgentMiddleName;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
    return this;
  }

  /**
   * Get coBuyerAgentMlsId
   * @return coBuyerAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerAgentMlsId() {
    return coBuyerAgentMlsId;
  }

  public void setCoBuyerAgentMlsId(String coBuyerAgentMlsId) {
    this.coBuyerAgentMlsId = coBuyerAgentMlsId;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
    return this;
  }

  /**
   * Get coBuyerAgentMobilePhone
   * @return coBuyerAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentMobilePhone() {
    return coBuyerAgentMobilePhone;
  }

  public void setCoBuyerAgentMobilePhone(String coBuyerAgentMobilePhone) {
    this.coBuyerAgentMobilePhone = coBuyerAgentMobilePhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
    return this;
  }

  /**
   * Get coBuyerAgentNamePrefix
   * @return coBuyerAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNamePrefix() {
    return coBuyerAgentNamePrefix;
  }

  public void setCoBuyerAgentNamePrefix(String coBuyerAgentNamePrefix) {
    this.coBuyerAgentNamePrefix = coBuyerAgentNamePrefix;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
    return this;
  }

  /**
   * Get coBuyerAgentNameSuffix
   * @return coBuyerAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentNameSuffix() {
    return coBuyerAgentNameSuffix;
  }

  public void setCoBuyerAgentNameSuffix(String coBuyerAgentNameSuffix) {
    this.coBuyerAgentNameSuffix = coBuyerAgentNameSuffix;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhone
   * @return coBuyerAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentOfficePhone() {
    return coBuyerAgentOfficePhone;
  }

  public void setCoBuyerAgentOfficePhone(String coBuyerAgentOfficePhone) {
    this.coBuyerAgentOfficePhone = coBuyerAgentOfficePhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentOfficePhoneExt
   * @return coBuyerAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentOfficePhoneExt() {
    return coBuyerAgentOfficePhoneExt;
  }

  public void setCoBuyerAgentOfficePhoneExt(String coBuyerAgentOfficePhoneExt) {
    this.coBuyerAgentOfficePhoneExt = coBuyerAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
    return this;
  }

  /**
   * Get coBuyerAgentPager
   * @return coBuyerAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPager() {
    return coBuyerAgentPager;
  }

  public void setCoBuyerAgentPager(String coBuyerAgentPager) {
    this.coBuyerAgentPager = coBuyerAgentPager;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhone
   * @return coBuyerAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentPreferredPhone() {
    return coBuyerAgentPreferredPhone;
  }

  public void setCoBuyerAgentPreferredPhone(String coBuyerAgentPreferredPhone) {
    this.coBuyerAgentPreferredPhone = coBuyerAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coBuyerAgentPreferredPhoneExt
   * @return coBuyerAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentPreferredPhoneExt() {
    return coBuyerAgentPreferredPhoneExt;
  }

  public void setCoBuyerAgentPreferredPhoneExt(String coBuyerAgentPreferredPhoneExt) {
    this.coBuyerAgentPreferredPhoneExt = coBuyerAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
    return this;
  }

  /**
   * Get coBuyerAgentStateLicense
   * @return coBuyerAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoBuyerAgentStateLicense() {
    return coBuyerAgentStateLicense;
  }

  public void setCoBuyerAgentStateLicense(String coBuyerAgentStateLicense) {
    this.coBuyerAgentStateLicense = coBuyerAgentStateLicense;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
    return this;
  }

  /**
   * Get coBuyerAgentTollFreePhone
   * @return coBuyerAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentTollFreePhone() {
    return coBuyerAgentTollFreePhone;
  }

  public void setCoBuyerAgentTollFreePhone(String coBuyerAgentTollFreePhone) {
    this.coBuyerAgentTollFreePhone = coBuyerAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
    return this;
  }

  /**
   * Get coBuyerAgentURL
   * @return coBuyerAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerAgentURL() {
    return coBuyerAgentURL;
  }

  public void setCoBuyerAgentURL(String coBuyerAgentURL) {
    this.coBuyerAgentURL = coBuyerAgentURL;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMail
   * @return coBuyerAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerAgentVoiceMail() {
    return coBuyerAgentVoiceMail;
  }

  public void setCoBuyerAgentVoiceMail(String coBuyerAgentVoiceMail) {
    this.coBuyerAgentVoiceMail = coBuyerAgentVoiceMail;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coBuyerAgentVoiceMailExt
   * @return coBuyerAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerAgentVoiceMailExt() {
    return coBuyerAgentVoiceMailExt;
  }

  public void setCoBuyerAgentVoiceMailExt(String coBuyerAgentVoiceMailExt) {
    this.coBuyerAgentVoiceMailExt = coBuyerAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeAOR(AnyOforgResoMetadataPropertyCreateCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
    return this;
  }

  /**
   * Get coBuyerOfficeAOR
   * @return coBuyerOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerOfficeAOR getCoBuyerOfficeAOR() {
    return coBuyerOfficeAOR;
  }

  public void setCoBuyerOfficeAOR(AnyOforgResoMetadataPropertyCreateCoBuyerOfficeAOR coBuyerOfficeAOR) {
    this.coBuyerOfficeAOR = coBuyerOfficeAOR;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
    return this;
  }

  /**
   * Get coBuyerOfficeEmail
   * @return coBuyerOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoBuyerOfficeEmail() {
    return coBuyerOfficeEmail;
  }

  public void setCoBuyerOfficeEmail(String coBuyerOfficeEmail) {
    this.coBuyerOfficeEmail = coBuyerOfficeEmail;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
    return this;
  }

  /**
   * Get coBuyerOfficeFax
   * @return coBuyerOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficeFax() {
    return coBuyerOfficeFax;
  }

  public void setCoBuyerOfficeFax(String coBuyerOfficeFax) {
    this.coBuyerOfficeFax = coBuyerOfficeFax;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
    return this;
  }

  /**
   * Get coBuyerOfficeKey
   * @return coBuyerOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeKey() {
    return coBuyerOfficeKey;
  }

  public void setCoBuyerOfficeKey(String coBuyerOfficeKey) {
    this.coBuyerOfficeKey = coBuyerOfficeKey;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coBuyerOfficeKeyNumeric
   * @return coBuyerOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric getCoBuyerOfficeKeyNumeric() {
    return coBuyerOfficeKeyNumeric;
  }

  public void setCoBuyerOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric coBuyerOfficeKeyNumeric) {
    this.coBuyerOfficeKeyNumeric = coBuyerOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
    return this;
  }

  /**
   * Get coBuyerOfficeMlsId
   * @return coBuyerOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoBuyerOfficeMlsId() {
    return coBuyerOfficeMlsId;
  }

  public void setCoBuyerOfficeMlsId(String coBuyerOfficeMlsId) {
    this.coBuyerOfficeMlsId = coBuyerOfficeMlsId;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
    return this;
  }

  /**
   * Get coBuyerOfficeName
   * @return coBuyerOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoBuyerOfficeName() {
    return coBuyerOfficeName;
  }

  public void setCoBuyerOfficeName(String coBuyerOfficeName) {
    this.coBuyerOfficeName = coBuyerOfficeName;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
    return this;
  }

  /**
   * Get coBuyerOfficePhone
   * @return coBuyerOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoBuyerOfficePhone() {
    return coBuyerOfficePhone;
  }

  public void setCoBuyerOfficePhone(String coBuyerOfficePhone) {
    this.coBuyerOfficePhone = coBuyerOfficePhone;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
    return this;
  }

  /**
   * Get coBuyerOfficePhoneExt
   * @return coBuyerOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoBuyerOfficePhoneExt() {
    return coBuyerOfficePhoneExt;
  }

  public void setCoBuyerOfficePhoneExt(String coBuyerOfficePhoneExt) {
    this.coBuyerOfficePhoneExt = coBuyerOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate coBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
    return this;
  }

  /**
   * Get coBuyerOfficeURL
   * @return coBuyerOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoBuyerOfficeURL() {
    return coBuyerOfficeURL;
  }

  public void setCoBuyerOfficeURL(String coBuyerOfficeURL) {
    this.coBuyerOfficeURL = coBuyerOfficeURL;
  }

  public OrgResoMetadataPropertyCreate coListAgentAOR(AnyOforgResoMetadataPropertyCreateCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
    return this;
  }

  /**
   * Get coListAgentAOR
   * @return coListAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListAgentAOR getCoListAgentAOR() {
    return coListAgentAOR;
  }

  public void setCoListAgentAOR(AnyOforgResoMetadataPropertyCreateCoListAgentAOR coListAgentAOR) {
    this.coListAgentAOR = coListAgentAOR;
  }

  public OrgResoMetadataPropertyCreate coListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCoListAgentDesignationItem(OrgResoMetadataEnumsCoListAgentDesignation coListAgentDesignationItem) {
    if (this.coListAgentDesignation == null) {
      this.coListAgentDesignation = new ArrayList<OrgResoMetadataEnumsCoListAgentDesignation>();
    }
    this.coListAgentDesignation.add(coListAgentDesignationItem);
    return this;
  }

  /**
   * Get coListAgentDesignation
   * @return coListAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCoListAgentDesignation> getCoListAgentDesignation() {
    return coListAgentDesignation;
  }

  public void setCoListAgentDesignation(List<OrgResoMetadataEnumsCoListAgentDesignation> coListAgentDesignation) {
    this.coListAgentDesignation = coListAgentDesignation;
  }

  public OrgResoMetadataPropertyCreate coListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
    return this;
  }

  /**
   * Get coListAgentDirectPhone
   * @return coListAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentDirectPhone() {
    return coListAgentDirectPhone;
  }

  public void setCoListAgentDirectPhone(String coListAgentDirectPhone) {
    this.coListAgentDirectPhone = coListAgentDirectPhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
    return this;
  }

  /**
   * Get coListAgentEmail
   * @return coListAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListAgentEmail() {
    return coListAgentEmail;
  }

  public void setCoListAgentEmail(String coListAgentEmail) {
    this.coListAgentEmail = coListAgentEmail;
  }

  public OrgResoMetadataPropertyCreate coListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
    return this;
  }

  /**
   * Get coListAgentFax
   * @return coListAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentFax() {
    return coListAgentFax;
  }

  public void setCoListAgentFax(String coListAgentFax) {
    this.coListAgentFax = coListAgentFax;
  }

  public OrgResoMetadataPropertyCreate coListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
    return this;
  }

  /**
   * Get coListAgentFirstName
   * @return coListAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentFirstName() {
    return coListAgentFirstName;
  }

  public void setCoListAgentFirstName(String coListAgentFirstName) {
    this.coListAgentFirstName = coListAgentFirstName;
  }

  public OrgResoMetadataPropertyCreate coListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
    return this;
  }

  /**
   * Get coListAgentFullName
   * @return coListAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCoListAgentFullName() {
    return coListAgentFullName;
  }

  public void setCoListAgentFullName(String coListAgentFullName) {
    this.coListAgentFullName = coListAgentFullName;
  }

  public OrgResoMetadataPropertyCreate coListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
    return this;
  }

  /**
   * Get coListAgentHomePhone
   * @return coListAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentHomePhone() {
    return coListAgentHomePhone;
  }

  public void setCoListAgentHomePhone(String coListAgentHomePhone) {
    this.coListAgentHomePhone = coListAgentHomePhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
    return this;
  }

  /**
   * Get coListAgentKey
   * @return coListAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListAgentKey() {
    return coListAgentKey;
  }

  public void setCoListAgentKey(String coListAgentKey) {
    this.coListAgentKey = coListAgentKey;
  }

  public OrgResoMetadataPropertyCreate coListAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
    return this;
  }

  /**
   * Get coListAgentKeyNumeric
   * @return coListAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListAgentKeyNumeric getCoListAgentKeyNumeric() {
    return coListAgentKeyNumeric;
  }

  public void setCoListAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateCoListAgentKeyNumeric coListAgentKeyNumeric) {
    this.coListAgentKeyNumeric = coListAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate coListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
    return this;
  }

  /**
   * Get coListAgentLastName
   * @return coListAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentLastName() {
    return coListAgentLastName;
  }

  public void setCoListAgentLastName(String coListAgentLastName) {
    this.coListAgentLastName = coListAgentLastName;
  }

  public OrgResoMetadataPropertyCreate coListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
    return this;
  }

  /**
   * Get coListAgentMiddleName
   * @return coListAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentMiddleName() {
    return coListAgentMiddleName;
  }

  public void setCoListAgentMiddleName(String coListAgentMiddleName) {
    this.coListAgentMiddleName = coListAgentMiddleName;
  }

  public OrgResoMetadataPropertyCreate coListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
    return this;
  }

  /**
   * Get coListAgentMlsId
   * @return coListAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListAgentMlsId() {
    return coListAgentMlsId;
  }

  public void setCoListAgentMlsId(String coListAgentMlsId) {
    this.coListAgentMlsId = coListAgentMlsId;
  }

  public OrgResoMetadataPropertyCreate coListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
    return this;
  }

  /**
   * Get coListAgentMobilePhone
   * @return coListAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentMobilePhone() {
    return coListAgentMobilePhone;
  }

  public void setCoListAgentMobilePhone(String coListAgentMobilePhone) {
    this.coListAgentMobilePhone = coListAgentMobilePhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
    return this;
  }

  /**
   * Get coListAgentNamePrefix
   * @return coListAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNamePrefix() {
    return coListAgentNamePrefix;
  }

  public void setCoListAgentNamePrefix(String coListAgentNamePrefix) {
    this.coListAgentNamePrefix = coListAgentNamePrefix;
  }

  public OrgResoMetadataPropertyCreate coListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
    return this;
  }

  /**
   * Get coListAgentNameSuffix
   * @return coListAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentNameSuffix() {
    return coListAgentNameSuffix;
  }

  public void setCoListAgentNameSuffix(String coListAgentNameSuffix) {
    this.coListAgentNameSuffix = coListAgentNameSuffix;
  }

  public OrgResoMetadataPropertyCreate coListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
    return this;
  }

  /**
   * Get coListAgentOfficePhone
   * @return coListAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentOfficePhone() {
    return coListAgentOfficePhone;
  }

  public void setCoListAgentOfficePhone(String coListAgentOfficePhone) {
    this.coListAgentOfficePhone = coListAgentOfficePhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get coListAgentOfficePhoneExt
   * @return coListAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentOfficePhoneExt() {
    return coListAgentOfficePhoneExt;
  }

  public void setCoListAgentOfficePhoneExt(String coListAgentOfficePhoneExt) {
    this.coListAgentOfficePhoneExt = coListAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate coListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
    return this;
  }

  /**
   * Get coListAgentPager
   * @return coListAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPager() {
    return coListAgentPager;
  }

  public void setCoListAgentPager(String coListAgentPager) {
    this.coListAgentPager = coListAgentPager;
  }

  public OrgResoMetadataPropertyCreate coListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
    return this;
  }

  /**
   * Get coListAgentPreferredPhone
   * @return coListAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentPreferredPhone() {
    return coListAgentPreferredPhone;
  }

  public void setCoListAgentPreferredPhone(String coListAgentPreferredPhone) {
    this.coListAgentPreferredPhone = coListAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get coListAgentPreferredPhoneExt
   * @return coListAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentPreferredPhoneExt() {
    return coListAgentPreferredPhoneExt;
  }

  public void setCoListAgentPreferredPhoneExt(String coListAgentPreferredPhoneExt) {
    this.coListAgentPreferredPhoneExt = coListAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyCreate coListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
    return this;
  }

  /**
   * Get coListAgentStateLicense
   * @return coListAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCoListAgentStateLicense() {
    return coListAgentStateLicense;
  }

  public void setCoListAgentStateLicense(String coListAgentStateLicense) {
    this.coListAgentStateLicense = coListAgentStateLicense;
  }

  public OrgResoMetadataPropertyCreate coListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
    return this;
  }

  /**
   * Get coListAgentTollFreePhone
   * @return coListAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentTollFreePhone() {
    return coListAgentTollFreePhone;
  }

  public void setCoListAgentTollFreePhone(String coListAgentTollFreePhone) {
    this.coListAgentTollFreePhone = coListAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyCreate coListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
    return this;
  }

  /**
   * Get coListAgentURL
   * @return coListAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListAgentURL() {
    return coListAgentURL;
  }

  public void setCoListAgentURL(String coListAgentURL) {
    this.coListAgentURL = coListAgentURL;
  }

  public OrgResoMetadataPropertyCreate coListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
    return this;
  }

  /**
   * Get coListAgentVoiceMail
   * @return coListAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListAgentVoiceMail() {
    return coListAgentVoiceMail;
  }

  public void setCoListAgentVoiceMail(String coListAgentVoiceMail) {
    this.coListAgentVoiceMail = coListAgentVoiceMail;
  }

  public OrgResoMetadataPropertyCreate coListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
    return this;
  }

  /**
   * Get coListAgentVoiceMailExt
   * @return coListAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListAgentVoiceMailExt() {
    return coListAgentVoiceMailExt;
  }

  public void setCoListAgentVoiceMailExt(String coListAgentVoiceMailExt) {
    this.coListAgentVoiceMailExt = coListAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyCreate coListOfficeAOR(AnyOforgResoMetadataPropertyCreateCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
    return this;
  }

  /**
   * Get coListOfficeAOR
   * @return coListOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListOfficeAOR getCoListOfficeAOR() {
    return coListOfficeAOR;
  }

  public void setCoListOfficeAOR(AnyOforgResoMetadataPropertyCreateCoListOfficeAOR coListOfficeAOR) {
    this.coListOfficeAOR = coListOfficeAOR;
  }

  public OrgResoMetadataPropertyCreate coListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
    return this;
  }

  /**
   * Get coListOfficeEmail
   * @return coListOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getCoListOfficeEmail() {
    return coListOfficeEmail;
  }

  public void setCoListOfficeEmail(String coListOfficeEmail) {
    this.coListOfficeEmail = coListOfficeEmail;
  }

  public OrgResoMetadataPropertyCreate coListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
    return this;
  }

  /**
   * Get coListOfficeFax
   * @return coListOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficeFax() {
    return coListOfficeFax;
  }

  public void setCoListOfficeFax(String coListOfficeFax) {
    this.coListOfficeFax = coListOfficeFax;
  }

  public OrgResoMetadataPropertyCreate coListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
    return this;
  }

  /**
   * Get coListOfficeKey
   * @return coListOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeKey() {
    return coListOfficeKey;
  }

  public void setCoListOfficeKey(String coListOfficeKey) {
    this.coListOfficeKey = coListOfficeKey;
  }

  public OrgResoMetadataPropertyCreate coListOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
    return this;
  }

  /**
   * Get coListOfficeKeyNumeric
   * @return coListOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric getCoListOfficeKeyNumeric() {
    return coListOfficeKeyNumeric;
  }

  public void setCoListOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateCoListOfficeKeyNumeric coListOfficeKeyNumeric) {
    this.coListOfficeKeyNumeric = coListOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate coListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
    return this;
  }

  /**
   * Get coListOfficeMlsId
   * @return coListOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getCoListOfficeMlsId() {
    return coListOfficeMlsId;
  }

  public void setCoListOfficeMlsId(String coListOfficeMlsId) {
    this.coListOfficeMlsId = coListOfficeMlsId;
  }

  public OrgResoMetadataPropertyCreate coListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
    return this;
  }

  /**
   * Get coListOfficeName
   * @return coListOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getCoListOfficeName() {
    return coListOfficeName;
  }

  public void setCoListOfficeName(String coListOfficeName) {
    this.coListOfficeName = coListOfficeName;
  }

  public OrgResoMetadataPropertyCreate coListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
    return this;
  }

  /**
   * Get coListOfficePhone
   * @return coListOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getCoListOfficePhone() {
    return coListOfficePhone;
  }

  public void setCoListOfficePhone(String coListOfficePhone) {
    this.coListOfficePhone = coListOfficePhone;
  }

  public OrgResoMetadataPropertyCreate coListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
    return this;
  }

  /**
   * Get coListOfficePhoneExt
   * @return coListOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getCoListOfficePhoneExt() {
    return coListOfficePhoneExt;
  }

  public void setCoListOfficePhoneExt(String coListOfficePhoneExt) {
    this.coListOfficePhoneExt = coListOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate coListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
    return this;
  }

  /**
   * Get coListOfficeURL
   * @return coListOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getCoListOfficeURL() {
    return coListOfficeURL;
  }

  public void setCoListOfficeURL(String coListOfficeURL) {
    this.coListOfficeURL = coListOfficeURL;
  }

  public OrgResoMetadataPropertyCreate commonInterest(AnyOforgResoMetadataPropertyCreateCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
    return this;
  }

  /**
   * Get commonInterest
   * @return commonInterest
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCommonInterest getCommonInterest() {
    return commonInterest;
  }

  public void setCommonInterest(AnyOforgResoMetadataPropertyCreateCommonInterest commonInterest) {
    this.commonInterest = commonInterest;
  }

  public OrgResoMetadataPropertyCreate commonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCommonWallsItem(OrgResoMetadataEnumsCommonWalls commonWallsItem) {
    if (this.commonWalls == null) {
      this.commonWalls = new ArrayList<OrgResoMetadataEnumsCommonWalls>();
    }
    this.commonWalls.add(commonWallsItem);
    return this;
  }

  /**
   * Get commonWalls
   * @return commonWalls
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommonWalls> getCommonWalls() {
    return commonWalls;
  }

  public void setCommonWalls(List<OrgResoMetadataEnumsCommonWalls> commonWalls) {
    this.commonWalls = commonWalls;
  }

  public OrgResoMetadataPropertyCreate communityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCommunityFeaturesItem(OrgResoMetadataEnumsCommunityFeatures communityFeaturesItem) {
    if (this.communityFeatures == null) {
      this.communityFeatures = new ArrayList<OrgResoMetadataEnumsCommunityFeatures>();
    }
    this.communityFeatures.add(communityFeaturesItem);
    return this;
  }

  /**
   * Get communityFeatures
   * @return communityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCommunityFeatures> getCommunityFeatures() {
    return communityFeatures;
  }

  public void setCommunityFeatures(List<OrgResoMetadataEnumsCommunityFeatures> communityFeatures) {
    this.communityFeatures = communityFeatures;
  }

  public OrgResoMetadataPropertyCreate concessions(AnyOforgResoMetadataPropertyCreateConcessions concessions) {
    this.concessions = concessions;
    return this;
  }

  /**
   * Get concessions
   * @return concessions
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateConcessions getConcessions() {
    return concessions;
  }

  public void setConcessions(AnyOforgResoMetadataPropertyCreateConcessions concessions) {
    this.concessions = concessions;
  }

  public OrgResoMetadataPropertyCreate concessionsAmount(AnyOforgResoMetadataPropertyCreateConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
    return this;
  }

  /**
   * Get concessionsAmount
   * @return concessionsAmount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateConcessionsAmount getConcessionsAmount() {
    return concessionsAmount;
  }

  public void setConcessionsAmount(AnyOforgResoMetadataPropertyCreateConcessionsAmount concessionsAmount) {
    this.concessionsAmount = concessionsAmount;
  }

  public OrgResoMetadataPropertyCreate concessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
    return this;
  }

  /**
   * Get concessionsComments
   * @return concessionsComments
   **/
  @Schema(description = "")
  
  @Size(max=200)   public String getConcessionsComments() {
    return concessionsComments;
  }

  public void setConcessionsComments(String concessionsComments) {
    this.concessionsComments = concessionsComments;
  }

  public OrgResoMetadataPropertyCreate constructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
    return this;
  }

  public OrgResoMetadataPropertyCreate addConstructionMaterialsItem(OrgResoMetadataEnumsConstructionMaterials constructionMaterialsItem) {
    if (this.constructionMaterials == null) {
      this.constructionMaterials = new ArrayList<OrgResoMetadataEnumsConstructionMaterials>();
    }
    this.constructionMaterials.add(constructionMaterialsItem);
    return this;
  }

  /**
   * Get constructionMaterials
   * @return constructionMaterials
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsConstructionMaterials> getConstructionMaterials() {
    return constructionMaterials;
  }

  public void setConstructionMaterials(List<OrgResoMetadataEnumsConstructionMaterials> constructionMaterials) {
    this.constructionMaterials = constructionMaterials;
  }

  public OrgResoMetadataPropertyCreate continentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
    return this;
  }

  /**
   * Get continentRegion
   * @return continentRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getContinentRegion() {
    return continentRegion;
  }

  public void setContinentRegion(String continentRegion) {
    this.continentRegion = continentRegion;
  }

  public OrgResoMetadataPropertyCreate contingency(String contingency) {
    this.contingency = contingency;
    return this;
  }

  /**
   * Get contingency
   * @return contingency
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getContingency() {
    return contingency;
  }

  public void setContingency(String contingency) {
    this.contingency = contingency;
  }

  public OrgResoMetadataPropertyCreate contingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
    return this;
  }

  /**
   * Get contingentDate
   * @return contingentDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContingentDate() {
    return contingentDate;
  }

  public void setContingentDate(LocalDate contingentDate) {
    this.contingentDate = contingentDate;
  }

  public OrgResoMetadataPropertyCreate contractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
    return this;
  }

  /**
   * Get contractStatusChangeDate
   * @return contractStatusChangeDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getContractStatusChangeDate() {
    return contractStatusChangeDate;
  }

  public void setContractStatusChangeDate(LocalDate contractStatusChangeDate) {
    this.contractStatusChangeDate = contractStatusChangeDate;
  }

  public OrgResoMetadataPropertyCreate cooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCoolingItem(OrgResoMetadataEnumsCooling coolingItem) {
    if (this.cooling == null) {
      this.cooling = new ArrayList<OrgResoMetadataEnumsCooling>();
    }
    this.cooling.add(coolingItem);
    return this;
  }

  /**
   * Get cooling
   * @return cooling
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCooling> getCooling() {
    return cooling;
  }

  public void setCooling(List<OrgResoMetadataEnumsCooling> cooling) {
    this.cooling = cooling;
  }

  public OrgResoMetadataPropertyCreate coolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
    return this;
  }

  /**
   * Get coolingYN
   * @return coolingYN
   **/
  @Schema(description = "")
  
    public Boolean isCoolingYN() {
    return coolingYN;
  }

  public void setCoolingYN(Boolean coolingYN) {
    this.coolingYN = coolingYN;
  }

  public OrgResoMetadataPropertyCreate copyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
    return this;
  }

  /**
   * Get copyrightNotice
   * @return copyrightNotice
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getCopyrightNotice() {
    return copyrightNotice;
  }

  public void setCopyrightNotice(String copyrightNotice) {
    this.copyrightNotice = copyrightNotice;
  }

  public OrgResoMetadataPropertyCreate country(AnyOforgResoMetadataPropertyCreateCountry country) {
    this.country = country;
    return this;
  }

  /**
   * Get country
   * @return country
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCountry getCountry() {
    return country;
  }

  public void setCountry(AnyOforgResoMetadataPropertyCreateCountry country) {
    this.country = country;
  }

  public OrgResoMetadataPropertyCreate countryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
    return this;
  }

  /**
   * Get countryRegion
   * @return countryRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getCountryRegion() {
    return countryRegion;
  }

  public void setCountryRegion(String countryRegion) {
    this.countryRegion = countryRegion;
  }

  public OrgResoMetadataPropertyCreate countyOrParish(AnyOforgResoMetadataPropertyCreateCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
    return this;
  }

  /**
   * Get countyOrParish
   * @return countyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCountyOrParish getCountyOrParish() {
    return countyOrParish;
  }

  public void setCountyOrParish(AnyOforgResoMetadataPropertyCreateCountyOrParish countyOrParish) {
    this.countyOrParish = countyOrParish;
  }

  public OrgResoMetadataPropertyCreate coveredSpaces(AnyOforgResoMetadataPropertyCreateCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
    return this;
  }

  /**
   * Get coveredSpaces
   * @return coveredSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoveredSpaces getCoveredSpaces() {
    return coveredSpaces;
  }

  public void setCoveredSpaces(AnyOforgResoMetadataPropertyCreateCoveredSpaces coveredSpaces) {
    this.coveredSpaces = coveredSpaces;
  }

  public OrgResoMetadataPropertyCreate cropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
    return this;
  }

  /**
   * Get cropsIncludedYN
   * @return cropsIncludedYN
   **/
  @Schema(description = "")
  
    public Boolean isCropsIncludedYN() {
    return cropsIncludedYN;
  }

  public void setCropsIncludedYN(Boolean cropsIncludedYN) {
    this.cropsIncludedYN = cropsIncludedYN;
  }

  public OrgResoMetadataPropertyCreate crossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
    return this;
  }

  /**
   * Get crossStreet
   * @return crossStreet
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getCrossStreet() {
    return crossStreet;
  }

  public void setCrossStreet(String crossStreet) {
    this.crossStreet = crossStreet;
  }

  public OrgResoMetadataPropertyCreate cultivatedArea(AnyOforgResoMetadataPropertyCreateCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
    return this;
  }

  /**
   * Get cultivatedArea
   * @return cultivatedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCultivatedArea getCultivatedArea() {
    return cultivatedArea;
  }

  public void setCultivatedArea(AnyOforgResoMetadataPropertyCreateCultivatedArea cultivatedArea) {
    this.cultivatedArea = cultivatedArea;
  }

  public OrgResoMetadataPropertyCreate cumulativeDaysOnMarket(AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
    return this;
  }

  /**
   * Get cumulativeDaysOnMarket
   * @return cumulativeDaysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket getCumulativeDaysOnMarket() {
    return cumulativeDaysOnMarket;
  }

  public void setCumulativeDaysOnMarket(AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket cumulativeDaysOnMarket) {
    this.cumulativeDaysOnMarket = cumulativeDaysOnMarket;
  }

  public OrgResoMetadataPropertyCreate currentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCurrentFinancingItem(OrgResoMetadataEnumsCurrentFinancing currentFinancingItem) {
    if (this.currentFinancing == null) {
      this.currentFinancing = new ArrayList<OrgResoMetadataEnumsCurrentFinancing>();
    }
    this.currentFinancing.add(currentFinancingItem);
    return this;
  }

  /**
   * Get currentFinancing
   * @return currentFinancing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentFinancing> getCurrentFinancing() {
    return currentFinancing;
  }

  public void setCurrentFinancing(List<OrgResoMetadataEnumsCurrentFinancing> currentFinancing) {
    this.currentFinancing = currentFinancing;
  }

  public OrgResoMetadataPropertyCreate currentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
    return this;
  }

  public OrgResoMetadataPropertyCreate addCurrentUseItem(OrgResoMetadataEnumsCurrentUse currentUseItem) {
    if (this.currentUse == null) {
      this.currentUse = new ArrayList<OrgResoMetadataEnumsCurrentUse>();
    }
    this.currentUse.add(currentUseItem);
    return this;
  }

  /**
   * Get currentUse
   * @return currentUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsCurrentUse> getCurrentUse() {
    return currentUse;
  }

  public void setCurrentUse(List<OrgResoMetadataEnumsCurrentUse> currentUse) {
    this.currentUse = currentUse;
  }

  public OrgResoMetadataPropertyCreate doH1(String doH1) {
    this.doH1 = doH1;
    return this;
  }

  /**
   * Get doH1
   * @return doH1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH1() {
    return doH1;
  }

  public void setDoH1(String doH1) {
    this.doH1 = doH1;
  }

  public OrgResoMetadataPropertyCreate doH2(String doH2) {
    this.doH2 = doH2;
    return this;
  }

  /**
   * Get doH2
   * @return doH2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH2() {
    return doH2;
  }

  public void setDoH2(String doH2) {
    this.doH2 = doH2;
  }

  public OrgResoMetadataPropertyCreate doH3(String doH3) {
    this.doH3 = doH3;
    return this;
  }

  /**
   * Get doH3
   * @return doH3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getDoH3() {
    return doH3;
  }

  public void setDoH3(String doH3) {
    this.doH3 = doH3;
  }

  public OrgResoMetadataPropertyCreate daysOnMarket(AnyOforgResoMetadataPropertyCreateDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
    return this;
  }

  /**
   * Get daysOnMarket
   * @return daysOnMarket
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDaysOnMarket getDaysOnMarket() {
    return daysOnMarket;
  }

  public void setDaysOnMarket(AnyOforgResoMetadataPropertyCreateDaysOnMarket daysOnMarket) {
    this.daysOnMarket = daysOnMarket;
  }

  public OrgResoMetadataPropertyCreate developmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
    return this;
  }

  public OrgResoMetadataPropertyCreate addDevelopmentStatusItem(OrgResoMetadataEnumsDevelopmentStatus developmentStatusItem) {
    if (this.developmentStatus == null) {
      this.developmentStatus = new ArrayList<OrgResoMetadataEnumsDevelopmentStatus>();
    }
    this.developmentStatus.add(developmentStatusItem);
    return this;
  }

  /**
   * Get developmentStatus
   * @return developmentStatus
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDevelopmentStatus> getDevelopmentStatus() {
    return developmentStatus;
  }

  public void setDevelopmentStatus(List<OrgResoMetadataEnumsDevelopmentStatus> developmentStatus) {
    this.developmentStatus = developmentStatus;
  }

  public OrgResoMetadataPropertyCreate directionFaces(AnyOforgResoMetadataPropertyCreateDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
    return this;
  }

  /**
   * Get directionFaces
   * @return directionFaces
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDirectionFaces getDirectionFaces() {
    return directionFaces;
  }

  public void setDirectionFaces(AnyOforgResoMetadataPropertyCreateDirectionFaces directionFaces) {
    this.directionFaces = directionFaces;
  }

  public OrgResoMetadataPropertyCreate directions(String directions) {
    this.directions = directions;
    return this;
  }

  /**
   * Get directions
   * @return directions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getDirections() {
    return directions;
  }

  public void setDirections(String directions) {
    this.directions = directions;
  }

  public OrgResoMetadataPropertyCreate disclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
    return this;
  }

  /**
   * Get disclaimer
   * @return disclaimer
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getDisclaimer() {
    return disclaimer;
  }

  public void setDisclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
  }

  public OrgResoMetadataPropertyCreate disclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addDisclosuresItem(OrgResoMetadataEnumsDisclosures disclosuresItem) {
    if (this.disclosures == null) {
      this.disclosures = new ArrayList<OrgResoMetadataEnumsDisclosures>();
    }
    this.disclosures.add(disclosuresItem);
    return this;
  }

  /**
   * Get disclosures
   * @return disclosures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDisclosures> getDisclosures() {
    return disclosures;
  }

  public void setDisclosures(List<OrgResoMetadataEnumsDisclosures> disclosures) {
    this.disclosures = disclosures;
  }

  public OrgResoMetadataPropertyCreate distanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
    return this;
  }

  /**
   * Get distanceToBusComments
   * @return distanceToBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToBusComments() {
    return distanceToBusComments;
  }

  public void setDistanceToBusComments(String distanceToBusComments) {
    this.distanceToBusComments = distanceToBusComments;
  }

  public OrgResoMetadataPropertyCreate distanceToBusNumeric(AnyOforgResoMetadataPropertyCreateDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
    return this;
  }

  /**
   * Get distanceToBusNumeric
   * @return distanceToBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToBusNumeric getDistanceToBusNumeric() {
    return distanceToBusNumeric;
  }

  public void setDistanceToBusNumeric(AnyOforgResoMetadataPropertyCreateDistanceToBusNumeric distanceToBusNumeric) {
    this.distanceToBusNumeric = distanceToBusNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToBusUnits(AnyOforgResoMetadataPropertyCreateDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
    return this;
  }

  /**
   * Get distanceToBusUnits
   * @return distanceToBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToBusUnits getDistanceToBusUnits() {
    return distanceToBusUnits;
  }

  public void setDistanceToBusUnits(AnyOforgResoMetadataPropertyCreateDistanceToBusUnits distanceToBusUnits) {
    this.distanceToBusUnits = distanceToBusUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
    return this;
  }

  /**
   * Get distanceToElectricComments
   * @return distanceToElectricComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToElectricComments() {
    return distanceToElectricComments;
  }

  public void setDistanceToElectricComments(String distanceToElectricComments) {
    this.distanceToElectricComments = distanceToElectricComments;
  }

  public OrgResoMetadataPropertyCreate distanceToElectricNumeric(AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
    return this;
  }

  /**
   * Get distanceToElectricNumeric
   * @return distanceToElectricNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric getDistanceToElectricNumeric() {
    return distanceToElectricNumeric;
  }

  public void setDistanceToElectricNumeric(AnyOforgResoMetadataPropertyCreateDistanceToElectricNumeric distanceToElectricNumeric) {
    this.distanceToElectricNumeric = distanceToElectricNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToElectricUnits(AnyOforgResoMetadataPropertyCreateDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
    return this;
  }

  /**
   * Get distanceToElectricUnits
   * @return distanceToElectricUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToElectricUnits getDistanceToElectricUnits() {
    return distanceToElectricUnits;
  }

  public void setDistanceToElectricUnits(AnyOforgResoMetadataPropertyCreateDistanceToElectricUnits distanceToElectricUnits) {
    this.distanceToElectricUnits = distanceToElectricUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
    return this;
  }

  /**
   * Get distanceToFreewayComments
   * @return distanceToFreewayComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToFreewayComments() {
    return distanceToFreewayComments;
  }

  public void setDistanceToFreewayComments(String distanceToFreewayComments) {
    this.distanceToFreewayComments = distanceToFreewayComments;
  }

  public OrgResoMetadataPropertyCreate distanceToFreewayNumeric(AnyOforgResoMetadataPropertyCreateDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
    return this;
  }

  /**
   * Get distanceToFreewayNumeric
   * @return distanceToFreewayNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToFreewayNumeric getDistanceToFreewayNumeric() {
    return distanceToFreewayNumeric;
  }

  public void setDistanceToFreewayNumeric(AnyOforgResoMetadataPropertyCreateDistanceToFreewayNumeric distanceToFreewayNumeric) {
    this.distanceToFreewayNumeric = distanceToFreewayNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToFreewayUnits(AnyOforgResoMetadataPropertyCreateDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
    return this;
  }

  /**
   * Get distanceToFreewayUnits
   * @return distanceToFreewayUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToFreewayUnits getDistanceToFreewayUnits() {
    return distanceToFreewayUnits;
  }

  public void setDistanceToFreewayUnits(AnyOforgResoMetadataPropertyCreateDistanceToFreewayUnits distanceToFreewayUnits) {
    this.distanceToFreewayUnits = distanceToFreewayUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
    return this;
  }

  /**
   * Get distanceToGasComments
   * @return distanceToGasComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToGasComments() {
    return distanceToGasComments;
  }

  public void setDistanceToGasComments(String distanceToGasComments) {
    this.distanceToGasComments = distanceToGasComments;
  }

  public OrgResoMetadataPropertyCreate distanceToGasNumeric(AnyOforgResoMetadataPropertyCreateDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
    return this;
  }

  /**
   * Get distanceToGasNumeric
   * @return distanceToGasNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToGasNumeric getDistanceToGasNumeric() {
    return distanceToGasNumeric;
  }

  public void setDistanceToGasNumeric(AnyOforgResoMetadataPropertyCreateDistanceToGasNumeric distanceToGasNumeric) {
    this.distanceToGasNumeric = distanceToGasNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToGasUnits(AnyOforgResoMetadataPropertyCreateDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
    return this;
  }

  /**
   * Get distanceToGasUnits
   * @return distanceToGasUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToGasUnits getDistanceToGasUnits() {
    return distanceToGasUnits;
  }

  public void setDistanceToGasUnits(AnyOforgResoMetadataPropertyCreateDistanceToGasUnits distanceToGasUnits) {
    this.distanceToGasUnits = distanceToGasUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
    return this;
  }

  /**
   * Get distanceToPhoneServiceComments
   * @return distanceToPhoneServiceComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPhoneServiceComments() {
    return distanceToPhoneServiceComments;
  }

  public void setDistanceToPhoneServiceComments(String distanceToPhoneServiceComments) {
    this.distanceToPhoneServiceComments = distanceToPhoneServiceComments;
  }

  public OrgResoMetadataPropertyCreate distanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
    return this;
  }

  /**
   * Get distanceToPhoneServiceNumeric
   * @return distanceToPhoneServiceNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric getDistanceToPhoneServiceNumeric() {
    return distanceToPhoneServiceNumeric;
  }

  public void setDistanceToPhoneServiceNumeric(AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric distanceToPhoneServiceNumeric) {
    this.distanceToPhoneServiceNumeric = distanceToPhoneServiceNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
    return this;
  }

  /**
   * Get distanceToPhoneServiceUnits
   * @return distanceToPhoneServiceUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceUnits getDistanceToPhoneServiceUnits() {
    return distanceToPhoneServiceUnits;
  }

  public void setDistanceToPhoneServiceUnits(AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceUnits distanceToPhoneServiceUnits) {
    this.distanceToPhoneServiceUnits = distanceToPhoneServiceUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipComments
   * @return distanceToPlaceofWorshipComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToPlaceofWorshipComments() {
    return distanceToPlaceofWorshipComments;
  }

  public void setDistanceToPlaceofWorshipComments(String distanceToPlaceofWorshipComments) {
    this.distanceToPlaceofWorshipComments = distanceToPlaceofWorshipComments;
  }

  public OrgResoMetadataPropertyCreate distanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipNumeric
   * @return distanceToPlaceofWorshipNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipNumeric getDistanceToPlaceofWorshipNumeric() {
    return distanceToPlaceofWorshipNumeric;
  }

  public void setDistanceToPlaceofWorshipNumeric(AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipNumeric distanceToPlaceofWorshipNumeric) {
    this.distanceToPlaceofWorshipNumeric = distanceToPlaceofWorshipNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
    return this;
  }

  /**
   * Get distanceToPlaceofWorshipUnits
   * @return distanceToPlaceofWorshipUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits getDistanceToPlaceofWorshipUnits() {
    return distanceToPlaceofWorshipUnits;
  }

  public void setDistanceToPlaceofWorshipUnits(AnyOforgResoMetadataPropertyCreateDistanceToPlaceofWorshipUnits distanceToPlaceofWorshipUnits) {
    this.distanceToPlaceofWorshipUnits = distanceToPlaceofWorshipUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
    return this;
  }

  /**
   * Get distanceToSchoolBusComments
   * @return distanceToSchoolBusComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolBusComments() {
    return distanceToSchoolBusComments;
  }

  public void setDistanceToSchoolBusComments(String distanceToSchoolBusComments) {
    this.distanceToSchoolBusComments = distanceToSchoolBusComments;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolBusNumeric
   * @return distanceToSchoolBusNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric getDistanceToSchoolBusNumeric() {
    return distanceToSchoolBusNumeric;
  }

  public void setDistanceToSchoolBusNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusNumeric distanceToSchoolBusNumeric) {
    this.distanceToSchoolBusNumeric = distanceToSchoolBusNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolBusUnits(AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
    return this;
  }

  /**
   * Get distanceToSchoolBusUnits
   * @return distanceToSchoolBusUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusUnits getDistanceToSchoolBusUnits() {
    return distanceToSchoolBusUnits;
  }

  public void setDistanceToSchoolBusUnits(AnyOforgResoMetadataPropertyCreateDistanceToSchoolBusUnits distanceToSchoolBusUnits) {
    this.distanceToSchoolBusUnits = distanceToSchoolBusUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
    return this;
  }

  /**
   * Get distanceToSchoolsComments
   * @return distanceToSchoolsComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSchoolsComments() {
    return distanceToSchoolsComments;
  }

  public void setDistanceToSchoolsComments(String distanceToSchoolsComments) {
    this.distanceToSchoolsComments = distanceToSchoolsComments;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolsNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
    return this;
  }

  /**
   * Get distanceToSchoolsNumeric
   * @return distanceToSchoolsNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSchoolsNumeric getDistanceToSchoolsNumeric() {
    return distanceToSchoolsNumeric;
  }

  public void setDistanceToSchoolsNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSchoolsNumeric distanceToSchoolsNumeric) {
    this.distanceToSchoolsNumeric = distanceToSchoolsNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToSchoolsUnits(AnyOforgResoMetadataPropertyCreateDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
    return this;
  }

  /**
   * Get distanceToSchoolsUnits
   * @return distanceToSchoolsUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSchoolsUnits getDistanceToSchoolsUnits() {
    return distanceToSchoolsUnits;
  }

  public void setDistanceToSchoolsUnits(AnyOforgResoMetadataPropertyCreateDistanceToSchoolsUnits distanceToSchoolsUnits) {
    this.distanceToSchoolsUnits = distanceToSchoolsUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
    return this;
  }

  /**
   * Get distanceToSewerComments
   * @return distanceToSewerComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToSewerComments() {
    return distanceToSewerComments;
  }

  public void setDistanceToSewerComments(String distanceToSewerComments) {
    this.distanceToSewerComments = distanceToSewerComments;
  }

  public OrgResoMetadataPropertyCreate distanceToSewerNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
    return this;
  }

  /**
   * Get distanceToSewerNumeric
   * @return distanceToSewerNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric getDistanceToSewerNumeric() {
    return distanceToSewerNumeric;
  }

  public void setDistanceToSewerNumeric(AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric distanceToSewerNumeric) {
    this.distanceToSewerNumeric = distanceToSewerNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToSewerUnits(AnyOforgResoMetadataPropertyCreateDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
    return this;
  }

  /**
   * Get distanceToSewerUnits
   * @return distanceToSewerUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToSewerUnits getDistanceToSewerUnits() {
    return distanceToSewerUnits;
  }

  public void setDistanceToSewerUnits(AnyOforgResoMetadataPropertyCreateDistanceToSewerUnits distanceToSewerUnits) {
    this.distanceToSewerUnits = distanceToSewerUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
    return this;
  }

  /**
   * Get distanceToShoppingComments
   * @return distanceToShoppingComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToShoppingComments() {
    return distanceToShoppingComments;
  }

  public void setDistanceToShoppingComments(String distanceToShoppingComments) {
    this.distanceToShoppingComments = distanceToShoppingComments;
  }

  public OrgResoMetadataPropertyCreate distanceToShoppingNumeric(AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
    return this;
  }

  /**
   * Get distanceToShoppingNumeric
   * @return distanceToShoppingNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric getDistanceToShoppingNumeric() {
    return distanceToShoppingNumeric;
  }

  public void setDistanceToShoppingNumeric(AnyOforgResoMetadataPropertyCreateDistanceToShoppingNumeric distanceToShoppingNumeric) {
    this.distanceToShoppingNumeric = distanceToShoppingNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToShoppingUnits(AnyOforgResoMetadataPropertyCreateDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
    return this;
  }

  /**
   * Get distanceToShoppingUnits
   * @return distanceToShoppingUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToShoppingUnits getDistanceToShoppingUnits() {
    return distanceToShoppingUnits;
  }

  public void setDistanceToShoppingUnits(AnyOforgResoMetadataPropertyCreateDistanceToShoppingUnits distanceToShoppingUnits) {
    this.distanceToShoppingUnits = distanceToShoppingUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
    return this;
  }

  /**
   * Get distanceToStreetComments
   * @return distanceToStreetComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToStreetComments() {
    return distanceToStreetComments;
  }

  public void setDistanceToStreetComments(String distanceToStreetComments) {
    this.distanceToStreetComments = distanceToStreetComments;
  }

  public OrgResoMetadataPropertyCreate distanceToStreetNumeric(AnyOforgResoMetadataPropertyCreateDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
    return this;
  }

  /**
   * Get distanceToStreetNumeric
   * @return distanceToStreetNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToStreetNumeric getDistanceToStreetNumeric() {
    return distanceToStreetNumeric;
  }

  public void setDistanceToStreetNumeric(AnyOforgResoMetadataPropertyCreateDistanceToStreetNumeric distanceToStreetNumeric) {
    this.distanceToStreetNumeric = distanceToStreetNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToStreetUnits(AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
    return this;
  }

  /**
   * Get distanceToStreetUnits
   * @return distanceToStreetUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits getDistanceToStreetUnits() {
    return distanceToStreetUnits;
  }

  public void setDistanceToStreetUnits(AnyOforgResoMetadataPropertyCreateDistanceToStreetUnits distanceToStreetUnits) {
    this.distanceToStreetUnits = distanceToStreetUnits;
  }

  public OrgResoMetadataPropertyCreate distanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
    return this;
  }

  /**
   * Get distanceToWaterComments
   * @return distanceToWaterComments
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getDistanceToWaterComments() {
    return distanceToWaterComments;
  }

  public void setDistanceToWaterComments(String distanceToWaterComments) {
    this.distanceToWaterComments = distanceToWaterComments;
  }

  public OrgResoMetadataPropertyCreate distanceToWaterNumeric(AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
    return this;
  }

  /**
   * Get distanceToWaterNumeric
   * @return distanceToWaterNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric getDistanceToWaterNumeric() {
    return distanceToWaterNumeric;
  }

  public void setDistanceToWaterNumeric(AnyOforgResoMetadataPropertyCreateDistanceToWaterNumeric distanceToWaterNumeric) {
    this.distanceToWaterNumeric = distanceToWaterNumeric;
  }

  public OrgResoMetadataPropertyCreate distanceToWaterUnits(AnyOforgResoMetadataPropertyCreateDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
    return this;
  }

  /**
   * Get distanceToWaterUnits
   * @return distanceToWaterUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateDistanceToWaterUnits getDistanceToWaterUnits() {
    return distanceToWaterUnits;
  }

  public void setDistanceToWaterUnits(AnyOforgResoMetadataPropertyCreateDistanceToWaterUnits distanceToWaterUnits) {
    this.distanceToWaterUnits = distanceToWaterUnits;
  }

  public OrgResoMetadataPropertyCreate documentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
    return this;
  }

  public OrgResoMetadataPropertyCreate addDocumentsAvailableItem(OrgResoMetadataEnumsDocumentsAvailable documentsAvailableItem) {
    if (this.documentsAvailable == null) {
      this.documentsAvailable = new ArrayList<OrgResoMetadataEnumsDocumentsAvailable>();
    }
    this.documentsAvailable.add(documentsAvailableItem);
    return this;
  }

  /**
   * Get documentsAvailable
   * @return documentsAvailable
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDocumentsAvailable> getDocumentsAvailable() {
    return documentsAvailable;
  }

  public void setDocumentsAvailable(List<OrgResoMetadataEnumsDocumentsAvailable> documentsAvailable) {
    this.documentsAvailable = documentsAvailable;
  }

  public OrgResoMetadataPropertyCreate documentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
    return this;
  }

  /**
   * Get documentsChangeTimestamp
   * @return documentsChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getDocumentsChangeTimestamp() {
    return documentsChangeTimestamp;
  }

  public void setDocumentsChangeTimestamp(OffsetDateTime documentsChangeTimestamp) {
    this.documentsChangeTimestamp = documentsChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate documentsCount(AnyOforgResoMetadataPropertyCreateDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
    return this;
  }

  /**
   * Get documentsCount
   * @return documentsCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateDocumentsCount getDocumentsCount() {
    return documentsCount;
  }

  public void setDocumentsCount(AnyOforgResoMetadataPropertyCreateDocumentsCount documentsCount) {
    this.documentsCount = documentsCount;
  }

  public OrgResoMetadataPropertyCreate doorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addDoorFeaturesItem(OrgResoMetadataEnumsDoorFeatures doorFeaturesItem) {
    if (this.doorFeatures == null) {
      this.doorFeatures = new ArrayList<OrgResoMetadataEnumsDoorFeatures>();
    }
    this.doorFeatures.add(doorFeaturesItem);
    return this;
  }

  /**
   * Get doorFeatures
   * @return doorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsDoorFeatures> getDoorFeatures() {
    return doorFeatures;
  }

  public void setDoorFeatures(List<OrgResoMetadataEnumsDoorFeatures> doorFeatures) {
    this.doorFeatures = doorFeatures;
  }

  public OrgResoMetadataPropertyCreate dualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
    return this;
  }

  /**
   * Get dualVariableCompensationYN
   * @return dualVariableCompensationYN
   **/
  @Schema(description = "")
  
    public Boolean isDualVariableCompensationYN() {
    return dualVariableCompensationYN;
  }

  public void setDualVariableCompensationYN(Boolean dualVariableCompensationYN) {
    this.dualVariableCompensationYN = dualVariableCompensationYN;
  }

  public OrgResoMetadataPropertyCreate electric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
    return this;
  }

  public OrgResoMetadataPropertyCreate addElectricItem(OrgResoMetadataEnumsElectric electricItem) {
    if (this.electric == null) {
      this.electric = new ArrayList<OrgResoMetadataEnumsElectric>();
    }
    this.electric.add(electricItem);
    return this;
  }

  /**
   * Get electric
   * @return electric
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsElectric> getElectric() {
    return electric;
  }

  public void setElectric(List<OrgResoMetadataEnumsElectric> electric) {
    this.electric = electric;
  }

  public OrgResoMetadataPropertyCreate electricExpense(AnyOforgResoMetadataPropertyCreateElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
    return this;
  }

  /**
   * Get electricExpense
   * @return electricExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateElectricExpense getElectricExpense() {
    return electricExpense;
  }

  public void setElectricExpense(AnyOforgResoMetadataPropertyCreateElectricExpense electricExpense) {
    this.electricExpense = electricExpense;
  }

  public OrgResoMetadataPropertyCreate electricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
    return this;
  }

  /**
   * Get electricOnPropertyYN
   * @return electricOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isElectricOnPropertyYN() {
    return electricOnPropertyYN;
  }

  public void setElectricOnPropertyYN(Boolean electricOnPropertyYN) {
    this.electricOnPropertyYN = electricOnPropertyYN;
  }

  public OrgResoMetadataPropertyCreate elementarySchool(AnyOforgResoMetadataPropertyCreateElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
    return this;
  }

  /**
   * Get elementarySchool
   * @return elementarySchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateElementarySchool getElementarySchool() {
    return elementarySchool;
  }

  public void setElementarySchool(AnyOforgResoMetadataPropertyCreateElementarySchool elementarySchool) {
    this.elementarySchool = elementarySchool;
  }

  public OrgResoMetadataPropertyCreate elementarySchoolDistrict(AnyOforgResoMetadataPropertyCreateElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
    return this;
  }

  /**
   * Get elementarySchoolDistrict
   * @return elementarySchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateElementarySchoolDistrict getElementarySchoolDistrict() {
    return elementarySchoolDistrict;
  }

  public void setElementarySchoolDistrict(AnyOforgResoMetadataPropertyCreateElementarySchoolDistrict elementarySchoolDistrict) {
    this.elementarySchoolDistrict = elementarySchoolDistrict;
  }

  public OrgResoMetadataPropertyCreate elevation(AnyOforgResoMetadataPropertyCreateElevation elevation) {
    this.elevation = elevation;
    return this;
  }

  /**
   * Get elevation
   * @return elevation
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateElevation getElevation() {
    return elevation;
  }

  public void setElevation(AnyOforgResoMetadataPropertyCreateElevation elevation) {
    this.elevation = elevation;
  }

  public OrgResoMetadataPropertyCreate elevationUnits(AnyOforgResoMetadataPropertyCreateElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
    return this;
  }

  /**
   * Get elevationUnits
   * @return elevationUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateElevationUnits getElevationUnits() {
    return elevationUnits;
  }

  public void setElevationUnits(AnyOforgResoMetadataPropertyCreateElevationUnits elevationUnits) {
    this.elevationUnits = elevationUnits;
  }

  public OrgResoMetadataPropertyCreate entryLevel(AnyOforgResoMetadataPropertyCreateEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
    return this;
  }

  /**
   * Get entryLevel
   * @return entryLevel
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateEntryLevel getEntryLevel() {
    return entryLevel;
  }

  public void setEntryLevel(AnyOforgResoMetadataPropertyCreateEntryLevel entryLevel) {
    this.entryLevel = entryLevel;
  }

  public OrgResoMetadataPropertyCreate entryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
    return this;
  }

  /**
   * Get entryLocation
   * @return entryLocation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getEntryLocation() {
    return entryLocation;
  }

  public void setEntryLocation(String entryLocation) {
    this.entryLocation = entryLocation;
  }

  public OrgResoMetadataPropertyCreate exclusions(String exclusions) {
    this.exclusions = exclusions;
    return this;
  }

  /**
   * Get exclusions
   * @return exclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getExclusions() {
    return exclusions;
  }

  public void setExclusions(String exclusions) {
    this.exclusions = exclusions;
  }

  public OrgResoMetadataPropertyCreate existingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addExistingLeaseTypeItem(OrgResoMetadataEnumsExistingLeaseType existingLeaseTypeItem) {
    if (this.existingLeaseType == null) {
      this.existingLeaseType = new ArrayList<OrgResoMetadataEnumsExistingLeaseType>();
    }
    this.existingLeaseType.add(existingLeaseTypeItem);
    return this;
  }

  /**
   * Get existingLeaseType
   * @return existingLeaseType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExistingLeaseType> getExistingLeaseType() {
    return existingLeaseType;
  }

  public void setExistingLeaseType(List<OrgResoMetadataEnumsExistingLeaseType> existingLeaseType) {
    this.existingLeaseType = existingLeaseType;
  }

  public OrgResoMetadataPropertyCreate expirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
    return this;
  }

  /**
   * Get expirationDate
   * @return expirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(LocalDate expirationDate) {
    this.expirationDate = expirationDate;
  }

  public OrgResoMetadataPropertyCreate exteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addExteriorFeaturesItem(OrgResoMetadataEnumsExteriorFeatures exteriorFeaturesItem) {
    if (this.exteriorFeatures == null) {
      this.exteriorFeatures = new ArrayList<OrgResoMetadataEnumsExteriorFeatures>();
    }
    this.exteriorFeatures.add(exteriorFeaturesItem);
    return this;
  }

  /**
   * Get exteriorFeatures
   * @return exteriorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsExteriorFeatures> getExteriorFeatures() {
    return exteriorFeatures;
  }

  public void setExteriorFeatures(List<OrgResoMetadataEnumsExteriorFeatures> exteriorFeatures) {
    this.exteriorFeatures = exteriorFeatures;
  }

  public OrgResoMetadataPropertyCreate farmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
    return this;
  }

  /**
   * Get farmCreditServiceInclYN
   * @return farmCreditServiceInclYN
   **/
  @Schema(description = "")
  
    public Boolean isFarmCreditServiceInclYN() {
    return farmCreditServiceInclYN;
  }

  public void setFarmCreditServiceInclYN(Boolean farmCreditServiceInclYN) {
    this.farmCreditServiceInclYN = farmCreditServiceInclYN;
  }

  public OrgResoMetadataPropertyCreate farmLandAreaSource(AnyOforgResoMetadataPropertyCreateFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
    return this;
  }

  /**
   * Get farmLandAreaSource
   * @return farmLandAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateFarmLandAreaSource getFarmLandAreaSource() {
    return farmLandAreaSource;
  }

  public void setFarmLandAreaSource(AnyOforgResoMetadataPropertyCreateFarmLandAreaSource farmLandAreaSource) {
    this.farmLandAreaSource = farmLandAreaSource;
  }

  public OrgResoMetadataPropertyCreate farmLandAreaUnits(AnyOforgResoMetadataPropertyCreateFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
    return this;
  }

  /**
   * Get farmLandAreaUnits
   * @return farmLandAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateFarmLandAreaUnits getFarmLandAreaUnits() {
    return farmLandAreaUnits;
  }

  public void setFarmLandAreaUnits(AnyOforgResoMetadataPropertyCreateFarmLandAreaUnits farmLandAreaUnits) {
    this.farmLandAreaUnits = farmLandAreaUnits;
  }

  public OrgResoMetadataPropertyCreate fencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFencingItem(OrgResoMetadataEnumsFencing fencingItem) {
    if (this.fencing == null) {
      this.fencing = new ArrayList<OrgResoMetadataEnumsFencing>();
    }
    this.fencing.add(fencingItem);
    return this;
  }

  /**
   * Get fencing
   * @return fencing
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFencing> getFencing() {
    return fencing;
  }

  public void setFencing(List<OrgResoMetadataEnumsFencing> fencing) {
    this.fencing = fencing;
  }

  public OrgResoMetadataPropertyCreate financialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFinancialDataSourceItem(OrgResoMetadataEnumsFinancialDataSource financialDataSourceItem) {
    if (this.financialDataSource == null) {
      this.financialDataSource = new ArrayList<OrgResoMetadataEnumsFinancialDataSource>();
    }
    this.financialDataSource.add(financialDataSourceItem);
    return this;
  }

  /**
   * Get financialDataSource
   * @return financialDataSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFinancialDataSource> getFinancialDataSource() {
    return financialDataSource;
  }

  public void setFinancialDataSource(List<OrgResoMetadataEnumsFinancialDataSource> financialDataSource) {
    this.financialDataSource = financialDataSource;
  }

  public OrgResoMetadataPropertyCreate fireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFireplaceFeaturesItem(OrgResoMetadataEnumsFireplaceFeatures fireplaceFeaturesItem) {
    if (this.fireplaceFeatures == null) {
      this.fireplaceFeatures = new ArrayList<OrgResoMetadataEnumsFireplaceFeatures>();
    }
    this.fireplaceFeatures.add(fireplaceFeaturesItem);
    return this;
  }

  /**
   * Get fireplaceFeatures
   * @return fireplaceFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFireplaceFeatures> getFireplaceFeatures() {
    return fireplaceFeatures;
  }

  public void setFireplaceFeatures(List<OrgResoMetadataEnumsFireplaceFeatures> fireplaceFeatures) {
    this.fireplaceFeatures = fireplaceFeatures;
  }

  public OrgResoMetadataPropertyCreate fireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
    return this;
  }

  /**
   * Get fireplaceYN
   * @return fireplaceYN
   **/
  @Schema(description = "")
  
    public Boolean isFireplaceYN() {
    return fireplaceYN;
  }

  public void setFireplaceYN(Boolean fireplaceYN) {
    this.fireplaceYN = fireplaceYN;
  }

  public OrgResoMetadataPropertyCreate fireplacesTotal(AnyOforgResoMetadataPropertyCreateFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
    return this;
  }

  /**
   * Get fireplacesTotal
   * @return fireplacesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateFireplacesTotal getFireplacesTotal() {
    return fireplacesTotal;
  }

  public void setFireplacesTotal(AnyOforgResoMetadataPropertyCreateFireplacesTotal fireplacesTotal) {
    this.fireplacesTotal = fireplacesTotal;
  }

  public OrgResoMetadataPropertyCreate flooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFlooringItem(OrgResoMetadataEnumsFlooring flooringItem) {
    if (this.flooring == null) {
      this.flooring = new ArrayList<OrgResoMetadataEnumsFlooring>();
    }
    this.flooring.add(flooringItem);
    return this;
  }

  /**
   * Get flooring
   * @return flooring
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFlooring> getFlooring() {
    return flooring;
  }

  public void setFlooring(List<OrgResoMetadataEnumsFlooring> flooring) {
    this.flooring = flooring;
  }

  public OrgResoMetadataPropertyCreate foundationArea(AnyOforgResoMetadataPropertyCreateFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
    return this;
  }

  /**
   * Get foundationArea
   * @return foundationArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateFoundationArea getFoundationArea() {
    return foundationArea;
  }

  public void setFoundationArea(AnyOforgResoMetadataPropertyCreateFoundationArea foundationArea) {
    this.foundationArea = foundationArea;
  }

  public OrgResoMetadataPropertyCreate foundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFoundationDetailsItem(OrgResoMetadataEnumsFoundationDetails foundationDetailsItem) {
    if (this.foundationDetails == null) {
      this.foundationDetails = new ArrayList<OrgResoMetadataEnumsFoundationDetails>();
    }
    this.foundationDetails.add(foundationDetailsItem);
    return this;
  }

  /**
   * Get foundationDetails
   * @return foundationDetails
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFoundationDetails> getFoundationDetails() {
    return foundationDetails;
  }

  public void setFoundationDetails(List<OrgResoMetadataEnumsFoundationDetails> foundationDetails) {
    this.foundationDetails = foundationDetails;
  }

  public OrgResoMetadataPropertyCreate frontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
    return this;
  }

  /**
   * Get frontageLength
   * @return frontageLength
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getFrontageLength() {
    return frontageLength;
  }

  public void setFrontageLength(String frontageLength) {
    this.frontageLength = frontageLength;
  }

  public OrgResoMetadataPropertyCreate frontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addFrontageTypeItem(OrgResoMetadataEnumsFrontageType frontageTypeItem) {
    if (this.frontageType == null) {
      this.frontageType = new ArrayList<OrgResoMetadataEnumsFrontageType>();
    }
    this.frontageType.add(frontageTypeItem);
    return this;
  }

  /**
   * Get frontageType
   * @return frontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsFrontageType> getFrontageType() {
    return frontageType;
  }

  public void setFrontageType(List<OrgResoMetadataEnumsFrontageType> frontageType) {
    this.frontageType = frontageType;
  }

  public OrgResoMetadataPropertyCreate fuelExpense(AnyOforgResoMetadataPropertyCreateFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
    return this;
  }

  /**
   * Get fuelExpense
   * @return fuelExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateFuelExpense getFuelExpense() {
    return fuelExpense;
  }

  public void setFuelExpense(AnyOforgResoMetadataPropertyCreateFuelExpense fuelExpense) {
    this.fuelExpense = fuelExpense;
  }

  public OrgResoMetadataPropertyCreate furnished(AnyOforgResoMetadataPropertyCreateFurnished furnished) {
    this.furnished = furnished;
    return this;
  }

  /**
   * Get furnished
   * @return furnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateFurnished getFurnished() {
    return furnished;
  }

  public void setFurnished(AnyOforgResoMetadataPropertyCreateFurnished furnished) {
    this.furnished = furnished;
  }

  public OrgResoMetadataPropertyCreate furnitureReplacementExpense(AnyOforgResoMetadataPropertyCreateFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
    return this;
  }

  /**
   * Get furnitureReplacementExpense
   * @return furnitureReplacementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateFurnitureReplacementExpense getFurnitureReplacementExpense() {
    return furnitureReplacementExpense;
  }

  public void setFurnitureReplacementExpense(AnyOforgResoMetadataPropertyCreateFurnitureReplacementExpense furnitureReplacementExpense) {
    this.furnitureReplacementExpense = furnitureReplacementExpense;
  }

  public OrgResoMetadataPropertyCreate garageSpaces(AnyOforgResoMetadataPropertyCreateGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
    return this;
  }

  /**
   * Get garageSpaces
   * @return garageSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateGarageSpaces getGarageSpaces() {
    return garageSpaces;
  }

  public void setGarageSpaces(AnyOforgResoMetadataPropertyCreateGarageSpaces garageSpaces) {
    this.garageSpaces = garageSpaces;
  }

  public OrgResoMetadataPropertyCreate garageYN(Boolean garageYN) {
    this.garageYN = garageYN;
    return this;
  }

  /**
   * Get garageYN
   * @return garageYN
   **/
  @Schema(description = "")
  
    public Boolean isGarageYN() {
    return garageYN;
  }

  public void setGarageYN(Boolean garageYN) {
    this.garageYN = garageYN;
  }

  public OrgResoMetadataPropertyCreate gardenerExpense(AnyOforgResoMetadataPropertyCreateGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
    return this;
  }

  /**
   * Get gardenerExpense
   * @return gardenerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateGardenerExpense getGardenerExpense() {
    return gardenerExpense;
  }

  public void setGardenerExpense(AnyOforgResoMetadataPropertyCreateGardenerExpense gardenerExpense) {
    this.gardenerExpense = gardenerExpense;
  }

  public OrgResoMetadataPropertyCreate grazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
    return this;
  }

  /**
   * Get grazingPermitsBlmYN
   * @return grazingPermitsBlmYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsBlmYN() {
    return grazingPermitsBlmYN;
  }

  public void setGrazingPermitsBlmYN(Boolean grazingPermitsBlmYN) {
    this.grazingPermitsBlmYN = grazingPermitsBlmYN;
  }

  public OrgResoMetadataPropertyCreate grazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
    return this;
  }

  /**
   * Get grazingPermitsForestServiceYN
   * @return grazingPermitsForestServiceYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsForestServiceYN() {
    return grazingPermitsForestServiceYN;
  }

  public void setGrazingPermitsForestServiceYN(Boolean grazingPermitsForestServiceYN) {
    this.grazingPermitsForestServiceYN = grazingPermitsForestServiceYN;
  }

  public OrgResoMetadataPropertyCreate grazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
    return this;
  }

  /**
   * Get grazingPermitsPrivateYN
   * @return grazingPermitsPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isGrazingPermitsPrivateYN() {
    return grazingPermitsPrivateYN;
  }

  public void setGrazingPermitsPrivateYN(Boolean grazingPermitsPrivateYN) {
    this.grazingPermitsPrivateYN = grazingPermitsPrivateYN;
  }

  public OrgResoMetadataPropertyCreate greenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenBuildingVerificationTypeItem(OrgResoMetadataEnumsGreenBuildingVerificationType greenBuildingVerificationTypeItem) {
    if (this.greenBuildingVerificationType == null) {
      this.greenBuildingVerificationType = new ArrayList<OrgResoMetadataEnumsGreenBuildingVerificationType>();
    }
    this.greenBuildingVerificationType.add(greenBuildingVerificationTypeItem);
    return this;
  }

  /**
   * Get greenBuildingVerificationType
   * @return greenBuildingVerificationType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenBuildingVerificationType> getGreenBuildingVerificationType() {
    return greenBuildingVerificationType;
  }

  public void setGreenBuildingVerificationType(List<OrgResoMetadataEnumsGreenBuildingVerificationType> greenBuildingVerificationType) {
    this.greenBuildingVerificationType = greenBuildingVerificationType;
  }

  public OrgResoMetadataPropertyCreate greenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenEnergyEfficientItem(OrgResoMetadataEnumsGreenEnergyEfficient greenEnergyEfficientItem) {
    if (this.greenEnergyEfficient == null) {
      this.greenEnergyEfficient = new ArrayList<OrgResoMetadataEnumsGreenEnergyEfficient>();
    }
    this.greenEnergyEfficient.add(greenEnergyEfficientItem);
    return this;
  }

  /**
   * Get greenEnergyEfficient
   * @return greenEnergyEfficient
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyEfficient> getGreenEnergyEfficient() {
    return greenEnergyEfficient;
  }

  public void setGreenEnergyEfficient(List<OrgResoMetadataEnumsGreenEnergyEfficient> greenEnergyEfficient) {
    this.greenEnergyEfficient = greenEnergyEfficient;
  }

  public OrgResoMetadataPropertyCreate greenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenEnergyGenerationItem(OrgResoMetadataEnumsGreenEnergyGeneration greenEnergyGenerationItem) {
    if (this.greenEnergyGeneration == null) {
      this.greenEnergyGeneration = new ArrayList<OrgResoMetadataEnumsGreenEnergyGeneration>();
    }
    this.greenEnergyGeneration.add(greenEnergyGenerationItem);
    return this;
  }

  /**
   * Get greenEnergyGeneration
   * @return greenEnergyGeneration
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenEnergyGeneration> getGreenEnergyGeneration() {
    return greenEnergyGeneration;
  }

  public void setGreenEnergyGeneration(List<OrgResoMetadataEnumsGreenEnergyGeneration> greenEnergyGeneration) {
    this.greenEnergyGeneration = greenEnergyGeneration;
  }

  public OrgResoMetadataPropertyCreate greenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenIndoorAirQualityItem(OrgResoMetadataEnumsGreenIndoorAirQuality greenIndoorAirQualityItem) {
    if (this.greenIndoorAirQuality == null) {
      this.greenIndoorAirQuality = new ArrayList<OrgResoMetadataEnumsGreenIndoorAirQuality>();
    }
    this.greenIndoorAirQuality.add(greenIndoorAirQualityItem);
    return this;
  }

  /**
   * Get greenIndoorAirQuality
   * @return greenIndoorAirQuality
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenIndoorAirQuality> getGreenIndoorAirQuality() {
    return greenIndoorAirQuality;
  }

  public void setGreenIndoorAirQuality(List<OrgResoMetadataEnumsGreenIndoorAirQuality> greenIndoorAirQuality) {
    this.greenIndoorAirQuality = greenIndoorAirQuality;
  }

  public OrgResoMetadataPropertyCreate greenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenLocationItem(OrgResoMetadataEnumsGreenLocation greenLocationItem) {
    if (this.greenLocation == null) {
      this.greenLocation = new ArrayList<OrgResoMetadataEnumsGreenLocation>();
    }
    this.greenLocation.add(greenLocationItem);
    return this;
  }

  /**
   * Get greenLocation
   * @return greenLocation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenLocation> getGreenLocation() {
    return greenLocation;
  }

  public void setGreenLocation(List<OrgResoMetadataEnumsGreenLocation> greenLocation) {
    this.greenLocation = greenLocation;
  }

  public OrgResoMetadataPropertyCreate greenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenSustainabilityItem(OrgResoMetadataEnumsGreenSustainability greenSustainabilityItem) {
    if (this.greenSustainability == null) {
      this.greenSustainability = new ArrayList<OrgResoMetadataEnumsGreenSustainability>();
    }
    this.greenSustainability.add(greenSustainabilityItem);
    return this;
  }

  /**
   * Get greenSustainability
   * @return greenSustainability
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenSustainability> getGreenSustainability() {
    return greenSustainability;
  }

  public void setGreenSustainability(List<OrgResoMetadataEnumsGreenSustainability> greenSustainability) {
    this.greenSustainability = greenSustainability;
  }

  public OrgResoMetadataPropertyCreate greenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addGreenWaterConservationItem(OrgResoMetadataEnumsGreenWaterConservation greenWaterConservationItem) {
    if (this.greenWaterConservation == null) {
      this.greenWaterConservation = new ArrayList<OrgResoMetadataEnumsGreenWaterConservation>();
    }
    this.greenWaterConservation.add(greenWaterConservationItem);
    return this;
  }

  /**
   * Get greenWaterConservation
   * @return greenWaterConservation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsGreenWaterConservation> getGreenWaterConservation() {
    return greenWaterConservation;
  }

  public void setGreenWaterConservation(List<OrgResoMetadataEnumsGreenWaterConservation> greenWaterConservation) {
    this.greenWaterConservation = greenWaterConservation;
  }

  public OrgResoMetadataPropertyCreate grossIncome(AnyOforgResoMetadataPropertyCreateGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
    return this;
  }

  /**
   * Get grossIncome
   * @return grossIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateGrossIncome getGrossIncome() {
    return grossIncome;
  }

  public void setGrossIncome(AnyOforgResoMetadataPropertyCreateGrossIncome grossIncome) {
    this.grossIncome = grossIncome;
  }

  public OrgResoMetadataPropertyCreate grossScheduledIncome(AnyOforgResoMetadataPropertyCreateGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
    return this;
  }

  /**
   * Get grossScheduledIncome
   * @return grossScheduledIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateGrossScheduledIncome getGrossScheduledIncome() {
    return grossScheduledIncome;
  }

  public void setGrossScheduledIncome(AnyOforgResoMetadataPropertyCreateGrossScheduledIncome grossScheduledIncome) {
    this.grossScheduledIncome = grossScheduledIncome;
  }

  public OrgResoMetadataPropertyCreate habitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
    return this;
  }

  /**
   * Get habitableResidenceYN
   * @return habitableResidenceYN
   **/
  @Schema(description = "")
  
    public Boolean isHabitableResidenceYN() {
    return habitableResidenceYN;
  }

  public void setHabitableResidenceYN(Boolean habitableResidenceYN) {
    this.habitableResidenceYN = habitableResidenceYN;
  }

  public OrgResoMetadataPropertyCreate heating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
    return this;
  }

  public OrgResoMetadataPropertyCreate addHeatingItem(OrgResoMetadataEnumsHeating heatingItem) {
    if (this.heating == null) {
      this.heating = new ArrayList<OrgResoMetadataEnumsHeating>();
    }
    this.heating.add(heatingItem);
    return this;
  }

  /**
   * Get heating
   * @return heating
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHeating> getHeating() {
    return heating;
  }

  public void setHeating(List<OrgResoMetadataEnumsHeating> heating) {
    this.heating = heating;
  }

  public OrgResoMetadataPropertyCreate heatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
    return this;
  }

  /**
   * Get heatingYN
   * @return heatingYN
   **/
  @Schema(description = "")
  
    public Boolean isHeatingYN() {
    return heatingYN;
  }

  public void setHeatingYN(Boolean heatingYN) {
    this.heatingYN = heatingYN;
  }

  public OrgResoMetadataPropertyCreate highSchool(AnyOforgResoMetadataPropertyCreateHighSchool highSchool) {
    this.highSchool = highSchool;
    return this;
  }

  /**
   * Get highSchool
   * @return highSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateHighSchool getHighSchool() {
    return highSchool;
  }

  public void setHighSchool(AnyOforgResoMetadataPropertyCreateHighSchool highSchool) {
    this.highSchool = highSchool;
  }

  public OrgResoMetadataPropertyCreate highSchoolDistrict(AnyOforgResoMetadataPropertyCreateHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
    return this;
  }

  /**
   * Get highSchoolDistrict
   * @return highSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateHighSchoolDistrict getHighSchoolDistrict() {
    return highSchoolDistrict;
  }

  public void setHighSchoolDistrict(AnyOforgResoMetadataPropertyCreateHighSchoolDistrict highSchoolDistrict) {
    this.highSchoolDistrict = highSchoolDistrict;
  }

  public OrgResoMetadataPropertyCreate homeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
    return this;
  }

  /**
   * Get homeWarrantyYN
   * @return homeWarrantyYN
   **/
  @Schema(description = "")
  
    public Boolean isHomeWarrantyYN() {
    return homeWarrantyYN;
  }

  public void setHomeWarrantyYN(Boolean homeWarrantyYN) {
    this.homeWarrantyYN = homeWarrantyYN;
  }

  public OrgResoMetadataPropertyCreate horseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
    return this;
  }

  public OrgResoMetadataPropertyCreate addHorseAmenitiesItem(OrgResoMetadataEnumsHorseAmenities horseAmenitiesItem) {
    if (this.horseAmenities == null) {
      this.horseAmenities = new ArrayList<OrgResoMetadataEnumsHorseAmenities>();
    }
    this.horseAmenities.add(horseAmenitiesItem);
    return this;
  }

  /**
   * Get horseAmenities
   * @return horseAmenities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHorseAmenities> getHorseAmenities() {
    return horseAmenities;
  }

  public void setHorseAmenities(List<OrgResoMetadataEnumsHorseAmenities> horseAmenities) {
    this.horseAmenities = horseAmenities;
  }

  public OrgResoMetadataPropertyCreate horseYN(Boolean horseYN) {
    this.horseYN = horseYN;
    return this;
  }

  /**
   * Get horseYN
   * @return horseYN
   **/
  @Schema(description = "")
  
    public Boolean isHorseYN() {
    return horseYN;
  }

  public void setHorseYN(Boolean horseYN) {
    this.horseYN = horseYN;
  }

  public OrgResoMetadataPropertyCreate hoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addHoursDaysOfOperationItem(OrgResoMetadataEnumsHoursDaysOfOperation hoursDaysOfOperationItem) {
    if (this.hoursDaysOfOperation == null) {
      this.hoursDaysOfOperation = new ArrayList<OrgResoMetadataEnumsHoursDaysOfOperation>();
    }
    this.hoursDaysOfOperation.add(hoursDaysOfOperationItem);
    return this;
  }

  /**
   * Get hoursDaysOfOperation
   * @return hoursDaysOfOperation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsHoursDaysOfOperation> getHoursDaysOfOperation() {
    return hoursDaysOfOperation;
  }

  public void setHoursDaysOfOperation(List<OrgResoMetadataEnumsHoursDaysOfOperation> hoursDaysOfOperation) {
    this.hoursDaysOfOperation = hoursDaysOfOperation;
  }

  public OrgResoMetadataPropertyCreate hoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
    return this;
  }

  /**
   * Get hoursDaysOfOperationDescription
   * @return hoursDaysOfOperationDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getHoursDaysOfOperationDescription() {
    return hoursDaysOfOperationDescription;
  }

  public void setHoursDaysOfOperationDescription(String hoursDaysOfOperationDescription) {
    this.hoursDaysOfOperationDescription = hoursDaysOfOperationDescription;
  }

  public OrgResoMetadataPropertyCreate inclusions(String inclusions) {
    this.inclusions = inclusions;
    return this;
  }

  /**
   * Get inclusions
   * @return inclusions
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getInclusions() {
    return inclusions;
  }

  public void setInclusions(String inclusions) {
    this.inclusions = inclusions;
  }

  public OrgResoMetadataPropertyCreate incomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
    return this;
  }

  public OrgResoMetadataPropertyCreate addIncomeIncludesItem(OrgResoMetadataEnumsIncomeIncludes incomeIncludesItem) {
    if (this.incomeIncludes == null) {
      this.incomeIncludes = new ArrayList<OrgResoMetadataEnumsIncomeIncludes>();
    }
    this.incomeIncludes.add(incomeIncludesItem);
    return this;
  }

  /**
   * Get incomeIncludes
   * @return incomeIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIncomeIncludes> getIncomeIncludes() {
    return incomeIncludes;
  }

  public void setIncomeIncludes(List<OrgResoMetadataEnumsIncomeIncludes> incomeIncludes) {
    this.incomeIncludes = incomeIncludes;
  }

  public OrgResoMetadataPropertyCreate insuranceExpense(AnyOforgResoMetadataPropertyCreateInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
    return this;
  }

  /**
   * Get insuranceExpense
   * @return insuranceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateInsuranceExpense getInsuranceExpense() {
    return insuranceExpense;
  }

  public void setInsuranceExpense(AnyOforgResoMetadataPropertyCreateInsuranceExpense insuranceExpense) {
    this.insuranceExpense = insuranceExpense;
  }

  public OrgResoMetadataPropertyCreate interiorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addInteriorFeaturesItem(OrgResoMetadataEnumsInteriorOrRoomFeatures interiorFeaturesItem) {
    if (this.interiorFeatures == null) {
      this.interiorFeatures = new ArrayList<OrgResoMetadataEnumsInteriorOrRoomFeatures>();
    }
    this.interiorFeatures.add(interiorFeaturesItem);
    return this;
  }

  /**
   * Get interiorFeatures
   * @return interiorFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsInteriorOrRoomFeatures> getInteriorFeatures() {
    return interiorFeatures;
  }

  public void setInteriorFeatures(List<OrgResoMetadataEnumsInteriorOrRoomFeatures> interiorFeatures) {
    this.interiorFeatures = interiorFeatures;
  }

  public OrgResoMetadataPropertyCreate internetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
    return this;
  }

  /**
   * Get internetAddressDisplayYN
   * @return internetAddressDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAddressDisplayYN() {
    return internetAddressDisplayYN;
  }

  public void setInternetAddressDisplayYN(Boolean internetAddressDisplayYN) {
    this.internetAddressDisplayYN = internetAddressDisplayYN;
  }

  public OrgResoMetadataPropertyCreate internetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
    return this;
  }

  /**
   * Get internetAutomatedValuationDisplayYN
   * @return internetAutomatedValuationDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetAutomatedValuationDisplayYN() {
    return internetAutomatedValuationDisplayYN;
  }

  public void setInternetAutomatedValuationDisplayYN(Boolean internetAutomatedValuationDisplayYN) {
    this.internetAutomatedValuationDisplayYN = internetAutomatedValuationDisplayYN;
  }

  public OrgResoMetadataPropertyCreate internetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
    return this;
  }

  /**
   * Get internetConsumerCommentYN
   * @return internetConsumerCommentYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetConsumerCommentYN() {
    return internetConsumerCommentYN;
  }

  public void setInternetConsumerCommentYN(Boolean internetConsumerCommentYN) {
    this.internetConsumerCommentYN = internetConsumerCommentYN;
  }

  public OrgResoMetadataPropertyCreate internetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
    return this;
  }

  /**
   * Get internetEntireListingDisplayYN
   * @return internetEntireListingDisplayYN
   **/
  @Schema(description = "")
  
    public Boolean isInternetEntireListingDisplayYN() {
    return internetEntireListingDisplayYN;
  }

  public void setInternetEntireListingDisplayYN(Boolean internetEntireListingDisplayYN) {
    this.internetEntireListingDisplayYN = internetEntireListingDisplayYN;
  }

  public OrgResoMetadataPropertyCreate irrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
    return this;
  }

  public OrgResoMetadataPropertyCreate addIrrigationSourceItem(OrgResoMetadataEnumsIrrigationSource irrigationSourceItem) {
    if (this.irrigationSource == null) {
      this.irrigationSource = new ArrayList<OrgResoMetadataEnumsIrrigationSource>();
    }
    this.irrigationSource.add(irrigationSourceItem);
    return this;
  }

  /**
   * Get irrigationSource
   * @return irrigationSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsIrrigationSource> getIrrigationSource() {
    return irrigationSource;
  }

  public void setIrrigationSource(List<OrgResoMetadataEnumsIrrigationSource> irrigationSource) {
    this.irrigationSource = irrigationSource;
  }

  public OrgResoMetadataPropertyCreate irrigationWaterRightsAcres(AnyOforgResoMetadataPropertyCreateIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
    return this;
  }

  /**
   * Get irrigationWaterRightsAcres
   * @return irrigationWaterRightsAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateIrrigationWaterRightsAcres getIrrigationWaterRightsAcres() {
    return irrigationWaterRightsAcres;
  }

  public void setIrrigationWaterRightsAcres(AnyOforgResoMetadataPropertyCreateIrrigationWaterRightsAcres irrigationWaterRightsAcres) {
    this.irrigationWaterRightsAcres = irrigationWaterRightsAcres;
  }

  public OrgResoMetadataPropertyCreate irrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
    return this;
  }

  /**
   * Get irrigationWaterRightsYN
   * @return irrigationWaterRightsYN
   **/
  @Schema(description = "")
  
    public Boolean isIrrigationWaterRightsYN() {
    return irrigationWaterRightsYN;
  }

  public void setIrrigationWaterRightsYN(Boolean irrigationWaterRightsYN) {
    this.irrigationWaterRightsYN = irrigationWaterRightsYN;
  }

  public OrgResoMetadataPropertyCreate laborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLaborInformationItem(OrgResoMetadataEnumsLaborInformation laborInformationItem) {
    if (this.laborInformation == null) {
      this.laborInformation = new ArrayList<OrgResoMetadataEnumsLaborInformation>();
    }
    this.laborInformation.add(laborInformationItem);
    return this;
  }

  /**
   * Get laborInformation
   * @return laborInformation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaborInformation> getLaborInformation() {
    return laborInformation;
  }

  public void setLaborInformation(List<OrgResoMetadataEnumsLaborInformation> laborInformation) {
    this.laborInformation = laborInformation;
  }

  public OrgResoMetadataPropertyCreate landLeaseAmount(AnyOforgResoMetadataPropertyCreateLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
    return this;
  }

  /**
   * Get landLeaseAmount
   * @return landLeaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLandLeaseAmount getLandLeaseAmount() {
    return landLeaseAmount;
  }

  public void setLandLeaseAmount(AnyOforgResoMetadataPropertyCreateLandLeaseAmount landLeaseAmount) {
    this.landLeaseAmount = landLeaseAmount;
  }

  public OrgResoMetadataPropertyCreate landLeaseAmountFrequency(AnyOforgResoMetadataPropertyCreateLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
    return this;
  }

  /**
   * Get landLeaseAmountFrequency
   * @return landLeaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLandLeaseAmountFrequency getLandLeaseAmountFrequency() {
    return landLeaseAmountFrequency;
  }

  public void setLandLeaseAmountFrequency(AnyOforgResoMetadataPropertyCreateLandLeaseAmountFrequency landLeaseAmountFrequency) {
    this.landLeaseAmountFrequency = landLeaseAmountFrequency;
  }

  public OrgResoMetadataPropertyCreate landLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
    return this;
  }

  /**
   * Get landLeaseExpirationDate
   * @return landLeaseExpirationDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLandLeaseExpirationDate() {
    return landLeaseExpirationDate;
  }

  public void setLandLeaseExpirationDate(LocalDate landLeaseExpirationDate) {
    this.landLeaseExpirationDate = landLeaseExpirationDate;
  }

  public OrgResoMetadataPropertyCreate landLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
    return this;
  }

  /**
   * Get landLeaseYN
   * @return landLeaseYN
   **/
  @Schema(description = "")
  
    public Boolean isLandLeaseYN() {
    return landLeaseYN;
  }

  public void setLandLeaseYN(Boolean landLeaseYN) {
    this.landLeaseYN = landLeaseYN;
  }

  public OrgResoMetadataPropertyCreate latitude(AnyOforgResoMetadataPropertyCreateLatitude latitude) {
    this.latitude = latitude;
    return this;
  }

  /**
   * Get latitude
   * @return latitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLatitude getLatitude() {
    return latitude;
  }

  public void setLatitude(AnyOforgResoMetadataPropertyCreateLatitude latitude) {
    this.latitude = latitude;
  }

  public OrgResoMetadataPropertyCreate laundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLaundryFeaturesItem(OrgResoMetadataEnumsLaundryFeatures laundryFeaturesItem) {
    if (this.laundryFeatures == null) {
      this.laundryFeatures = new ArrayList<OrgResoMetadataEnumsLaundryFeatures>();
    }
    this.laundryFeatures.add(laundryFeaturesItem);
    return this;
  }

  /**
   * Get laundryFeatures
   * @return laundryFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLaundryFeatures> getLaundryFeatures() {
    return laundryFeatures;
  }

  public void setLaundryFeatures(List<OrgResoMetadataEnumsLaundryFeatures> laundryFeatures) {
    this.laundryFeatures = laundryFeatures;
  }

  public OrgResoMetadataPropertyCreate leasableArea(AnyOforgResoMetadataPropertyCreateLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
    return this;
  }

  /**
   * Get leasableArea
   * @return leasableArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLeasableArea getLeasableArea() {
    return leasableArea;
  }

  public void setLeasableArea(AnyOforgResoMetadataPropertyCreateLeasableArea leasableArea) {
    this.leasableArea = leasableArea;
  }

  public OrgResoMetadataPropertyCreate leasableAreaUnits(AnyOforgResoMetadataPropertyCreateLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
    return this;
  }

  /**
   * Get leasableAreaUnits
   * @return leasableAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLeasableAreaUnits getLeasableAreaUnits() {
    return leasableAreaUnits;
  }

  public void setLeasableAreaUnits(AnyOforgResoMetadataPropertyCreateLeasableAreaUnits leasableAreaUnits) {
    this.leasableAreaUnits = leasableAreaUnits;
  }

  public OrgResoMetadataPropertyCreate leaseAmount(AnyOforgResoMetadataPropertyCreateLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
    return this;
  }

  /**
   * Get leaseAmount
   * @return leaseAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLeaseAmount getLeaseAmount() {
    return leaseAmount;
  }

  public void setLeaseAmount(AnyOforgResoMetadataPropertyCreateLeaseAmount leaseAmount) {
    this.leaseAmount = leaseAmount;
  }

  public OrgResoMetadataPropertyCreate leaseAmountFrequency(AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
    return this;
  }

  /**
   * Get leaseAmountFrequency
   * @return leaseAmountFrequency
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency getLeaseAmountFrequency() {
    return leaseAmountFrequency;
  }

  public void setLeaseAmountFrequency(AnyOforgResoMetadataPropertyCreateLeaseAmountFrequency leaseAmountFrequency) {
    this.leaseAmountFrequency = leaseAmountFrequency;
  }

  public OrgResoMetadataPropertyCreate leaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
    return this;
  }

  /**
   * Get leaseAssignableYN
   * @return leaseAssignableYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseAssignableYN() {
    return leaseAssignableYN;
  }

  public void setLeaseAssignableYN(Boolean leaseAssignableYN) {
    this.leaseAssignableYN = leaseAssignableYN;
  }

  public OrgResoMetadataPropertyCreate leaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
    return this;
  }

  /**
   * Get leaseConsideredYN
   * @return leaseConsideredYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseConsideredYN() {
    return leaseConsideredYN;
  }

  public void setLeaseConsideredYN(Boolean leaseConsideredYN) {
    this.leaseConsideredYN = leaseConsideredYN;
  }

  public OrgResoMetadataPropertyCreate leaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
    return this;
  }

  /**
   * Get leaseExpiration
   * @return leaseExpiration
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getLeaseExpiration() {
    return leaseExpiration;
  }

  public void setLeaseExpiration(LocalDate leaseExpiration) {
    this.leaseExpiration = leaseExpiration;
  }

  public OrgResoMetadataPropertyCreate leaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLeaseRenewalCompensationItem(OrgResoMetadataEnumsLeaseRenewalCompensation leaseRenewalCompensationItem) {
    if (this.leaseRenewalCompensation == null) {
      this.leaseRenewalCompensation = new ArrayList<OrgResoMetadataEnumsLeaseRenewalCompensation>();
    }
    this.leaseRenewalCompensation.add(leaseRenewalCompensationItem);
    return this;
  }

  /**
   * Get leaseRenewalCompensation
   * @return leaseRenewalCompensation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLeaseRenewalCompensation> getLeaseRenewalCompensation() {
    return leaseRenewalCompensation;
  }

  public void setLeaseRenewalCompensation(List<OrgResoMetadataEnumsLeaseRenewalCompensation> leaseRenewalCompensation) {
    this.leaseRenewalCompensation = leaseRenewalCompensation;
  }

  public OrgResoMetadataPropertyCreate leaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
    return this;
  }

  /**
   * Get leaseRenewalOptionYN
   * @return leaseRenewalOptionYN
   **/
  @Schema(description = "")
  
    public Boolean isLeaseRenewalOptionYN() {
    return leaseRenewalOptionYN;
  }

  public void setLeaseRenewalOptionYN(Boolean leaseRenewalOptionYN) {
    this.leaseRenewalOptionYN = leaseRenewalOptionYN;
  }

  public OrgResoMetadataPropertyCreate leaseTerm(AnyOforgResoMetadataPropertyCreateLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
    return this;
  }

  /**
   * Get leaseTerm
   * @return leaseTerm
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLeaseTerm getLeaseTerm() {
    return leaseTerm;
  }

  public void setLeaseTerm(AnyOforgResoMetadataPropertyCreateLeaseTerm leaseTerm) {
    this.leaseTerm = leaseTerm;
  }

  public OrgResoMetadataPropertyCreate levels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLevelsItem(OrgResoMetadataEnumsLevels levelsItem) {
    if (this.levels == null) {
      this.levels = new ArrayList<OrgResoMetadataEnumsLevels>();
    }
    this.levels.add(levelsItem);
    return this;
  }

  /**
   * Get levels
   * @return levels
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLevels> getLevels() {
    return levels;
  }

  public void setLevels(List<OrgResoMetadataEnumsLevels> levels) {
    this.levels = levels;
  }

  public OrgResoMetadataPropertyCreate license1(String license1) {
    this.license1 = license1;
    return this;
  }

  /**
   * Get license1
   * @return license1
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense1() {
    return license1;
  }

  public void setLicense1(String license1) {
    this.license1 = license1;
  }

  public OrgResoMetadataPropertyCreate license2(String license2) {
    this.license2 = license2;
    return this;
  }

  /**
   * Get license2
   * @return license2
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense2() {
    return license2;
  }

  public void setLicense2(String license2) {
    this.license2 = license2;
  }

  public OrgResoMetadataPropertyCreate license3(String license3) {
    this.license3 = license3;
    return this;
  }

  /**
   * Get license3
   * @return license3
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLicense3() {
    return license3;
  }

  public void setLicense3(String license3) {
    this.license3 = license3;
  }

  public OrgResoMetadataPropertyCreate licensesExpense(AnyOforgResoMetadataPropertyCreateLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
    return this;
  }

  /**
   * Get licensesExpense
   * @return licensesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLicensesExpense getLicensesExpense() {
    return licensesExpense;
  }

  public void setLicensesExpense(AnyOforgResoMetadataPropertyCreateLicensesExpense licensesExpense) {
    this.licensesExpense = licensesExpense;
  }

  public OrgResoMetadataPropertyCreate listAOR(AnyOforgResoMetadataPropertyCreateListAOR listAOR) {
    this.listAOR = listAOR;
    return this;
  }

  /**
   * Get listAOR
   * @return listAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListAOR getListAOR() {
    return listAOR;
  }

  public void setListAOR(AnyOforgResoMetadataPropertyCreateListAOR listAOR) {
    this.listAOR = listAOR;
  }

  public OrgResoMetadataPropertyCreate listAgentAOR(AnyOforgResoMetadataPropertyCreateListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
    return this;
  }

  /**
   * Get listAgentAOR
   * @return listAgentAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListAgentAOR getListAgentAOR() {
    return listAgentAOR;
  }

  public void setListAgentAOR(AnyOforgResoMetadataPropertyCreateListAgentAOR listAgentAOR) {
    this.listAgentAOR = listAgentAOR;
  }

  public OrgResoMetadataPropertyCreate listAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addListAgentDesignationItem(OrgResoMetadataEnumsListAgentDesignation listAgentDesignationItem) {
    if (this.listAgentDesignation == null) {
      this.listAgentDesignation = new ArrayList<OrgResoMetadataEnumsListAgentDesignation>();
    }
    this.listAgentDesignation.add(listAgentDesignationItem);
    return this;
  }

  /**
   * Get listAgentDesignation
   * @return listAgentDesignation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListAgentDesignation> getListAgentDesignation() {
    return listAgentDesignation;
  }

  public void setListAgentDesignation(List<OrgResoMetadataEnumsListAgentDesignation> listAgentDesignation) {
    this.listAgentDesignation = listAgentDesignation;
  }

  public OrgResoMetadataPropertyCreate listAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
    return this;
  }

  /**
   * Get listAgentDirectPhone
   * @return listAgentDirectPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentDirectPhone() {
    return listAgentDirectPhone;
  }

  public void setListAgentDirectPhone(String listAgentDirectPhone) {
    this.listAgentDirectPhone = listAgentDirectPhone;
  }

  public OrgResoMetadataPropertyCreate listAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
    return this;
  }

  /**
   * Get listAgentEmail
   * @return listAgentEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListAgentEmail() {
    return listAgentEmail;
  }

  public void setListAgentEmail(String listAgentEmail) {
    this.listAgentEmail = listAgentEmail;
  }

  public OrgResoMetadataPropertyCreate listAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
    return this;
  }

  /**
   * Get listAgentFax
   * @return listAgentFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentFax() {
    return listAgentFax;
  }

  public void setListAgentFax(String listAgentFax) {
    this.listAgentFax = listAgentFax;
  }

  public OrgResoMetadataPropertyCreate listAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
    return this;
  }

  /**
   * Get listAgentFirstName
   * @return listAgentFirstName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentFirstName() {
    return listAgentFirstName;
  }

  public void setListAgentFirstName(String listAgentFirstName) {
    this.listAgentFirstName = listAgentFirstName;
  }

  public OrgResoMetadataPropertyCreate listAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
    return this;
  }

  /**
   * Get listAgentFullName
   * @return listAgentFullName
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getListAgentFullName() {
    return listAgentFullName;
  }

  public void setListAgentFullName(String listAgentFullName) {
    this.listAgentFullName = listAgentFullName;
  }

  public OrgResoMetadataPropertyCreate listAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
    return this;
  }

  /**
   * Get listAgentHomePhone
   * @return listAgentHomePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentHomePhone() {
    return listAgentHomePhone;
  }

  public void setListAgentHomePhone(String listAgentHomePhone) {
    this.listAgentHomePhone = listAgentHomePhone;
  }

  public OrgResoMetadataPropertyCreate listAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
    return this;
  }

  /**
   * Get listAgentKey
   * @return listAgentKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListAgentKey() {
    return listAgentKey;
  }

  public void setListAgentKey(String listAgentKey) {
    this.listAgentKey = listAgentKey;
  }

  public OrgResoMetadataPropertyCreate listAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
    return this;
  }

  /**
   * Get listAgentKeyNumeric
   * @return listAgentKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListAgentKeyNumeric getListAgentKeyNumeric() {
    return listAgentKeyNumeric;
  }

  public void setListAgentKeyNumeric(AnyOforgResoMetadataPropertyCreateListAgentKeyNumeric listAgentKeyNumeric) {
    this.listAgentKeyNumeric = listAgentKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate listAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
    return this;
  }

  /**
   * Get listAgentLastName
   * @return listAgentLastName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentLastName() {
    return listAgentLastName;
  }

  public void setListAgentLastName(String listAgentLastName) {
    this.listAgentLastName = listAgentLastName;
  }

  public OrgResoMetadataPropertyCreate listAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
    return this;
  }

  /**
   * Get listAgentMiddleName
   * @return listAgentMiddleName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentMiddleName() {
    return listAgentMiddleName;
  }

  public void setListAgentMiddleName(String listAgentMiddleName) {
    this.listAgentMiddleName = listAgentMiddleName;
  }

  public OrgResoMetadataPropertyCreate listAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
    return this;
  }

  /**
   * Get listAgentMlsId
   * @return listAgentMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListAgentMlsId() {
    return listAgentMlsId;
  }

  public void setListAgentMlsId(String listAgentMlsId) {
    this.listAgentMlsId = listAgentMlsId;
  }

  public OrgResoMetadataPropertyCreate listAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
    return this;
  }

  /**
   * Get listAgentMobilePhone
   * @return listAgentMobilePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentMobilePhone() {
    return listAgentMobilePhone;
  }

  public void setListAgentMobilePhone(String listAgentMobilePhone) {
    this.listAgentMobilePhone = listAgentMobilePhone;
  }

  public OrgResoMetadataPropertyCreate listAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
    return this;
  }

  /**
   * Get listAgentNamePrefix
   * @return listAgentNamePrefix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNamePrefix() {
    return listAgentNamePrefix;
  }

  public void setListAgentNamePrefix(String listAgentNamePrefix) {
    this.listAgentNamePrefix = listAgentNamePrefix;
  }

  public OrgResoMetadataPropertyCreate listAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
    return this;
  }

  /**
   * Get listAgentNameSuffix
   * @return listAgentNameSuffix
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentNameSuffix() {
    return listAgentNameSuffix;
  }

  public void setListAgentNameSuffix(String listAgentNameSuffix) {
    this.listAgentNameSuffix = listAgentNameSuffix;
  }

  public OrgResoMetadataPropertyCreate listAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
    return this;
  }

  /**
   * Get listAgentOfficePhone
   * @return listAgentOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentOfficePhone() {
    return listAgentOfficePhone;
  }

  public void setListAgentOfficePhone(String listAgentOfficePhone) {
    this.listAgentOfficePhone = listAgentOfficePhone;
  }

  public OrgResoMetadataPropertyCreate listAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
    return this;
  }

  /**
   * Get listAgentOfficePhoneExt
   * @return listAgentOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentOfficePhoneExt() {
    return listAgentOfficePhoneExt;
  }

  public void setListAgentOfficePhoneExt(String listAgentOfficePhoneExt) {
    this.listAgentOfficePhoneExt = listAgentOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate listAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
    return this;
  }

  /**
   * Get listAgentPager
   * @return listAgentPager
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPager() {
    return listAgentPager;
  }

  public void setListAgentPager(String listAgentPager) {
    this.listAgentPager = listAgentPager;
  }

  public OrgResoMetadataPropertyCreate listAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
    return this;
  }

  /**
   * Get listAgentPreferredPhone
   * @return listAgentPreferredPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentPreferredPhone() {
    return listAgentPreferredPhone;
  }

  public void setListAgentPreferredPhone(String listAgentPreferredPhone) {
    this.listAgentPreferredPhone = listAgentPreferredPhone;
  }

  public OrgResoMetadataPropertyCreate listAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
    return this;
  }

  /**
   * Get listAgentPreferredPhoneExt
   * @return listAgentPreferredPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentPreferredPhoneExt() {
    return listAgentPreferredPhoneExt;
  }

  public void setListAgentPreferredPhoneExt(String listAgentPreferredPhoneExt) {
    this.listAgentPreferredPhoneExt = listAgentPreferredPhoneExt;
  }

  public OrgResoMetadataPropertyCreate listAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
    return this;
  }

  /**
   * Get listAgentStateLicense
   * @return listAgentStateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListAgentStateLicense() {
    return listAgentStateLicense;
  }

  public void setListAgentStateLicense(String listAgentStateLicense) {
    this.listAgentStateLicense = listAgentStateLicense;
  }

  public OrgResoMetadataPropertyCreate listAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
    return this;
  }

  /**
   * Get listAgentTollFreePhone
   * @return listAgentTollFreePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentTollFreePhone() {
    return listAgentTollFreePhone;
  }

  public void setListAgentTollFreePhone(String listAgentTollFreePhone) {
    this.listAgentTollFreePhone = listAgentTollFreePhone;
  }

  public OrgResoMetadataPropertyCreate listAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
    return this;
  }

  /**
   * Get listAgentURL
   * @return listAgentURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListAgentURL() {
    return listAgentURL;
  }

  public void setListAgentURL(String listAgentURL) {
    this.listAgentURL = listAgentURL;
  }

  public OrgResoMetadataPropertyCreate listAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
    return this;
  }

  /**
   * Get listAgentVoiceMail
   * @return listAgentVoiceMail
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListAgentVoiceMail() {
    return listAgentVoiceMail;
  }

  public void setListAgentVoiceMail(String listAgentVoiceMail) {
    this.listAgentVoiceMail = listAgentVoiceMail;
  }

  public OrgResoMetadataPropertyCreate listAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
    return this;
  }

  /**
   * Get listAgentVoiceMailExt
   * @return listAgentVoiceMailExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListAgentVoiceMailExt() {
    return listAgentVoiceMailExt;
  }

  public void setListAgentVoiceMailExt(String listAgentVoiceMailExt) {
    this.listAgentVoiceMailExt = listAgentVoiceMailExt;
  }

  public OrgResoMetadataPropertyCreate listOfficeAOR(AnyOforgResoMetadataPropertyCreateListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
    return this;
  }

  /**
   * Get listOfficeAOR
   * @return listOfficeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListOfficeAOR getListOfficeAOR() {
    return listOfficeAOR;
  }

  public void setListOfficeAOR(AnyOforgResoMetadataPropertyCreateListOfficeAOR listOfficeAOR) {
    this.listOfficeAOR = listOfficeAOR;
  }

  public OrgResoMetadataPropertyCreate listOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
    return this;
  }

  /**
   * Get listOfficeEmail
   * @return listOfficeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getListOfficeEmail() {
    return listOfficeEmail;
  }

  public void setListOfficeEmail(String listOfficeEmail) {
    this.listOfficeEmail = listOfficeEmail;
  }

  public OrgResoMetadataPropertyCreate listOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
    return this;
  }

  /**
   * Get listOfficeFax
   * @return listOfficeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficeFax() {
    return listOfficeFax;
  }

  public void setListOfficeFax(String listOfficeFax) {
    this.listOfficeFax = listOfficeFax;
  }

  public OrgResoMetadataPropertyCreate listOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
    return this;
  }

  /**
   * Get listOfficeKey
   * @return listOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeKey() {
    return listOfficeKey;
  }

  public void setListOfficeKey(String listOfficeKey) {
    this.listOfficeKey = listOfficeKey;
  }

  public OrgResoMetadataPropertyCreate listOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
    return this;
  }

  /**
   * Get listOfficeKeyNumeric
   * @return listOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric getListOfficeKeyNumeric() {
    return listOfficeKeyNumeric;
  }

  public void setListOfficeKeyNumeric(AnyOforgResoMetadataPropertyCreateListOfficeKeyNumeric listOfficeKeyNumeric) {
    this.listOfficeKeyNumeric = listOfficeKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate listOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
    return this;
  }

  /**
   * Get listOfficeMlsId
   * @return listOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getListOfficeMlsId() {
    return listOfficeMlsId;
  }

  public void setListOfficeMlsId(String listOfficeMlsId) {
    this.listOfficeMlsId = listOfficeMlsId;
  }

  public OrgResoMetadataPropertyCreate listOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
    return this;
  }

  /**
   * Get listOfficeName
   * @return listOfficeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListOfficeName() {
    return listOfficeName;
  }

  public void setListOfficeName(String listOfficeName) {
    this.listOfficeName = listOfficeName;
  }

  public OrgResoMetadataPropertyCreate listOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
    return this;
  }

  /**
   * Get listOfficePhone
   * @return listOfficePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getListOfficePhone() {
    return listOfficePhone;
  }

  public void setListOfficePhone(String listOfficePhone) {
    this.listOfficePhone = listOfficePhone;
  }

  public OrgResoMetadataPropertyCreate listOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
    return this;
  }

  /**
   * Get listOfficePhoneExt
   * @return listOfficePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getListOfficePhoneExt() {
    return listOfficePhoneExt;
  }

  public void setListOfficePhoneExt(String listOfficePhoneExt) {
    this.listOfficePhoneExt = listOfficePhoneExt;
  }

  public OrgResoMetadataPropertyCreate listOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
    return this;
  }

  /**
   * Get listOfficeURL
   * @return listOfficeURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getListOfficeURL() {
    return listOfficeURL;
  }

  public void setListOfficeURL(String listOfficeURL) {
    this.listOfficeURL = listOfficeURL;
  }

  public OrgResoMetadataPropertyCreate listPrice(AnyOforgResoMetadataPropertyCreateListPrice listPrice) {
    this.listPrice = listPrice;
    return this;
  }

  /**
   * Get listPrice
   * @return listPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListPrice getListPrice() {
    return listPrice;
  }

  public void setListPrice(AnyOforgResoMetadataPropertyCreateListPrice listPrice) {
    this.listPrice = listPrice;
  }

  public OrgResoMetadataPropertyCreate listPriceLow(AnyOforgResoMetadataPropertyCreateListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
    return this;
  }

  /**
   * Get listPriceLow
   * @return listPriceLow
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListPriceLow getListPriceLow() {
    return listPriceLow;
  }

  public void setListPriceLow(AnyOforgResoMetadataPropertyCreateListPriceLow listPriceLow) {
    this.listPriceLow = listPriceLow;
  }

  public OrgResoMetadataPropertyCreate listTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
    return this;
  }

  /**
   * Get listTeamKey
   * @return listTeamKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListTeamKey() {
    return listTeamKey;
  }

  public void setListTeamKey(String listTeamKey) {
    this.listTeamKey = listTeamKey;
  }

  public OrgResoMetadataPropertyCreate listTeamKeyNumeric(AnyOforgResoMetadataPropertyCreateListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
    return this;
  }

  /**
   * Get listTeamKeyNumeric
   * @return listTeamKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListTeamKeyNumeric getListTeamKeyNumeric() {
    return listTeamKeyNumeric;
  }

  public void setListTeamKeyNumeric(AnyOforgResoMetadataPropertyCreateListTeamKeyNumeric listTeamKeyNumeric) {
    this.listTeamKeyNumeric = listTeamKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate listTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
    return this;
  }

  /**
   * Get listTeamName
   * @return listTeamName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getListTeamName() {
    return listTeamName;
  }

  public void setListTeamName(String listTeamName) {
    this.listTeamName = listTeamName;
  }

  public OrgResoMetadataPropertyCreate listingAgreement(AnyOforgResoMetadataPropertyCreateListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
    return this;
  }

  /**
   * Get listingAgreement
   * @return listingAgreement
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListingAgreement getListingAgreement() {
    return listingAgreement;
  }

  public void setListingAgreement(AnyOforgResoMetadataPropertyCreateListingAgreement listingAgreement) {
    this.listingAgreement = listingAgreement;
  }

  public OrgResoMetadataPropertyCreate listingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
    return this;
  }

  /**
   * Get listingContractDate
   * @return listingContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getListingContractDate() {
    return listingContractDate;
  }

  public void setListingContractDate(LocalDate listingContractDate) {
    this.listingContractDate = listingContractDate;
  }

  public OrgResoMetadataPropertyCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataPropertyCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataPropertyCreate listingKeyNumeric(AnyOforgResoMetadataPropertyCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataPropertyCreate listingService(AnyOforgResoMetadataPropertyCreateListingService listingService) {
    this.listingService = listingService;
    return this;
  }

  /**
   * Get listingService
   * @return listingService
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListingService getListingService() {
    return listingService;
  }

  public void setListingService(AnyOforgResoMetadataPropertyCreateListingService listingService) {
    this.listingService = listingService;
  }

  public OrgResoMetadataPropertyCreate listingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
    return this;
  }

  public OrgResoMetadataPropertyCreate addListingTermsItem(OrgResoMetadataEnumsListingTerms listingTermsItem) {
    if (this.listingTerms == null) {
      this.listingTerms = new ArrayList<OrgResoMetadataEnumsListingTerms>();
    }
    this.listingTerms.add(listingTermsItem);
    return this;
  }

  /**
   * Get listingTerms
   * @return listingTerms
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsListingTerms> getListingTerms() {
    return listingTerms;
  }

  public void setListingTerms(List<OrgResoMetadataEnumsListingTerms> listingTerms) {
    this.listingTerms = listingTerms;
  }

  public OrgResoMetadataPropertyCreate livingArea(AnyOforgResoMetadataPropertyCreateLivingArea livingArea) {
    this.livingArea = livingArea;
    return this;
  }

  /**
   * Get livingArea
   * @return livingArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLivingArea getLivingArea() {
    return livingArea;
  }

  public void setLivingArea(AnyOforgResoMetadataPropertyCreateLivingArea livingArea) {
    this.livingArea = livingArea;
  }

  public OrgResoMetadataPropertyCreate livingAreaSource(AnyOforgResoMetadataPropertyCreateLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
    return this;
  }

  /**
   * Get livingAreaSource
   * @return livingAreaSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLivingAreaSource getLivingAreaSource() {
    return livingAreaSource;
  }

  public void setLivingAreaSource(AnyOforgResoMetadataPropertyCreateLivingAreaSource livingAreaSource) {
    this.livingAreaSource = livingAreaSource;
  }

  public OrgResoMetadataPropertyCreate livingAreaUnits(AnyOforgResoMetadataPropertyCreateLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
    return this;
  }

  /**
   * Get livingAreaUnits
   * @return livingAreaUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLivingAreaUnits getLivingAreaUnits() {
    return livingAreaUnits;
  }

  public void setLivingAreaUnits(AnyOforgResoMetadataPropertyCreateLivingAreaUnits livingAreaUnits) {
    this.livingAreaUnits = livingAreaUnits;
  }

  public OrgResoMetadataPropertyCreate lockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
    return this;
  }

  /**
   * Get lockBoxLocation
   * @return lockBoxLocation
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getLockBoxLocation() {
    return lockBoxLocation;
  }

  public void setLockBoxLocation(String lockBoxLocation) {
    this.lockBoxLocation = lockBoxLocation;
  }

  public OrgResoMetadataPropertyCreate lockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
    return this;
  }

  /**
   * Get lockBoxSerialNumber
   * @return lockBoxSerialNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getLockBoxSerialNumber() {
    return lockBoxSerialNumber;
  }

  public void setLockBoxSerialNumber(String lockBoxSerialNumber) {
    this.lockBoxSerialNumber = lockBoxSerialNumber;
  }

  public OrgResoMetadataPropertyCreate lockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLockBoxTypeItem(OrgResoMetadataEnumsLockBoxType lockBoxTypeItem) {
    if (this.lockBoxType == null) {
      this.lockBoxType = new ArrayList<OrgResoMetadataEnumsLockBoxType>();
    }
    this.lockBoxType.add(lockBoxTypeItem);
    return this;
  }

  /**
   * Get lockBoxType
   * @return lockBoxType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLockBoxType> getLockBoxType() {
    return lockBoxType;
  }

  public void setLockBoxType(List<OrgResoMetadataEnumsLockBoxType> lockBoxType) {
    this.lockBoxType = lockBoxType;
  }

  public OrgResoMetadataPropertyCreate longitude(AnyOforgResoMetadataPropertyCreateLongitude longitude) {
    this.longitude = longitude;
    return this;
  }

  /**
   * Get longitude
   * @return longitude
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLongitude getLongitude() {
    return longitude;
  }

  public void setLongitude(AnyOforgResoMetadataPropertyCreateLongitude longitude) {
    this.longitude = longitude;
  }

  public OrgResoMetadataPropertyCreate lotDimensionsSource(AnyOforgResoMetadataPropertyCreateLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
    return this;
  }

  /**
   * Get lotDimensionsSource
   * @return lotDimensionsSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotDimensionsSource getLotDimensionsSource() {
    return lotDimensionsSource;
  }

  public void setLotDimensionsSource(AnyOforgResoMetadataPropertyCreateLotDimensionsSource lotDimensionsSource) {
    this.lotDimensionsSource = lotDimensionsSource;
  }

  public OrgResoMetadataPropertyCreate lotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addLotFeaturesItem(OrgResoMetadataEnumsLotFeatures lotFeaturesItem) {
    if (this.lotFeatures == null) {
      this.lotFeatures = new ArrayList<OrgResoMetadataEnumsLotFeatures>();
    }
    this.lotFeatures.add(lotFeaturesItem);
    return this;
  }

  /**
   * Get lotFeatures
   * @return lotFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsLotFeatures> getLotFeatures() {
    return lotFeatures;
  }

  public void setLotFeatures(List<OrgResoMetadataEnumsLotFeatures> lotFeatures) {
    this.lotFeatures = lotFeatures;
  }

  public OrgResoMetadataPropertyCreate lotSizeAcres(AnyOforgResoMetadataPropertyCreateLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
    return this;
  }

  /**
   * Get lotSizeAcres
   * @return lotSizeAcres
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotSizeAcres getLotSizeAcres() {
    return lotSizeAcres;
  }

  public void setLotSizeAcres(AnyOforgResoMetadataPropertyCreateLotSizeAcres lotSizeAcres) {
    this.lotSizeAcres = lotSizeAcres;
  }

  public OrgResoMetadataPropertyCreate lotSizeArea(AnyOforgResoMetadataPropertyCreateLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
    return this;
  }

  /**
   * Get lotSizeArea
   * @return lotSizeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotSizeArea getLotSizeArea() {
    return lotSizeArea;
  }

  public void setLotSizeArea(AnyOforgResoMetadataPropertyCreateLotSizeArea lotSizeArea) {
    this.lotSizeArea = lotSizeArea;
  }

  public OrgResoMetadataPropertyCreate lotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
    return this;
  }

  /**
   * Get lotSizeDimensions
   * @return lotSizeDimensions
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getLotSizeDimensions() {
    return lotSizeDimensions;
  }

  public void setLotSizeDimensions(String lotSizeDimensions) {
    this.lotSizeDimensions = lotSizeDimensions;
  }

  public OrgResoMetadataPropertyCreate lotSizeSource(AnyOforgResoMetadataPropertyCreateLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
    return this;
  }

  /**
   * Get lotSizeSource
   * @return lotSizeSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotSizeSource getLotSizeSource() {
    return lotSizeSource;
  }

  public void setLotSizeSource(AnyOforgResoMetadataPropertyCreateLotSizeSource lotSizeSource) {
    this.lotSizeSource = lotSizeSource;
  }

  public OrgResoMetadataPropertyCreate lotSizeSquareFeet(AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
    return this;
  }

  /**
   * Get lotSizeSquareFeet
   * @return lotSizeSquareFeet
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet getLotSizeSquareFeet() {
    return lotSizeSquareFeet;
  }

  public void setLotSizeSquareFeet(AnyOforgResoMetadataPropertyCreateLotSizeSquareFeet lotSizeSquareFeet) {
    this.lotSizeSquareFeet = lotSizeSquareFeet;
  }

  public OrgResoMetadataPropertyCreate lotSizeUnits(AnyOforgResoMetadataPropertyCreateLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
    return this;
  }

  /**
   * Get lotSizeUnits
   * @return lotSizeUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateLotSizeUnits getLotSizeUnits() {
    return lotSizeUnits;
  }

  public void setLotSizeUnits(AnyOforgResoMetadataPropertyCreateLotSizeUnits lotSizeUnits) {
    this.lotSizeUnits = lotSizeUnits;
  }

  public OrgResoMetadataPropertyCreate mlSAreaMajor(AnyOforgResoMetadataPropertyCreateMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
    return this;
  }

  /**
   * Get mlSAreaMajor
   * @return mlSAreaMajor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMlSAreaMajor getMlSAreaMajor() {
    return mlSAreaMajor;
  }

  public void setMlSAreaMajor(AnyOforgResoMetadataPropertyCreateMlSAreaMajor mlSAreaMajor) {
    this.mlSAreaMajor = mlSAreaMajor;
  }

  public OrgResoMetadataPropertyCreate mlSAreaMinor(AnyOforgResoMetadataPropertyCreateMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
    return this;
  }

  /**
   * Get mlSAreaMinor
   * @return mlSAreaMinor
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMlSAreaMinor getMlSAreaMinor() {
    return mlSAreaMinor;
  }

  public void setMlSAreaMinor(AnyOforgResoMetadataPropertyCreateMlSAreaMinor mlSAreaMinor) {
    this.mlSAreaMinor = mlSAreaMinor;
  }

  public OrgResoMetadataPropertyCreate mainLevelBathrooms(AnyOforgResoMetadataPropertyCreateMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
    return this;
  }

  /**
   * Get mainLevelBathrooms
   * @return mainLevelBathrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateMainLevelBathrooms getMainLevelBathrooms() {
    return mainLevelBathrooms;
  }

  public void setMainLevelBathrooms(AnyOforgResoMetadataPropertyCreateMainLevelBathrooms mainLevelBathrooms) {
    this.mainLevelBathrooms = mainLevelBathrooms;
  }

  public OrgResoMetadataPropertyCreate mainLevelBedrooms(AnyOforgResoMetadataPropertyCreateMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
    return this;
  }

  /**
   * Get mainLevelBedrooms
   * @return mainLevelBedrooms
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateMainLevelBedrooms getMainLevelBedrooms() {
    return mainLevelBedrooms;
  }

  public void setMainLevelBedrooms(AnyOforgResoMetadataPropertyCreateMainLevelBedrooms mainLevelBedrooms) {
    this.mainLevelBedrooms = mainLevelBedrooms;
  }

  public OrgResoMetadataPropertyCreate maintenanceExpense(AnyOforgResoMetadataPropertyCreateMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
    return this;
  }

  /**
   * Get maintenanceExpense
   * @return maintenanceExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateMaintenanceExpense getMaintenanceExpense() {
    return maintenanceExpense;
  }

  public void setMaintenanceExpense(AnyOforgResoMetadataPropertyCreateMaintenanceExpense maintenanceExpense) {
    this.maintenanceExpense = maintenanceExpense;
  }

  public OrgResoMetadataPropertyCreate majorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
    return this;
  }

  /**
   * Get majorChangeTimestamp
   * @return majorChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getMajorChangeTimestamp() {
    return majorChangeTimestamp;
  }

  public void setMajorChangeTimestamp(OffsetDateTime majorChangeTimestamp) {
    this.majorChangeTimestamp = majorChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate majorChangeType(AnyOforgResoMetadataPropertyCreateMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
    return this;
  }

  /**
   * Get majorChangeType
   * @return majorChangeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMajorChangeType getMajorChangeType() {
    return majorChangeType;
  }

  public void setMajorChangeType(AnyOforgResoMetadataPropertyCreateMajorChangeType majorChangeType) {
    this.majorChangeType = majorChangeType;
  }

  public OrgResoMetadataPropertyCreate make(String make) {
    this.make = make;
    return this;
  }

  /**
   * Get make
   * @return make
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getMake() {
    return make;
  }

  public void setMake(String make) {
    this.make = make;
  }

  public OrgResoMetadataPropertyCreate managerExpense(AnyOforgResoMetadataPropertyCreateManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
    return this;
  }

  /**
   * Get managerExpense
   * @return managerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateManagerExpense getManagerExpense() {
    return managerExpense;
  }

  public void setManagerExpense(AnyOforgResoMetadataPropertyCreateManagerExpense managerExpense) {
    this.managerExpense = managerExpense;
  }

  public OrgResoMetadataPropertyCreate mapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
    return this;
  }

  /**
   * Get mapCoordinate
   * @return mapCoordinate
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinate() {
    return mapCoordinate;
  }

  public void setMapCoordinate(String mapCoordinate) {
    this.mapCoordinate = mapCoordinate;
  }

  public OrgResoMetadataPropertyCreate mapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
    return this;
  }

  /**
   * Get mapCoordinateSource
   * @return mapCoordinateSource
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMapCoordinateSource() {
    return mapCoordinateSource;
  }

  public void setMapCoordinateSource(String mapCoordinateSource) {
    this.mapCoordinateSource = mapCoordinateSource;
  }

  public OrgResoMetadataPropertyCreate mapURL(String mapURL) {
    this.mapURL = mapURL;
    return this;
  }

  /**
   * Get mapURL
   * @return mapURL
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getMapURL() {
    return mapURL;
  }

  public void setMapURL(String mapURL) {
    this.mapURL = mapURL;
  }

  public OrgResoMetadataPropertyCreate middleOrJuniorSchool(AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
    return this;
  }

  /**
   * Get middleOrJuniorSchool
   * @return middleOrJuniorSchool
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchool getMiddleOrJuniorSchool() {
    return middleOrJuniorSchool;
  }

  public void setMiddleOrJuniorSchool(AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchool middleOrJuniorSchool) {
    this.middleOrJuniorSchool = middleOrJuniorSchool;
  }

  public OrgResoMetadataPropertyCreate middleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
    return this;
  }

  /**
   * Get middleOrJuniorSchoolDistrict
   * @return middleOrJuniorSchoolDistrict
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchoolDistrict getMiddleOrJuniorSchoolDistrict() {
    return middleOrJuniorSchoolDistrict;
  }

  public void setMiddleOrJuniorSchoolDistrict(AnyOforgResoMetadataPropertyCreateMiddleOrJuniorSchoolDistrict middleOrJuniorSchoolDistrict) {
    this.middleOrJuniorSchoolDistrict = middleOrJuniorSchoolDistrict;
  }

  public OrgResoMetadataPropertyCreate mlsStatus(AnyOforgResoMetadataPropertyCreateMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
    return this;
  }

  /**
   * Get mlsStatus
   * @return mlsStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMlsStatus getMlsStatus() {
    return mlsStatus;
  }

  public void setMlsStatus(AnyOforgResoMetadataPropertyCreateMlsStatus mlsStatus) {
    this.mlsStatus = mlsStatus;
  }

  public OrgResoMetadataPropertyCreate mobileDimUnits(AnyOforgResoMetadataPropertyCreateMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
    return this;
  }

  /**
   * Get mobileDimUnits
   * @return mobileDimUnits
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateMobileDimUnits getMobileDimUnits() {
    return mobileDimUnits;
  }

  public void setMobileDimUnits(AnyOforgResoMetadataPropertyCreateMobileDimUnits mobileDimUnits) {
    this.mobileDimUnits = mobileDimUnits;
  }

  public OrgResoMetadataPropertyCreate mobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
    return this;
  }

  /**
   * Get mobileHomeRemainsYN
   * @return mobileHomeRemainsYN
   **/
  @Schema(description = "")
  
    public Boolean isMobileHomeRemainsYN() {
    return mobileHomeRemainsYN;
  }

  public void setMobileHomeRemainsYN(Boolean mobileHomeRemainsYN) {
    this.mobileHomeRemainsYN = mobileHomeRemainsYN;
  }

  public OrgResoMetadataPropertyCreate mobileLength(AnyOforgResoMetadataPropertyCreateMobileLength mobileLength) {
    this.mobileLength = mobileLength;
    return this;
  }

  /**
   * Get mobileLength
   * @return mobileLength
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateMobileLength getMobileLength() {
    return mobileLength;
  }

  public void setMobileLength(AnyOforgResoMetadataPropertyCreateMobileLength mobileLength) {
    this.mobileLength = mobileLength;
  }

  public OrgResoMetadataPropertyCreate mobileWidth(AnyOforgResoMetadataPropertyCreateMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
    return this;
  }

  /**
   * Get mobileWidth
   * @return mobileWidth
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateMobileWidth getMobileWidth() {
    return mobileWidth;
  }

  public void setMobileWidth(AnyOforgResoMetadataPropertyCreateMobileWidth mobileWidth) {
    this.mobileWidth = mobileWidth;
  }

  public OrgResoMetadataPropertyCreate model(String model) {
    this.model = model;
    return this;
  }

  /**
   * Get model
   * @return model
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public OrgResoMetadataPropertyCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataPropertyCreate netOperatingIncome(AnyOforgResoMetadataPropertyCreateNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
    return this;
  }

  /**
   * Get netOperatingIncome
   * @return netOperatingIncome
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNetOperatingIncome getNetOperatingIncome() {
    return netOperatingIncome;
  }

  public void setNetOperatingIncome(AnyOforgResoMetadataPropertyCreateNetOperatingIncome netOperatingIncome) {
    this.netOperatingIncome = netOperatingIncome;
  }

  public OrgResoMetadataPropertyCreate newConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
    return this;
  }

  /**
   * Get newConstructionYN
   * @return newConstructionYN
   **/
  @Schema(description = "")
  
    public Boolean isNewConstructionYN() {
    return newConstructionYN;
  }

  public void setNewConstructionYN(Boolean newConstructionYN) {
    this.newConstructionYN = newConstructionYN;
  }

  public OrgResoMetadataPropertyCreate newTaxesExpense(AnyOforgResoMetadataPropertyCreateNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
    return this;
  }

  /**
   * Get newTaxesExpense
   * @return newTaxesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNewTaxesExpense getNewTaxesExpense() {
    return newTaxesExpense;
  }

  public void setNewTaxesExpense(AnyOforgResoMetadataPropertyCreateNewTaxesExpense newTaxesExpense) {
    this.newTaxesExpense = newTaxesExpense;
  }

  public OrgResoMetadataPropertyCreate numberOfBuildings(AnyOforgResoMetadataPropertyCreateNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
    return this;
  }

  /**
   * Get numberOfBuildings
   * @return numberOfBuildings
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfBuildings getNumberOfBuildings() {
    return numberOfBuildings;
  }

  public void setNumberOfBuildings(AnyOforgResoMetadataPropertyCreateNumberOfBuildings numberOfBuildings) {
    this.numberOfBuildings = numberOfBuildings;
  }

  public OrgResoMetadataPropertyCreate numberOfFullTimeEmployees(AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
    return this;
  }

  /**
   * Get numberOfFullTimeEmployees
   * @return numberOfFullTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees getNumberOfFullTimeEmployees() {
    return numberOfFullTimeEmployees;
  }

  public void setNumberOfFullTimeEmployees(AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees numberOfFullTimeEmployees) {
    this.numberOfFullTimeEmployees = numberOfFullTimeEmployees;
  }

  public OrgResoMetadataPropertyCreate numberOfLots(AnyOforgResoMetadataPropertyCreateNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
    return this;
  }

  /**
   * Get numberOfLots
   * @return numberOfLots
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfLots getNumberOfLots() {
    return numberOfLots;
  }

  public void setNumberOfLots(AnyOforgResoMetadataPropertyCreateNumberOfLots numberOfLots) {
    this.numberOfLots = numberOfLots;
  }

  public OrgResoMetadataPropertyCreate numberOfPads(AnyOforgResoMetadataPropertyCreateNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
    return this;
  }

  /**
   * Get numberOfPads
   * @return numberOfPads
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfPads getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(AnyOforgResoMetadataPropertyCreateNumberOfPads numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public OrgResoMetadataPropertyCreate numberOfPartTimeEmployees(AnyOforgResoMetadataPropertyCreateNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
    return this;
  }

  /**
   * Get numberOfPartTimeEmployees
   * @return numberOfPartTimeEmployees
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfPartTimeEmployees getNumberOfPartTimeEmployees() {
    return numberOfPartTimeEmployees;
  }

  public void setNumberOfPartTimeEmployees(AnyOforgResoMetadataPropertyCreateNumberOfPartTimeEmployees numberOfPartTimeEmployees) {
    this.numberOfPartTimeEmployees = numberOfPartTimeEmployees;
  }

  public OrgResoMetadataPropertyCreate numberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
    return this;
  }

  /**
   * Get numberOfSeparateElectricMeters
   * @return numberOfSeparateElectricMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters getNumberOfSeparateElectricMeters() {
    return numberOfSeparateElectricMeters;
  }

  public void setNumberOfSeparateElectricMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters numberOfSeparateElectricMeters) {
    this.numberOfSeparateElectricMeters = numberOfSeparateElectricMeters;
  }

  public OrgResoMetadataPropertyCreate numberOfSeparateGasMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
    return this;
  }

  /**
   * Get numberOfSeparateGasMeters
   * @return numberOfSeparateGasMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters getNumberOfSeparateGasMeters() {
    return numberOfSeparateGasMeters;
  }

  public void setNumberOfSeparateGasMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateGasMeters numberOfSeparateGasMeters) {
    this.numberOfSeparateGasMeters = numberOfSeparateGasMeters;
  }

  public OrgResoMetadataPropertyCreate numberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
    return this;
  }

  /**
   * Get numberOfSeparateWaterMeters
   * @return numberOfSeparateWaterMeters
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfSeparateWaterMeters getNumberOfSeparateWaterMeters() {
    return numberOfSeparateWaterMeters;
  }

  public void setNumberOfSeparateWaterMeters(AnyOforgResoMetadataPropertyCreateNumberOfSeparateWaterMeters numberOfSeparateWaterMeters) {
    this.numberOfSeparateWaterMeters = numberOfSeparateWaterMeters;
  }

  public OrgResoMetadataPropertyCreate numberOfUnitsInCommunity(AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
    return this;
  }

  /**
   * Get numberOfUnitsInCommunity
   * @return numberOfUnitsInCommunity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity getNumberOfUnitsInCommunity() {
    return numberOfUnitsInCommunity;
  }

  public void setNumberOfUnitsInCommunity(AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity numberOfUnitsInCommunity) {
    this.numberOfUnitsInCommunity = numberOfUnitsInCommunity;
  }

  public OrgResoMetadataPropertyCreate numberOfUnitsLeased(AnyOforgResoMetadataPropertyCreateNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
    return this;
  }

  /**
   * Get numberOfUnitsLeased
   * @return numberOfUnitsLeased
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfUnitsLeased getNumberOfUnitsLeased() {
    return numberOfUnitsLeased;
  }

  public void setNumberOfUnitsLeased(AnyOforgResoMetadataPropertyCreateNumberOfUnitsLeased numberOfUnitsLeased) {
    this.numberOfUnitsLeased = numberOfUnitsLeased;
  }

  public OrgResoMetadataPropertyCreate numberOfUnitsMoMo(AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
    return this;
  }

  /**
   * Get numberOfUnitsMoMo
   * @return numberOfUnitsMoMo
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo getNumberOfUnitsMoMo() {
    return numberOfUnitsMoMo;
  }

  public void setNumberOfUnitsMoMo(AnyOforgResoMetadataPropertyCreateNumberOfUnitsMoMo numberOfUnitsMoMo) {
    this.numberOfUnitsMoMo = numberOfUnitsMoMo;
  }

  public OrgResoMetadataPropertyCreate numberOfUnitsTotal(AnyOforgResoMetadataPropertyCreateNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
    return this;
  }

  /**
   * Get numberOfUnitsTotal
   * @return numberOfUnitsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfUnitsTotal getNumberOfUnitsTotal() {
    return numberOfUnitsTotal;
  }

  public void setNumberOfUnitsTotal(AnyOforgResoMetadataPropertyCreateNumberOfUnitsTotal numberOfUnitsTotal) {
    this.numberOfUnitsTotal = numberOfUnitsTotal;
  }

  public OrgResoMetadataPropertyCreate numberOfUnitsVacant(AnyOforgResoMetadataPropertyCreateNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
    return this;
  }

  /**
   * Get numberOfUnitsVacant
   * @return numberOfUnitsVacant
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateNumberOfUnitsVacant getNumberOfUnitsVacant() {
    return numberOfUnitsVacant;
  }

  public void setNumberOfUnitsVacant(AnyOforgResoMetadataPropertyCreateNumberOfUnitsVacant numberOfUnitsVacant) {
    this.numberOfUnitsVacant = numberOfUnitsVacant;
  }

  public OrgResoMetadataPropertyCreate occupantName(String occupantName) {
    this.occupantName = occupantName;
    return this;
  }

  /**
   * Get occupantName
   * @return occupantName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOccupantName() {
    return occupantName;
  }

  public void setOccupantName(String occupantName) {
    this.occupantName = occupantName;
  }

  public OrgResoMetadataPropertyCreate occupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
    return this;
  }

  /**
   * Get occupantPhone
   * @return occupantPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOccupantPhone() {
    return occupantPhone;
  }

  public void setOccupantPhone(String occupantPhone) {
    this.occupantPhone = occupantPhone;
  }

  public OrgResoMetadataPropertyCreate occupantType(AnyOforgResoMetadataPropertyCreateOccupantType occupantType) {
    this.occupantType = occupantType;
    return this;
  }

  /**
   * Get occupantType
   * @return occupantType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateOccupantType getOccupantType() {
    return occupantType;
  }

  public void setOccupantType(AnyOforgResoMetadataPropertyCreateOccupantType occupantType) {
    this.occupantType = occupantType;
  }

  public OrgResoMetadataPropertyCreate offMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
    return this;
  }

  /**
   * Get offMarketDate
   * @return offMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOffMarketDate() {
    return offMarketDate;
  }

  public void setOffMarketDate(LocalDate offMarketDate) {
    this.offMarketDate = offMarketDate;
  }

  public OrgResoMetadataPropertyCreate offMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
    return this;
  }

  /**
   * Get offMarketTimestamp
   * @return offMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOffMarketTimestamp() {
    return offMarketTimestamp;
  }

  public void setOffMarketTimestamp(OffsetDateTime offMarketTimestamp) {
    this.offMarketTimestamp = offMarketTimestamp;
  }

  public OrgResoMetadataPropertyCreate onMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
    return this;
  }

  /**
   * Get onMarketDate
   * @return onMarketDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getOnMarketDate() {
    return onMarketDate;
  }

  public void setOnMarketDate(LocalDate onMarketDate) {
    this.onMarketDate = onMarketDate;
  }

  public OrgResoMetadataPropertyCreate onMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
    return this;
  }

  /**
   * Get onMarketTimestamp
   * @return onMarketTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOnMarketTimestamp() {
    return onMarketTimestamp;
  }

  public void setOnMarketTimestamp(OffsetDateTime onMarketTimestamp) {
    this.onMarketTimestamp = onMarketTimestamp;
  }

  public OrgResoMetadataPropertyCreate openParkingSpaces(AnyOforgResoMetadataPropertyCreateOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
    return this;
  }

  /**
   * Get openParkingSpaces
   * @return openParkingSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateOpenParkingSpaces getOpenParkingSpaces() {
    return openParkingSpaces;
  }

  public void setOpenParkingSpaces(AnyOforgResoMetadataPropertyCreateOpenParkingSpaces openParkingSpaces) {
    this.openParkingSpaces = openParkingSpaces;
  }

  public OrgResoMetadataPropertyCreate openParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
    return this;
  }

  /**
   * Get openParkingYN
   * @return openParkingYN
   **/
  @Schema(description = "")
  
    public Boolean isOpenParkingYN() {
    return openParkingYN;
  }

  public void setOpenParkingYN(Boolean openParkingYN) {
    this.openParkingYN = openParkingYN;
  }

  public OrgResoMetadataPropertyCreate operatingExpense(AnyOforgResoMetadataPropertyCreateOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
    return this;
  }

  /**
   * Get operatingExpense
   * @return operatingExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateOperatingExpense getOperatingExpense() {
    return operatingExpense;
  }

  public void setOperatingExpense(AnyOforgResoMetadataPropertyCreateOperatingExpense operatingExpense) {
    this.operatingExpense = operatingExpense;
  }

  public OrgResoMetadataPropertyCreate operatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
    return this;
  }

  public OrgResoMetadataPropertyCreate addOperatingExpenseIncludesItem(OrgResoMetadataEnumsOperatingExpenseIncludes operatingExpenseIncludesItem) {
    if (this.operatingExpenseIncludes == null) {
      this.operatingExpenseIncludes = new ArrayList<OrgResoMetadataEnumsOperatingExpenseIncludes>();
    }
    this.operatingExpenseIncludes.add(operatingExpenseIncludesItem);
    return this;
  }

  /**
   * Get operatingExpenseIncludes
   * @return operatingExpenseIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOperatingExpenseIncludes> getOperatingExpenseIncludes() {
    return operatingExpenseIncludes;
  }

  public void setOperatingExpenseIncludes(List<OrgResoMetadataEnumsOperatingExpenseIncludes> operatingExpenseIncludes) {
    this.operatingExpenseIncludes = operatingExpenseIncludes;
  }

  public OrgResoMetadataPropertyCreate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataPropertyCreate originalListPrice(AnyOforgResoMetadataPropertyCreateOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
    return this;
  }

  /**
   * Get originalListPrice
   * @return originalListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateOriginalListPrice getOriginalListPrice() {
    return originalListPrice;
  }

  public void setOriginalListPrice(AnyOforgResoMetadataPropertyCreateOriginalListPrice originalListPrice) {
    this.originalListPrice = originalListPrice;
  }

  public OrgResoMetadataPropertyCreate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataPropertyCreate originatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
    return this;
  }

  /**
   * Get originatingSystemKey
   * @return originatingSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemKey() {
    return originatingSystemKey;
  }

  public void setOriginatingSystemKey(String originatingSystemKey) {
    this.originatingSystemKey = originatingSystemKey;
  }

  public OrgResoMetadataPropertyCreate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataPropertyCreate otherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
    return this;
  }

  public OrgResoMetadataPropertyCreate addOtherEquipmentItem(OrgResoMetadataEnumsOtherEquipment otherEquipmentItem) {
    if (this.otherEquipment == null) {
      this.otherEquipment = new ArrayList<OrgResoMetadataEnumsOtherEquipment>();
    }
    this.otherEquipment.add(otherEquipmentItem);
    return this;
  }

  /**
   * Get otherEquipment
   * @return otherEquipment
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherEquipment> getOtherEquipment() {
    return otherEquipment;
  }

  public void setOtherEquipment(List<OrgResoMetadataEnumsOtherEquipment> otherEquipment) {
    this.otherEquipment = otherEquipment;
  }

  public OrgResoMetadataPropertyCreate otherExpense(AnyOforgResoMetadataPropertyCreateOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
    return this;
  }

  /**
   * Get otherExpense
   * @return otherExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateOtherExpense getOtherExpense() {
    return otherExpense;
  }

  public void setOtherExpense(AnyOforgResoMetadataPropertyCreateOtherExpense otherExpense) {
    this.otherExpense = otherExpense;
  }

  public OrgResoMetadataPropertyCreate otherParking(String otherParking) {
    this.otherParking = otherParking;
    return this;
  }

  /**
   * Get otherParking
   * @return otherParking
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOtherParking() {
    return otherParking;
  }

  public void setOtherParking(String otherParking) {
    this.otherParking = otherParking;
  }

  public OrgResoMetadataPropertyCreate otherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addOtherStructuresItem(OrgResoMetadataEnumsOtherStructures otherStructuresItem) {
    if (this.otherStructures == null) {
      this.otherStructures = new ArrayList<OrgResoMetadataEnumsOtherStructures>();
    }
    this.otherStructures.add(otherStructuresItem);
    return this;
  }

  /**
   * Get otherStructures
   * @return otherStructures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOtherStructures> getOtherStructures() {
    return otherStructures;
  }

  public void setOtherStructures(List<OrgResoMetadataEnumsOtherStructures> otherStructures) {
    this.otherStructures = otherStructures;
  }

  public OrgResoMetadataPropertyCreate ownerName(String ownerName) {
    this.ownerName = ownerName;
    return this;
  }

  /**
   * Get ownerName
   * @return ownerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOwnerName() {
    return ownerName;
  }

  public void setOwnerName(String ownerName) {
    this.ownerName = ownerName;
  }

  public OrgResoMetadataPropertyCreate ownerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
    return this;
  }

  public OrgResoMetadataPropertyCreate addOwnerPaysItem(OrgResoMetadataEnumsOwnerPays ownerPaysItem) {
    if (this.ownerPays == null) {
      this.ownerPays = new ArrayList<OrgResoMetadataEnumsOwnerPays>();
    }
    this.ownerPays.add(ownerPaysItem);
    return this;
  }

  /**
   * Get ownerPays
   * @return ownerPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsOwnerPays> getOwnerPays() {
    return ownerPays;
  }

  public void setOwnerPays(List<OrgResoMetadataEnumsOwnerPays> ownerPays) {
    this.ownerPays = ownerPays;
  }

  public OrgResoMetadataPropertyCreate ownerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
    return this;
  }

  /**
   * Get ownerPhone
   * @return ownerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOwnerPhone() {
    return ownerPhone;
  }

  public void setOwnerPhone(String ownerPhone) {
    this.ownerPhone = ownerPhone;
  }

  public OrgResoMetadataPropertyCreate ownership(String ownership) {
    this.ownership = ownership;
    return this;
  }

  /**
   * Get ownership
   * @return ownership
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getOwnership() {
    return ownership;
  }

  public void setOwnership(String ownership) {
    this.ownership = ownership;
  }

  public OrgResoMetadataPropertyCreate ownershipType(AnyOforgResoMetadataPropertyCreateOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
    return this;
  }

  /**
   * Get ownershipType
   * @return ownershipType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateOwnershipType getOwnershipType() {
    return ownershipType;
  }

  public void setOwnershipType(AnyOforgResoMetadataPropertyCreateOwnershipType ownershipType) {
    this.ownershipType = ownershipType;
  }

  public OrgResoMetadataPropertyCreate parcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
    return this;
  }

  /**
   * Get parcelNumber
   * @return parcelNumber
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParcelNumber() {
    return parcelNumber;
  }

  public void setParcelNumber(String parcelNumber) {
    this.parcelNumber = parcelNumber;
  }

  public OrgResoMetadataPropertyCreate parkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
    return this;
  }

  /**
   * Get parkManagerName
   * @return parkManagerName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkManagerName() {
    return parkManagerName;
  }

  public void setParkManagerName(String parkManagerName) {
    this.parkManagerName = parkManagerName;
  }

  public OrgResoMetadataPropertyCreate parkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
    return this;
  }

  /**
   * Get parkManagerPhone
   * @return parkManagerPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getParkManagerPhone() {
    return parkManagerPhone;
  }

  public void setParkManagerPhone(String parkManagerPhone) {
    this.parkManagerPhone = parkManagerPhone;
  }

  public OrgResoMetadataPropertyCreate parkName(String parkName) {
    this.parkName = parkName;
    return this;
  }

  /**
   * Get parkName
   * @return parkName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getParkName() {
    return parkName;
  }

  public void setParkName(String parkName) {
    this.parkName = parkName;
  }

  public OrgResoMetadataPropertyCreate parkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addParkingFeaturesItem(OrgResoMetadataEnumsParkingFeatures parkingFeaturesItem) {
    if (this.parkingFeatures == null) {
      this.parkingFeatures = new ArrayList<OrgResoMetadataEnumsParkingFeatures>();
    }
    this.parkingFeatures.add(parkingFeaturesItem);
    return this;
  }

  /**
   * Get parkingFeatures
   * @return parkingFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsParkingFeatures> getParkingFeatures() {
    return parkingFeatures;
  }

  public void setParkingFeatures(List<OrgResoMetadataEnumsParkingFeatures> parkingFeatures) {
    this.parkingFeatures = parkingFeatures;
  }

  public OrgResoMetadataPropertyCreate parkingTotal(AnyOforgResoMetadataPropertyCreateParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
    return this;
  }

  /**
   * Get parkingTotal
   * @return parkingTotal
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateParkingTotal getParkingTotal() {
    return parkingTotal;
  }

  public void setParkingTotal(AnyOforgResoMetadataPropertyCreateParkingTotal parkingTotal) {
    this.parkingTotal = parkingTotal;
  }

  public OrgResoMetadataPropertyCreate pastureArea(AnyOforgResoMetadataPropertyCreatePastureArea pastureArea) {
    this.pastureArea = pastureArea;
    return this;
  }

  /**
   * Get pastureArea
   * @return pastureArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreatePastureArea getPastureArea() {
    return pastureArea;
  }

  public void setPastureArea(AnyOforgResoMetadataPropertyCreatePastureArea pastureArea) {
    this.pastureArea = pastureArea;
  }

  public OrgResoMetadataPropertyCreate patioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPatioAndPorchFeaturesItem(OrgResoMetadataEnumsPatioAndPorchFeatures patioAndPorchFeaturesItem) {
    if (this.patioAndPorchFeatures == null) {
      this.patioAndPorchFeatures = new ArrayList<OrgResoMetadataEnumsPatioAndPorchFeatures>();
    }
    this.patioAndPorchFeatures.add(patioAndPorchFeaturesItem);
    return this;
  }

  /**
   * Get patioAndPorchFeatures
   * @return patioAndPorchFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPatioAndPorchFeatures> getPatioAndPorchFeatures() {
    return patioAndPorchFeatures;
  }

  public void setPatioAndPorchFeatures(List<OrgResoMetadataEnumsPatioAndPorchFeatures> patioAndPorchFeatures) {
    this.patioAndPorchFeatures = patioAndPorchFeatures;
  }

  public OrgResoMetadataPropertyCreate pendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
    return this;
  }

  /**
   * Get pendingTimestamp
   * @return pendingTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPendingTimestamp() {
    return pendingTimestamp;
  }

  public void setPendingTimestamp(OffsetDateTime pendingTimestamp) {
    this.pendingTimestamp = pendingTimestamp;
  }

  public OrgResoMetadataPropertyCreate pestControlExpense(AnyOforgResoMetadataPropertyCreatePestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
    return this;
  }

  /**
   * Get pestControlExpense
   * @return pestControlExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreatePestControlExpense getPestControlExpense() {
    return pestControlExpense;
  }

  public void setPestControlExpense(AnyOforgResoMetadataPropertyCreatePestControlExpense pestControlExpense) {
    this.pestControlExpense = pestControlExpense;
  }

  public OrgResoMetadataPropertyCreate petsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPetsAllowedItem(OrgResoMetadataEnumsPetsAllowed petsAllowedItem) {
    if (this.petsAllowed == null) {
      this.petsAllowed = new ArrayList<OrgResoMetadataEnumsPetsAllowed>();
    }
    this.petsAllowed.add(petsAllowedItem);
    return this;
  }

  /**
   * Get petsAllowed
   * @return petsAllowed
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPetsAllowed> getPetsAllowed() {
    return petsAllowed;
  }

  public void setPetsAllowed(List<OrgResoMetadataEnumsPetsAllowed> petsAllowed) {
    this.petsAllowed = petsAllowed;
  }

  public OrgResoMetadataPropertyCreate photosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
    return this;
  }

  /**
   * Get photosChangeTimestamp
   * @return photosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPhotosChangeTimestamp() {
    return photosChangeTimestamp;
  }

  public void setPhotosChangeTimestamp(OffsetDateTime photosChangeTimestamp) {
    this.photosChangeTimestamp = photosChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate photosCount(AnyOforgResoMetadataPropertyCreatePhotosCount photosCount) {
    this.photosCount = photosCount;
    return this;
  }

  /**
   * Get photosCount
   * @return photosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreatePhotosCount getPhotosCount() {
    return photosCount;
  }

  public void setPhotosCount(AnyOforgResoMetadataPropertyCreatePhotosCount photosCount) {
    this.photosCount = photosCount;
  }

  public OrgResoMetadataPropertyCreate poolExpense(AnyOforgResoMetadataPropertyCreatePoolExpense poolExpense) {
    this.poolExpense = poolExpense;
    return this;
  }

  /**
   * Get poolExpense
   * @return poolExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreatePoolExpense getPoolExpense() {
    return poolExpense;
  }

  public void setPoolExpense(AnyOforgResoMetadataPropertyCreatePoolExpense poolExpense) {
    this.poolExpense = poolExpense;
  }

  public OrgResoMetadataPropertyCreate poolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPoolFeaturesItem(OrgResoMetadataEnumsPoolFeatures poolFeaturesItem) {
    if (this.poolFeatures == null) {
      this.poolFeatures = new ArrayList<OrgResoMetadataEnumsPoolFeatures>();
    }
    this.poolFeatures.add(poolFeaturesItem);
    return this;
  }

  /**
   * Get poolFeatures
   * @return poolFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPoolFeatures> getPoolFeatures() {
    return poolFeatures;
  }

  public void setPoolFeatures(List<OrgResoMetadataEnumsPoolFeatures> poolFeatures) {
    this.poolFeatures = poolFeatures;
  }

  public OrgResoMetadataPropertyCreate poolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
    return this;
  }

  /**
   * Get poolPrivateYN
   * @return poolPrivateYN
   **/
  @Schema(description = "")
  
    public Boolean isPoolPrivateYN() {
    return poolPrivateYN;
  }

  public void setPoolPrivateYN(Boolean poolPrivateYN) {
    this.poolPrivateYN = poolPrivateYN;
  }

  public OrgResoMetadataPropertyCreate possession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPossessionItem(OrgResoMetadataEnumsPossession possessionItem) {
    if (this.possession == null) {
      this.possession = new ArrayList<OrgResoMetadataEnumsPossession>();
    }
    this.possession.add(possessionItem);
    return this;
  }

  /**
   * Get possession
   * @return possession
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossession> getPossession() {
    return possession;
  }

  public void setPossession(List<OrgResoMetadataEnumsPossession> possession) {
    this.possession = possession;
  }

  public OrgResoMetadataPropertyCreate possibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPossibleUseItem(OrgResoMetadataEnumsPossibleUse possibleUseItem) {
    if (this.possibleUse == null) {
      this.possibleUse = new ArrayList<OrgResoMetadataEnumsPossibleUse>();
    }
    this.possibleUse.add(possibleUseItem);
    return this;
  }

  /**
   * Get possibleUse
   * @return possibleUse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPossibleUse> getPossibleUse() {
    return possibleUse;
  }

  public void setPossibleUse(List<OrgResoMetadataEnumsPossibleUse> possibleUse) {
    this.possibleUse = possibleUse;
  }

  public OrgResoMetadataPropertyCreate postalCity(AnyOforgResoMetadataPropertyCreatePostalCity postalCity) {
    this.postalCity = postalCity;
    return this;
  }

  /**
   * Get postalCity
   * @return postalCity
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreatePostalCity getPostalCity() {
    return postalCity;
  }

  public void setPostalCity(AnyOforgResoMetadataPropertyCreatePostalCity postalCity) {
    this.postalCity = postalCity;
  }

  public OrgResoMetadataPropertyCreate postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Get postalCode
   * @return postalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public OrgResoMetadataPropertyCreate postalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
    return this;
  }

  /**
   * Get postalCodePlus4
   * @return postalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getPostalCodePlus4() {
    return postalCodePlus4;
  }

  public void setPostalCodePlus4(String postalCodePlus4) {
    this.postalCodePlus4 = postalCodePlus4;
  }

  public OrgResoMetadataPropertyCreate powerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPowerProductionTypeItem(OrgResoMetadataEnumsPowerProductionType powerProductionTypeItem) {
    if (this.powerProductionType == null) {
      this.powerProductionType = new ArrayList<OrgResoMetadataEnumsPowerProductionType>();
    }
    this.powerProductionType.add(powerProductionTypeItem);
    return this;
  }

  /**
   * Get powerProductionType
   * @return powerProductionType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPowerProductionType> getPowerProductionType() {
    return powerProductionType;
  }

  public void setPowerProductionType(List<OrgResoMetadataEnumsPowerProductionType> powerProductionType) {
    this.powerProductionType = powerProductionType;
  }

  public OrgResoMetadataPropertyCreate previousListPrice(AnyOforgResoMetadataPropertyCreatePreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
    return this;
  }

  /**
   * Get previousListPrice
   * @return previousListPrice
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreatePreviousListPrice getPreviousListPrice() {
    return previousListPrice;
  }

  public void setPreviousListPrice(AnyOforgResoMetadataPropertyCreatePreviousListPrice previousListPrice) {
    this.previousListPrice = previousListPrice;
  }

  public OrgResoMetadataPropertyCreate priceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
    return this;
  }

  /**
   * Get priceChangeTimestamp
   * @return priceChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPriceChangeTimestamp() {
    return priceChangeTimestamp;
  }

  public void setPriceChangeTimestamp(OffsetDateTime priceChangeTimestamp) {
    this.priceChangeTimestamp = priceChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate privateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
    return this;
  }

  /**
   * Get privateOfficeRemarks
   * @return privateOfficeRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateOfficeRemarks() {
    return privateOfficeRemarks;
  }

  public void setPrivateOfficeRemarks(String privateOfficeRemarks) {
    this.privateOfficeRemarks = privateOfficeRemarks;
  }

  public OrgResoMetadataPropertyCreate privateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
    return this;
  }

  /**
   * Get privateRemarks
   * @return privateRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPrivateRemarks() {
    return privateRemarks;
  }

  public void setPrivateRemarks(String privateRemarks) {
    this.privateRemarks = privateRemarks;
  }

  public OrgResoMetadataPropertyCreate professionalManagementExpense(AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
    return this;
  }

  /**
   * Get professionalManagementExpense
   * @return professionalManagementExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense getProfessionalManagementExpense() {
    return professionalManagementExpense;
  }

  public void setProfessionalManagementExpense(AnyOforgResoMetadataPropertyCreateProfessionalManagementExpense professionalManagementExpense) {
    this.professionalManagementExpense = professionalManagementExpense;
  }

  public OrgResoMetadataPropertyCreate propertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
    return this;
  }

  /**
   * Get propertyAttachedYN
   * @return propertyAttachedYN
   **/
  @Schema(description = "")
  
    public Boolean isPropertyAttachedYN() {
    return propertyAttachedYN;
  }

  public void setPropertyAttachedYN(Boolean propertyAttachedYN) {
    this.propertyAttachedYN = propertyAttachedYN;
  }

  public OrgResoMetadataPropertyCreate propertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
    return this;
  }

  public OrgResoMetadataPropertyCreate addPropertyConditionItem(OrgResoMetadataEnumsPropertyCondition propertyConditionItem) {
    if (this.propertyCondition == null) {
      this.propertyCondition = new ArrayList<OrgResoMetadataEnumsPropertyCondition>();
    }
    this.propertyCondition.add(propertyConditionItem);
    return this;
  }

  /**
   * Get propertyCondition
   * @return propertyCondition
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsPropertyCondition> getPropertyCondition() {
    return propertyCondition;
  }

  public void setPropertyCondition(List<OrgResoMetadataEnumsPropertyCondition> propertyCondition) {
    this.propertyCondition = propertyCondition;
  }

  public OrgResoMetadataPropertyCreate propertySubType(AnyOforgResoMetadataPropertyCreatePropertySubType propertySubType) {
    this.propertySubType = propertySubType;
    return this;
  }

  /**
   * Get propertySubType
   * @return propertySubType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreatePropertySubType getPropertySubType() {
    return propertySubType;
  }

  public void setPropertySubType(AnyOforgResoMetadataPropertyCreatePropertySubType propertySubType) {
    this.propertySubType = propertySubType;
  }

  public OrgResoMetadataPropertyCreate propertyType(AnyOforgResoMetadataPropertyCreatePropertyType propertyType) {
    this.propertyType = propertyType;
    return this;
  }

  /**
   * Get propertyType
   * @return propertyType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreatePropertyType getPropertyType() {
    return propertyType;
  }

  public void setPropertyType(AnyOforgResoMetadataPropertyCreatePropertyType propertyType) {
    this.propertyType = propertyType;
  }

  public OrgResoMetadataPropertyCreate publicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
    return this;
  }

  /**
   * Get publicRemarks
   * @return publicRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getPublicRemarks() {
    return publicRemarks;
  }

  public void setPublicRemarks(String publicRemarks) {
    this.publicRemarks = publicRemarks;
  }

  public OrgResoMetadataPropertyCreate publicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
    return this;
  }

  /**
   * Get publicSurveyRange
   * @return publicSurveyRange
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyRange() {
    return publicSurveyRange;
  }

  public void setPublicSurveyRange(String publicSurveyRange) {
    this.publicSurveyRange = publicSurveyRange;
  }

  public OrgResoMetadataPropertyCreate publicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
    return this;
  }

  /**
   * Get publicSurveySection
   * @return publicSurveySection
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveySection() {
    return publicSurveySection;
  }

  public void setPublicSurveySection(String publicSurveySection) {
    this.publicSurveySection = publicSurveySection;
  }

  public OrgResoMetadataPropertyCreate publicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
    return this;
  }

  /**
   * Get publicSurveyTownship
   * @return publicSurveyTownship
   **/
  @Schema(description = "")
  
  @Size(max=20)   public String getPublicSurveyTownship() {
    return publicSurveyTownship;
  }

  public void setPublicSurveyTownship(String publicSurveyTownship) {
    this.publicSurveyTownship = publicSurveyTownship;
  }

  public OrgResoMetadataPropertyCreate purchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
    return this;
  }

  /**
   * Get purchaseContractDate
   * @return purchaseContractDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getPurchaseContractDate() {
    return purchaseContractDate;
  }

  public void setPurchaseContractDate(LocalDate purchaseContractDate) {
    this.purchaseContractDate = purchaseContractDate;
  }

  public OrgResoMetadataPropertyCreate rvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
    return this;
  }

  /**
   * Get rvParkingDimensions
   * @return rvParkingDimensions
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getRvParkingDimensions() {
    return rvParkingDimensions;
  }

  public void setRvParkingDimensions(String rvParkingDimensions) {
    this.rvParkingDimensions = rvParkingDimensions;
  }

  public OrgResoMetadataPropertyCreate rangeArea(AnyOforgResoMetadataPropertyCreateRangeArea rangeArea) {
    this.rangeArea = rangeArea;
    return this;
  }

  /**
   * Get rangeArea
   * @return rangeArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateRangeArea getRangeArea() {
    return rangeArea;
  }

  public void setRangeArea(AnyOforgResoMetadataPropertyCreateRangeArea rangeArea) {
    this.rangeArea = rangeArea;
  }

  public OrgResoMetadataPropertyCreate rentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
    return this;
  }

  /**
   * Get rentControlYN
   * @return rentControlYN
   **/
  @Schema(description = "")
  
    public Boolean isRentControlYN() {
    return rentControlYN;
  }

  public void setRentControlYN(Boolean rentControlYN) {
    this.rentControlYN = rentControlYN;
  }

  public OrgResoMetadataPropertyCreate rentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRentIncludesItem(OrgResoMetadataEnumsRentIncludes rentIncludesItem) {
    if (this.rentIncludes == null) {
      this.rentIncludes = new ArrayList<OrgResoMetadataEnumsRentIncludes>();
    }
    this.rentIncludes.add(rentIncludesItem);
    return this;
  }

  /**
   * Get rentIncludes
   * @return rentIncludes
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRentIncludes> getRentIncludes() {
    return rentIncludes;
  }

  public void setRentIncludes(List<OrgResoMetadataEnumsRentIncludes> rentIncludes) {
    this.rentIncludes = rentIncludes;
  }

  public OrgResoMetadataPropertyCreate roadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRoadFrontageTypeItem(OrgResoMetadataEnumsRoadFrontageType roadFrontageTypeItem) {
    if (this.roadFrontageType == null) {
      this.roadFrontageType = new ArrayList<OrgResoMetadataEnumsRoadFrontageType>();
    }
    this.roadFrontageType.add(roadFrontageTypeItem);
    return this;
  }

  /**
   * Get roadFrontageType
   * @return roadFrontageType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadFrontageType> getRoadFrontageType() {
    return roadFrontageType;
  }

  public void setRoadFrontageType(List<OrgResoMetadataEnumsRoadFrontageType> roadFrontageType) {
    this.roadFrontageType = roadFrontageType;
  }

  public OrgResoMetadataPropertyCreate roadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRoadResponsibilityItem(OrgResoMetadataEnumsRoadResponsibility roadResponsibilityItem) {
    if (this.roadResponsibility == null) {
      this.roadResponsibility = new ArrayList<OrgResoMetadataEnumsRoadResponsibility>();
    }
    this.roadResponsibility.add(roadResponsibilityItem);
    return this;
  }

  /**
   * Get roadResponsibility
   * @return roadResponsibility
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadResponsibility> getRoadResponsibility() {
    return roadResponsibility;
  }

  public void setRoadResponsibility(List<OrgResoMetadataEnumsRoadResponsibility> roadResponsibility) {
    this.roadResponsibility = roadResponsibility;
  }

  public OrgResoMetadataPropertyCreate roadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRoadSurfaceTypeItem(OrgResoMetadataEnumsRoadSurfaceType roadSurfaceTypeItem) {
    if (this.roadSurfaceType == null) {
      this.roadSurfaceType = new ArrayList<OrgResoMetadataEnumsRoadSurfaceType>();
    }
    this.roadSurfaceType.add(roadSurfaceTypeItem);
    return this;
  }

  /**
   * Get roadSurfaceType
   * @return roadSurfaceType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoadSurfaceType> getRoadSurfaceType() {
    return roadSurfaceType;
  }

  public void setRoadSurfaceType(List<OrgResoMetadataEnumsRoadSurfaceType> roadSurfaceType) {
    this.roadSurfaceType = roadSurfaceType;
  }

  public OrgResoMetadataPropertyCreate roof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRoofItem(OrgResoMetadataEnumsRoof roofItem) {
    if (this.roof == null) {
      this.roof = new ArrayList<OrgResoMetadataEnumsRoof>();
    }
    this.roof.add(roofItem);
    return this;
  }

  /**
   * Get roof
   * @return roof
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoof> getRoof() {
    return roof;
  }

  public void setRoof(List<OrgResoMetadataEnumsRoof> roof) {
    this.roof = roof;
  }

  public OrgResoMetadataPropertyCreate roomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addRoomTypeItem(OrgResoMetadataEnumsRoomType roomTypeItem) {
    if (this.roomType == null) {
      this.roomType = new ArrayList<OrgResoMetadataEnumsRoomType>();
    }
    this.roomType.add(roomTypeItem);
    return this;
  }

  /**
   * Get roomType
   * @return roomType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsRoomType> getRoomType() {
    return roomType;
  }

  public void setRoomType(List<OrgResoMetadataEnumsRoomType> roomType) {
    this.roomType = roomType;
  }

  public OrgResoMetadataPropertyCreate roomsTotal(AnyOforgResoMetadataPropertyCreateRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
    return this;
  }

  /**
   * Get roomsTotal
   * @return roomsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateRoomsTotal getRoomsTotal() {
    return roomsTotal;
  }

  public void setRoomsTotal(AnyOforgResoMetadataPropertyCreateRoomsTotal roomsTotal) {
    this.roomsTotal = roomsTotal;
  }

  public OrgResoMetadataPropertyCreate seatingCapacity(AnyOforgResoMetadataPropertyCreateSeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
    return this;
  }

  /**
   * Get seatingCapacity
   * @return seatingCapacity
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateSeatingCapacity getSeatingCapacity() {
    return seatingCapacity;
  }

  public void setSeatingCapacity(AnyOforgResoMetadataPropertyCreateSeatingCapacity seatingCapacity) {
    this.seatingCapacity = seatingCapacity;
  }

  public OrgResoMetadataPropertyCreate securityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSecurityFeaturesItem(OrgResoMetadataEnumsSecurityFeatures securityFeaturesItem) {
    if (this.securityFeatures == null) {
      this.securityFeatures = new ArrayList<OrgResoMetadataEnumsSecurityFeatures>();
    }
    this.securityFeatures.add(securityFeaturesItem);
    return this;
  }

  /**
   * Get securityFeatures
   * @return securityFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSecurityFeatures> getSecurityFeatures() {
    return securityFeatures;
  }

  public void setSecurityFeatures(List<OrgResoMetadataEnumsSecurityFeatures> securityFeatures) {
    this.securityFeatures = securityFeatures;
  }

  public OrgResoMetadataPropertyCreate seniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
    return this;
  }

  /**
   * Get seniorCommunityYN
   * @return seniorCommunityYN
   **/
  @Schema(description = "")
  
    public Boolean isSeniorCommunityYN() {
    return seniorCommunityYN;
  }

  public void setSeniorCommunityYN(Boolean seniorCommunityYN) {
    this.seniorCommunityYN = seniorCommunityYN;
  }

  public OrgResoMetadataPropertyCreate serialU(String serialU) {
    this.serialU = serialU;
    return this;
  }

  /**
   * Get serialU
   * @return serialU
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialU() {
    return serialU;
  }

  public void setSerialU(String serialU) {
    this.serialU = serialU;
  }

  public OrgResoMetadataPropertyCreate serialX(String serialX) {
    this.serialX = serialX;
    return this;
  }

  /**
   * Get serialX
   * @return serialX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialX() {
    return serialX;
  }

  public void setSerialX(String serialX) {
    this.serialX = serialX;
  }

  public OrgResoMetadataPropertyCreate serialXX(String serialXX) {
    this.serialXX = serialXX;
    return this;
  }

  /**
   * Get serialXX
   * @return serialXX
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSerialXX() {
    return serialXX;
  }

  public void setSerialXX(String serialXX) {
    this.serialXX = serialXX;
  }

  public OrgResoMetadataPropertyCreate sewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSewerItem(OrgResoMetadataEnumsSewer sewerItem) {
    if (this.sewer == null) {
      this.sewer = new ArrayList<OrgResoMetadataEnumsSewer>();
    }
    this.sewer.add(sewerItem);
    return this;
  }

  /**
   * Get sewer
   * @return sewer
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSewer> getSewer() {
    return sewer;
  }

  public void setSewer(List<OrgResoMetadataEnumsSewer> sewer) {
    this.sewer = sewer;
  }

  public OrgResoMetadataPropertyCreate showingAdvanceNotice(AnyOforgResoMetadataPropertyCreateShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
    return this;
  }

  /**
   * Get showingAdvanceNotice
   * @return showingAdvanceNotice
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateShowingAdvanceNotice getShowingAdvanceNotice() {
    return showingAdvanceNotice;
  }

  public void setShowingAdvanceNotice(AnyOforgResoMetadataPropertyCreateShowingAdvanceNotice showingAdvanceNotice) {
    this.showingAdvanceNotice = showingAdvanceNotice;
  }

  public OrgResoMetadataPropertyCreate showingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
    return this;
  }

  /**
   * Get showingAttendedYN
   * @return showingAttendedYN
   **/
  @Schema(description = "")
  
    public Boolean isShowingAttendedYN() {
    return showingAttendedYN;
  }

  public void setShowingAttendedYN(Boolean showingAttendedYN) {
    this.showingAttendedYN = showingAttendedYN;
  }

  public OrgResoMetadataPropertyCreate showingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
    return this;
  }

  /**
   * Get showingContactName
   * @return showingContactName
   **/
  @Schema(description = "")
  
  @Size(max=40)   public String getShowingContactName() {
    return showingContactName;
  }

  public void setShowingContactName(String showingContactName) {
    this.showingContactName = showingContactName;
  }

  public OrgResoMetadataPropertyCreate showingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
    return this;
  }

  /**
   * Get showingContactPhone
   * @return showingContactPhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getShowingContactPhone() {
    return showingContactPhone;
  }

  public void setShowingContactPhone(String showingContactPhone) {
    this.showingContactPhone = showingContactPhone;
  }

  public OrgResoMetadataPropertyCreate showingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
    return this;
  }

  /**
   * Get showingContactPhoneExt
   * @return showingContactPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getShowingContactPhoneExt() {
    return showingContactPhoneExt;
  }

  public void setShowingContactPhoneExt(String showingContactPhoneExt) {
    this.showingContactPhoneExt = showingContactPhoneExt;
  }

  public OrgResoMetadataPropertyCreate showingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addShowingContactTypeItem(OrgResoMetadataEnumsShowingContactType showingContactTypeItem) {
    if (this.showingContactType == null) {
      this.showingContactType = new ArrayList<OrgResoMetadataEnumsShowingContactType>();
    }
    this.showingContactType.add(showingContactTypeItem);
    return this;
  }

  /**
   * Get showingContactType
   * @return showingContactType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingContactType> getShowingContactType() {
    return showingContactType;
  }

  public void setShowingContactType(List<OrgResoMetadataEnumsShowingContactType> showingContactType) {
    this.showingContactType = showingContactType;
  }

  public OrgResoMetadataPropertyCreate showingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
    return this;
  }

  public OrgResoMetadataPropertyCreate addShowingDaysItem(OrgResoMetadataEnumsShowingDays showingDaysItem) {
    if (this.showingDays == null) {
      this.showingDays = new ArrayList<OrgResoMetadataEnumsShowingDays>();
    }
    this.showingDays.add(showingDaysItem);
    return this;
  }

  /**
   * Get showingDays
   * @return showingDays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingDays> getShowingDays() {
    return showingDays;
  }

  public void setShowingDays(List<OrgResoMetadataEnumsShowingDays> showingDays) {
    this.showingDays = showingDays;
  }

  public OrgResoMetadataPropertyCreate showingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
    return this;
  }

  /**
   * Get showingEndTime
   * @return showingEndTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingEndTime() {
    return showingEndTime;
  }

  public void setShowingEndTime(OffsetDateTime showingEndTime) {
    this.showingEndTime = showingEndTime;
  }

  public OrgResoMetadataPropertyCreate showingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
    return this;
  }

  /**
   * Get showingInstructions
   * @return showingInstructions
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getShowingInstructions() {
    return showingInstructions;
  }

  public void setShowingInstructions(String showingInstructions) {
    this.showingInstructions = showingInstructions;
  }

  public OrgResoMetadataPropertyCreate showingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
    return this;
  }

  public OrgResoMetadataPropertyCreate addShowingRequirementsItem(OrgResoMetadataEnumsShowingRequirements showingRequirementsItem) {
    if (this.showingRequirements == null) {
      this.showingRequirements = new ArrayList<OrgResoMetadataEnumsShowingRequirements>();
    }
    this.showingRequirements.add(showingRequirementsItem);
    return this;
  }

  /**
   * Get showingRequirements
   * @return showingRequirements
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsShowingRequirements> getShowingRequirements() {
    return showingRequirements;
  }

  public void setShowingRequirements(List<OrgResoMetadataEnumsShowingRequirements> showingRequirements) {
    this.showingRequirements = showingRequirements;
  }

  public OrgResoMetadataPropertyCreate showingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
    return this;
  }

  /**
   * Get showingStartTime
   * @return showingStartTime
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getShowingStartTime() {
    return showingStartTime;
  }

  public void setShowingStartTime(OffsetDateTime showingStartTime) {
    this.showingStartTime = showingStartTime;
  }

  public OrgResoMetadataPropertyCreate signOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
    return this;
  }

  /**
   * Get signOnPropertyYN
   * @return signOnPropertyYN
   **/
  @Schema(description = "")
  
    public Boolean isSignOnPropertyYN() {
    return signOnPropertyYN;
  }

  public void setSignOnPropertyYN(Boolean signOnPropertyYN) {
    this.signOnPropertyYN = signOnPropertyYN;
  }

  public OrgResoMetadataPropertyCreate skirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSkirtItem(OrgResoMetadataEnumsSkirt skirtItem) {
    if (this.skirt == null) {
      this.skirt = new ArrayList<OrgResoMetadataEnumsSkirt>();
    }
    this.skirt.add(skirtItem);
    return this;
  }

  /**
   * Get skirt
   * @return skirt
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSkirt> getSkirt() {
    return skirt;
  }

  public void setSkirt(List<OrgResoMetadataEnumsSkirt> skirt) {
    this.skirt = skirt;
  }

  public OrgResoMetadataPropertyCreate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataPropertyCreate sourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
    return this;
  }

  /**
   * Get sourceSystemKey
   * @return sourceSystemKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemKey() {
    return sourceSystemKey;
  }

  public void setSourceSystemKey(String sourceSystemKey) {
    this.sourceSystemKey = sourceSystemKey;
  }

  public OrgResoMetadataPropertyCreate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataPropertyCreate spaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSpaFeaturesItem(OrgResoMetadataEnumsSpaFeatures spaFeaturesItem) {
    if (this.spaFeatures == null) {
      this.spaFeatures = new ArrayList<OrgResoMetadataEnumsSpaFeatures>();
    }
    this.spaFeatures.add(spaFeaturesItem);
    return this;
  }

  /**
   * Get spaFeatures
   * @return spaFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpaFeatures> getSpaFeatures() {
    return spaFeatures;
  }

  public void setSpaFeatures(List<OrgResoMetadataEnumsSpaFeatures> spaFeatures) {
    this.spaFeatures = spaFeatures;
  }

  public OrgResoMetadataPropertyCreate spaYN(Boolean spaYN) {
    this.spaYN = spaYN;
    return this;
  }

  /**
   * Get spaYN
   * @return spaYN
   **/
  @Schema(description = "")
  
    public Boolean isSpaYN() {
    return spaYN;
  }

  public void setSpaYN(Boolean spaYN) {
    this.spaYN = spaYN;
  }

  public OrgResoMetadataPropertyCreate specialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSpecialLicensesItem(OrgResoMetadataEnumsSpecialLicenses specialLicensesItem) {
    if (this.specialLicenses == null) {
      this.specialLicenses = new ArrayList<OrgResoMetadataEnumsSpecialLicenses>();
    }
    this.specialLicenses.add(specialLicensesItem);
    return this;
  }

  /**
   * Get specialLicenses
   * @return specialLicenses
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialLicenses> getSpecialLicenses() {
    return specialLicenses;
  }

  public void setSpecialLicenses(List<OrgResoMetadataEnumsSpecialLicenses> specialLicenses) {
    this.specialLicenses = specialLicenses;
  }

  public OrgResoMetadataPropertyCreate specialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSpecialListingConditionsItem(OrgResoMetadataEnumsSpecialListingConditions specialListingConditionsItem) {
    if (this.specialListingConditions == null) {
      this.specialListingConditions = new ArrayList<OrgResoMetadataEnumsSpecialListingConditions>();
    }
    this.specialListingConditions.add(specialListingConditionsItem);
    return this;
  }

  /**
   * Get specialListingConditions
   * @return specialListingConditions
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSpecialListingConditions> getSpecialListingConditions() {
    return specialListingConditions;
  }

  public void setSpecialListingConditions(List<OrgResoMetadataEnumsSpecialListingConditions> specialListingConditions) {
    this.specialListingConditions = specialListingConditions;
  }

  public OrgResoMetadataPropertyCreate standardStatus(AnyOforgResoMetadataPropertyCreateStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
    return this;
  }

  /**
   * Get standardStatus
   * @return standardStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateStandardStatus getStandardStatus() {
    return standardStatus;
  }

  public void setStandardStatus(AnyOforgResoMetadataPropertyCreateStandardStatus standardStatus) {
    this.standardStatus = standardStatus;
  }

  public OrgResoMetadataPropertyCreate stateOrProvince(AnyOforgResoMetadataPropertyCreateStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
    return this;
  }

  /**
   * Get stateOrProvince
   * @return stateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateStateOrProvince getStateOrProvince() {
    return stateOrProvince;
  }

  public void setStateOrProvince(AnyOforgResoMetadataPropertyCreateStateOrProvince stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  public OrgResoMetadataPropertyCreate stateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
    return this;
  }

  /**
   * Get stateRegion
   * @return stateRegion
   **/
  @Schema(description = "")
  
  @Size(max=150)   public String getStateRegion() {
    return stateRegion;
  }

  public void setStateRegion(String stateRegion) {
    this.stateRegion = stateRegion;
  }

  public OrgResoMetadataPropertyCreate statusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
    return this;
  }

  /**
   * Get statusChangeTimestamp
   * @return statusChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getStatusChangeTimestamp() {
    return statusChangeTimestamp;
  }

  public void setStatusChangeTimestamp(OffsetDateTime statusChangeTimestamp) {
    this.statusChangeTimestamp = statusChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate stories(AnyOforgResoMetadataPropertyCreateStories stories) {
    this.stories = stories;
    return this;
  }

  /**
   * Get stories
   * @return stories
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateStories getStories() {
    return stories;
  }

  public void setStories(AnyOforgResoMetadataPropertyCreateStories stories) {
    this.stories = stories;
  }

  public OrgResoMetadataPropertyCreate storiesTotal(AnyOforgResoMetadataPropertyCreateStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
    return this;
  }

  /**
   * Get storiesTotal
   * @return storiesTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateStoriesTotal getStoriesTotal() {
    return storiesTotal;
  }

  public void setStoriesTotal(AnyOforgResoMetadataPropertyCreateStoriesTotal storiesTotal) {
    this.storiesTotal = storiesTotal;
  }

  public OrgResoMetadataPropertyCreate streetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
    return this;
  }

  /**
   * Get streetAdditionalInfo
   * @return streetAdditionalInfo
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetAdditionalInfo() {
    return streetAdditionalInfo;
  }

  public void setStreetAdditionalInfo(String streetAdditionalInfo) {
    this.streetAdditionalInfo = streetAdditionalInfo;
  }

  public OrgResoMetadataPropertyCreate streetDirPrefix(AnyOforgResoMetadataPropertyCreateStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
    return this;
  }

  /**
   * Get streetDirPrefix
   * @return streetDirPrefix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateStreetDirPrefix getStreetDirPrefix() {
    return streetDirPrefix;
  }

  public void setStreetDirPrefix(AnyOforgResoMetadataPropertyCreateStreetDirPrefix streetDirPrefix) {
    this.streetDirPrefix = streetDirPrefix;
  }

  public OrgResoMetadataPropertyCreate streetDirSuffix(AnyOforgResoMetadataPropertyCreateStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
    return this;
  }

  /**
   * Get streetDirSuffix
   * @return streetDirSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateStreetDirSuffix getStreetDirSuffix() {
    return streetDirSuffix;
  }

  public void setStreetDirSuffix(AnyOforgResoMetadataPropertyCreateStreetDirSuffix streetDirSuffix) {
    this.streetDirSuffix = streetDirSuffix;
  }

  public OrgResoMetadataPropertyCreate streetName(String streetName) {
    this.streetName = streetName;
    return this;
  }

  /**
   * Get streetName
   * @return streetName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getStreetName() {
    return streetName;
  }

  public void setStreetName(String streetName) {
    this.streetName = streetName;
  }

  public OrgResoMetadataPropertyCreate streetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
    return this;
  }

  /**
   * Get streetNumber
   * @return streetNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetNumber() {
    return streetNumber;
  }

  public void setStreetNumber(String streetNumber) {
    this.streetNumber = streetNumber;
  }

  public OrgResoMetadataPropertyCreate streetNumberNumeric(AnyOforgResoMetadataPropertyCreateStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
    return this;
  }

  /**
   * Get streetNumberNumeric
   * @return streetNumberNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateStreetNumberNumeric getStreetNumberNumeric() {
    return streetNumberNumeric;
  }

  public void setStreetNumberNumeric(AnyOforgResoMetadataPropertyCreateStreetNumberNumeric streetNumberNumeric) {
    this.streetNumberNumeric = streetNumberNumeric;
  }

  public OrgResoMetadataPropertyCreate streetSuffix(AnyOforgResoMetadataPropertyCreateStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
    return this;
  }

  /**
   * Get streetSuffix
   * @return streetSuffix
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateStreetSuffix getStreetSuffix() {
    return streetSuffix;
  }

  public void setStreetSuffix(AnyOforgResoMetadataPropertyCreateStreetSuffix streetSuffix) {
    this.streetSuffix = streetSuffix;
  }

  public OrgResoMetadataPropertyCreate streetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
    return this;
  }

  /**
   * Get streetSuffixModifier
   * @return streetSuffixModifier
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getStreetSuffixModifier() {
    return streetSuffixModifier;
  }

  public void setStreetSuffixModifier(String streetSuffixModifier) {
    this.streetSuffixModifier = streetSuffixModifier;
  }

  public OrgResoMetadataPropertyCreate structureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addStructureTypeItem(OrgResoMetadataEnumsStructureType structureTypeItem) {
    if (this.structureType == null) {
      this.structureType = new ArrayList<OrgResoMetadataEnumsStructureType>();
    }
    this.structureType.add(structureTypeItem);
    return this;
  }

  /**
   * Get structureType
   * @return structureType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsStructureType> getStructureType() {
    return structureType;
  }

  public void setStructureType(List<OrgResoMetadataEnumsStructureType> structureType) {
    this.structureType = structureType;
  }

  public OrgResoMetadataPropertyCreate subAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
    return this;
  }

  /**
   * Get subAgencyCompensation
   * @return subAgencyCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSubAgencyCompensation() {
    return subAgencyCompensation;
  }

  public void setSubAgencyCompensation(String subAgencyCompensation) {
    this.subAgencyCompensation = subAgencyCompensation;
  }

  public OrgResoMetadataPropertyCreate subAgencyCompensationType(AnyOforgResoMetadataPropertyCreateSubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
    return this;
  }

  /**
   * Get subAgencyCompensationType
   * @return subAgencyCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateSubAgencyCompensationType getSubAgencyCompensationType() {
    return subAgencyCompensationType;
  }

  public void setSubAgencyCompensationType(AnyOforgResoMetadataPropertyCreateSubAgencyCompensationType subAgencyCompensationType) {
    this.subAgencyCompensationType = subAgencyCompensationType;
  }

  public OrgResoMetadataPropertyCreate subdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
    return this;
  }

  /**
   * Get subdivisionName
   * @return subdivisionName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getSubdivisionName() {
    return subdivisionName;
  }

  public void setSubdivisionName(String subdivisionName) {
    this.subdivisionName = subdivisionName;
  }

  public OrgResoMetadataPropertyCreate suppliesExpense(AnyOforgResoMetadataPropertyCreateSuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
    return this;
  }

  /**
   * Get suppliesExpense
   * @return suppliesExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateSuppliesExpense getSuppliesExpense() {
    return suppliesExpense;
  }

  public void setSuppliesExpense(AnyOforgResoMetadataPropertyCreateSuppliesExpense suppliesExpense) {
    this.suppliesExpense = suppliesExpense;
  }

  public OrgResoMetadataPropertyCreate syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }

  public OrgResoMetadataPropertyCreate syndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
    return this;
  }

  /**
   * Get syndicationRemarks
   * @return syndicationRemarks
   **/
  @Schema(description = "")
  
  @Size(max=4000)   public String getSyndicationRemarks() {
    return syndicationRemarks;
  }

  public void setSyndicationRemarks(String syndicationRemarks) {
    this.syndicationRemarks = syndicationRemarks;
  }

  public OrgResoMetadataPropertyCreate taxAnnualAmount(AnyOforgResoMetadataPropertyCreateTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
    return this;
  }

  /**
   * Get taxAnnualAmount
   * @return taxAnnualAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTaxAnnualAmount getTaxAnnualAmount() {
    return taxAnnualAmount;
  }

  public void setTaxAnnualAmount(AnyOforgResoMetadataPropertyCreateTaxAnnualAmount taxAnnualAmount) {
    this.taxAnnualAmount = taxAnnualAmount;
  }

  public OrgResoMetadataPropertyCreate taxAssessedValue(AnyOforgResoMetadataPropertyCreateTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
    return this;
  }

  /**
   * Get taxAssessedValue
   * @return taxAssessedValue
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTaxAssessedValue getTaxAssessedValue() {
    return taxAssessedValue;
  }

  public void setTaxAssessedValue(AnyOforgResoMetadataPropertyCreateTaxAssessedValue taxAssessedValue) {
    this.taxAssessedValue = taxAssessedValue;
  }

  public OrgResoMetadataPropertyCreate taxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
    return this;
  }

  /**
   * Get taxBlock
   * @return taxBlock
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBlock() {
    return taxBlock;
  }

  public void setTaxBlock(String taxBlock) {
    this.taxBlock = taxBlock;
  }

  public OrgResoMetadataPropertyCreate taxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
    return this;
  }

  /**
   * Get taxBookNumber
   * @return taxBookNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxBookNumber() {
    return taxBookNumber;
  }

  public void setTaxBookNumber(String taxBookNumber) {
    this.taxBookNumber = taxBookNumber;
  }

  public OrgResoMetadataPropertyCreate taxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
    return this;
  }

  /**
   * Get taxLegalDescription
   * @return taxLegalDescription
   **/
  @Schema(description = "")
  
  @Size(max=6000)   public String getTaxLegalDescription() {
    return taxLegalDescription;
  }

  public void setTaxLegalDescription(String taxLegalDescription) {
    this.taxLegalDescription = taxLegalDescription;
  }

  public OrgResoMetadataPropertyCreate taxLot(String taxLot) {
    this.taxLot = taxLot;
    return this;
  }

  /**
   * Get taxLot
   * @return taxLot
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxLot() {
    return taxLot;
  }

  public void setTaxLot(String taxLot) {
    this.taxLot = taxLot;
  }

  public OrgResoMetadataPropertyCreate taxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
    return this;
  }

  /**
   * Get taxMapNumber
   * @return taxMapNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxMapNumber() {
    return taxMapNumber;
  }

  public void setTaxMapNumber(String taxMapNumber) {
    this.taxMapNumber = taxMapNumber;
  }

  public OrgResoMetadataPropertyCreate taxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
    return this;
  }

  /**
   * Get taxOtherAnnualAssessmentAmount
   * @return taxOtherAnnualAssessmentAmount
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount getTaxOtherAnnualAssessmentAmount() {
    return taxOtherAnnualAssessmentAmount;
  }

  public void setTaxOtherAnnualAssessmentAmount(AnyOforgResoMetadataPropertyCreateTaxOtherAnnualAssessmentAmount taxOtherAnnualAssessmentAmount) {
    this.taxOtherAnnualAssessmentAmount = taxOtherAnnualAssessmentAmount;
  }

  public OrgResoMetadataPropertyCreate taxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
    return this;
  }

  /**
   * Get taxParcelLetter
   * @return taxParcelLetter
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxParcelLetter() {
    return taxParcelLetter;
  }

  public void setTaxParcelLetter(String taxParcelLetter) {
    this.taxParcelLetter = taxParcelLetter;
  }

  public OrgResoMetadataPropertyCreate taxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
    return this;
  }

  public OrgResoMetadataPropertyCreate addTaxStatusCurrentItem(OrgResoMetadataEnumsTaxStatusCurrent taxStatusCurrentItem) {
    if (this.taxStatusCurrent == null) {
      this.taxStatusCurrent = new ArrayList<OrgResoMetadataEnumsTaxStatusCurrent>();
    }
    this.taxStatusCurrent.add(taxStatusCurrentItem);
    return this;
  }

  /**
   * Get taxStatusCurrent
   * @return taxStatusCurrent
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTaxStatusCurrent> getTaxStatusCurrent() {
    return taxStatusCurrent;
  }

  public void setTaxStatusCurrent(List<OrgResoMetadataEnumsTaxStatusCurrent> taxStatusCurrent) {
    this.taxStatusCurrent = taxStatusCurrent;
  }

  public OrgResoMetadataPropertyCreate taxTract(String taxTract) {
    this.taxTract = taxTract;
    return this;
  }

  /**
   * Get taxTract
   * @return taxTract
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTaxTract() {
    return taxTract;
  }

  public void setTaxTract(String taxTract) {
    this.taxTract = taxTract;
  }

  public OrgResoMetadataPropertyCreate taxYear(AnyOforgResoMetadataPropertyCreateTaxYear taxYear) {
    this.taxYear = taxYear;
    return this;
  }

  /**
   * Get taxYear
   * @return taxYear
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTaxYear getTaxYear() {
    return taxYear;
  }

  public void setTaxYear(AnyOforgResoMetadataPropertyCreateTaxYear taxYear) {
    this.taxYear = taxYear;
  }

  public OrgResoMetadataPropertyCreate tenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
    return this;
  }

  public OrgResoMetadataPropertyCreate addTenantPaysItem(OrgResoMetadataEnumsTenantPays tenantPaysItem) {
    if (this.tenantPays == null) {
      this.tenantPays = new ArrayList<OrgResoMetadataEnumsTenantPays>();
    }
    this.tenantPays.add(tenantPaysItem);
    return this;
  }

  /**
   * Get tenantPays
   * @return tenantPays
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsTenantPays> getTenantPays() {
    return tenantPays;
  }

  public void setTenantPays(List<OrgResoMetadataEnumsTenantPays> tenantPays) {
    this.tenantPays = tenantPays;
  }

  public OrgResoMetadataPropertyCreate topography(String topography) {
    this.topography = topography;
    return this;
  }

  /**
   * Get topography
   * @return topography
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getTopography() {
    return topography;
  }

  public void setTopography(String topography) {
    this.topography = topography;
  }

  public OrgResoMetadataPropertyCreate totalActualRent(AnyOforgResoMetadataPropertyCreateTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
    return this;
  }

  /**
   * Get totalActualRent
   * @return totalActualRent
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTotalActualRent getTotalActualRent() {
    return totalActualRent;
  }

  public void setTotalActualRent(AnyOforgResoMetadataPropertyCreateTotalActualRent totalActualRent) {
    this.totalActualRent = totalActualRent;
  }

  public OrgResoMetadataPropertyCreate township(String township) {
    this.township = township;
    return this;
  }

  /**
   * Get township
   * @return township
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getTownship() {
    return township;
  }

  public void setTownship(String township) {
    this.township = township;
  }

  public OrgResoMetadataPropertyCreate transactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
    return this;
  }

  /**
   * Get transactionBrokerCompensation
   * @return transactionBrokerCompensation
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getTransactionBrokerCompensation() {
    return transactionBrokerCompensation;
  }

  public void setTransactionBrokerCompensation(String transactionBrokerCompensation) {
    this.transactionBrokerCompensation = transactionBrokerCompensation;
  }

  public OrgResoMetadataPropertyCreate transactionBrokerCompensationType(AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
    return this;
  }

  /**
   * Get transactionBrokerCompensationType
   * @return transactionBrokerCompensationType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType getTransactionBrokerCompensationType() {
    return transactionBrokerCompensationType;
  }

  public void setTransactionBrokerCompensationType(AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType transactionBrokerCompensationType) {
    this.transactionBrokerCompensationType = transactionBrokerCompensationType;
  }

  public OrgResoMetadataPropertyCreate trashExpense(AnyOforgResoMetadataPropertyCreateTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
    return this;
  }

  /**
   * Get trashExpense
   * @return trashExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateTrashExpense getTrashExpense() {
    return trashExpense;
  }

  public void setTrashExpense(AnyOforgResoMetadataPropertyCreateTrashExpense trashExpense) {
    this.trashExpense = trashExpense;
  }

  public OrgResoMetadataPropertyCreate unitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
    return this;
  }

  /**
   * Get unitNumber
   * @return unitNumber
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getUnitNumber() {
    return unitNumber;
  }

  public void setUnitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
  }

  public OrgResoMetadataPropertyCreate unitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
    return this;
  }

  public OrgResoMetadataPropertyCreate addUnitTypeTypeItem(OrgResoMetadataEnumsUnitTypeType unitTypeTypeItem) {
    if (this.unitTypeType == null) {
      this.unitTypeType = new ArrayList<OrgResoMetadataEnumsUnitTypeType>();
    }
    this.unitTypeType.add(unitTypeTypeItem);
    return this;
  }

  /**
   * Get unitTypeType
   * @return unitTypeType
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUnitTypeType> getUnitTypeType() {
    return unitTypeType;
  }

  public void setUnitTypeType(List<OrgResoMetadataEnumsUnitTypeType> unitTypeType) {
    this.unitTypeType = unitTypeType;
  }

  public OrgResoMetadataPropertyCreate unitsFurnished(AnyOforgResoMetadataPropertyCreateUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
    return this;
  }

  /**
   * Get unitsFurnished
   * @return unitsFurnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateUnitsFurnished getUnitsFurnished() {
    return unitsFurnished;
  }

  public void setUnitsFurnished(AnyOforgResoMetadataPropertyCreateUnitsFurnished unitsFurnished) {
    this.unitsFurnished = unitsFurnished;
  }

  public OrgResoMetadataPropertyCreate universalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
    return this;
  }

  /**
   * Get universalPropertyId
   * @return universalPropertyId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertyId() {
    return universalPropertyId;
  }

  public void setUniversalPropertyId(String universalPropertyId) {
    this.universalPropertyId = universalPropertyId;
  }

  public OrgResoMetadataPropertyCreate universalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
    return this;
  }

  /**
   * Get universalPropertySubId
   * @return universalPropertySubId
   **/
  @Schema(description = "")
  
  @Size(max=128)   public String getUniversalPropertySubId() {
    return universalPropertySubId;
  }

  public void setUniversalPropertySubId(String universalPropertySubId) {
    this.universalPropertySubId = universalPropertySubId;
  }

  public OrgResoMetadataPropertyCreate unparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
    return this;
  }

  /**
   * Get unparsedAddress
   * @return unparsedAddress
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getUnparsedAddress() {
    return unparsedAddress;
  }

  public void setUnparsedAddress(String unparsedAddress) {
    this.unparsedAddress = unparsedAddress;
  }

  public OrgResoMetadataPropertyCreate utilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
    return this;
  }

  public OrgResoMetadataPropertyCreate addUtilitiesItem(OrgResoMetadataEnumsUtilities utilitiesItem) {
    if (this.utilities == null) {
      this.utilities = new ArrayList<OrgResoMetadataEnumsUtilities>();
    }
    this.utilities.add(utilitiesItem);
    return this;
  }

  /**
   * Get utilities
   * @return utilities
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsUtilities> getUtilities() {
    return utilities;
  }

  public void setUtilities(List<OrgResoMetadataEnumsUtilities> utilities) {
    this.utilities = utilities;
  }

  public OrgResoMetadataPropertyCreate vacancyAllowance(AnyOforgResoMetadataPropertyCreateVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
    return this;
  }

  /**
   * Get vacancyAllowance
   * @return vacancyAllowance
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateVacancyAllowance getVacancyAllowance() {
    return vacancyAllowance;
  }

  public void setVacancyAllowance(AnyOforgResoMetadataPropertyCreateVacancyAllowance vacancyAllowance) {
    this.vacancyAllowance = vacancyAllowance;
  }

  public OrgResoMetadataPropertyCreate vacancyAllowanceRate(AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
    return this;
  }

  /**
   * Get vacancyAllowanceRate
   * @return vacancyAllowanceRate
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate getVacancyAllowanceRate() {
    return vacancyAllowanceRate;
  }

  public void setVacancyAllowanceRate(AnyOforgResoMetadataPropertyCreateVacancyAllowanceRate vacancyAllowanceRate) {
    this.vacancyAllowanceRate = vacancyAllowanceRate;
  }

  public OrgResoMetadataPropertyCreate vegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
    return this;
  }

  public OrgResoMetadataPropertyCreate addVegetationItem(OrgResoMetadataEnumsVegetation vegetationItem) {
    if (this.vegetation == null) {
      this.vegetation = new ArrayList<OrgResoMetadataEnumsVegetation>();
    }
    this.vegetation.add(vegetationItem);
    return this;
  }

  /**
   * Get vegetation
   * @return vegetation
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsVegetation> getVegetation() {
    return vegetation;
  }

  public void setVegetation(List<OrgResoMetadataEnumsVegetation> vegetation) {
    this.vegetation = vegetation;
  }

  public OrgResoMetadataPropertyCreate videosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
    return this;
  }

  /**
   * Get videosChangeTimestamp
   * @return videosChangeTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getVideosChangeTimestamp() {
    return videosChangeTimestamp;
  }

  public void setVideosChangeTimestamp(OffsetDateTime videosChangeTimestamp) {
    this.videosChangeTimestamp = videosChangeTimestamp;
  }

  public OrgResoMetadataPropertyCreate videosCount(AnyOforgResoMetadataPropertyCreateVideosCount videosCount) {
    this.videosCount = videosCount;
    return this;
  }

  /**
   * Get videosCount
   * @return videosCount
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateVideosCount getVideosCount() {
    return videosCount;
  }

  public void setVideosCount(AnyOforgResoMetadataPropertyCreateVideosCount videosCount) {
    this.videosCount = videosCount;
  }

  public OrgResoMetadataPropertyCreate view(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
    return this;
  }

  public OrgResoMetadataPropertyCreate addViewItem(OrgResoMetadataEnumsView viewItem) {
    if (this.view == null) {
      this.view = new ArrayList<OrgResoMetadataEnumsView>();
    }
    this.view.add(viewItem);
    return this;
  }

  /**
   * Get view
   * @return view
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsView> getView() {
    return view;
  }

  public void setView(List<OrgResoMetadataEnumsView> view) {
    this.view = view;
  }

  public OrgResoMetadataPropertyCreate viewYN(Boolean viewYN) {
    this.viewYN = viewYN;
    return this;
  }

  /**
   * Get viewYN
   * @return viewYN
   **/
  @Schema(description = "")
  
    public Boolean isViewYN() {
    return viewYN;
  }

  public void setViewYN(Boolean viewYN) {
    this.viewYN = viewYN;
  }

  public OrgResoMetadataPropertyCreate virtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
    return this;
  }

  /**
   * Get virtualTourURLBranded
   * @return virtualTourURLBranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLBranded() {
    return virtualTourURLBranded;
  }

  public void setVirtualTourURLBranded(String virtualTourURLBranded) {
    this.virtualTourURLBranded = virtualTourURLBranded;
  }

  public OrgResoMetadataPropertyCreate virtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
    return this;
  }

  /**
   * Get virtualTourURLUnbranded
   * @return virtualTourURLUnbranded
   **/
  @Schema(description = "")
  
  @Size(max=8000)   public String getVirtualTourURLUnbranded() {
    return virtualTourURLUnbranded;
  }

  public void setVirtualTourURLUnbranded(String virtualTourURLUnbranded) {
    this.virtualTourURLUnbranded = virtualTourURLUnbranded;
  }

  public OrgResoMetadataPropertyCreate walkScore(AnyOforgResoMetadataPropertyCreateWalkScore walkScore) {
    this.walkScore = walkScore;
    return this;
  }

  /**
   * Get walkScore
   * @return walkScore
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateWalkScore getWalkScore() {
    return walkScore;
  }

  public void setWalkScore(AnyOforgResoMetadataPropertyCreateWalkScore walkScore) {
    this.walkScore = walkScore;
  }

  public OrgResoMetadataPropertyCreate waterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
    return this;
  }

  /**
   * Get waterBodyName
   * @return waterBodyName
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getWaterBodyName() {
    return waterBodyName;
  }

  public void setWaterBodyName(String waterBodyName) {
    this.waterBodyName = waterBodyName;
  }

  public OrgResoMetadataPropertyCreate waterSewerExpense(AnyOforgResoMetadataPropertyCreateWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
    return this;
  }

  /**
   * Get waterSewerExpense
   * @return waterSewerExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateWaterSewerExpense getWaterSewerExpense() {
    return waterSewerExpense;
  }

  public void setWaterSewerExpense(AnyOforgResoMetadataPropertyCreateWaterSewerExpense waterSewerExpense) {
    this.waterSewerExpense = waterSewerExpense;
  }

  public OrgResoMetadataPropertyCreate waterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
    return this;
  }

  public OrgResoMetadataPropertyCreate addWaterSourceItem(OrgResoMetadataEnumsWaterSource waterSourceItem) {
    if (this.waterSource == null) {
      this.waterSource = new ArrayList<OrgResoMetadataEnumsWaterSource>();
    }
    this.waterSource.add(waterSourceItem);
    return this;
  }

  /**
   * Get waterSource
   * @return waterSource
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterSource> getWaterSource() {
    return waterSource;
  }

  public void setWaterSource(List<OrgResoMetadataEnumsWaterSource> waterSource) {
    this.waterSource = waterSource;
  }

  public OrgResoMetadataPropertyCreate waterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addWaterfrontFeaturesItem(OrgResoMetadataEnumsWaterfrontFeatures waterfrontFeaturesItem) {
    if (this.waterfrontFeatures == null) {
      this.waterfrontFeatures = new ArrayList<OrgResoMetadataEnumsWaterfrontFeatures>();
    }
    this.waterfrontFeatures.add(waterfrontFeaturesItem);
    return this;
  }

  /**
   * Get waterfrontFeatures
   * @return waterfrontFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWaterfrontFeatures> getWaterfrontFeatures() {
    return waterfrontFeatures;
  }

  public void setWaterfrontFeatures(List<OrgResoMetadataEnumsWaterfrontFeatures> waterfrontFeatures) {
    this.waterfrontFeatures = waterfrontFeatures;
  }

  public OrgResoMetadataPropertyCreate waterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
    return this;
  }

  /**
   * Get waterfrontYN
   * @return waterfrontYN
   **/
  @Schema(description = "")
  
    public Boolean isWaterfrontYN() {
    return waterfrontYN;
  }

  public void setWaterfrontYN(Boolean waterfrontYN) {
    this.waterfrontYN = waterfrontYN;
  }

  public OrgResoMetadataPropertyCreate windowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
    return this;
  }

  public OrgResoMetadataPropertyCreate addWindowFeaturesItem(OrgResoMetadataEnumsWindowFeatures windowFeaturesItem) {
    if (this.windowFeatures == null) {
      this.windowFeatures = new ArrayList<OrgResoMetadataEnumsWindowFeatures>();
    }
    this.windowFeatures.add(windowFeaturesItem);
    return this;
  }

  /**
   * Get windowFeatures
   * @return windowFeatures
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsWindowFeatures> getWindowFeatures() {
    return windowFeatures;
  }

  public void setWindowFeatures(List<OrgResoMetadataEnumsWindowFeatures> windowFeatures) {
    this.windowFeatures = windowFeatures;
  }

  public OrgResoMetadataPropertyCreate withdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
    return this;
  }

  /**
   * Get withdrawnDate
   * @return withdrawnDate
   **/
  @Schema(example = "Thu Apr 13 00:00:00 GMT 2017", description = "")
  
    @Valid
    public LocalDate getWithdrawnDate() {
    return withdrawnDate;
  }

  public void setWithdrawnDate(LocalDate withdrawnDate) {
    this.withdrawnDate = withdrawnDate;
  }

  public OrgResoMetadataPropertyCreate woodedArea(AnyOforgResoMetadataPropertyCreateWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
    return this;
  }

  /**
   * Get woodedArea
   * @return woodedArea
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateWoodedArea getWoodedArea() {
    return woodedArea;
  }

  public void setWoodedArea(AnyOforgResoMetadataPropertyCreateWoodedArea woodedArea) {
    this.woodedArea = woodedArea;
  }

  public OrgResoMetadataPropertyCreate workmansCompensationExpense(AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
    return this;
  }

  /**
   * Get workmansCompensationExpense
   * @return workmansCompensationExpense
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense getWorkmansCompensationExpense() {
    return workmansCompensationExpense;
  }

  public void setWorkmansCompensationExpense(AnyOforgResoMetadataPropertyCreateWorkmansCompensationExpense workmansCompensationExpense) {
    this.workmansCompensationExpense = workmansCompensationExpense;
  }

  public OrgResoMetadataPropertyCreate yearBuilt(AnyOforgResoMetadataPropertyCreateYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
    return this;
  }

  /**
   * Get yearBuilt
   * @return yearBuilt
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateYearBuilt getYearBuilt() {
    return yearBuilt;
  }

  public void setYearBuilt(AnyOforgResoMetadataPropertyCreateYearBuilt yearBuilt) {
    this.yearBuilt = yearBuilt;
  }

  public OrgResoMetadataPropertyCreate yearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
    return this;
  }

  /**
   * Get yearBuiltDetails
   * @return yearBuiltDetails
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getYearBuiltDetails() {
    return yearBuiltDetails;
  }

  public void setYearBuiltDetails(String yearBuiltDetails) {
    this.yearBuiltDetails = yearBuiltDetails;
  }

  public OrgResoMetadataPropertyCreate yearBuiltEffective(AnyOforgResoMetadataPropertyCreateYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
    return this;
  }

  /**
   * Get yearBuiltEffective
   * @return yearBuiltEffective
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateYearBuiltEffective getYearBuiltEffective() {
    return yearBuiltEffective;
  }

  public void setYearBuiltEffective(AnyOforgResoMetadataPropertyCreateYearBuiltEffective yearBuiltEffective) {
    this.yearBuiltEffective = yearBuiltEffective;
  }

  public OrgResoMetadataPropertyCreate yearBuiltSource(AnyOforgResoMetadataPropertyCreateYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
    return this;
  }

  /**
   * Get yearBuiltSource
   * @return yearBuiltSource
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateYearBuiltSource getYearBuiltSource() {
    return yearBuiltSource;
  }

  public void setYearBuiltSource(AnyOforgResoMetadataPropertyCreateYearBuiltSource yearBuiltSource) {
    this.yearBuiltSource = yearBuiltSource;
  }

  public OrgResoMetadataPropertyCreate yearEstablished(AnyOforgResoMetadataPropertyCreateYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
    return this;
  }

  /**
   * Get yearEstablished
   * @return yearEstablished
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateYearEstablished getYearEstablished() {
    return yearEstablished;
  }

  public void setYearEstablished(AnyOforgResoMetadataPropertyCreateYearEstablished yearEstablished) {
    this.yearEstablished = yearEstablished;
  }

  public OrgResoMetadataPropertyCreate yearsCurrentOwner(AnyOforgResoMetadataPropertyCreateYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
    return this;
  }

  /**
   * Get yearsCurrentOwner
   * @return yearsCurrentOwner
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyCreateYearsCurrentOwner getYearsCurrentOwner() {
    return yearsCurrentOwner;
  }

  public void setYearsCurrentOwner(AnyOforgResoMetadataPropertyCreateYearsCurrentOwner yearsCurrentOwner) {
    this.yearsCurrentOwner = yearsCurrentOwner;
  }

  public OrgResoMetadataPropertyCreate zoning(String zoning) {
    this.zoning = zoning;
    return this;
  }

  /**
   * Get zoning
   * @return zoning
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getZoning() {
    return zoning;
  }

  public void setZoning(String zoning) {
    this.zoning = zoning;
  }

  public OrgResoMetadataPropertyCreate zoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
    return this;
  }

  /**
   * Get zoningDescription
   * @return zoningDescription
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getZoningDescription() {
    return zoningDescription;
  }

  public void setZoningDescription(String zoningDescription) {
    this.zoningDescription = zoningDescription;
  }

  public OrgResoMetadataPropertyCreate originatingSystem(AnyOforgResoMetadataPropertyCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
    return this;
  }

  /**
   * Get originatingSystem
   * @return originatingSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateOriginatingSystem getOriginatingSystem() {
    return originatingSystem;
  }

  public void setOriginatingSystem(AnyOforgResoMetadataPropertyCreateOriginatingSystem originatingSystem) {
    this.originatingSystem = originatingSystem;
  }

  public OrgResoMetadataPropertyCreate buyerAgent(AnyOforgResoMetadataPropertyCreateBuyerAgent buyerAgent) {
    this.buyerAgent = buyerAgent;
    return this;
  }

  /**
   * Get buyerAgent
   * @return buyerAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerAgent getBuyerAgent() {
    return buyerAgent;
  }

  public void setBuyerAgent(AnyOforgResoMetadataPropertyCreateBuyerAgent buyerAgent) {
    this.buyerAgent = buyerAgent;
  }

  public OrgResoMetadataPropertyCreate buyerOffice(AnyOforgResoMetadataPropertyCreateBuyerOffice buyerOffice) {
    this.buyerOffice = buyerOffice;
    return this;
  }

  /**
   * Get buyerOffice
   * @return buyerOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerOffice getBuyerOffice() {
    return buyerOffice;
  }

  public void setBuyerOffice(AnyOforgResoMetadataPropertyCreateBuyerOffice buyerOffice) {
    this.buyerOffice = buyerOffice;
  }

  public OrgResoMetadataPropertyCreate coBuyerAgent(AnyOforgResoMetadataPropertyCreateCoBuyerAgent coBuyerAgent) {
    this.coBuyerAgent = coBuyerAgent;
    return this;
  }

  /**
   * Get coBuyerAgent
   * @return coBuyerAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerAgent getCoBuyerAgent() {
    return coBuyerAgent;
  }

  public void setCoBuyerAgent(AnyOforgResoMetadataPropertyCreateCoBuyerAgent coBuyerAgent) {
    this.coBuyerAgent = coBuyerAgent;
  }

  public OrgResoMetadataPropertyCreate coBuyerOffice(AnyOforgResoMetadataPropertyCreateCoBuyerOffice coBuyerOffice) {
    this.coBuyerOffice = coBuyerOffice;
    return this;
  }

  /**
   * Get coBuyerOffice
   * @return coBuyerOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoBuyerOffice getCoBuyerOffice() {
    return coBuyerOffice;
  }

  public void setCoBuyerOffice(AnyOforgResoMetadataPropertyCreateCoBuyerOffice coBuyerOffice) {
    this.coBuyerOffice = coBuyerOffice;
  }

  public OrgResoMetadataPropertyCreate coListAgent(AnyOforgResoMetadataPropertyCreateCoListAgent coListAgent) {
    this.coListAgent = coListAgent;
    return this;
  }

  /**
   * Get coListAgent
   * @return coListAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListAgent getCoListAgent() {
    return coListAgent;
  }

  public void setCoListAgent(AnyOforgResoMetadataPropertyCreateCoListAgent coListAgent) {
    this.coListAgent = coListAgent;
  }

  public OrgResoMetadataPropertyCreate coListOffice(AnyOforgResoMetadataPropertyCreateCoListOffice coListOffice) {
    this.coListOffice = coListOffice;
    return this;
  }

  /**
   * Get coListOffice
   * @return coListOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateCoListOffice getCoListOffice() {
    return coListOffice;
  }

  public void setCoListOffice(AnyOforgResoMetadataPropertyCreateCoListOffice coListOffice) {
    this.coListOffice = coListOffice;
  }

  public OrgResoMetadataPropertyCreate listAgent(AnyOforgResoMetadataPropertyCreateListAgent listAgent) {
    this.listAgent = listAgent;
    return this;
  }

  /**
   * Get listAgent
   * @return listAgent
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListAgent getListAgent() {
    return listAgent;
  }

  public void setListAgent(AnyOforgResoMetadataPropertyCreateListAgent listAgent) {
    this.listAgent = listAgent;
  }

  public OrgResoMetadataPropertyCreate listOffice(AnyOforgResoMetadataPropertyCreateListOffice listOffice) {
    this.listOffice = listOffice;
    return this;
  }

  /**
   * Get listOffice
   * @return listOffice
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListOffice getListOffice() {
    return listOffice;
  }

  public void setListOffice(AnyOforgResoMetadataPropertyCreateListOffice listOffice) {
    this.listOffice = listOffice;
  }

  public OrgResoMetadataPropertyCreate buyerTeam(AnyOforgResoMetadataPropertyCreateBuyerTeam buyerTeam) {
    this.buyerTeam = buyerTeam;
    return this;
  }

  /**
   * Get buyerTeam
   * @return buyerTeam
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateBuyerTeam getBuyerTeam() {
    return buyerTeam;
  }

  public void setBuyerTeam(AnyOforgResoMetadataPropertyCreateBuyerTeam buyerTeam) {
    this.buyerTeam = buyerTeam;
  }

  public OrgResoMetadataPropertyCreate listTeam(AnyOforgResoMetadataPropertyCreateListTeam listTeam) {
    this.listTeam = listTeam;
    return this;
  }

  /**
   * Get listTeam
   * @return listTeam
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateListTeam getListTeam() {
    return listTeam;
  }

  public void setListTeam(AnyOforgResoMetadataPropertyCreateListTeam listTeam) {
    this.listTeam = listTeam;
  }

  public OrgResoMetadataPropertyCreate sourceSystem(AnyOforgResoMetadataPropertyCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
    return this;
  }

  /**
   * Get sourceSystem
   * @return sourceSystem
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyCreateSourceSystem getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(AnyOforgResoMetadataPropertyCreateSourceSystem sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public OrgResoMetadataPropertyCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataPropertyCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }

  public OrgResoMetadataPropertyCreate media(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
    return this;
  }

  public OrgResoMetadataPropertyCreate addMediaItem(OrgResoMetadataMediaCreate mediaItem) {
    if (this.media == null) {
      this.media = new ArrayList<OrgResoMetadataMediaCreate>();
    }
    this.media.add(mediaItem);
    return this;
  }

  /**
   * Get media
   * @return media
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataMediaCreate> getMedia() {
    return media;
  }

  public void setMedia(List<OrgResoMetadataMediaCreate> media) {
    this.media = media;
  }

  public OrgResoMetadataPropertyCreate socialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
    return this;
  }

  public OrgResoMetadataPropertyCreate addSocialMediaItem(OrgResoMetadataSocialMediaCreate socialMediaItem) {
    if (this.socialMedia == null) {
      this.socialMedia = new ArrayList<OrgResoMetadataSocialMediaCreate>();
    }
    this.socialMedia.add(socialMediaItem);
    return this;
  }

  /**
   * Get socialMedia
   * @return socialMedia
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataSocialMediaCreate> getSocialMedia() {
    return socialMedia;
  }

  public void setSocialMedia(List<OrgResoMetadataSocialMediaCreate> socialMedia) {
    this.socialMedia = socialMedia;
  }

  public OrgResoMetadataPropertyCreate openHouse(List<OrgResoMetadataOpenHouseCreate> openHouse) {
    this.openHouse = openHouse;
    return this;
  }

  public OrgResoMetadataPropertyCreate addOpenHouseItem(OrgResoMetadataOpenHouseCreate openHouseItem) {
    if (this.openHouse == null) {
      this.openHouse = new ArrayList<OrgResoMetadataOpenHouseCreate>();
    }
    this.openHouse.add(openHouseItem);
    return this;
  }

  /**
   * Get openHouse
   * @return openHouse
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataOpenHouseCreate> getOpenHouse() {
    return openHouse;
  }

  public void setOpenHouse(List<OrgResoMetadataOpenHouseCreate> openHouse) {
    this.openHouse = openHouse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataPropertyCreate orgResoMetadataPropertyCreate = (OrgResoMetadataPropertyCreate) o;
    return Objects.equals(this.aboveGradeFinishedArea, orgResoMetadataPropertyCreate.aboveGradeFinishedArea) &&
        Objects.equals(this.aboveGradeFinishedAreaSource, orgResoMetadataPropertyCreate.aboveGradeFinishedAreaSource) &&
        Objects.equals(this.aboveGradeFinishedAreaUnits, orgResoMetadataPropertyCreate.aboveGradeFinishedAreaUnits) &&
        Objects.equals(this.accessCode, orgResoMetadataPropertyCreate.accessCode) &&
        Objects.equals(this.accessibilityFeatures, orgResoMetadataPropertyCreate.accessibilityFeatures) &&
        Objects.equals(this.additionalParcelsDescription, orgResoMetadataPropertyCreate.additionalParcelsDescription) &&
        Objects.equals(this.additionalParcelsYN, orgResoMetadataPropertyCreate.additionalParcelsYN) &&
        Objects.equals(this.anchorsCoTenants, orgResoMetadataPropertyCreate.anchorsCoTenants) &&
        Objects.equals(this.appliances, orgResoMetadataPropertyCreate.appliances) &&
        Objects.equals(this.architecturalStyle, orgResoMetadataPropertyCreate.architecturalStyle) &&
        Objects.equals(this.associationAmenities, orgResoMetadataPropertyCreate.associationAmenities) &&
        Objects.equals(this.associationFee, orgResoMetadataPropertyCreate.associationFee) &&
        Objects.equals(this.associationFee2, orgResoMetadataPropertyCreate.associationFee2) &&
        Objects.equals(this.associationFee2Frequency, orgResoMetadataPropertyCreate.associationFee2Frequency) &&
        Objects.equals(this.associationFeeFrequency, orgResoMetadataPropertyCreate.associationFeeFrequency) &&
        Objects.equals(this.associationFeeIncludes, orgResoMetadataPropertyCreate.associationFeeIncludes) &&
        Objects.equals(this.associationName, orgResoMetadataPropertyCreate.associationName) &&
        Objects.equals(this.associationName2, orgResoMetadataPropertyCreate.associationName2) &&
        Objects.equals(this.associationPhone, orgResoMetadataPropertyCreate.associationPhone) &&
        Objects.equals(this.associationPhone2, orgResoMetadataPropertyCreate.associationPhone2) &&
        Objects.equals(this.associationYN, orgResoMetadataPropertyCreate.associationYN) &&
        Objects.equals(this.attachedGarageYN, orgResoMetadataPropertyCreate.attachedGarageYN) &&
        Objects.equals(this.availabilityDate, orgResoMetadataPropertyCreate.availabilityDate) &&
        Objects.equals(this.basement, orgResoMetadataPropertyCreate.basement) &&
        Objects.equals(this.basementYN, orgResoMetadataPropertyCreate.basementYN) &&
        Objects.equals(this.bathroomsFull, orgResoMetadataPropertyCreate.bathroomsFull) &&
        Objects.equals(this.bathroomsHalf, orgResoMetadataPropertyCreate.bathroomsHalf) &&
        Objects.equals(this.bathroomsOneQuarter, orgResoMetadataPropertyCreate.bathroomsOneQuarter) &&
        Objects.equals(this.bathroomsPartial, orgResoMetadataPropertyCreate.bathroomsPartial) &&
        Objects.equals(this.bathroomsThreeQuarter, orgResoMetadataPropertyCreate.bathroomsThreeQuarter) &&
        Objects.equals(this.bathroomsTotalInteger, orgResoMetadataPropertyCreate.bathroomsTotalInteger) &&
        Objects.equals(this.bedroomsPossible, orgResoMetadataPropertyCreate.bedroomsPossible) &&
        Objects.equals(this.bedroomsTotal, orgResoMetadataPropertyCreate.bedroomsTotal) &&
        Objects.equals(this.belowGradeFinishedArea, orgResoMetadataPropertyCreate.belowGradeFinishedArea) &&
        Objects.equals(this.belowGradeFinishedAreaSource, orgResoMetadataPropertyCreate.belowGradeFinishedAreaSource) &&
        Objects.equals(this.belowGradeFinishedAreaUnits, orgResoMetadataPropertyCreate.belowGradeFinishedAreaUnits) &&
        Objects.equals(this.bodyType, orgResoMetadataPropertyCreate.bodyType) &&
        Objects.equals(this.builderModel, orgResoMetadataPropertyCreate.builderModel) &&
        Objects.equals(this.builderName, orgResoMetadataPropertyCreate.builderName) &&
        Objects.equals(this.buildingAreaSource, orgResoMetadataPropertyCreate.buildingAreaSource) &&
        Objects.equals(this.buildingAreaTotal, orgResoMetadataPropertyCreate.buildingAreaTotal) &&
        Objects.equals(this.buildingAreaUnits, orgResoMetadataPropertyCreate.buildingAreaUnits) &&
        Objects.equals(this.buildingFeatures, orgResoMetadataPropertyCreate.buildingFeatures) &&
        Objects.equals(this.buildingName, orgResoMetadataPropertyCreate.buildingName) &&
        Objects.equals(this.businessName, orgResoMetadataPropertyCreate.businessName) &&
        Objects.equals(this.businessType, orgResoMetadataPropertyCreate.businessType) &&
        Objects.equals(this.buyerAgencyCompensation, orgResoMetadataPropertyCreate.buyerAgencyCompensation) &&
        Objects.equals(this.buyerAgencyCompensationType, orgResoMetadataPropertyCreate.buyerAgencyCompensationType) &&
        Objects.equals(this.buyerAgentAOR, orgResoMetadataPropertyCreate.buyerAgentAOR) &&
        Objects.equals(this.buyerAgentDesignation, orgResoMetadataPropertyCreate.buyerAgentDesignation) &&
        Objects.equals(this.buyerAgentDirectPhone, orgResoMetadataPropertyCreate.buyerAgentDirectPhone) &&
        Objects.equals(this.buyerAgentEmail, orgResoMetadataPropertyCreate.buyerAgentEmail) &&
        Objects.equals(this.buyerAgentFax, orgResoMetadataPropertyCreate.buyerAgentFax) &&
        Objects.equals(this.buyerAgentFirstName, orgResoMetadataPropertyCreate.buyerAgentFirstName) &&
        Objects.equals(this.buyerAgentFullName, orgResoMetadataPropertyCreate.buyerAgentFullName) &&
        Objects.equals(this.buyerAgentHomePhone, orgResoMetadataPropertyCreate.buyerAgentHomePhone) &&
        Objects.equals(this.buyerAgentKey, orgResoMetadataPropertyCreate.buyerAgentKey) &&
        Objects.equals(this.buyerAgentKeyNumeric, orgResoMetadataPropertyCreate.buyerAgentKeyNumeric) &&
        Objects.equals(this.buyerAgentLastName, orgResoMetadataPropertyCreate.buyerAgentLastName) &&
        Objects.equals(this.buyerAgentMiddleName, orgResoMetadataPropertyCreate.buyerAgentMiddleName) &&
        Objects.equals(this.buyerAgentMlsId, orgResoMetadataPropertyCreate.buyerAgentMlsId) &&
        Objects.equals(this.buyerAgentMobilePhone, orgResoMetadataPropertyCreate.buyerAgentMobilePhone) &&
        Objects.equals(this.buyerAgentNamePrefix, orgResoMetadataPropertyCreate.buyerAgentNamePrefix) &&
        Objects.equals(this.buyerAgentNameSuffix, orgResoMetadataPropertyCreate.buyerAgentNameSuffix) &&
        Objects.equals(this.buyerAgentOfficePhone, orgResoMetadataPropertyCreate.buyerAgentOfficePhone) &&
        Objects.equals(this.buyerAgentOfficePhoneExt, orgResoMetadataPropertyCreate.buyerAgentOfficePhoneExt) &&
        Objects.equals(this.buyerAgentPager, orgResoMetadataPropertyCreate.buyerAgentPager) &&
        Objects.equals(this.buyerAgentPreferredPhone, orgResoMetadataPropertyCreate.buyerAgentPreferredPhone) &&
        Objects.equals(this.buyerAgentPreferredPhoneExt, orgResoMetadataPropertyCreate.buyerAgentPreferredPhoneExt) &&
        Objects.equals(this.buyerAgentStateLicense, orgResoMetadataPropertyCreate.buyerAgentStateLicense) &&
        Objects.equals(this.buyerAgentTollFreePhone, orgResoMetadataPropertyCreate.buyerAgentTollFreePhone) &&
        Objects.equals(this.buyerAgentURL, orgResoMetadataPropertyCreate.buyerAgentURL) &&
        Objects.equals(this.buyerAgentVoiceMail, orgResoMetadataPropertyCreate.buyerAgentVoiceMail) &&
        Objects.equals(this.buyerAgentVoiceMailExt, orgResoMetadataPropertyCreate.buyerAgentVoiceMailExt) &&
        Objects.equals(this.buyerFinancing, orgResoMetadataPropertyCreate.buyerFinancing) &&
        Objects.equals(this.buyerOfficeAOR, orgResoMetadataPropertyCreate.buyerOfficeAOR) &&
        Objects.equals(this.buyerOfficeEmail, orgResoMetadataPropertyCreate.buyerOfficeEmail) &&
        Objects.equals(this.buyerOfficeFax, orgResoMetadataPropertyCreate.buyerOfficeFax) &&
        Objects.equals(this.buyerOfficeKey, orgResoMetadataPropertyCreate.buyerOfficeKey) &&
        Objects.equals(this.buyerOfficeKeyNumeric, orgResoMetadataPropertyCreate.buyerOfficeKeyNumeric) &&
        Objects.equals(this.buyerOfficeMlsId, orgResoMetadataPropertyCreate.buyerOfficeMlsId) &&
        Objects.equals(this.buyerOfficeName, orgResoMetadataPropertyCreate.buyerOfficeName) &&
        Objects.equals(this.buyerOfficePhone, orgResoMetadataPropertyCreate.buyerOfficePhone) &&
        Objects.equals(this.buyerOfficePhoneExt, orgResoMetadataPropertyCreate.buyerOfficePhoneExt) &&
        Objects.equals(this.buyerOfficeURL, orgResoMetadataPropertyCreate.buyerOfficeURL) &&
        Objects.equals(this.buyerTeamKey, orgResoMetadataPropertyCreate.buyerTeamKey) &&
        Objects.equals(this.buyerTeamKeyNumeric, orgResoMetadataPropertyCreate.buyerTeamKeyNumeric) &&
        Objects.equals(this.buyerTeamName, orgResoMetadataPropertyCreate.buyerTeamName) &&
        Objects.equals(this.cableTvExpense, orgResoMetadataPropertyCreate.cableTvExpense) &&
        Objects.equals(this.cancellationDate, orgResoMetadataPropertyCreate.cancellationDate) &&
        Objects.equals(this.capRate, orgResoMetadataPropertyCreate.capRate) &&
        Objects.equals(this.carportSpaces, orgResoMetadataPropertyCreate.carportSpaces) &&
        Objects.equals(this.carportYN, orgResoMetadataPropertyCreate.carportYN) &&
        Objects.equals(this.carrierRoute, orgResoMetadataPropertyCreate.carrierRoute) &&
        Objects.equals(this.city, orgResoMetadataPropertyCreate.city) &&
        Objects.equals(this.cityRegion, orgResoMetadataPropertyCreate.cityRegion) &&
        Objects.equals(this.closeDate, orgResoMetadataPropertyCreate.closeDate) &&
        Objects.equals(this.closePrice, orgResoMetadataPropertyCreate.closePrice) &&
        Objects.equals(this.coBuyerAgentAOR, orgResoMetadataPropertyCreate.coBuyerAgentAOR) &&
        Objects.equals(this.coBuyerAgentDesignation, orgResoMetadataPropertyCreate.coBuyerAgentDesignation) &&
        Objects.equals(this.coBuyerAgentDirectPhone, orgResoMetadataPropertyCreate.coBuyerAgentDirectPhone) &&
        Objects.equals(this.coBuyerAgentEmail, orgResoMetadataPropertyCreate.coBuyerAgentEmail) &&
        Objects.equals(this.coBuyerAgentFax, orgResoMetadataPropertyCreate.coBuyerAgentFax) &&
        Objects.equals(this.coBuyerAgentFirstName, orgResoMetadataPropertyCreate.coBuyerAgentFirstName) &&
        Objects.equals(this.coBuyerAgentFullName, orgResoMetadataPropertyCreate.coBuyerAgentFullName) &&
        Objects.equals(this.coBuyerAgentHomePhone, orgResoMetadataPropertyCreate.coBuyerAgentHomePhone) &&
        Objects.equals(this.coBuyerAgentKey, orgResoMetadataPropertyCreate.coBuyerAgentKey) &&
        Objects.equals(this.coBuyerAgentKeyNumeric, orgResoMetadataPropertyCreate.coBuyerAgentKeyNumeric) &&
        Objects.equals(this.coBuyerAgentLastName, orgResoMetadataPropertyCreate.coBuyerAgentLastName) &&
        Objects.equals(this.coBuyerAgentMiddleName, orgResoMetadataPropertyCreate.coBuyerAgentMiddleName) &&
        Objects.equals(this.coBuyerAgentMlsId, orgResoMetadataPropertyCreate.coBuyerAgentMlsId) &&
        Objects.equals(this.coBuyerAgentMobilePhone, orgResoMetadataPropertyCreate.coBuyerAgentMobilePhone) &&
        Objects.equals(this.coBuyerAgentNamePrefix, orgResoMetadataPropertyCreate.coBuyerAgentNamePrefix) &&
        Objects.equals(this.coBuyerAgentNameSuffix, orgResoMetadataPropertyCreate.coBuyerAgentNameSuffix) &&
        Objects.equals(this.coBuyerAgentOfficePhone, orgResoMetadataPropertyCreate.coBuyerAgentOfficePhone) &&
        Objects.equals(this.coBuyerAgentOfficePhoneExt, orgResoMetadataPropertyCreate.coBuyerAgentOfficePhoneExt) &&
        Objects.equals(this.coBuyerAgentPager, orgResoMetadataPropertyCreate.coBuyerAgentPager) &&
        Objects.equals(this.coBuyerAgentPreferredPhone, orgResoMetadataPropertyCreate.coBuyerAgentPreferredPhone) &&
        Objects.equals(this.coBuyerAgentPreferredPhoneExt, orgResoMetadataPropertyCreate.coBuyerAgentPreferredPhoneExt) &&
        Objects.equals(this.coBuyerAgentStateLicense, orgResoMetadataPropertyCreate.coBuyerAgentStateLicense) &&
        Objects.equals(this.coBuyerAgentTollFreePhone, orgResoMetadataPropertyCreate.coBuyerAgentTollFreePhone) &&
        Objects.equals(this.coBuyerAgentURL, orgResoMetadataPropertyCreate.coBuyerAgentURL) &&
        Objects.equals(this.coBuyerAgentVoiceMail, orgResoMetadataPropertyCreate.coBuyerAgentVoiceMail) &&
        Objects.equals(this.coBuyerAgentVoiceMailExt, orgResoMetadataPropertyCreate.coBuyerAgentVoiceMailExt) &&
        Objects.equals(this.coBuyerOfficeAOR, orgResoMetadataPropertyCreate.coBuyerOfficeAOR) &&
        Objects.equals(this.coBuyerOfficeEmail, orgResoMetadataPropertyCreate.coBuyerOfficeEmail) &&
        Objects.equals(this.coBuyerOfficeFax, orgResoMetadataPropertyCreate.coBuyerOfficeFax) &&
        Objects.equals(this.coBuyerOfficeKey, orgResoMetadataPropertyCreate.coBuyerOfficeKey) &&
        Objects.equals(this.coBuyerOfficeKeyNumeric, orgResoMetadataPropertyCreate.coBuyerOfficeKeyNumeric) &&
        Objects.equals(this.coBuyerOfficeMlsId, orgResoMetadataPropertyCreate.coBuyerOfficeMlsId) &&
        Objects.equals(this.coBuyerOfficeName, orgResoMetadataPropertyCreate.coBuyerOfficeName) &&
        Objects.equals(this.coBuyerOfficePhone, orgResoMetadataPropertyCreate.coBuyerOfficePhone) &&
        Objects.equals(this.coBuyerOfficePhoneExt, orgResoMetadataPropertyCreate.coBuyerOfficePhoneExt) &&
        Objects.equals(this.coBuyerOfficeURL, orgResoMetadataPropertyCreate.coBuyerOfficeURL) &&
        Objects.equals(this.coListAgentAOR, orgResoMetadataPropertyCreate.coListAgentAOR) &&
        Objects.equals(this.coListAgentDesignation, orgResoMetadataPropertyCreate.coListAgentDesignation) &&
        Objects.equals(this.coListAgentDirectPhone, orgResoMetadataPropertyCreate.coListAgentDirectPhone) &&
        Objects.equals(this.coListAgentEmail, orgResoMetadataPropertyCreate.coListAgentEmail) &&
        Objects.equals(this.coListAgentFax, orgResoMetadataPropertyCreate.coListAgentFax) &&
        Objects.equals(this.coListAgentFirstName, orgResoMetadataPropertyCreate.coListAgentFirstName) &&
        Objects.equals(this.coListAgentFullName, orgResoMetadataPropertyCreate.coListAgentFullName) &&
        Objects.equals(this.coListAgentHomePhone, orgResoMetadataPropertyCreate.coListAgentHomePhone) &&
        Objects.equals(this.coListAgentKey, orgResoMetadataPropertyCreate.coListAgentKey) &&
        Objects.equals(this.coListAgentKeyNumeric, orgResoMetadataPropertyCreate.coListAgentKeyNumeric) &&
        Objects.equals(this.coListAgentLastName, orgResoMetadataPropertyCreate.coListAgentLastName) &&
        Objects.equals(this.coListAgentMiddleName, orgResoMetadataPropertyCreate.coListAgentMiddleName) &&
        Objects.equals(this.coListAgentMlsId, orgResoMetadataPropertyCreate.coListAgentMlsId) &&
        Objects.equals(this.coListAgentMobilePhone, orgResoMetadataPropertyCreate.coListAgentMobilePhone) &&
        Objects.equals(this.coListAgentNamePrefix, orgResoMetadataPropertyCreate.coListAgentNamePrefix) &&
        Objects.equals(this.coListAgentNameSuffix, orgResoMetadataPropertyCreate.coListAgentNameSuffix) &&
        Objects.equals(this.coListAgentOfficePhone, orgResoMetadataPropertyCreate.coListAgentOfficePhone) &&
        Objects.equals(this.coListAgentOfficePhoneExt, orgResoMetadataPropertyCreate.coListAgentOfficePhoneExt) &&
        Objects.equals(this.coListAgentPager, orgResoMetadataPropertyCreate.coListAgentPager) &&
        Objects.equals(this.coListAgentPreferredPhone, orgResoMetadataPropertyCreate.coListAgentPreferredPhone) &&
        Objects.equals(this.coListAgentPreferredPhoneExt, orgResoMetadataPropertyCreate.coListAgentPreferredPhoneExt) &&
        Objects.equals(this.coListAgentStateLicense, orgResoMetadataPropertyCreate.coListAgentStateLicense) &&
        Objects.equals(this.coListAgentTollFreePhone, orgResoMetadataPropertyCreate.coListAgentTollFreePhone) &&
        Objects.equals(this.coListAgentURL, orgResoMetadataPropertyCreate.coListAgentURL) &&
        Objects.equals(this.coListAgentVoiceMail, orgResoMetadataPropertyCreate.coListAgentVoiceMail) &&
        Objects.equals(this.coListAgentVoiceMailExt, orgResoMetadataPropertyCreate.coListAgentVoiceMailExt) &&
        Objects.equals(this.coListOfficeAOR, orgResoMetadataPropertyCreate.coListOfficeAOR) &&
        Objects.equals(this.coListOfficeEmail, orgResoMetadataPropertyCreate.coListOfficeEmail) &&
        Objects.equals(this.coListOfficeFax, orgResoMetadataPropertyCreate.coListOfficeFax) &&
        Objects.equals(this.coListOfficeKey, orgResoMetadataPropertyCreate.coListOfficeKey) &&
        Objects.equals(this.coListOfficeKeyNumeric, orgResoMetadataPropertyCreate.coListOfficeKeyNumeric) &&
        Objects.equals(this.coListOfficeMlsId, orgResoMetadataPropertyCreate.coListOfficeMlsId) &&
        Objects.equals(this.coListOfficeName, orgResoMetadataPropertyCreate.coListOfficeName) &&
        Objects.equals(this.coListOfficePhone, orgResoMetadataPropertyCreate.coListOfficePhone) &&
        Objects.equals(this.coListOfficePhoneExt, orgResoMetadataPropertyCreate.coListOfficePhoneExt) &&
        Objects.equals(this.coListOfficeURL, orgResoMetadataPropertyCreate.coListOfficeURL) &&
        Objects.equals(this.commonInterest, orgResoMetadataPropertyCreate.commonInterest) &&
        Objects.equals(this.commonWalls, orgResoMetadataPropertyCreate.commonWalls) &&
        Objects.equals(this.communityFeatures, orgResoMetadataPropertyCreate.communityFeatures) &&
        Objects.equals(this.concessions, orgResoMetadataPropertyCreate.concessions) &&
        Objects.equals(this.concessionsAmount, orgResoMetadataPropertyCreate.concessionsAmount) &&
        Objects.equals(this.concessionsComments, orgResoMetadataPropertyCreate.concessionsComments) &&
        Objects.equals(this.constructionMaterials, orgResoMetadataPropertyCreate.constructionMaterials) &&
        Objects.equals(this.continentRegion, orgResoMetadataPropertyCreate.continentRegion) &&
        Objects.equals(this.contingency, orgResoMetadataPropertyCreate.contingency) &&
        Objects.equals(this.contingentDate, orgResoMetadataPropertyCreate.contingentDate) &&
        Objects.equals(this.contractStatusChangeDate, orgResoMetadataPropertyCreate.contractStatusChangeDate) &&
        Objects.equals(this.cooling, orgResoMetadataPropertyCreate.cooling) &&
        Objects.equals(this.coolingYN, orgResoMetadataPropertyCreate.coolingYN) &&
        Objects.equals(this.copyrightNotice, orgResoMetadataPropertyCreate.copyrightNotice) &&
        Objects.equals(this.country, orgResoMetadataPropertyCreate.country) &&
        Objects.equals(this.countryRegion, orgResoMetadataPropertyCreate.countryRegion) &&
        Objects.equals(this.countyOrParish, orgResoMetadataPropertyCreate.countyOrParish) &&
        Objects.equals(this.coveredSpaces, orgResoMetadataPropertyCreate.coveredSpaces) &&
        Objects.equals(this.cropsIncludedYN, orgResoMetadataPropertyCreate.cropsIncludedYN) &&
        Objects.equals(this.crossStreet, orgResoMetadataPropertyCreate.crossStreet) &&
        Objects.equals(this.cultivatedArea, orgResoMetadataPropertyCreate.cultivatedArea) &&
        Objects.equals(this.cumulativeDaysOnMarket, orgResoMetadataPropertyCreate.cumulativeDaysOnMarket) &&
        Objects.equals(this.currentFinancing, orgResoMetadataPropertyCreate.currentFinancing) &&
        Objects.equals(this.currentUse, orgResoMetadataPropertyCreate.currentUse) &&
        Objects.equals(this.doH1, orgResoMetadataPropertyCreate.doH1) &&
        Objects.equals(this.doH2, orgResoMetadataPropertyCreate.doH2) &&
        Objects.equals(this.doH3, orgResoMetadataPropertyCreate.doH3) &&
        Objects.equals(this.daysOnMarket, orgResoMetadataPropertyCreate.daysOnMarket) &&
        Objects.equals(this.developmentStatus, orgResoMetadataPropertyCreate.developmentStatus) &&
        Objects.equals(this.directionFaces, orgResoMetadataPropertyCreate.directionFaces) &&
        Objects.equals(this.directions, orgResoMetadataPropertyCreate.directions) &&
        Objects.equals(this.disclaimer, orgResoMetadataPropertyCreate.disclaimer) &&
        Objects.equals(this.disclosures, orgResoMetadataPropertyCreate.disclosures) &&
        Objects.equals(this.distanceToBusComments, orgResoMetadataPropertyCreate.distanceToBusComments) &&
        Objects.equals(this.distanceToBusNumeric, orgResoMetadataPropertyCreate.distanceToBusNumeric) &&
        Objects.equals(this.distanceToBusUnits, orgResoMetadataPropertyCreate.distanceToBusUnits) &&
        Objects.equals(this.distanceToElectricComments, orgResoMetadataPropertyCreate.distanceToElectricComments) &&
        Objects.equals(this.distanceToElectricNumeric, orgResoMetadataPropertyCreate.distanceToElectricNumeric) &&
        Objects.equals(this.distanceToElectricUnits, orgResoMetadataPropertyCreate.distanceToElectricUnits) &&
        Objects.equals(this.distanceToFreewayComments, orgResoMetadataPropertyCreate.distanceToFreewayComments) &&
        Objects.equals(this.distanceToFreewayNumeric, orgResoMetadataPropertyCreate.distanceToFreewayNumeric) &&
        Objects.equals(this.distanceToFreewayUnits, orgResoMetadataPropertyCreate.distanceToFreewayUnits) &&
        Objects.equals(this.distanceToGasComments, orgResoMetadataPropertyCreate.distanceToGasComments) &&
        Objects.equals(this.distanceToGasNumeric, orgResoMetadataPropertyCreate.distanceToGasNumeric) &&
        Objects.equals(this.distanceToGasUnits, orgResoMetadataPropertyCreate.distanceToGasUnits) &&
        Objects.equals(this.distanceToPhoneServiceComments, orgResoMetadataPropertyCreate.distanceToPhoneServiceComments) &&
        Objects.equals(this.distanceToPhoneServiceNumeric, orgResoMetadataPropertyCreate.distanceToPhoneServiceNumeric) &&
        Objects.equals(this.distanceToPhoneServiceUnits, orgResoMetadataPropertyCreate.distanceToPhoneServiceUnits) &&
        Objects.equals(this.distanceToPlaceofWorshipComments, orgResoMetadataPropertyCreate.distanceToPlaceofWorshipComments) &&
        Objects.equals(this.distanceToPlaceofWorshipNumeric, orgResoMetadataPropertyCreate.distanceToPlaceofWorshipNumeric) &&
        Objects.equals(this.distanceToPlaceofWorshipUnits, orgResoMetadataPropertyCreate.distanceToPlaceofWorshipUnits) &&
        Objects.equals(this.distanceToSchoolBusComments, orgResoMetadataPropertyCreate.distanceToSchoolBusComments) &&
        Objects.equals(this.distanceToSchoolBusNumeric, orgResoMetadataPropertyCreate.distanceToSchoolBusNumeric) &&
        Objects.equals(this.distanceToSchoolBusUnits, orgResoMetadataPropertyCreate.distanceToSchoolBusUnits) &&
        Objects.equals(this.distanceToSchoolsComments, orgResoMetadataPropertyCreate.distanceToSchoolsComments) &&
        Objects.equals(this.distanceToSchoolsNumeric, orgResoMetadataPropertyCreate.distanceToSchoolsNumeric) &&
        Objects.equals(this.distanceToSchoolsUnits, orgResoMetadataPropertyCreate.distanceToSchoolsUnits) &&
        Objects.equals(this.distanceToSewerComments, orgResoMetadataPropertyCreate.distanceToSewerComments) &&
        Objects.equals(this.distanceToSewerNumeric, orgResoMetadataPropertyCreate.distanceToSewerNumeric) &&
        Objects.equals(this.distanceToSewerUnits, orgResoMetadataPropertyCreate.distanceToSewerUnits) &&
        Objects.equals(this.distanceToShoppingComments, orgResoMetadataPropertyCreate.distanceToShoppingComments) &&
        Objects.equals(this.distanceToShoppingNumeric, orgResoMetadataPropertyCreate.distanceToShoppingNumeric) &&
        Objects.equals(this.distanceToShoppingUnits, orgResoMetadataPropertyCreate.distanceToShoppingUnits) &&
        Objects.equals(this.distanceToStreetComments, orgResoMetadataPropertyCreate.distanceToStreetComments) &&
        Objects.equals(this.distanceToStreetNumeric, orgResoMetadataPropertyCreate.distanceToStreetNumeric) &&
        Objects.equals(this.distanceToStreetUnits, orgResoMetadataPropertyCreate.distanceToStreetUnits) &&
        Objects.equals(this.distanceToWaterComments, orgResoMetadataPropertyCreate.distanceToWaterComments) &&
        Objects.equals(this.distanceToWaterNumeric, orgResoMetadataPropertyCreate.distanceToWaterNumeric) &&
        Objects.equals(this.distanceToWaterUnits, orgResoMetadataPropertyCreate.distanceToWaterUnits) &&
        Objects.equals(this.documentsAvailable, orgResoMetadataPropertyCreate.documentsAvailable) &&
        Objects.equals(this.documentsChangeTimestamp, orgResoMetadataPropertyCreate.documentsChangeTimestamp) &&
        Objects.equals(this.documentsCount, orgResoMetadataPropertyCreate.documentsCount) &&
        Objects.equals(this.doorFeatures, orgResoMetadataPropertyCreate.doorFeatures) &&
        Objects.equals(this.dualVariableCompensationYN, orgResoMetadataPropertyCreate.dualVariableCompensationYN) &&
        Objects.equals(this.electric, orgResoMetadataPropertyCreate.electric) &&
        Objects.equals(this.electricExpense, orgResoMetadataPropertyCreate.electricExpense) &&
        Objects.equals(this.electricOnPropertyYN, orgResoMetadataPropertyCreate.electricOnPropertyYN) &&
        Objects.equals(this.elementarySchool, orgResoMetadataPropertyCreate.elementarySchool) &&
        Objects.equals(this.elementarySchoolDistrict, orgResoMetadataPropertyCreate.elementarySchoolDistrict) &&
        Objects.equals(this.elevation, orgResoMetadataPropertyCreate.elevation) &&
        Objects.equals(this.elevationUnits, orgResoMetadataPropertyCreate.elevationUnits) &&
        Objects.equals(this.entryLevel, orgResoMetadataPropertyCreate.entryLevel) &&
        Objects.equals(this.entryLocation, orgResoMetadataPropertyCreate.entryLocation) &&
        Objects.equals(this.exclusions, orgResoMetadataPropertyCreate.exclusions) &&
        Objects.equals(this.existingLeaseType, orgResoMetadataPropertyCreate.existingLeaseType) &&
        Objects.equals(this.expirationDate, orgResoMetadataPropertyCreate.expirationDate) &&
        Objects.equals(this.exteriorFeatures, orgResoMetadataPropertyCreate.exteriorFeatures) &&
        Objects.equals(this.farmCreditServiceInclYN, orgResoMetadataPropertyCreate.farmCreditServiceInclYN) &&
        Objects.equals(this.farmLandAreaSource, orgResoMetadataPropertyCreate.farmLandAreaSource) &&
        Objects.equals(this.farmLandAreaUnits, orgResoMetadataPropertyCreate.farmLandAreaUnits) &&
        Objects.equals(this.fencing, orgResoMetadataPropertyCreate.fencing) &&
        Objects.equals(this.financialDataSource, orgResoMetadataPropertyCreate.financialDataSource) &&
        Objects.equals(this.fireplaceFeatures, orgResoMetadataPropertyCreate.fireplaceFeatures) &&
        Objects.equals(this.fireplaceYN, orgResoMetadataPropertyCreate.fireplaceYN) &&
        Objects.equals(this.fireplacesTotal, orgResoMetadataPropertyCreate.fireplacesTotal) &&
        Objects.equals(this.flooring, orgResoMetadataPropertyCreate.flooring) &&
        Objects.equals(this.foundationArea, orgResoMetadataPropertyCreate.foundationArea) &&
        Objects.equals(this.foundationDetails, orgResoMetadataPropertyCreate.foundationDetails) &&
        Objects.equals(this.frontageLength, orgResoMetadataPropertyCreate.frontageLength) &&
        Objects.equals(this.frontageType, orgResoMetadataPropertyCreate.frontageType) &&
        Objects.equals(this.fuelExpense, orgResoMetadataPropertyCreate.fuelExpense) &&
        Objects.equals(this.furnished, orgResoMetadataPropertyCreate.furnished) &&
        Objects.equals(this.furnitureReplacementExpense, orgResoMetadataPropertyCreate.furnitureReplacementExpense) &&
        Objects.equals(this.garageSpaces, orgResoMetadataPropertyCreate.garageSpaces) &&
        Objects.equals(this.garageYN, orgResoMetadataPropertyCreate.garageYN) &&
        Objects.equals(this.gardenerExpense, orgResoMetadataPropertyCreate.gardenerExpense) &&
        Objects.equals(this.grazingPermitsBlmYN, orgResoMetadataPropertyCreate.grazingPermitsBlmYN) &&
        Objects.equals(this.grazingPermitsForestServiceYN, orgResoMetadataPropertyCreate.grazingPermitsForestServiceYN) &&
        Objects.equals(this.grazingPermitsPrivateYN, orgResoMetadataPropertyCreate.grazingPermitsPrivateYN) &&
        Objects.equals(this.greenBuildingVerificationType, orgResoMetadataPropertyCreate.greenBuildingVerificationType) &&
        Objects.equals(this.greenEnergyEfficient, orgResoMetadataPropertyCreate.greenEnergyEfficient) &&
        Objects.equals(this.greenEnergyGeneration, orgResoMetadataPropertyCreate.greenEnergyGeneration) &&
        Objects.equals(this.greenIndoorAirQuality, orgResoMetadataPropertyCreate.greenIndoorAirQuality) &&
        Objects.equals(this.greenLocation, orgResoMetadataPropertyCreate.greenLocation) &&
        Objects.equals(this.greenSustainability, orgResoMetadataPropertyCreate.greenSustainability) &&
        Objects.equals(this.greenWaterConservation, orgResoMetadataPropertyCreate.greenWaterConservation) &&
        Objects.equals(this.grossIncome, orgResoMetadataPropertyCreate.grossIncome) &&
        Objects.equals(this.grossScheduledIncome, orgResoMetadataPropertyCreate.grossScheduledIncome) &&
        Objects.equals(this.habitableResidenceYN, orgResoMetadataPropertyCreate.habitableResidenceYN) &&
        Objects.equals(this.heating, orgResoMetadataPropertyCreate.heating) &&
        Objects.equals(this.heatingYN, orgResoMetadataPropertyCreate.heatingYN) &&
        Objects.equals(this.highSchool, orgResoMetadataPropertyCreate.highSchool) &&
        Objects.equals(this.highSchoolDistrict, orgResoMetadataPropertyCreate.highSchoolDistrict) &&
        Objects.equals(this.homeWarrantyYN, orgResoMetadataPropertyCreate.homeWarrantyYN) &&
        Objects.equals(this.horseAmenities, orgResoMetadataPropertyCreate.horseAmenities) &&
        Objects.equals(this.horseYN, orgResoMetadataPropertyCreate.horseYN) &&
        Objects.equals(this.hoursDaysOfOperation, orgResoMetadataPropertyCreate.hoursDaysOfOperation) &&
        Objects.equals(this.hoursDaysOfOperationDescription, orgResoMetadataPropertyCreate.hoursDaysOfOperationDescription) &&
        Objects.equals(this.inclusions, orgResoMetadataPropertyCreate.inclusions) &&
        Objects.equals(this.incomeIncludes, orgResoMetadataPropertyCreate.incomeIncludes) &&
        Objects.equals(this.insuranceExpense, orgResoMetadataPropertyCreate.insuranceExpense) &&
        Objects.equals(this.interiorFeatures, orgResoMetadataPropertyCreate.interiorFeatures) &&
        Objects.equals(this.internetAddressDisplayYN, orgResoMetadataPropertyCreate.internetAddressDisplayYN) &&
        Objects.equals(this.internetAutomatedValuationDisplayYN, orgResoMetadataPropertyCreate.internetAutomatedValuationDisplayYN) &&
        Objects.equals(this.internetConsumerCommentYN, orgResoMetadataPropertyCreate.internetConsumerCommentYN) &&
        Objects.equals(this.internetEntireListingDisplayYN, orgResoMetadataPropertyCreate.internetEntireListingDisplayYN) &&
        Objects.equals(this.irrigationSource, orgResoMetadataPropertyCreate.irrigationSource) &&
        Objects.equals(this.irrigationWaterRightsAcres, orgResoMetadataPropertyCreate.irrigationWaterRightsAcres) &&
        Objects.equals(this.irrigationWaterRightsYN, orgResoMetadataPropertyCreate.irrigationWaterRightsYN) &&
        Objects.equals(this.laborInformation, orgResoMetadataPropertyCreate.laborInformation) &&
        Objects.equals(this.landLeaseAmount, orgResoMetadataPropertyCreate.landLeaseAmount) &&
        Objects.equals(this.landLeaseAmountFrequency, orgResoMetadataPropertyCreate.landLeaseAmountFrequency) &&
        Objects.equals(this.landLeaseExpirationDate, orgResoMetadataPropertyCreate.landLeaseExpirationDate) &&
        Objects.equals(this.landLeaseYN, orgResoMetadataPropertyCreate.landLeaseYN) &&
        Objects.equals(this.latitude, orgResoMetadataPropertyCreate.latitude) &&
        Objects.equals(this.laundryFeatures, orgResoMetadataPropertyCreate.laundryFeatures) &&
        Objects.equals(this.leasableArea, orgResoMetadataPropertyCreate.leasableArea) &&
        Objects.equals(this.leasableAreaUnits, orgResoMetadataPropertyCreate.leasableAreaUnits) &&
        Objects.equals(this.leaseAmount, orgResoMetadataPropertyCreate.leaseAmount) &&
        Objects.equals(this.leaseAmountFrequency, orgResoMetadataPropertyCreate.leaseAmountFrequency) &&
        Objects.equals(this.leaseAssignableYN, orgResoMetadataPropertyCreate.leaseAssignableYN) &&
        Objects.equals(this.leaseConsideredYN, orgResoMetadataPropertyCreate.leaseConsideredYN) &&
        Objects.equals(this.leaseExpiration, orgResoMetadataPropertyCreate.leaseExpiration) &&
        Objects.equals(this.leaseRenewalCompensation, orgResoMetadataPropertyCreate.leaseRenewalCompensation) &&
        Objects.equals(this.leaseRenewalOptionYN, orgResoMetadataPropertyCreate.leaseRenewalOptionYN) &&
        Objects.equals(this.leaseTerm, orgResoMetadataPropertyCreate.leaseTerm) &&
        Objects.equals(this.levels, orgResoMetadataPropertyCreate.levels) &&
        Objects.equals(this.license1, orgResoMetadataPropertyCreate.license1) &&
        Objects.equals(this.license2, orgResoMetadataPropertyCreate.license2) &&
        Objects.equals(this.license3, orgResoMetadataPropertyCreate.license3) &&
        Objects.equals(this.licensesExpense, orgResoMetadataPropertyCreate.licensesExpense) &&
        Objects.equals(this.listAOR, orgResoMetadataPropertyCreate.listAOR) &&
        Objects.equals(this.listAgentAOR, orgResoMetadataPropertyCreate.listAgentAOR) &&
        Objects.equals(this.listAgentDesignation, orgResoMetadataPropertyCreate.listAgentDesignation) &&
        Objects.equals(this.listAgentDirectPhone, orgResoMetadataPropertyCreate.listAgentDirectPhone) &&
        Objects.equals(this.listAgentEmail, orgResoMetadataPropertyCreate.listAgentEmail) &&
        Objects.equals(this.listAgentFax, orgResoMetadataPropertyCreate.listAgentFax) &&
        Objects.equals(this.listAgentFirstName, orgResoMetadataPropertyCreate.listAgentFirstName) &&
        Objects.equals(this.listAgentFullName, orgResoMetadataPropertyCreate.listAgentFullName) &&
        Objects.equals(this.listAgentHomePhone, orgResoMetadataPropertyCreate.listAgentHomePhone) &&
        Objects.equals(this.listAgentKey, orgResoMetadataPropertyCreate.listAgentKey) &&
        Objects.equals(this.listAgentKeyNumeric, orgResoMetadataPropertyCreate.listAgentKeyNumeric) &&
        Objects.equals(this.listAgentLastName, orgResoMetadataPropertyCreate.listAgentLastName) &&
        Objects.equals(this.listAgentMiddleName, orgResoMetadataPropertyCreate.listAgentMiddleName) &&
        Objects.equals(this.listAgentMlsId, orgResoMetadataPropertyCreate.listAgentMlsId) &&
        Objects.equals(this.listAgentMobilePhone, orgResoMetadataPropertyCreate.listAgentMobilePhone) &&
        Objects.equals(this.listAgentNamePrefix, orgResoMetadataPropertyCreate.listAgentNamePrefix) &&
        Objects.equals(this.listAgentNameSuffix, orgResoMetadataPropertyCreate.listAgentNameSuffix) &&
        Objects.equals(this.listAgentOfficePhone, orgResoMetadataPropertyCreate.listAgentOfficePhone) &&
        Objects.equals(this.listAgentOfficePhoneExt, orgResoMetadataPropertyCreate.listAgentOfficePhoneExt) &&
        Objects.equals(this.listAgentPager, orgResoMetadataPropertyCreate.listAgentPager) &&
        Objects.equals(this.listAgentPreferredPhone, orgResoMetadataPropertyCreate.listAgentPreferredPhone) &&
        Objects.equals(this.listAgentPreferredPhoneExt, orgResoMetadataPropertyCreate.listAgentPreferredPhoneExt) &&
        Objects.equals(this.listAgentStateLicense, orgResoMetadataPropertyCreate.listAgentStateLicense) &&
        Objects.equals(this.listAgentTollFreePhone, orgResoMetadataPropertyCreate.listAgentTollFreePhone) &&
        Objects.equals(this.listAgentURL, orgResoMetadataPropertyCreate.listAgentURL) &&
        Objects.equals(this.listAgentVoiceMail, orgResoMetadataPropertyCreate.listAgentVoiceMail) &&
        Objects.equals(this.listAgentVoiceMailExt, orgResoMetadataPropertyCreate.listAgentVoiceMailExt) &&
        Objects.equals(this.listOfficeAOR, orgResoMetadataPropertyCreate.listOfficeAOR) &&
        Objects.equals(this.listOfficeEmail, orgResoMetadataPropertyCreate.listOfficeEmail) &&
        Objects.equals(this.listOfficeFax, orgResoMetadataPropertyCreate.listOfficeFax) &&
        Objects.equals(this.listOfficeKey, orgResoMetadataPropertyCreate.listOfficeKey) &&
        Objects.equals(this.listOfficeKeyNumeric, orgResoMetadataPropertyCreate.listOfficeKeyNumeric) &&
        Objects.equals(this.listOfficeMlsId, orgResoMetadataPropertyCreate.listOfficeMlsId) &&
        Objects.equals(this.listOfficeName, orgResoMetadataPropertyCreate.listOfficeName) &&
        Objects.equals(this.listOfficePhone, orgResoMetadataPropertyCreate.listOfficePhone) &&
        Objects.equals(this.listOfficePhoneExt, orgResoMetadataPropertyCreate.listOfficePhoneExt) &&
        Objects.equals(this.listOfficeURL, orgResoMetadataPropertyCreate.listOfficeURL) &&
        Objects.equals(this.listPrice, orgResoMetadataPropertyCreate.listPrice) &&
        Objects.equals(this.listPriceLow, orgResoMetadataPropertyCreate.listPriceLow) &&
        Objects.equals(this.listTeamKey, orgResoMetadataPropertyCreate.listTeamKey) &&
        Objects.equals(this.listTeamKeyNumeric, orgResoMetadataPropertyCreate.listTeamKeyNumeric) &&
        Objects.equals(this.listTeamName, orgResoMetadataPropertyCreate.listTeamName) &&
        Objects.equals(this.listingAgreement, orgResoMetadataPropertyCreate.listingAgreement) &&
        Objects.equals(this.listingContractDate, orgResoMetadataPropertyCreate.listingContractDate) &&
        Objects.equals(this.listingId, orgResoMetadataPropertyCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataPropertyCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataPropertyCreate.listingKeyNumeric) &&
        Objects.equals(this.listingService, orgResoMetadataPropertyCreate.listingService) &&
        Objects.equals(this.listingTerms, orgResoMetadataPropertyCreate.listingTerms) &&
        Objects.equals(this.livingArea, orgResoMetadataPropertyCreate.livingArea) &&
        Objects.equals(this.livingAreaSource, orgResoMetadataPropertyCreate.livingAreaSource) &&
        Objects.equals(this.livingAreaUnits, orgResoMetadataPropertyCreate.livingAreaUnits) &&
        Objects.equals(this.lockBoxLocation, orgResoMetadataPropertyCreate.lockBoxLocation) &&
        Objects.equals(this.lockBoxSerialNumber, orgResoMetadataPropertyCreate.lockBoxSerialNumber) &&
        Objects.equals(this.lockBoxType, orgResoMetadataPropertyCreate.lockBoxType) &&
        Objects.equals(this.longitude, orgResoMetadataPropertyCreate.longitude) &&
        Objects.equals(this.lotDimensionsSource, orgResoMetadataPropertyCreate.lotDimensionsSource) &&
        Objects.equals(this.lotFeatures, orgResoMetadataPropertyCreate.lotFeatures) &&
        Objects.equals(this.lotSizeAcres, orgResoMetadataPropertyCreate.lotSizeAcres) &&
        Objects.equals(this.lotSizeArea, orgResoMetadataPropertyCreate.lotSizeArea) &&
        Objects.equals(this.lotSizeDimensions, orgResoMetadataPropertyCreate.lotSizeDimensions) &&
        Objects.equals(this.lotSizeSource, orgResoMetadataPropertyCreate.lotSizeSource) &&
        Objects.equals(this.lotSizeSquareFeet, orgResoMetadataPropertyCreate.lotSizeSquareFeet) &&
        Objects.equals(this.lotSizeUnits, orgResoMetadataPropertyCreate.lotSizeUnits) &&
        Objects.equals(this.mlSAreaMajor, orgResoMetadataPropertyCreate.mlSAreaMajor) &&
        Objects.equals(this.mlSAreaMinor, orgResoMetadataPropertyCreate.mlSAreaMinor) &&
        Objects.equals(this.mainLevelBathrooms, orgResoMetadataPropertyCreate.mainLevelBathrooms) &&
        Objects.equals(this.mainLevelBedrooms, orgResoMetadataPropertyCreate.mainLevelBedrooms) &&
        Objects.equals(this.maintenanceExpense, orgResoMetadataPropertyCreate.maintenanceExpense) &&
        Objects.equals(this.majorChangeTimestamp, orgResoMetadataPropertyCreate.majorChangeTimestamp) &&
        Objects.equals(this.majorChangeType, orgResoMetadataPropertyCreate.majorChangeType) &&
        Objects.equals(this.make, orgResoMetadataPropertyCreate.make) &&
        Objects.equals(this.managerExpense, orgResoMetadataPropertyCreate.managerExpense) &&
        Objects.equals(this.mapCoordinate, orgResoMetadataPropertyCreate.mapCoordinate) &&
        Objects.equals(this.mapCoordinateSource, orgResoMetadataPropertyCreate.mapCoordinateSource) &&
        Objects.equals(this.mapURL, orgResoMetadataPropertyCreate.mapURL) &&
        Objects.equals(this.middleOrJuniorSchool, orgResoMetadataPropertyCreate.middleOrJuniorSchool) &&
        Objects.equals(this.middleOrJuniorSchoolDistrict, orgResoMetadataPropertyCreate.middleOrJuniorSchoolDistrict) &&
        Objects.equals(this.mlsStatus, orgResoMetadataPropertyCreate.mlsStatus) &&
        Objects.equals(this.mobileDimUnits, orgResoMetadataPropertyCreate.mobileDimUnits) &&
        Objects.equals(this.mobileHomeRemainsYN, orgResoMetadataPropertyCreate.mobileHomeRemainsYN) &&
        Objects.equals(this.mobileLength, orgResoMetadataPropertyCreate.mobileLength) &&
        Objects.equals(this.mobileWidth, orgResoMetadataPropertyCreate.mobileWidth) &&
        Objects.equals(this.model, orgResoMetadataPropertyCreate.model) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataPropertyCreate.modificationTimestamp) &&
        Objects.equals(this.netOperatingIncome, orgResoMetadataPropertyCreate.netOperatingIncome) &&
        Objects.equals(this.newConstructionYN, orgResoMetadataPropertyCreate.newConstructionYN) &&
        Objects.equals(this.newTaxesExpense, orgResoMetadataPropertyCreate.newTaxesExpense) &&
        Objects.equals(this.numberOfBuildings, orgResoMetadataPropertyCreate.numberOfBuildings) &&
        Objects.equals(this.numberOfFullTimeEmployees, orgResoMetadataPropertyCreate.numberOfFullTimeEmployees) &&
        Objects.equals(this.numberOfLots, orgResoMetadataPropertyCreate.numberOfLots) &&
        Objects.equals(this.numberOfPads, orgResoMetadataPropertyCreate.numberOfPads) &&
        Objects.equals(this.numberOfPartTimeEmployees, orgResoMetadataPropertyCreate.numberOfPartTimeEmployees) &&
        Objects.equals(this.numberOfSeparateElectricMeters, orgResoMetadataPropertyCreate.numberOfSeparateElectricMeters) &&
        Objects.equals(this.numberOfSeparateGasMeters, orgResoMetadataPropertyCreate.numberOfSeparateGasMeters) &&
        Objects.equals(this.numberOfSeparateWaterMeters, orgResoMetadataPropertyCreate.numberOfSeparateWaterMeters) &&
        Objects.equals(this.numberOfUnitsInCommunity, orgResoMetadataPropertyCreate.numberOfUnitsInCommunity) &&
        Objects.equals(this.numberOfUnitsLeased, orgResoMetadataPropertyCreate.numberOfUnitsLeased) &&
        Objects.equals(this.numberOfUnitsMoMo, orgResoMetadataPropertyCreate.numberOfUnitsMoMo) &&
        Objects.equals(this.numberOfUnitsTotal, orgResoMetadataPropertyCreate.numberOfUnitsTotal) &&
        Objects.equals(this.numberOfUnitsVacant, orgResoMetadataPropertyCreate.numberOfUnitsVacant) &&
        Objects.equals(this.occupantName, orgResoMetadataPropertyCreate.occupantName) &&
        Objects.equals(this.occupantPhone, orgResoMetadataPropertyCreate.occupantPhone) &&
        Objects.equals(this.occupantType, orgResoMetadataPropertyCreate.occupantType) &&
        Objects.equals(this.offMarketDate, orgResoMetadataPropertyCreate.offMarketDate) &&
        Objects.equals(this.offMarketTimestamp, orgResoMetadataPropertyCreate.offMarketTimestamp) &&
        Objects.equals(this.onMarketDate, orgResoMetadataPropertyCreate.onMarketDate) &&
        Objects.equals(this.onMarketTimestamp, orgResoMetadataPropertyCreate.onMarketTimestamp) &&
        Objects.equals(this.openParkingSpaces, orgResoMetadataPropertyCreate.openParkingSpaces) &&
        Objects.equals(this.openParkingYN, orgResoMetadataPropertyCreate.openParkingYN) &&
        Objects.equals(this.operatingExpense, orgResoMetadataPropertyCreate.operatingExpense) &&
        Objects.equals(this.operatingExpenseIncludes, orgResoMetadataPropertyCreate.operatingExpenseIncludes) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataPropertyCreate.originalEntryTimestamp) &&
        Objects.equals(this.originalListPrice, orgResoMetadataPropertyCreate.originalListPrice) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataPropertyCreate.originatingSystemID) &&
        Objects.equals(this.originatingSystemKey, orgResoMetadataPropertyCreate.originatingSystemKey) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataPropertyCreate.originatingSystemName) &&
        Objects.equals(this.otherEquipment, orgResoMetadataPropertyCreate.otherEquipment) &&
        Objects.equals(this.otherExpense, orgResoMetadataPropertyCreate.otherExpense) &&
        Objects.equals(this.otherParking, orgResoMetadataPropertyCreate.otherParking) &&
        Objects.equals(this.otherStructures, orgResoMetadataPropertyCreate.otherStructures) &&
        Objects.equals(this.ownerName, orgResoMetadataPropertyCreate.ownerName) &&
        Objects.equals(this.ownerPays, orgResoMetadataPropertyCreate.ownerPays) &&
        Objects.equals(this.ownerPhone, orgResoMetadataPropertyCreate.ownerPhone) &&
        Objects.equals(this.ownership, orgResoMetadataPropertyCreate.ownership) &&
        Objects.equals(this.ownershipType, orgResoMetadataPropertyCreate.ownershipType) &&
        Objects.equals(this.parcelNumber, orgResoMetadataPropertyCreate.parcelNumber) &&
        Objects.equals(this.parkManagerName, orgResoMetadataPropertyCreate.parkManagerName) &&
        Objects.equals(this.parkManagerPhone, orgResoMetadataPropertyCreate.parkManagerPhone) &&
        Objects.equals(this.parkName, orgResoMetadataPropertyCreate.parkName) &&
        Objects.equals(this.parkingFeatures, orgResoMetadataPropertyCreate.parkingFeatures) &&
        Objects.equals(this.parkingTotal, orgResoMetadataPropertyCreate.parkingTotal) &&
        Objects.equals(this.pastureArea, orgResoMetadataPropertyCreate.pastureArea) &&
        Objects.equals(this.patioAndPorchFeatures, orgResoMetadataPropertyCreate.patioAndPorchFeatures) &&
        Objects.equals(this.pendingTimestamp, orgResoMetadataPropertyCreate.pendingTimestamp) &&
        Objects.equals(this.pestControlExpense, orgResoMetadataPropertyCreate.pestControlExpense) &&
        Objects.equals(this.petsAllowed, orgResoMetadataPropertyCreate.petsAllowed) &&
        Objects.equals(this.photosChangeTimestamp, orgResoMetadataPropertyCreate.photosChangeTimestamp) &&
        Objects.equals(this.photosCount, orgResoMetadataPropertyCreate.photosCount) &&
        Objects.equals(this.poolExpense, orgResoMetadataPropertyCreate.poolExpense) &&
        Objects.equals(this.poolFeatures, orgResoMetadataPropertyCreate.poolFeatures) &&
        Objects.equals(this.poolPrivateYN, orgResoMetadataPropertyCreate.poolPrivateYN) &&
        Objects.equals(this.possession, orgResoMetadataPropertyCreate.possession) &&
        Objects.equals(this.possibleUse, orgResoMetadataPropertyCreate.possibleUse) &&
        Objects.equals(this.postalCity, orgResoMetadataPropertyCreate.postalCity) &&
        Objects.equals(this.postalCode, orgResoMetadataPropertyCreate.postalCode) &&
        Objects.equals(this.postalCodePlus4, orgResoMetadataPropertyCreate.postalCodePlus4) &&
        Objects.equals(this.powerProductionType, orgResoMetadataPropertyCreate.powerProductionType) &&
        Objects.equals(this.previousListPrice, orgResoMetadataPropertyCreate.previousListPrice) &&
        Objects.equals(this.priceChangeTimestamp, orgResoMetadataPropertyCreate.priceChangeTimestamp) &&
        Objects.equals(this.privateOfficeRemarks, orgResoMetadataPropertyCreate.privateOfficeRemarks) &&
        Objects.equals(this.privateRemarks, orgResoMetadataPropertyCreate.privateRemarks) &&
        Objects.equals(this.professionalManagementExpense, orgResoMetadataPropertyCreate.professionalManagementExpense) &&
        Objects.equals(this.propertyAttachedYN, orgResoMetadataPropertyCreate.propertyAttachedYN) &&
        Objects.equals(this.propertyCondition, orgResoMetadataPropertyCreate.propertyCondition) &&
        Objects.equals(this.propertySubType, orgResoMetadataPropertyCreate.propertySubType) &&
        Objects.equals(this.propertyType, orgResoMetadataPropertyCreate.propertyType) &&
        Objects.equals(this.publicRemarks, orgResoMetadataPropertyCreate.publicRemarks) &&
        Objects.equals(this.publicSurveyRange, orgResoMetadataPropertyCreate.publicSurveyRange) &&
        Objects.equals(this.publicSurveySection, orgResoMetadataPropertyCreate.publicSurveySection) &&
        Objects.equals(this.publicSurveyTownship, orgResoMetadataPropertyCreate.publicSurveyTownship) &&
        Objects.equals(this.purchaseContractDate, orgResoMetadataPropertyCreate.purchaseContractDate) &&
        Objects.equals(this.rvParkingDimensions, orgResoMetadataPropertyCreate.rvParkingDimensions) &&
        Objects.equals(this.rangeArea, orgResoMetadataPropertyCreate.rangeArea) &&
        Objects.equals(this.rentControlYN, orgResoMetadataPropertyCreate.rentControlYN) &&
        Objects.equals(this.rentIncludes, orgResoMetadataPropertyCreate.rentIncludes) &&
        Objects.equals(this.roadFrontageType, orgResoMetadataPropertyCreate.roadFrontageType) &&
        Objects.equals(this.roadResponsibility, orgResoMetadataPropertyCreate.roadResponsibility) &&
        Objects.equals(this.roadSurfaceType, orgResoMetadataPropertyCreate.roadSurfaceType) &&
        Objects.equals(this.roof, orgResoMetadataPropertyCreate.roof) &&
        Objects.equals(this.roomType, orgResoMetadataPropertyCreate.roomType) &&
        Objects.equals(this.roomsTotal, orgResoMetadataPropertyCreate.roomsTotal) &&
        Objects.equals(this.seatingCapacity, orgResoMetadataPropertyCreate.seatingCapacity) &&
        Objects.equals(this.securityFeatures, orgResoMetadataPropertyCreate.securityFeatures) &&
        Objects.equals(this.seniorCommunityYN, orgResoMetadataPropertyCreate.seniorCommunityYN) &&
        Objects.equals(this.serialU, orgResoMetadataPropertyCreate.serialU) &&
        Objects.equals(this.serialX, orgResoMetadataPropertyCreate.serialX) &&
        Objects.equals(this.serialXX, orgResoMetadataPropertyCreate.serialXX) &&
        Objects.equals(this.sewer, orgResoMetadataPropertyCreate.sewer) &&
        Objects.equals(this.showingAdvanceNotice, orgResoMetadataPropertyCreate.showingAdvanceNotice) &&
        Objects.equals(this.showingAttendedYN, orgResoMetadataPropertyCreate.showingAttendedYN) &&
        Objects.equals(this.showingContactName, orgResoMetadataPropertyCreate.showingContactName) &&
        Objects.equals(this.showingContactPhone, orgResoMetadataPropertyCreate.showingContactPhone) &&
        Objects.equals(this.showingContactPhoneExt, orgResoMetadataPropertyCreate.showingContactPhoneExt) &&
        Objects.equals(this.showingContactType, orgResoMetadataPropertyCreate.showingContactType) &&
        Objects.equals(this.showingDays, orgResoMetadataPropertyCreate.showingDays) &&
        Objects.equals(this.showingEndTime, orgResoMetadataPropertyCreate.showingEndTime) &&
        Objects.equals(this.showingInstructions, orgResoMetadataPropertyCreate.showingInstructions) &&
        Objects.equals(this.showingRequirements, orgResoMetadataPropertyCreate.showingRequirements) &&
        Objects.equals(this.showingStartTime, orgResoMetadataPropertyCreate.showingStartTime) &&
        Objects.equals(this.signOnPropertyYN, orgResoMetadataPropertyCreate.signOnPropertyYN) &&
        Objects.equals(this.skirt, orgResoMetadataPropertyCreate.skirt) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataPropertyCreate.sourceSystemID) &&
        Objects.equals(this.sourceSystemKey, orgResoMetadataPropertyCreate.sourceSystemKey) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataPropertyCreate.sourceSystemName) &&
        Objects.equals(this.spaFeatures, orgResoMetadataPropertyCreate.spaFeatures) &&
        Objects.equals(this.spaYN, orgResoMetadataPropertyCreate.spaYN) &&
        Objects.equals(this.specialLicenses, orgResoMetadataPropertyCreate.specialLicenses) &&
        Objects.equals(this.specialListingConditions, orgResoMetadataPropertyCreate.specialListingConditions) &&
        Objects.equals(this.standardStatus, orgResoMetadataPropertyCreate.standardStatus) &&
        Objects.equals(this.stateOrProvince, orgResoMetadataPropertyCreate.stateOrProvince) &&
        Objects.equals(this.stateRegion, orgResoMetadataPropertyCreate.stateRegion) &&
        Objects.equals(this.statusChangeTimestamp, orgResoMetadataPropertyCreate.statusChangeTimestamp) &&
        Objects.equals(this.stories, orgResoMetadataPropertyCreate.stories) &&
        Objects.equals(this.storiesTotal, orgResoMetadataPropertyCreate.storiesTotal) &&
        Objects.equals(this.streetAdditionalInfo, orgResoMetadataPropertyCreate.streetAdditionalInfo) &&
        Objects.equals(this.streetDirPrefix, orgResoMetadataPropertyCreate.streetDirPrefix) &&
        Objects.equals(this.streetDirSuffix, orgResoMetadataPropertyCreate.streetDirSuffix) &&
        Objects.equals(this.streetName, orgResoMetadataPropertyCreate.streetName) &&
        Objects.equals(this.streetNumber, orgResoMetadataPropertyCreate.streetNumber) &&
        Objects.equals(this.streetNumberNumeric, orgResoMetadataPropertyCreate.streetNumberNumeric) &&
        Objects.equals(this.streetSuffix, orgResoMetadataPropertyCreate.streetSuffix) &&
        Objects.equals(this.streetSuffixModifier, orgResoMetadataPropertyCreate.streetSuffixModifier) &&
        Objects.equals(this.structureType, orgResoMetadataPropertyCreate.structureType) &&
        Objects.equals(this.subAgencyCompensation, orgResoMetadataPropertyCreate.subAgencyCompensation) &&
        Objects.equals(this.subAgencyCompensationType, orgResoMetadataPropertyCreate.subAgencyCompensationType) &&
        Objects.equals(this.subdivisionName, orgResoMetadataPropertyCreate.subdivisionName) &&
        Objects.equals(this.suppliesExpense, orgResoMetadataPropertyCreate.suppliesExpense) &&
        Objects.equals(this.syndicateTo, orgResoMetadataPropertyCreate.syndicateTo) &&
        Objects.equals(this.syndicationRemarks, orgResoMetadataPropertyCreate.syndicationRemarks) &&
        Objects.equals(this.taxAnnualAmount, orgResoMetadataPropertyCreate.taxAnnualAmount) &&
        Objects.equals(this.taxAssessedValue, orgResoMetadataPropertyCreate.taxAssessedValue) &&
        Objects.equals(this.taxBlock, orgResoMetadataPropertyCreate.taxBlock) &&
        Objects.equals(this.taxBookNumber, orgResoMetadataPropertyCreate.taxBookNumber) &&
        Objects.equals(this.taxLegalDescription, orgResoMetadataPropertyCreate.taxLegalDescription) &&
        Objects.equals(this.taxLot, orgResoMetadataPropertyCreate.taxLot) &&
        Objects.equals(this.taxMapNumber, orgResoMetadataPropertyCreate.taxMapNumber) &&
        Objects.equals(this.taxOtherAnnualAssessmentAmount, orgResoMetadataPropertyCreate.taxOtherAnnualAssessmentAmount) &&
        Objects.equals(this.taxParcelLetter, orgResoMetadataPropertyCreate.taxParcelLetter) &&
        Objects.equals(this.taxStatusCurrent, orgResoMetadataPropertyCreate.taxStatusCurrent) &&
        Objects.equals(this.taxTract, orgResoMetadataPropertyCreate.taxTract) &&
        Objects.equals(this.taxYear, orgResoMetadataPropertyCreate.taxYear) &&
        Objects.equals(this.tenantPays, orgResoMetadataPropertyCreate.tenantPays) &&
        Objects.equals(this.topography, orgResoMetadataPropertyCreate.topography) &&
        Objects.equals(this.totalActualRent, orgResoMetadataPropertyCreate.totalActualRent) &&
        Objects.equals(this.township, orgResoMetadataPropertyCreate.township) &&
        Objects.equals(this.transactionBrokerCompensation, orgResoMetadataPropertyCreate.transactionBrokerCompensation) &&
        Objects.equals(this.transactionBrokerCompensationType, orgResoMetadataPropertyCreate.transactionBrokerCompensationType) &&
        Objects.equals(this.trashExpense, orgResoMetadataPropertyCreate.trashExpense) &&
        Objects.equals(this.unitNumber, orgResoMetadataPropertyCreate.unitNumber) &&
        Objects.equals(this.unitTypeType, orgResoMetadataPropertyCreate.unitTypeType) &&
        Objects.equals(this.unitsFurnished, orgResoMetadataPropertyCreate.unitsFurnished) &&
        Objects.equals(this.universalPropertyId, orgResoMetadataPropertyCreate.universalPropertyId) &&
        Objects.equals(this.universalPropertySubId, orgResoMetadataPropertyCreate.universalPropertySubId) &&
        Objects.equals(this.unparsedAddress, orgResoMetadataPropertyCreate.unparsedAddress) &&
        Objects.equals(this.utilities, orgResoMetadataPropertyCreate.utilities) &&
        Objects.equals(this.vacancyAllowance, orgResoMetadataPropertyCreate.vacancyAllowance) &&
        Objects.equals(this.vacancyAllowanceRate, orgResoMetadataPropertyCreate.vacancyAllowanceRate) &&
        Objects.equals(this.vegetation, orgResoMetadataPropertyCreate.vegetation) &&
        Objects.equals(this.videosChangeTimestamp, orgResoMetadataPropertyCreate.videosChangeTimestamp) &&
        Objects.equals(this.videosCount, orgResoMetadataPropertyCreate.videosCount) &&
        Objects.equals(this.view, orgResoMetadataPropertyCreate.view) &&
        Objects.equals(this.viewYN, orgResoMetadataPropertyCreate.viewYN) &&
        Objects.equals(this.virtualTourURLBranded, orgResoMetadataPropertyCreate.virtualTourURLBranded) &&
        Objects.equals(this.virtualTourURLUnbranded, orgResoMetadataPropertyCreate.virtualTourURLUnbranded) &&
        Objects.equals(this.walkScore, orgResoMetadataPropertyCreate.walkScore) &&
        Objects.equals(this.waterBodyName, orgResoMetadataPropertyCreate.waterBodyName) &&
        Objects.equals(this.waterSewerExpense, orgResoMetadataPropertyCreate.waterSewerExpense) &&
        Objects.equals(this.waterSource, orgResoMetadataPropertyCreate.waterSource) &&
        Objects.equals(this.waterfrontFeatures, orgResoMetadataPropertyCreate.waterfrontFeatures) &&
        Objects.equals(this.waterfrontYN, orgResoMetadataPropertyCreate.waterfrontYN) &&
        Objects.equals(this.windowFeatures, orgResoMetadataPropertyCreate.windowFeatures) &&
        Objects.equals(this.withdrawnDate, orgResoMetadataPropertyCreate.withdrawnDate) &&
        Objects.equals(this.woodedArea, orgResoMetadataPropertyCreate.woodedArea) &&
        Objects.equals(this.workmansCompensationExpense, orgResoMetadataPropertyCreate.workmansCompensationExpense) &&
        Objects.equals(this.yearBuilt, orgResoMetadataPropertyCreate.yearBuilt) &&
        Objects.equals(this.yearBuiltDetails, orgResoMetadataPropertyCreate.yearBuiltDetails) &&
        Objects.equals(this.yearBuiltEffective, orgResoMetadataPropertyCreate.yearBuiltEffective) &&
        Objects.equals(this.yearBuiltSource, orgResoMetadataPropertyCreate.yearBuiltSource) &&
        Objects.equals(this.yearEstablished, orgResoMetadataPropertyCreate.yearEstablished) &&
        Objects.equals(this.yearsCurrentOwner, orgResoMetadataPropertyCreate.yearsCurrentOwner) &&
        Objects.equals(this.zoning, orgResoMetadataPropertyCreate.zoning) &&
        Objects.equals(this.zoningDescription, orgResoMetadataPropertyCreate.zoningDescription) &&
        Objects.equals(this.originatingSystem, orgResoMetadataPropertyCreate.originatingSystem) &&
        Objects.equals(this.buyerAgent, orgResoMetadataPropertyCreate.buyerAgent) &&
        Objects.equals(this.buyerOffice, orgResoMetadataPropertyCreate.buyerOffice) &&
        Objects.equals(this.coBuyerAgent, orgResoMetadataPropertyCreate.coBuyerAgent) &&
        Objects.equals(this.coBuyerOffice, orgResoMetadataPropertyCreate.coBuyerOffice) &&
        Objects.equals(this.coListAgent, orgResoMetadataPropertyCreate.coListAgent) &&
        Objects.equals(this.coListOffice, orgResoMetadataPropertyCreate.coListOffice) &&
        Objects.equals(this.listAgent, orgResoMetadataPropertyCreate.listAgent) &&
        Objects.equals(this.listOffice, orgResoMetadataPropertyCreate.listOffice) &&
        Objects.equals(this.buyerTeam, orgResoMetadataPropertyCreate.buyerTeam) &&
        Objects.equals(this.listTeam, orgResoMetadataPropertyCreate.listTeam) &&
        Objects.equals(this.sourceSystem, orgResoMetadataPropertyCreate.sourceSystem) &&
        Objects.equals(this.historyTransactional, orgResoMetadataPropertyCreate.historyTransactional) &&
        Objects.equals(this.media, orgResoMetadataPropertyCreate.media) &&
        Objects.equals(this.socialMedia, orgResoMetadataPropertyCreate.socialMedia) &&
        Objects.equals(this.openHouse, orgResoMetadataPropertyCreate.openHouse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(aboveGradeFinishedArea, aboveGradeFinishedAreaSource, aboveGradeFinishedAreaUnits, accessCode, accessibilityFeatures, additionalParcelsDescription, additionalParcelsYN, anchorsCoTenants, appliances, architecturalStyle, associationAmenities, associationFee, associationFee2, associationFee2Frequency, associationFeeFrequency, associationFeeIncludes, associationName, associationName2, associationPhone, associationPhone2, associationYN, attachedGarageYN, availabilityDate, basement, basementYN, bathroomsFull, bathroomsHalf, bathroomsOneQuarter, bathroomsPartial, bathroomsThreeQuarter, bathroomsTotalInteger, bedroomsPossible, bedroomsTotal, belowGradeFinishedArea, belowGradeFinishedAreaSource, belowGradeFinishedAreaUnits, bodyType, builderModel, builderName, buildingAreaSource, buildingAreaTotal, buildingAreaUnits, buildingFeatures, buildingName, businessName, businessType, buyerAgencyCompensation, buyerAgencyCompensationType, buyerAgentAOR, buyerAgentDesignation, buyerAgentDirectPhone, buyerAgentEmail, buyerAgentFax, buyerAgentFirstName, buyerAgentFullName, buyerAgentHomePhone, buyerAgentKey, buyerAgentKeyNumeric, buyerAgentLastName, buyerAgentMiddleName, buyerAgentMlsId, buyerAgentMobilePhone, buyerAgentNamePrefix, buyerAgentNameSuffix, buyerAgentOfficePhone, buyerAgentOfficePhoneExt, buyerAgentPager, buyerAgentPreferredPhone, buyerAgentPreferredPhoneExt, buyerAgentStateLicense, buyerAgentTollFreePhone, buyerAgentURL, buyerAgentVoiceMail, buyerAgentVoiceMailExt, buyerFinancing, buyerOfficeAOR, buyerOfficeEmail, buyerOfficeFax, buyerOfficeKey, buyerOfficeKeyNumeric, buyerOfficeMlsId, buyerOfficeName, buyerOfficePhone, buyerOfficePhoneExt, buyerOfficeURL, buyerTeamKey, buyerTeamKeyNumeric, buyerTeamName, cableTvExpense, cancellationDate, capRate, carportSpaces, carportYN, carrierRoute, city, cityRegion, closeDate, closePrice, coBuyerAgentAOR, coBuyerAgentDesignation, coBuyerAgentDirectPhone, coBuyerAgentEmail, coBuyerAgentFax, coBuyerAgentFirstName, coBuyerAgentFullName, coBuyerAgentHomePhone, coBuyerAgentKey, coBuyerAgentKeyNumeric, coBuyerAgentLastName, coBuyerAgentMiddleName, coBuyerAgentMlsId, coBuyerAgentMobilePhone, coBuyerAgentNamePrefix, coBuyerAgentNameSuffix, coBuyerAgentOfficePhone, coBuyerAgentOfficePhoneExt, coBuyerAgentPager, coBuyerAgentPreferredPhone, coBuyerAgentPreferredPhoneExt, coBuyerAgentStateLicense, coBuyerAgentTollFreePhone, coBuyerAgentURL, coBuyerAgentVoiceMail, coBuyerAgentVoiceMailExt, coBuyerOfficeAOR, coBuyerOfficeEmail, coBuyerOfficeFax, coBuyerOfficeKey, coBuyerOfficeKeyNumeric, coBuyerOfficeMlsId, coBuyerOfficeName, coBuyerOfficePhone, coBuyerOfficePhoneExt, coBuyerOfficeURL, coListAgentAOR, coListAgentDesignation, coListAgentDirectPhone, coListAgentEmail, coListAgentFax, coListAgentFirstName, coListAgentFullName, coListAgentHomePhone, coListAgentKey, coListAgentKeyNumeric, coListAgentLastName, coListAgentMiddleName, coListAgentMlsId, coListAgentMobilePhone, coListAgentNamePrefix, coListAgentNameSuffix, coListAgentOfficePhone, coListAgentOfficePhoneExt, coListAgentPager, coListAgentPreferredPhone, coListAgentPreferredPhoneExt, coListAgentStateLicense, coListAgentTollFreePhone, coListAgentURL, coListAgentVoiceMail, coListAgentVoiceMailExt, coListOfficeAOR, coListOfficeEmail, coListOfficeFax, coListOfficeKey, coListOfficeKeyNumeric, coListOfficeMlsId, coListOfficeName, coListOfficePhone, coListOfficePhoneExt, coListOfficeURL, commonInterest, commonWalls, communityFeatures, concessions, concessionsAmount, concessionsComments, constructionMaterials, continentRegion, contingency, contingentDate, contractStatusChangeDate, cooling, coolingYN, copyrightNotice, country, countryRegion, countyOrParish, coveredSpaces, cropsIncludedYN, crossStreet, cultivatedArea, cumulativeDaysOnMarket, currentFinancing, currentUse, doH1, doH2, doH3, daysOnMarket, developmentStatus, directionFaces, directions, disclaimer, disclosures, distanceToBusComments, distanceToBusNumeric, distanceToBusUnits, distanceToElectricComments, distanceToElectricNumeric, distanceToElectricUnits, distanceToFreewayComments, distanceToFreewayNumeric, distanceToFreewayUnits, distanceToGasComments, distanceToGasNumeric, distanceToGasUnits, distanceToPhoneServiceComments, distanceToPhoneServiceNumeric, distanceToPhoneServiceUnits, distanceToPlaceofWorshipComments, distanceToPlaceofWorshipNumeric, distanceToPlaceofWorshipUnits, distanceToSchoolBusComments, distanceToSchoolBusNumeric, distanceToSchoolBusUnits, distanceToSchoolsComments, distanceToSchoolsNumeric, distanceToSchoolsUnits, distanceToSewerComments, distanceToSewerNumeric, distanceToSewerUnits, distanceToShoppingComments, distanceToShoppingNumeric, distanceToShoppingUnits, distanceToStreetComments, distanceToStreetNumeric, distanceToStreetUnits, distanceToWaterComments, distanceToWaterNumeric, distanceToWaterUnits, documentsAvailable, documentsChangeTimestamp, documentsCount, doorFeatures, dualVariableCompensationYN, electric, electricExpense, electricOnPropertyYN, elementarySchool, elementarySchoolDistrict, elevation, elevationUnits, entryLevel, entryLocation, exclusions, existingLeaseType, expirationDate, exteriorFeatures, farmCreditServiceInclYN, farmLandAreaSource, farmLandAreaUnits, fencing, financialDataSource, fireplaceFeatures, fireplaceYN, fireplacesTotal, flooring, foundationArea, foundationDetails, frontageLength, frontageType, fuelExpense, furnished, furnitureReplacementExpense, garageSpaces, garageYN, gardenerExpense, grazingPermitsBlmYN, grazingPermitsForestServiceYN, grazingPermitsPrivateYN, greenBuildingVerificationType, greenEnergyEfficient, greenEnergyGeneration, greenIndoorAirQuality, greenLocation, greenSustainability, greenWaterConservation, grossIncome, grossScheduledIncome, habitableResidenceYN, heating, heatingYN, highSchool, highSchoolDistrict, homeWarrantyYN, horseAmenities, horseYN, hoursDaysOfOperation, hoursDaysOfOperationDescription, inclusions, incomeIncludes, insuranceExpense, interiorFeatures, internetAddressDisplayYN, internetAutomatedValuationDisplayYN, internetConsumerCommentYN, internetEntireListingDisplayYN, irrigationSource, irrigationWaterRightsAcres, irrigationWaterRightsYN, laborInformation, landLeaseAmount, landLeaseAmountFrequency, landLeaseExpirationDate, landLeaseYN, latitude, laundryFeatures, leasableArea, leasableAreaUnits, leaseAmount, leaseAmountFrequency, leaseAssignableYN, leaseConsideredYN, leaseExpiration, leaseRenewalCompensation, leaseRenewalOptionYN, leaseTerm, levels, license1, license2, license3, licensesExpense, listAOR, listAgentAOR, listAgentDesignation, listAgentDirectPhone, listAgentEmail, listAgentFax, listAgentFirstName, listAgentFullName, listAgentHomePhone, listAgentKey, listAgentKeyNumeric, listAgentLastName, listAgentMiddleName, listAgentMlsId, listAgentMobilePhone, listAgentNamePrefix, listAgentNameSuffix, listAgentOfficePhone, listAgentOfficePhoneExt, listAgentPager, listAgentPreferredPhone, listAgentPreferredPhoneExt, listAgentStateLicense, listAgentTollFreePhone, listAgentURL, listAgentVoiceMail, listAgentVoiceMailExt, listOfficeAOR, listOfficeEmail, listOfficeFax, listOfficeKey, listOfficeKeyNumeric, listOfficeMlsId, listOfficeName, listOfficePhone, listOfficePhoneExt, listOfficeURL, listPrice, listPriceLow, listTeamKey, listTeamKeyNumeric, listTeamName, listingAgreement, listingContractDate, listingId, listingKey, listingKeyNumeric, listingService, listingTerms, livingArea, livingAreaSource, livingAreaUnits, lockBoxLocation, lockBoxSerialNumber, lockBoxType, longitude, lotDimensionsSource, lotFeatures, lotSizeAcres, lotSizeArea, lotSizeDimensions, lotSizeSource, lotSizeSquareFeet, lotSizeUnits, mlSAreaMajor, mlSAreaMinor, mainLevelBathrooms, mainLevelBedrooms, maintenanceExpense, majorChangeTimestamp, majorChangeType, make, managerExpense, mapCoordinate, mapCoordinateSource, mapURL, middleOrJuniorSchool, middleOrJuniorSchoolDistrict, mlsStatus, mobileDimUnits, mobileHomeRemainsYN, mobileLength, mobileWidth, model, modificationTimestamp, netOperatingIncome, newConstructionYN, newTaxesExpense, numberOfBuildings, numberOfFullTimeEmployees, numberOfLots, numberOfPads, numberOfPartTimeEmployees, numberOfSeparateElectricMeters, numberOfSeparateGasMeters, numberOfSeparateWaterMeters, numberOfUnitsInCommunity, numberOfUnitsLeased, numberOfUnitsMoMo, numberOfUnitsTotal, numberOfUnitsVacant, occupantName, occupantPhone, occupantType, offMarketDate, offMarketTimestamp, onMarketDate, onMarketTimestamp, openParkingSpaces, openParkingYN, operatingExpense, operatingExpenseIncludes, originalEntryTimestamp, originalListPrice, originatingSystemID, originatingSystemKey, originatingSystemName, otherEquipment, otherExpense, otherParking, otherStructures, ownerName, ownerPays, ownerPhone, ownership, ownershipType, parcelNumber, parkManagerName, parkManagerPhone, parkName, parkingFeatures, parkingTotal, pastureArea, patioAndPorchFeatures, pendingTimestamp, pestControlExpense, petsAllowed, photosChangeTimestamp, photosCount, poolExpense, poolFeatures, poolPrivateYN, possession, possibleUse, postalCity, postalCode, postalCodePlus4, powerProductionType, previousListPrice, priceChangeTimestamp, privateOfficeRemarks, privateRemarks, professionalManagementExpense, propertyAttachedYN, propertyCondition, propertySubType, propertyType, publicRemarks, publicSurveyRange, publicSurveySection, publicSurveyTownship, purchaseContractDate, rvParkingDimensions, rangeArea, rentControlYN, rentIncludes, roadFrontageType, roadResponsibility, roadSurfaceType, roof, roomType, roomsTotal, seatingCapacity, securityFeatures, seniorCommunityYN, serialU, serialX, serialXX, sewer, showingAdvanceNotice, showingAttendedYN, showingContactName, showingContactPhone, showingContactPhoneExt, showingContactType, showingDays, showingEndTime, showingInstructions, showingRequirements, showingStartTime, signOnPropertyYN, skirt, sourceSystemID, sourceSystemKey, sourceSystemName, spaFeatures, spaYN, specialLicenses, specialListingConditions, standardStatus, stateOrProvince, stateRegion, statusChangeTimestamp, stories, storiesTotal, streetAdditionalInfo, streetDirPrefix, streetDirSuffix, streetName, streetNumber, streetNumberNumeric, streetSuffix, streetSuffixModifier, structureType, subAgencyCompensation, subAgencyCompensationType, subdivisionName, suppliesExpense, syndicateTo, syndicationRemarks, taxAnnualAmount, taxAssessedValue, taxBlock, taxBookNumber, taxLegalDescription, taxLot, taxMapNumber, taxOtherAnnualAssessmentAmount, taxParcelLetter, taxStatusCurrent, taxTract, taxYear, tenantPays, topography, totalActualRent, township, transactionBrokerCompensation, transactionBrokerCompensationType, trashExpense, unitNumber, unitTypeType, unitsFurnished, universalPropertyId, universalPropertySubId, unparsedAddress, utilities, vacancyAllowance, vacancyAllowanceRate, vegetation, videosChangeTimestamp, videosCount, view, viewYN, virtualTourURLBranded, virtualTourURLUnbranded, walkScore, waterBodyName, waterSewerExpense, waterSource, waterfrontFeatures, waterfrontYN, windowFeatures, withdrawnDate, woodedArea, workmansCompensationExpense, yearBuilt, yearBuiltDetails, yearBuiltEffective, yearBuiltSource, yearEstablished, yearsCurrentOwner, zoning, zoningDescription, originatingSystem, buyerAgent, buyerOffice, coBuyerAgent, coBuyerOffice, coListAgent, coListOffice, listAgent, listOffice, buyerTeam, listTeam, sourceSystem, historyTransactional, media, socialMedia, openHouse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataPropertyCreate {\n");
    
    sb.append("    aboveGradeFinishedArea: ").append(toIndentedString(aboveGradeFinishedArea)).append("\n");
    sb.append("    aboveGradeFinishedAreaSource: ").append(toIndentedString(aboveGradeFinishedAreaSource)).append("\n");
    sb.append("    aboveGradeFinishedAreaUnits: ").append(toIndentedString(aboveGradeFinishedAreaUnits)).append("\n");
    sb.append("    accessCode: ").append(toIndentedString(accessCode)).append("\n");
    sb.append("    accessibilityFeatures: ").append(toIndentedString(accessibilityFeatures)).append("\n");
    sb.append("    additionalParcelsDescription: ").append(toIndentedString(additionalParcelsDescription)).append("\n");
    sb.append("    additionalParcelsYN: ").append(toIndentedString(additionalParcelsYN)).append("\n");
    sb.append("    anchorsCoTenants: ").append(toIndentedString(anchorsCoTenants)).append("\n");
    sb.append("    appliances: ").append(toIndentedString(appliances)).append("\n");
    sb.append("    architecturalStyle: ").append(toIndentedString(architecturalStyle)).append("\n");
    sb.append("    associationAmenities: ").append(toIndentedString(associationAmenities)).append("\n");
    sb.append("    associationFee: ").append(toIndentedString(associationFee)).append("\n");
    sb.append("    associationFee2: ").append(toIndentedString(associationFee2)).append("\n");
    sb.append("    associationFee2Frequency: ").append(toIndentedString(associationFee2Frequency)).append("\n");
    sb.append("    associationFeeFrequency: ").append(toIndentedString(associationFeeFrequency)).append("\n");
    sb.append("    associationFeeIncludes: ").append(toIndentedString(associationFeeIncludes)).append("\n");
    sb.append("    associationName: ").append(toIndentedString(associationName)).append("\n");
    sb.append("    associationName2: ").append(toIndentedString(associationName2)).append("\n");
    sb.append("    associationPhone: ").append(toIndentedString(associationPhone)).append("\n");
    sb.append("    associationPhone2: ").append(toIndentedString(associationPhone2)).append("\n");
    sb.append("    associationYN: ").append(toIndentedString(associationYN)).append("\n");
    sb.append("    attachedGarageYN: ").append(toIndentedString(attachedGarageYN)).append("\n");
    sb.append("    availabilityDate: ").append(toIndentedString(availabilityDate)).append("\n");
    sb.append("    basement: ").append(toIndentedString(basement)).append("\n");
    sb.append("    basementYN: ").append(toIndentedString(basementYN)).append("\n");
    sb.append("    bathroomsFull: ").append(toIndentedString(bathroomsFull)).append("\n");
    sb.append("    bathroomsHalf: ").append(toIndentedString(bathroomsHalf)).append("\n");
    sb.append("    bathroomsOneQuarter: ").append(toIndentedString(bathroomsOneQuarter)).append("\n");
    sb.append("    bathroomsPartial: ").append(toIndentedString(bathroomsPartial)).append("\n");
    sb.append("    bathroomsThreeQuarter: ").append(toIndentedString(bathroomsThreeQuarter)).append("\n");
    sb.append("    bathroomsTotalInteger: ").append(toIndentedString(bathroomsTotalInteger)).append("\n");
    sb.append("    bedroomsPossible: ").append(toIndentedString(bedroomsPossible)).append("\n");
    sb.append("    bedroomsTotal: ").append(toIndentedString(bedroomsTotal)).append("\n");
    sb.append("    belowGradeFinishedArea: ").append(toIndentedString(belowGradeFinishedArea)).append("\n");
    sb.append("    belowGradeFinishedAreaSource: ").append(toIndentedString(belowGradeFinishedAreaSource)).append("\n");
    sb.append("    belowGradeFinishedAreaUnits: ").append(toIndentedString(belowGradeFinishedAreaUnits)).append("\n");
    sb.append("    bodyType: ").append(toIndentedString(bodyType)).append("\n");
    sb.append("    builderModel: ").append(toIndentedString(builderModel)).append("\n");
    sb.append("    builderName: ").append(toIndentedString(builderName)).append("\n");
    sb.append("    buildingAreaSource: ").append(toIndentedString(buildingAreaSource)).append("\n");
    sb.append("    buildingAreaTotal: ").append(toIndentedString(buildingAreaTotal)).append("\n");
    sb.append("    buildingAreaUnits: ").append(toIndentedString(buildingAreaUnits)).append("\n");
    sb.append("    buildingFeatures: ").append(toIndentedString(buildingFeatures)).append("\n");
    sb.append("    buildingName: ").append(toIndentedString(buildingName)).append("\n");
    sb.append("    businessName: ").append(toIndentedString(businessName)).append("\n");
    sb.append("    businessType: ").append(toIndentedString(businessType)).append("\n");
    sb.append("    buyerAgencyCompensation: ").append(toIndentedString(buyerAgencyCompensation)).append("\n");
    sb.append("    buyerAgencyCompensationType: ").append(toIndentedString(buyerAgencyCompensationType)).append("\n");
    sb.append("    buyerAgentAOR: ").append(toIndentedString(buyerAgentAOR)).append("\n");
    sb.append("    buyerAgentDesignation: ").append(toIndentedString(buyerAgentDesignation)).append("\n");
    sb.append("    buyerAgentDirectPhone: ").append(toIndentedString(buyerAgentDirectPhone)).append("\n");
    sb.append("    buyerAgentEmail: ").append(toIndentedString(buyerAgentEmail)).append("\n");
    sb.append("    buyerAgentFax: ").append(toIndentedString(buyerAgentFax)).append("\n");
    sb.append("    buyerAgentFirstName: ").append(toIndentedString(buyerAgentFirstName)).append("\n");
    sb.append("    buyerAgentFullName: ").append(toIndentedString(buyerAgentFullName)).append("\n");
    sb.append("    buyerAgentHomePhone: ").append(toIndentedString(buyerAgentHomePhone)).append("\n");
    sb.append("    buyerAgentKey: ").append(toIndentedString(buyerAgentKey)).append("\n");
    sb.append("    buyerAgentKeyNumeric: ").append(toIndentedString(buyerAgentKeyNumeric)).append("\n");
    sb.append("    buyerAgentLastName: ").append(toIndentedString(buyerAgentLastName)).append("\n");
    sb.append("    buyerAgentMiddleName: ").append(toIndentedString(buyerAgentMiddleName)).append("\n");
    sb.append("    buyerAgentMlsId: ").append(toIndentedString(buyerAgentMlsId)).append("\n");
    sb.append("    buyerAgentMobilePhone: ").append(toIndentedString(buyerAgentMobilePhone)).append("\n");
    sb.append("    buyerAgentNamePrefix: ").append(toIndentedString(buyerAgentNamePrefix)).append("\n");
    sb.append("    buyerAgentNameSuffix: ").append(toIndentedString(buyerAgentNameSuffix)).append("\n");
    sb.append("    buyerAgentOfficePhone: ").append(toIndentedString(buyerAgentOfficePhone)).append("\n");
    sb.append("    buyerAgentOfficePhoneExt: ").append(toIndentedString(buyerAgentOfficePhoneExt)).append("\n");
    sb.append("    buyerAgentPager: ").append(toIndentedString(buyerAgentPager)).append("\n");
    sb.append("    buyerAgentPreferredPhone: ").append(toIndentedString(buyerAgentPreferredPhone)).append("\n");
    sb.append("    buyerAgentPreferredPhoneExt: ").append(toIndentedString(buyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    buyerAgentStateLicense: ").append(toIndentedString(buyerAgentStateLicense)).append("\n");
    sb.append("    buyerAgentTollFreePhone: ").append(toIndentedString(buyerAgentTollFreePhone)).append("\n");
    sb.append("    buyerAgentURL: ").append(toIndentedString(buyerAgentURL)).append("\n");
    sb.append("    buyerAgentVoiceMail: ").append(toIndentedString(buyerAgentVoiceMail)).append("\n");
    sb.append("    buyerAgentVoiceMailExt: ").append(toIndentedString(buyerAgentVoiceMailExt)).append("\n");
    sb.append("    buyerFinancing: ").append(toIndentedString(buyerFinancing)).append("\n");
    sb.append("    buyerOfficeAOR: ").append(toIndentedString(buyerOfficeAOR)).append("\n");
    sb.append("    buyerOfficeEmail: ").append(toIndentedString(buyerOfficeEmail)).append("\n");
    sb.append("    buyerOfficeFax: ").append(toIndentedString(buyerOfficeFax)).append("\n");
    sb.append("    buyerOfficeKey: ").append(toIndentedString(buyerOfficeKey)).append("\n");
    sb.append("    buyerOfficeKeyNumeric: ").append(toIndentedString(buyerOfficeKeyNumeric)).append("\n");
    sb.append("    buyerOfficeMlsId: ").append(toIndentedString(buyerOfficeMlsId)).append("\n");
    sb.append("    buyerOfficeName: ").append(toIndentedString(buyerOfficeName)).append("\n");
    sb.append("    buyerOfficePhone: ").append(toIndentedString(buyerOfficePhone)).append("\n");
    sb.append("    buyerOfficePhoneExt: ").append(toIndentedString(buyerOfficePhoneExt)).append("\n");
    sb.append("    buyerOfficeURL: ").append(toIndentedString(buyerOfficeURL)).append("\n");
    sb.append("    buyerTeamKey: ").append(toIndentedString(buyerTeamKey)).append("\n");
    sb.append("    buyerTeamKeyNumeric: ").append(toIndentedString(buyerTeamKeyNumeric)).append("\n");
    sb.append("    buyerTeamName: ").append(toIndentedString(buyerTeamName)).append("\n");
    sb.append("    cableTvExpense: ").append(toIndentedString(cableTvExpense)).append("\n");
    sb.append("    cancellationDate: ").append(toIndentedString(cancellationDate)).append("\n");
    sb.append("    capRate: ").append(toIndentedString(capRate)).append("\n");
    sb.append("    carportSpaces: ").append(toIndentedString(carportSpaces)).append("\n");
    sb.append("    carportYN: ").append(toIndentedString(carportYN)).append("\n");
    sb.append("    carrierRoute: ").append(toIndentedString(carrierRoute)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    cityRegion: ").append(toIndentedString(cityRegion)).append("\n");
    sb.append("    closeDate: ").append(toIndentedString(closeDate)).append("\n");
    sb.append("    closePrice: ").append(toIndentedString(closePrice)).append("\n");
    sb.append("    coBuyerAgentAOR: ").append(toIndentedString(coBuyerAgentAOR)).append("\n");
    sb.append("    coBuyerAgentDesignation: ").append(toIndentedString(coBuyerAgentDesignation)).append("\n");
    sb.append("    coBuyerAgentDirectPhone: ").append(toIndentedString(coBuyerAgentDirectPhone)).append("\n");
    sb.append("    coBuyerAgentEmail: ").append(toIndentedString(coBuyerAgentEmail)).append("\n");
    sb.append("    coBuyerAgentFax: ").append(toIndentedString(coBuyerAgentFax)).append("\n");
    sb.append("    coBuyerAgentFirstName: ").append(toIndentedString(coBuyerAgentFirstName)).append("\n");
    sb.append("    coBuyerAgentFullName: ").append(toIndentedString(coBuyerAgentFullName)).append("\n");
    sb.append("    coBuyerAgentHomePhone: ").append(toIndentedString(coBuyerAgentHomePhone)).append("\n");
    sb.append("    coBuyerAgentKey: ").append(toIndentedString(coBuyerAgentKey)).append("\n");
    sb.append("    coBuyerAgentKeyNumeric: ").append(toIndentedString(coBuyerAgentKeyNumeric)).append("\n");
    sb.append("    coBuyerAgentLastName: ").append(toIndentedString(coBuyerAgentLastName)).append("\n");
    sb.append("    coBuyerAgentMiddleName: ").append(toIndentedString(coBuyerAgentMiddleName)).append("\n");
    sb.append("    coBuyerAgentMlsId: ").append(toIndentedString(coBuyerAgentMlsId)).append("\n");
    sb.append("    coBuyerAgentMobilePhone: ").append(toIndentedString(coBuyerAgentMobilePhone)).append("\n");
    sb.append("    coBuyerAgentNamePrefix: ").append(toIndentedString(coBuyerAgentNamePrefix)).append("\n");
    sb.append("    coBuyerAgentNameSuffix: ").append(toIndentedString(coBuyerAgentNameSuffix)).append("\n");
    sb.append("    coBuyerAgentOfficePhone: ").append(toIndentedString(coBuyerAgentOfficePhone)).append("\n");
    sb.append("    coBuyerAgentOfficePhoneExt: ").append(toIndentedString(coBuyerAgentOfficePhoneExt)).append("\n");
    sb.append("    coBuyerAgentPager: ").append(toIndentedString(coBuyerAgentPager)).append("\n");
    sb.append("    coBuyerAgentPreferredPhone: ").append(toIndentedString(coBuyerAgentPreferredPhone)).append("\n");
    sb.append("    coBuyerAgentPreferredPhoneExt: ").append(toIndentedString(coBuyerAgentPreferredPhoneExt)).append("\n");
    sb.append("    coBuyerAgentStateLicense: ").append(toIndentedString(coBuyerAgentStateLicense)).append("\n");
    sb.append("    coBuyerAgentTollFreePhone: ").append(toIndentedString(coBuyerAgentTollFreePhone)).append("\n");
    sb.append("    coBuyerAgentURL: ").append(toIndentedString(coBuyerAgentURL)).append("\n");
    sb.append("    coBuyerAgentVoiceMail: ").append(toIndentedString(coBuyerAgentVoiceMail)).append("\n");
    sb.append("    coBuyerAgentVoiceMailExt: ").append(toIndentedString(coBuyerAgentVoiceMailExt)).append("\n");
    sb.append("    coBuyerOfficeAOR: ").append(toIndentedString(coBuyerOfficeAOR)).append("\n");
    sb.append("    coBuyerOfficeEmail: ").append(toIndentedString(coBuyerOfficeEmail)).append("\n");
    sb.append("    coBuyerOfficeFax: ").append(toIndentedString(coBuyerOfficeFax)).append("\n");
    sb.append("    coBuyerOfficeKey: ").append(toIndentedString(coBuyerOfficeKey)).append("\n");
    sb.append("    coBuyerOfficeKeyNumeric: ").append(toIndentedString(coBuyerOfficeKeyNumeric)).append("\n");
    sb.append("    coBuyerOfficeMlsId: ").append(toIndentedString(coBuyerOfficeMlsId)).append("\n");
    sb.append("    coBuyerOfficeName: ").append(toIndentedString(coBuyerOfficeName)).append("\n");
    sb.append("    coBuyerOfficePhone: ").append(toIndentedString(coBuyerOfficePhone)).append("\n");
    sb.append("    coBuyerOfficePhoneExt: ").append(toIndentedString(coBuyerOfficePhoneExt)).append("\n");
    sb.append("    coBuyerOfficeURL: ").append(toIndentedString(coBuyerOfficeURL)).append("\n");
    sb.append("    coListAgentAOR: ").append(toIndentedString(coListAgentAOR)).append("\n");
    sb.append("    coListAgentDesignation: ").append(toIndentedString(coListAgentDesignation)).append("\n");
    sb.append("    coListAgentDirectPhone: ").append(toIndentedString(coListAgentDirectPhone)).append("\n");
    sb.append("    coListAgentEmail: ").append(toIndentedString(coListAgentEmail)).append("\n");
    sb.append("    coListAgentFax: ").append(toIndentedString(coListAgentFax)).append("\n");
    sb.append("    coListAgentFirstName: ").append(toIndentedString(coListAgentFirstName)).append("\n");
    sb.append("    coListAgentFullName: ").append(toIndentedString(coListAgentFullName)).append("\n");
    sb.append("    coListAgentHomePhone: ").append(toIndentedString(coListAgentHomePhone)).append("\n");
    sb.append("    coListAgentKey: ").append(toIndentedString(coListAgentKey)).append("\n");
    sb.append("    coListAgentKeyNumeric: ").append(toIndentedString(coListAgentKeyNumeric)).append("\n");
    sb.append("    coListAgentLastName: ").append(toIndentedString(coListAgentLastName)).append("\n");
    sb.append("    coListAgentMiddleName: ").append(toIndentedString(coListAgentMiddleName)).append("\n");
    sb.append("    coListAgentMlsId: ").append(toIndentedString(coListAgentMlsId)).append("\n");
    sb.append("    coListAgentMobilePhone: ").append(toIndentedString(coListAgentMobilePhone)).append("\n");
    sb.append("    coListAgentNamePrefix: ").append(toIndentedString(coListAgentNamePrefix)).append("\n");
    sb.append("    coListAgentNameSuffix: ").append(toIndentedString(coListAgentNameSuffix)).append("\n");
    sb.append("    coListAgentOfficePhone: ").append(toIndentedString(coListAgentOfficePhone)).append("\n");
    sb.append("    coListAgentOfficePhoneExt: ").append(toIndentedString(coListAgentOfficePhoneExt)).append("\n");
    sb.append("    coListAgentPager: ").append(toIndentedString(coListAgentPager)).append("\n");
    sb.append("    coListAgentPreferredPhone: ").append(toIndentedString(coListAgentPreferredPhone)).append("\n");
    sb.append("    coListAgentPreferredPhoneExt: ").append(toIndentedString(coListAgentPreferredPhoneExt)).append("\n");
    sb.append("    coListAgentStateLicense: ").append(toIndentedString(coListAgentStateLicense)).append("\n");
    sb.append("    coListAgentTollFreePhone: ").append(toIndentedString(coListAgentTollFreePhone)).append("\n");
    sb.append("    coListAgentURL: ").append(toIndentedString(coListAgentURL)).append("\n");
    sb.append("    coListAgentVoiceMail: ").append(toIndentedString(coListAgentVoiceMail)).append("\n");
    sb.append("    coListAgentVoiceMailExt: ").append(toIndentedString(coListAgentVoiceMailExt)).append("\n");
    sb.append("    coListOfficeAOR: ").append(toIndentedString(coListOfficeAOR)).append("\n");
    sb.append("    coListOfficeEmail: ").append(toIndentedString(coListOfficeEmail)).append("\n");
    sb.append("    coListOfficeFax: ").append(toIndentedString(coListOfficeFax)).append("\n");
    sb.append("    coListOfficeKey: ").append(toIndentedString(coListOfficeKey)).append("\n");
    sb.append("    coListOfficeKeyNumeric: ").append(toIndentedString(coListOfficeKeyNumeric)).append("\n");
    sb.append("    coListOfficeMlsId: ").append(toIndentedString(coListOfficeMlsId)).append("\n");
    sb.append("    coListOfficeName: ").append(toIndentedString(coListOfficeName)).append("\n");
    sb.append("    coListOfficePhone: ").append(toIndentedString(coListOfficePhone)).append("\n");
    sb.append("    coListOfficePhoneExt: ").append(toIndentedString(coListOfficePhoneExt)).append("\n");
    sb.append("    coListOfficeURL: ").append(toIndentedString(coListOfficeURL)).append("\n");
    sb.append("    commonInterest: ").append(toIndentedString(commonInterest)).append("\n");
    sb.append("    commonWalls: ").append(toIndentedString(commonWalls)).append("\n");
    sb.append("    communityFeatures: ").append(toIndentedString(communityFeatures)).append("\n");
    sb.append("    concessions: ").append(toIndentedString(concessions)).append("\n");
    sb.append("    concessionsAmount: ").append(toIndentedString(concessionsAmount)).append("\n");
    sb.append("    concessionsComments: ").append(toIndentedString(concessionsComments)).append("\n");
    sb.append("    constructionMaterials: ").append(toIndentedString(constructionMaterials)).append("\n");
    sb.append("    continentRegion: ").append(toIndentedString(continentRegion)).append("\n");
    sb.append("    contingency: ").append(toIndentedString(contingency)).append("\n");
    sb.append("    contingentDate: ").append(toIndentedString(contingentDate)).append("\n");
    sb.append("    contractStatusChangeDate: ").append(toIndentedString(contractStatusChangeDate)).append("\n");
    sb.append("    cooling: ").append(toIndentedString(cooling)).append("\n");
    sb.append("    coolingYN: ").append(toIndentedString(coolingYN)).append("\n");
    sb.append("    copyrightNotice: ").append(toIndentedString(copyrightNotice)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    countryRegion: ").append(toIndentedString(countryRegion)).append("\n");
    sb.append("    countyOrParish: ").append(toIndentedString(countyOrParish)).append("\n");
    sb.append("    coveredSpaces: ").append(toIndentedString(coveredSpaces)).append("\n");
    sb.append("    cropsIncludedYN: ").append(toIndentedString(cropsIncludedYN)).append("\n");
    sb.append("    crossStreet: ").append(toIndentedString(crossStreet)).append("\n");
    sb.append("    cultivatedArea: ").append(toIndentedString(cultivatedArea)).append("\n");
    sb.append("    cumulativeDaysOnMarket: ").append(toIndentedString(cumulativeDaysOnMarket)).append("\n");
    sb.append("    currentFinancing: ").append(toIndentedString(currentFinancing)).append("\n");
    sb.append("    currentUse: ").append(toIndentedString(currentUse)).append("\n");
    sb.append("    doH1: ").append(toIndentedString(doH1)).append("\n");
    sb.append("    doH2: ").append(toIndentedString(doH2)).append("\n");
    sb.append("    doH3: ").append(toIndentedString(doH3)).append("\n");
    sb.append("    daysOnMarket: ").append(toIndentedString(daysOnMarket)).append("\n");
    sb.append("    developmentStatus: ").append(toIndentedString(developmentStatus)).append("\n");
    sb.append("    directionFaces: ").append(toIndentedString(directionFaces)).append("\n");
    sb.append("    directions: ").append(toIndentedString(directions)).append("\n");
    sb.append("    disclaimer: ").append(toIndentedString(disclaimer)).append("\n");
    sb.append("    disclosures: ").append(toIndentedString(disclosures)).append("\n");
    sb.append("    distanceToBusComments: ").append(toIndentedString(distanceToBusComments)).append("\n");
    sb.append("    distanceToBusNumeric: ").append(toIndentedString(distanceToBusNumeric)).append("\n");
    sb.append("    distanceToBusUnits: ").append(toIndentedString(distanceToBusUnits)).append("\n");
    sb.append("    distanceToElectricComments: ").append(toIndentedString(distanceToElectricComments)).append("\n");
    sb.append("    distanceToElectricNumeric: ").append(toIndentedString(distanceToElectricNumeric)).append("\n");
    sb.append("    distanceToElectricUnits: ").append(toIndentedString(distanceToElectricUnits)).append("\n");
    sb.append("    distanceToFreewayComments: ").append(toIndentedString(distanceToFreewayComments)).append("\n");
    sb.append("    distanceToFreewayNumeric: ").append(toIndentedString(distanceToFreewayNumeric)).append("\n");
    sb.append("    distanceToFreewayUnits: ").append(toIndentedString(distanceToFreewayUnits)).append("\n");
    sb.append("    distanceToGasComments: ").append(toIndentedString(distanceToGasComments)).append("\n");
    sb.append("    distanceToGasNumeric: ").append(toIndentedString(distanceToGasNumeric)).append("\n");
    sb.append("    distanceToGasUnits: ").append(toIndentedString(distanceToGasUnits)).append("\n");
    sb.append("    distanceToPhoneServiceComments: ").append(toIndentedString(distanceToPhoneServiceComments)).append("\n");
    sb.append("    distanceToPhoneServiceNumeric: ").append(toIndentedString(distanceToPhoneServiceNumeric)).append("\n");
    sb.append("    distanceToPhoneServiceUnits: ").append(toIndentedString(distanceToPhoneServiceUnits)).append("\n");
    sb.append("    distanceToPlaceofWorshipComments: ").append(toIndentedString(distanceToPlaceofWorshipComments)).append("\n");
    sb.append("    distanceToPlaceofWorshipNumeric: ").append(toIndentedString(distanceToPlaceofWorshipNumeric)).append("\n");
    sb.append("    distanceToPlaceofWorshipUnits: ").append(toIndentedString(distanceToPlaceofWorshipUnits)).append("\n");
    sb.append("    distanceToSchoolBusComments: ").append(toIndentedString(distanceToSchoolBusComments)).append("\n");
    sb.append("    distanceToSchoolBusNumeric: ").append(toIndentedString(distanceToSchoolBusNumeric)).append("\n");
    sb.append("    distanceToSchoolBusUnits: ").append(toIndentedString(distanceToSchoolBusUnits)).append("\n");
    sb.append("    distanceToSchoolsComments: ").append(toIndentedString(distanceToSchoolsComments)).append("\n");
    sb.append("    distanceToSchoolsNumeric: ").append(toIndentedString(distanceToSchoolsNumeric)).append("\n");
    sb.append("    distanceToSchoolsUnits: ").append(toIndentedString(distanceToSchoolsUnits)).append("\n");
    sb.append("    distanceToSewerComments: ").append(toIndentedString(distanceToSewerComments)).append("\n");
    sb.append("    distanceToSewerNumeric: ").append(toIndentedString(distanceToSewerNumeric)).append("\n");
    sb.append("    distanceToSewerUnits: ").append(toIndentedString(distanceToSewerUnits)).append("\n");
    sb.append("    distanceToShoppingComments: ").append(toIndentedString(distanceToShoppingComments)).append("\n");
    sb.append("    distanceToShoppingNumeric: ").append(toIndentedString(distanceToShoppingNumeric)).append("\n");
    sb.append("    distanceToShoppingUnits: ").append(toIndentedString(distanceToShoppingUnits)).append("\n");
    sb.append("    distanceToStreetComments: ").append(toIndentedString(distanceToStreetComments)).append("\n");
    sb.append("    distanceToStreetNumeric: ").append(toIndentedString(distanceToStreetNumeric)).append("\n");
    sb.append("    distanceToStreetUnits: ").append(toIndentedString(distanceToStreetUnits)).append("\n");
    sb.append("    distanceToWaterComments: ").append(toIndentedString(distanceToWaterComments)).append("\n");
    sb.append("    distanceToWaterNumeric: ").append(toIndentedString(distanceToWaterNumeric)).append("\n");
    sb.append("    distanceToWaterUnits: ").append(toIndentedString(distanceToWaterUnits)).append("\n");
    sb.append("    documentsAvailable: ").append(toIndentedString(documentsAvailable)).append("\n");
    sb.append("    documentsChangeTimestamp: ").append(toIndentedString(documentsChangeTimestamp)).append("\n");
    sb.append("    documentsCount: ").append(toIndentedString(documentsCount)).append("\n");
    sb.append("    doorFeatures: ").append(toIndentedString(doorFeatures)).append("\n");
    sb.append("    dualVariableCompensationYN: ").append(toIndentedString(dualVariableCompensationYN)).append("\n");
    sb.append("    electric: ").append(toIndentedString(electric)).append("\n");
    sb.append("    electricExpense: ").append(toIndentedString(electricExpense)).append("\n");
    sb.append("    electricOnPropertyYN: ").append(toIndentedString(electricOnPropertyYN)).append("\n");
    sb.append("    elementarySchool: ").append(toIndentedString(elementarySchool)).append("\n");
    sb.append("    elementarySchoolDistrict: ").append(toIndentedString(elementarySchoolDistrict)).append("\n");
    sb.append("    elevation: ").append(toIndentedString(elevation)).append("\n");
    sb.append("    elevationUnits: ").append(toIndentedString(elevationUnits)).append("\n");
    sb.append("    entryLevel: ").append(toIndentedString(entryLevel)).append("\n");
    sb.append("    entryLocation: ").append(toIndentedString(entryLocation)).append("\n");
    sb.append("    exclusions: ").append(toIndentedString(exclusions)).append("\n");
    sb.append("    existingLeaseType: ").append(toIndentedString(existingLeaseType)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    exteriorFeatures: ").append(toIndentedString(exteriorFeatures)).append("\n");
    sb.append("    farmCreditServiceInclYN: ").append(toIndentedString(farmCreditServiceInclYN)).append("\n");
    sb.append("    farmLandAreaSource: ").append(toIndentedString(farmLandAreaSource)).append("\n");
    sb.append("    farmLandAreaUnits: ").append(toIndentedString(farmLandAreaUnits)).append("\n");
    sb.append("    fencing: ").append(toIndentedString(fencing)).append("\n");
    sb.append("    financialDataSource: ").append(toIndentedString(financialDataSource)).append("\n");
    sb.append("    fireplaceFeatures: ").append(toIndentedString(fireplaceFeatures)).append("\n");
    sb.append("    fireplaceYN: ").append(toIndentedString(fireplaceYN)).append("\n");
    sb.append("    fireplacesTotal: ").append(toIndentedString(fireplacesTotal)).append("\n");
    sb.append("    flooring: ").append(toIndentedString(flooring)).append("\n");
    sb.append("    foundationArea: ").append(toIndentedString(foundationArea)).append("\n");
    sb.append("    foundationDetails: ").append(toIndentedString(foundationDetails)).append("\n");
    sb.append("    frontageLength: ").append(toIndentedString(frontageLength)).append("\n");
    sb.append("    frontageType: ").append(toIndentedString(frontageType)).append("\n");
    sb.append("    fuelExpense: ").append(toIndentedString(fuelExpense)).append("\n");
    sb.append("    furnished: ").append(toIndentedString(furnished)).append("\n");
    sb.append("    furnitureReplacementExpense: ").append(toIndentedString(furnitureReplacementExpense)).append("\n");
    sb.append("    garageSpaces: ").append(toIndentedString(garageSpaces)).append("\n");
    sb.append("    garageYN: ").append(toIndentedString(garageYN)).append("\n");
    sb.append("    gardenerExpense: ").append(toIndentedString(gardenerExpense)).append("\n");
    sb.append("    grazingPermitsBlmYN: ").append(toIndentedString(grazingPermitsBlmYN)).append("\n");
    sb.append("    grazingPermitsForestServiceYN: ").append(toIndentedString(grazingPermitsForestServiceYN)).append("\n");
    sb.append("    grazingPermitsPrivateYN: ").append(toIndentedString(grazingPermitsPrivateYN)).append("\n");
    sb.append("    greenBuildingVerificationType: ").append(toIndentedString(greenBuildingVerificationType)).append("\n");
    sb.append("    greenEnergyEfficient: ").append(toIndentedString(greenEnergyEfficient)).append("\n");
    sb.append("    greenEnergyGeneration: ").append(toIndentedString(greenEnergyGeneration)).append("\n");
    sb.append("    greenIndoorAirQuality: ").append(toIndentedString(greenIndoorAirQuality)).append("\n");
    sb.append("    greenLocation: ").append(toIndentedString(greenLocation)).append("\n");
    sb.append("    greenSustainability: ").append(toIndentedString(greenSustainability)).append("\n");
    sb.append("    greenWaterConservation: ").append(toIndentedString(greenWaterConservation)).append("\n");
    sb.append("    grossIncome: ").append(toIndentedString(grossIncome)).append("\n");
    sb.append("    grossScheduledIncome: ").append(toIndentedString(grossScheduledIncome)).append("\n");
    sb.append("    habitableResidenceYN: ").append(toIndentedString(habitableResidenceYN)).append("\n");
    sb.append("    heating: ").append(toIndentedString(heating)).append("\n");
    sb.append("    heatingYN: ").append(toIndentedString(heatingYN)).append("\n");
    sb.append("    highSchool: ").append(toIndentedString(highSchool)).append("\n");
    sb.append("    highSchoolDistrict: ").append(toIndentedString(highSchoolDistrict)).append("\n");
    sb.append("    homeWarrantyYN: ").append(toIndentedString(homeWarrantyYN)).append("\n");
    sb.append("    horseAmenities: ").append(toIndentedString(horseAmenities)).append("\n");
    sb.append("    horseYN: ").append(toIndentedString(horseYN)).append("\n");
    sb.append("    hoursDaysOfOperation: ").append(toIndentedString(hoursDaysOfOperation)).append("\n");
    sb.append("    hoursDaysOfOperationDescription: ").append(toIndentedString(hoursDaysOfOperationDescription)).append("\n");
    sb.append("    inclusions: ").append(toIndentedString(inclusions)).append("\n");
    sb.append("    incomeIncludes: ").append(toIndentedString(incomeIncludes)).append("\n");
    sb.append("    insuranceExpense: ").append(toIndentedString(insuranceExpense)).append("\n");
    sb.append("    interiorFeatures: ").append(toIndentedString(interiorFeatures)).append("\n");
    sb.append("    internetAddressDisplayYN: ").append(toIndentedString(internetAddressDisplayYN)).append("\n");
    sb.append("    internetAutomatedValuationDisplayYN: ").append(toIndentedString(internetAutomatedValuationDisplayYN)).append("\n");
    sb.append("    internetConsumerCommentYN: ").append(toIndentedString(internetConsumerCommentYN)).append("\n");
    sb.append("    internetEntireListingDisplayYN: ").append(toIndentedString(internetEntireListingDisplayYN)).append("\n");
    sb.append("    irrigationSource: ").append(toIndentedString(irrigationSource)).append("\n");
    sb.append("    irrigationWaterRightsAcres: ").append(toIndentedString(irrigationWaterRightsAcres)).append("\n");
    sb.append("    irrigationWaterRightsYN: ").append(toIndentedString(irrigationWaterRightsYN)).append("\n");
    sb.append("    laborInformation: ").append(toIndentedString(laborInformation)).append("\n");
    sb.append("    landLeaseAmount: ").append(toIndentedString(landLeaseAmount)).append("\n");
    sb.append("    landLeaseAmountFrequency: ").append(toIndentedString(landLeaseAmountFrequency)).append("\n");
    sb.append("    landLeaseExpirationDate: ").append(toIndentedString(landLeaseExpirationDate)).append("\n");
    sb.append("    landLeaseYN: ").append(toIndentedString(landLeaseYN)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    laundryFeatures: ").append(toIndentedString(laundryFeatures)).append("\n");
    sb.append("    leasableArea: ").append(toIndentedString(leasableArea)).append("\n");
    sb.append("    leasableAreaUnits: ").append(toIndentedString(leasableAreaUnits)).append("\n");
    sb.append("    leaseAmount: ").append(toIndentedString(leaseAmount)).append("\n");
    sb.append("    leaseAmountFrequency: ").append(toIndentedString(leaseAmountFrequency)).append("\n");
    sb.append("    leaseAssignableYN: ").append(toIndentedString(leaseAssignableYN)).append("\n");
    sb.append("    leaseConsideredYN: ").append(toIndentedString(leaseConsideredYN)).append("\n");
    sb.append("    leaseExpiration: ").append(toIndentedString(leaseExpiration)).append("\n");
    sb.append("    leaseRenewalCompensation: ").append(toIndentedString(leaseRenewalCompensation)).append("\n");
    sb.append("    leaseRenewalOptionYN: ").append(toIndentedString(leaseRenewalOptionYN)).append("\n");
    sb.append("    leaseTerm: ").append(toIndentedString(leaseTerm)).append("\n");
    sb.append("    levels: ").append(toIndentedString(levels)).append("\n");
    sb.append("    license1: ").append(toIndentedString(license1)).append("\n");
    sb.append("    license2: ").append(toIndentedString(license2)).append("\n");
    sb.append("    license3: ").append(toIndentedString(license3)).append("\n");
    sb.append("    licensesExpense: ").append(toIndentedString(licensesExpense)).append("\n");
    sb.append("    listAOR: ").append(toIndentedString(listAOR)).append("\n");
    sb.append("    listAgentAOR: ").append(toIndentedString(listAgentAOR)).append("\n");
    sb.append("    listAgentDesignation: ").append(toIndentedString(listAgentDesignation)).append("\n");
    sb.append("    listAgentDirectPhone: ").append(toIndentedString(listAgentDirectPhone)).append("\n");
    sb.append("    listAgentEmail: ").append(toIndentedString(listAgentEmail)).append("\n");
    sb.append("    listAgentFax: ").append(toIndentedString(listAgentFax)).append("\n");
    sb.append("    listAgentFirstName: ").append(toIndentedString(listAgentFirstName)).append("\n");
    sb.append("    listAgentFullName: ").append(toIndentedString(listAgentFullName)).append("\n");
    sb.append("    listAgentHomePhone: ").append(toIndentedString(listAgentHomePhone)).append("\n");
    sb.append("    listAgentKey: ").append(toIndentedString(listAgentKey)).append("\n");
    sb.append("    listAgentKeyNumeric: ").append(toIndentedString(listAgentKeyNumeric)).append("\n");
    sb.append("    listAgentLastName: ").append(toIndentedString(listAgentLastName)).append("\n");
    sb.append("    listAgentMiddleName: ").append(toIndentedString(listAgentMiddleName)).append("\n");
    sb.append("    listAgentMlsId: ").append(toIndentedString(listAgentMlsId)).append("\n");
    sb.append("    listAgentMobilePhone: ").append(toIndentedString(listAgentMobilePhone)).append("\n");
    sb.append("    listAgentNamePrefix: ").append(toIndentedString(listAgentNamePrefix)).append("\n");
    sb.append("    listAgentNameSuffix: ").append(toIndentedString(listAgentNameSuffix)).append("\n");
    sb.append("    listAgentOfficePhone: ").append(toIndentedString(listAgentOfficePhone)).append("\n");
    sb.append("    listAgentOfficePhoneExt: ").append(toIndentedString(listAgentOfficePhoneExt)).append("\n");
    sb.append("    listAgentPager: ").append(toIndentedString(listAgentPager)).append("\n");
    sb.append("    listAgentPreferredPhone: ").append(toIndentedString(listAgentPreferredPhone)).append("\n");
    sb.append("    listAgentPreferredPhoneExt: ").append(toIndentedString(listAgentPreferredPhoneExt)).append("\n");
    sb.append("    listAgentStateLicense: ").append(toIndentedString(listAgentStateLicense)).append("\n");
    sb.append("    listAgentTollFreePhone: ").append(toIndentedString(listAgentTollFreePhone)).append("\n");
    sb.append("    listAgentURL: ").append(toIndentedString(listAgentURL)).append("\n");
    sb.append("    listAgentVoiceMail: ").append(toIndentedString(listAgentVoiceMail)).append("\n");
    sb.append("    listAgentVoiceMailExt: ").append(toIndentedString(listAgentVoiceMailExt)).append("\n");
    sb.append("    listOfficeAOR: ").append(toIndentedString(listOfficeAOR)).append("\n");
    sb.append("    listOfficeEmail: ").append(toIndentedString(listOfficeEmail)).append("\n");
    sb.append("    listOfficeFax: ").append(toIndentedString(listOfficeFax)).append("\n");
    sb.append("    listOfficeKey: ").append(toIndentedString(listOfficeKey)).append("\n");
    sb.append("    listOfficeKeyNumeric: ").append(toIndentedString(listOfficeKeyNumeric)).append("\n");
    sb.append("    listOfficeMlsId: ").append(toIndentedString(listOfficeMlsId)).append("\n");
    sb.append("    listOfficeName: ").append(toIndentedString(listOfficeName)).append("\n");
    sb.append("    listOfficePhone: ").append(toIndentedString(listOfficePhone)).append("\n");
    sb.append("    listOfficePhoneExt: ").append(toIndentedString(listOfficePhoneExt)).append("\n");
    sb.append("    listOfficeURL: ").append(toIndentedString(listOfficeURL)).append("\n");
    sb.append("    listPrice: ").append(toIndentedString(listPrice)).append("\n");
    sb.append("    listPriceLow: ").append(toIndentedString(listPriceLow)).append("\n");
    sb.append("    listTeamKey: ").append(toIndentedString(listTeamKey)).append("\n");
    sb.append("    listTeamKeyNumeric: ").append(toIndentedString(listTeamKeyNumeric)).append("\n");
    sb.append("    listTeamName: ").append(toIndentedString(listTeamName)).append("\n");
    sb.append("    listingAgreement: ").append(toIndentedString(listingAgreement)).append("\n");
    sb.append("    listingContractDate: ").append(toIndentedString(listingContractDate)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    listingService: ").append(toIndentedString(listingService)).append("\n");
    sb.append("    listingTerms: ").append(toIndentedString(listingTerms)).append("\n");
    sb.append("    livingArea: ").append(toIndentedString(livingArea)).append("\n");
    sb.append("    livingAreaSource: ").append(toIndentedString(livingAreaSource)).append("\n");
    sb.append("    livingAreaUnits: ").append(toIndentedString(livingAreaUnits)).append("\n");
    sb.append("    lockBoxLocation: ").append(toIndentedString(lockBoxLocation)).append("\n");
    sb.append("    lockBoxSerialNumber: ").append(toIndentedString(lockBoxSerialNumber)).append("\n");
    sb.append("    lockBoxType: ").append(toIndentedString(lockBoxType)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    lotDimensionsSource: ").append(toIndentedString(lotDimensionsSource)).append("\n");
    sb.append("    lotFeatures: ").append(toIndentedString(lotFeatures)).append("\n");
    sb.append("    lotSizeAcres: ").append(toIndentedString(lotSizeAcres)).append("\n");
    sb.append("    lotSizeArea: ").append(toIndentedString(lotSizeArea)).append("\n");
    sb.append("    lotSizeDimensions: ").append(toIndentedString(lotSizeDimensions)).append("\n");
    sb.append("    lotSizeSource: ").append(toIndentedString(lotSizeSource)).append("\n");
    sb.append("    lotSizeSquareFeet: ").append(toIndentedString(lotSizeSquareFeet)).append("\n");
    sb.append("    lotSizeUnits: ").append(toIndentedString(lotSizeUnits)).append("\n");
    sb.append("    mlSAreaMajor: ").append(toIndentedString(mlSAreaMajor)).append("\n");
    sb.append("    mlSAreaMinor: ").append(toIndentedString(mlSAreaMinor)).append("\n");
    sb.append("    mainLevelBathrooms: ").append(toIndentedString(mainLevelBathrooms)).append("\n");
    sb.append("    mainLevelBedrooms: ").append(toIndentedString(mainLevelBedrooms)).append("\n");
    sb.append("    maintenanceExpense: ").append(toIndentedString(maintenanceExpense)).append("\n");
    sb.append("    majorChangeTimestamp: ").append(toIndentedString(majorChangeTimestamp)).append("\n");
    sb.append("    majorChangeType: ").append(toIndentedString(majorChangeType)).append("\n");
    sb.append("    make: ").append(toIndentedString(make)).append("\n");
    sb.append("    managerExpense: ").append(toIndentedString(managerExpense)).append("\n");
    sb.append("    mapCoordinate: ").append(toIndentedString(mapCoordinate)).append("\n");
    sb.append("    mapCoordinateSource: ").append(toIndentedString(mapCoordinateSource)).append("\n");
    sb.append("    mapURL: ").append(toIndentedString(mapURL)).append("\n");
    sb.append("    middleOrJuniorSchool: ").append(toIndentedString(middleOrJuniorSchool)).append("\n");
    sb.append("    middleOrJuniorSchoolDistrict: ").append(toIndentedString(middleOrJuniorSchoolDistrict)).append("\n");
    sb.append("    mlsStatus: ").append(toIndentedString(mlsStatus)).append("\n");
    sb.append("    mobileDimUnits: ").append(toIndentedString(mobileDimUnits)).append("\n");
    sb.append("    mobileHomeRemainsYN: ").append(toIndentedString(mobileHomeRemainsYN)).append("\n");
    sb.append("    mobileLength: ").append(toIndentedString(mobileLength)).append("\n");
    sb.append("    mobileWidth: ").append(toIndentedString(mobileWidth)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    netOperatingIncome: ").append(toIndentedString(netOperatingIncome)).append("\n");
    sb.append("    newConstructionYN: ").append(toIndentedString(newConstructionYN)).append("\n");
    sb.append("    newTaxesExpense: ").append(toIndentedString(newTaxesExpense)).append("\n");
    sb.append("    numberOfBuildings: ").append(toIndentedString(numberOfBuildings)).append("\n");
    sb.append("    numberOfFullTimeEmployees: ").append(toIndentedString(numberOfFullTimeEmployees)).append("\n");
    sb.append("    numberOfLots: ").append(toIndentedString(numberOfLots)).append("\n");
    sb.append("    numberOfPads: ").append(toIndentedString(numberOfPads)).append("\n");
    sb.append("    numberOfPartTimeEmployees: ").append(toIndentedString(numberOfPartTimeEmployees)).append("\n");
    sb.append("    numberOfSeparateElectricMeters: ").append(toIndentedString(numberOfSeparateElectricMeters)).append("\n");
    sb.append("    numberOfSeparateGasMeters: ").append(toIndentedString(numberOfSeparateGasMeters)).append("\n");
    sb.append("    numberOfSeparateWaterMeters: ").append(toIndentedString(numberOfSeparateWaterMeters)).append("\n");
    sb.append("    numberOfUnitsInCommunity: ").append(toIndentedString(numberOfUnitsInCommunity)).append("\n");
    sb.append("    numberOfUnitsLeased: ").append(toIndentedString(numberOfUnitsLeased)).append("\n");
    sb.append("    numberOfUnitsMoMo: ").append(toIndentedString(numberOfUnitsMoMo)).append("\n");
    sb.append("    numberOfUnitsTotal: ").append(toIndentedString(numberOfUnitsTotal)).append("\n");
    sb.append("    numberOfUnitsVacant: ").append(toIndentedString(numberOfUnitsVacant)).append("\n");
    sb.append("    occupantName: ").append(toIndentedString(occupantName)).append("\n");
    sb.append("    occupantPhone: ").append(toIndentedString(occupantPhone)).append("\n");
    sb.append("    occupantType: ").append(toIndentedString(occupantType)).append("\n");
    sb.append("    offMarketDate: ").append(toIndentedString(offMarketDate)).append("\n");
    sb.append("    offMarketTimestamp: ").append(toIndentedString(offMarketTimestamp)).append("\n");
    sb.append("    onMarketDate: ").append(toIndentedString(onMarketDate)).append("\n");
    sb.append("    onMarketTimestamp: ").append(toIndentedString(onMarketTimestamp)).append("\n");
    sb.append("    openParkingSpaces: ").append(toIndentedString(openParkingSpaces)).append("\n");
    sb.append("    openParkingYN: ").append(toIndentedString(openParkingYN)).append("\n");
    sb.append("    operatingExpense: ").append(toIndentedString(operatingExpense)).append("\n");
    sb.append("    operatingExpenseIncludes: ").append(toIndentedString(operatingExpenseIncludes)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originalListPrice: ").append(toIndentedString(originalListPrice)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemKey: ").append(toIndentedString(originatingSystemKey)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    otherEquipment: ").append(toIndentedString(otherEquipment)).append("\n");
    sb.append("    otherExpense: ").append(toIndentedString(otherExpense)).append("\n");
    sb.append("    otherParking: ").append(toIndentedString(otherParking)).append("\n");
    sb.append("    otherStructures: ").append(toIndentedString(otherStructures)).append("\n");
    sb.append("    ownerName: ").append(toIndentedString(ownerName)).append("\n");
    sb.append("    ownerPays: ").append(toIndentedString(ownerPays)).append("\n");
    sb.append("    ownerPhone: ").append(toIndentedString(ownerPhone)).append("\n");
    sb.append("    ownership: ").append(toIndentedString(ownership)).append("\n");
    sb.append("    ownershipType: ").append(toIndentedString(ownershipType)).append("\n");
    sb.append("    parcelNumber: ").append(toIndentedString(parcelNumber)).append("\n");
    sb.append("    parkManagerName: ").append(toIndentedString(parkManagerName)).append("\n");
    sb.append("    parkManagerPhone: ").append(toIndentedString(parkManagerPhone)).append("\n");
    sb.append("    parkName: ").append(toIndentedString(parkName)).append("\n");
    sb.append("    parkingFeatures: ").append(toIndentedString(parkingFeatures)).append("\n");
    sb.append("    parkingTotal: ").append(toIndentedString(parkingTotal)).append("\n");
    sb.append("    pastureArea: ").append(toIndentedString(pastureArea)).append("\n");
    sb.append("    patioAndPorchFeatures: ").append(toIndentedString(patioAndPorchFeatures)).append("\n");
    sb.append("    pendingTimestamp: ").append(toIndentedString(pendingTimestamp)).append("\n");
    sb.append("    pestControlExpense: ").append(toIndentedString(pestControlExpense)).append("\n");
    sb.append("    petsAllowed: ").append(toIndentedString(petsAllowed)).append("\n");
    sb.append("    photosChangeTimestamp: ").append(toIndentedString(photosChangeTimestamp)).append("\n");
    sb.append("    photosCount: ").append(toIndentedString(photosCount)).append("\n");
    sb.append("    poolExpense: ").append(toIndentedString(poolExpense)).append("\n");
    sb.append("    poolFeatures: ").append(toIndentedString(poolFeatures)).append("\n");
    sb.append("    poolPrivateYN: ").append(toIndentedString(poolPrivateYN)).append("\n");
    sb.append("    possession: ").append(toIndentedString(possession)).append("\n");
    sb.append("    possibleUse: ").append(toIndentedString(possibleUse)).append("\n");
    sb.append("    postalCity: ").append(toIndentedString(postalCity)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    postalCodePlus4: ").append(toIndentedString(postalCodePlus4)).append("\n");
    sb.append("    powerProductionType: ").append(toIndentedString(powerProductionType)).append("\n");
    sb.append("    previousListPrice: ").append(toIndentedString(previousListPrice)).append("\n");
    sb.append("    priceChangeTimestamp: ").append(toIndentedString(priceChangeTimestamp)).append("\n");
    sb.append("    privateOfficeRemarks: ").append(toIndentedString(privateOfficeRemarks)).append("\n");
    sb.append("    privateRemarks: ").append(toIndentedString(privateRemarks)).append("\n");
    sb.append("    professionalManagementExpense: ").append(toIndentedString(professionalManagementExpense)).append("\n");
    sb.append("    propertyAttachedYN: ").append(toIndentedString(propertyAttachedYN)).append("\n");
    sb.append("    propertyCondition: ").append(toIndentedString(propertyCondition)).append("\n");
    sb.append("    propertySubType: ").append(toIndentedString(propertySubType)).append("\n");
    sb.append("    propertyType: ").append(toIndentedString(propertyType)).append("\n");
    sb.append("    publicRemarks: ").append(toIndentedString(publicRemarks)).append("\n");
    sb.append("    publicSurveyRange: ").append(toIndentedString(publicSurveyRange)).append("\n");
    sb.append("    publicSurveySection: ").append(toIndentedString(publicSurveySection)).append("\n");
    sb.append("    publicSurveyTownship: ").append(toIndentedString(publicSurveyTownship)).append("\n");
    sb.append("    purchaseContractDate: ").append(toIndentedString(purchaseContractDate)).append("\n");
    sb.append("    rvParkingDimensions: ").append(toIndentedString(rvParkingDimensions)).append("\n");
    sb.append("    rangeArea: ").append(toIndentedString(rangeArea)).append("\n");
    sb.append("    rentControlYN: ").append(toIndentedString(rentControlYN)).append("\n");
    sb.append("    rentIncludes: ").append(toIndentedString(rentIncludes)).append("\n");
    sb.append("    roadFrontageType: ").append(toIndentedString(roadFrontageType)).append("\n");
    sb.append("    roadResponsibility: ").append(toIndentedString(roadResponsibility)).append("\n");
    sb.append("    roadSurfaceType: ").append(toIndentedString(roadSurfaceType)).append("\n");
    sb.append("    roof: ").append(toIndentedString(roof)).append("\n");
    sb.append("    roomType: ").append(toIndentedString(roomType)).append("\n");
    sb.append("    roomsTotal: ").append(toIndentedString(roomsTotal)).append("\n");
    sb.append("    seatingCapacity: ").append(toIndentedString(seatingCapacity)).append("\n");
    sb.append("    securityFeatures: ").append(toIndentedString(securityFeatures)).append("\n");
    sb.append("    seniorCommunityYN: ").append(toIndentedString(seniorCommunityYN)).append("\n");
    sb.append("    serialU: ").append(toIndentedString(serialU)).append("\n");
    sb.append("    serialX: ").append(toIndentedString(serialX)).append("\n");
    sb.append("    serialXX: ").append(toIndentedString(serialXX)).append("\n");
    sb.append("    sewer: ").append(toIndentedString(sewer)).append("\n");
    sb.append("    showingAdvanceNotice: ").append(toIndentedString(showingAdvanceNotice)).append("\n");
    sb.append("    showingAttendedYN: ").append(toIndentedString(showingAttendedYN)).append("\n");
    sb.append("    showingContactName: ").append(toIndentedString(showingContactName)).append("\n");
    sb.append("    showingContactPhone: ").append(toIndentedString(showingContactPhone)).append("\n");
    sb.append("    showingContactPhoneExt: ").append(toIndentedString(showingContactPhoneExt)).append("\n");
    sb.append("    showingContactType: ").append(toIndentedString(showingContactType)).append("\n");
    sb.append("    showingDays: ").append(toIndentedString(showingDays)).append("\n");
    sb.append("    showingEndTime: ").append(toIndentedString(showingEndTime)).append("\n");
    sb.append("    showingInstructions: ").append(toIndentedString(showingInstructions)).append("\n");
    sb.append("    showingRequirements: ").append(toIndentedString(showingRequirements)).append("\n");
    sb.append("    showingStartTime: ").append(toIndentedString(showingStartTime)).append("\n");
    sb.append("    signOnPropertyYN: ").append(toIndentedString(signOnPropertyYN)).append("\n");
    sb.append("    skirt: ").append(toIndentedString(skirt)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemKey: ").append(toIndentedString(sourceSystemKey)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    spaFeatures: ").append(toIndentedString(spaFeatures)).append("\n");
    sb.append("    spaYN: ").append(toIndentedString(spaYN)).append("\n");
    sb.append("    specialLicenses: ").append(toIndentedString(specialLicenses)).append("\n");
    sb.append("    specialListingConditions: ").append(toIndentedString(specialListingConditions)).append("\n");
    sb.append("    standardStatus: ").append(toIndentedString(standardStatus)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    stateRegion: ").append(toIndentedString(stateRegion)).append("\n");
    sb.append("    statusChangeTimestamp: ").append(toIndentedString(statusChangeTimestamp)).append("\n");
    sb.append("    stories: ").append(toIndentedString(stories)).append("\n");
    sb.append("    storiesTotal: ").append(toIndentedString(storiesTotal)).append("\n");
    sb.append("    streetAdditionalInfo: ").append(toIndentedString(streetAdditionalInfo)).append("\n");
    sb.append("    streetDirPrefix: ").append(toIndentedString(streetDirPrefix)).append("\n");
    sb.append("    streetDirSuffix: ").append(toIndentedString(streetDirSuffix)).append("\n");
    sb.append("    streetName: ").append(toIndentedString(streetName)).append("\n");
    sb.append("    streetNumber: ").append(toIndentedString(streetNumber)).append("\n");
    sb.append("    streetNumberNumeric: ").append(toIndentedString(streetNumberNumeric)).append("\n");
    sb.append("    streetSuffix: ").append(toIndentedString(streetSuffix)).append("\n");
    sb.append("    streetSuffixModifier: ").append(toIndentedString(streetSuffixModifier)).append("\n");
    sb.append("    structureType: ").append(toIndentedString(structureType)).append("\n");
    sb.append("    subAgencyCompensation: ").append(toIndentedString(subAgencyCompensation)).append("\n");
    sb.append("    subAgencyCompensationType: ").append(toIndentedString(subAgencyCompensationType)).append("\n");
    sb.append("    subdivisionName: ").append(toIndentedString(subdivisionName)).append("\n");
    sb.append("    suppliesExpense: ").append(toIndentedString(suppliesExpense)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("    syndicationRemarks: ").append(toIndentedString(syndicationRemarks)).append("\n");
    sb.append("    taxAnnualAmount: ").append(toIndentedString(taxAnnualAmount)).append("\n");
    sb.append("    taxAssessedValue: ").append(toIndentedString(taxAssessedValue)).append("\n");
    sb.append("    taxBlock: ").append(toIndentedString(taxBlock)).append("\n");
    sb.append("    taxBookNumber: ").append(toIndentedString(taxBookNumber)).append("\n");
    sb.append("    taxLegalDescription: ").append(toIndentedString(taxLegalDescription)).append("\n");
    sb.append("    taxLot: ").append(toIndentedString(taxLot)).append("\n");
    sb.append("    taxMapNumber: ").append(toIndentedString(taxMapNumber)).append("\n");
    sb.append("    taxOtherAnnualAssessmentAmount: ").append(toIndentedString(taxOtherAnnualAssessmentAmount)).append("\n");
    sb.append("    taxParcelLetter: ").append(toIndentedString(taxParcelLetter)).append("\n");
    sb.append("    taxStatusCurrent: ").append(toIndentedString(taxStatusCurrent)).append("\n");
    sb.append("    taxTract: ").append(toIndentedString(taxTract)).append("\n");
    sb.append("    taxYear: ").append(toIndentedString(taxYear)).append("\n");
    sb.append("    tenantPays: ").append(toIndentedString(tenantPays)).append("\n");
    sb.append("    topography: ").append(toIndentedString(topography)).append("\n");
    sb.append("    totalActualRent: ").append(toIndentedString(totalActualRent)).append("\n");
    sb.append("    township: ").append(toIndentedString(township)).append("\n");
    sb.append("    transactionBrokerCompensation: ").append(toIndentedString(transactionBrokerCompensation)).append("\n");
    sb.append("    transactionBrokerCompensationType: ").append(toIndentedString(transactionBrokerCompensationType)).append("\n");
    sb.append("    trashExpense: ").append(toIndentedString(trashExpense)).append("\n");
    sb.append("    unitNumber: ").append(toIndentedString(unitNumber)).append("\n");
    sb.append("    unitTypeType: ").append(toIndentedString(unitTypeType)).append("\n");
    sb.append("    unitsFurnished: ").append(toIndentedString(unitsFurnished)).append("\n");
    sb.append("    universalPropertyId: ").append(toIndentedString(universalPropertyId)).append("\n");
    sb.append("    universalPropertySubId: ").append(toIndentedString(universalPropertySubId)).append("\n");
    sb.append("    unparsedAddress: ").append(toIndentedString(unparsedAddress)).append("\n");
    sb.append("    utilities: ").append(toIndentedString(utilities)).append("\n");
    sb.append("    vacancyAllowance: ").append(toIndentedString(vacancyAllowance)).append("\n");
    sb.append("    vacancyAllowanceRate: ").append(toIndentedString(vacancyAllowanceRate)).append("\n");
    sb.append("    vegetation: ").append(toIndentedString(vegetation)).append("\n");
    sb.append("    videosChangeTimestamp: ").append(toIndentedString(videosChangeTimestamp)).append("\n");
    sb.append("    videosCount: ").append(toIndentedString(videosCount)).append("\n");
    sb.append("    view: ").append(toIndentedString(view)).append("\n");
    sb.append("    viewYN: ").append(toIndentedString(viewYN)).append("\n");
    sb.append("    virtualTourURLBranded: ").append(toIndentedString(virtualTourURLBranded)).append("\n");
    sb.append("    virtualTourURLUnbranded: ").append(toIndentedString(virtualTourURLUnbranded)).append("\n");
    sb.append("    walkScore: ").append(toIndentedString(walkScore)).append("\n");
    sb.append("    waterBodyName: ").append(toIndentedString(waterBodyName)).append("\n");
    sb.append("    waterSewerExpense: ").append(toIndentedString(waterSewerExpense)).append("\n");
    sb.append("    waterSource: ").append(toIndentedString(waterSource)).append("\n");
    sb.append("    waterfrontFeatures: ").append(toIndentedString(waterfrontFeatures)).append("\n");
    sb.append("    waterfrontYN: ").append(toIndentedString(waterfrontYN)).append("\n");
    sb.append("    windowFeatures: ").append(toIndentedString(windowFeatures)).append("\n");
    sb.append("    withdrawnDate: ").append(toIndentedString(withdrawnDate)).append("\n");
    sb.append("    woodedArea: ").append(toIndentedString(woodedArea)).append("\n");
    sb.append("    workmansCompensationExpense: ").append(toIndentedString(workmansCompensationExpense)).append("\n");
    sb.append("    yearBuilt: ").append(toIndentedString(yearBuilt)).append("\n");
    sb.append("    yearBuiltDetails: ").append(toIndentedString(yearBuiltDetails)).append("\n");
    sb.append("    yearBuiltEffective: ").append(toIndentedString(yearBuiltEffective)).append("\n");
    sb.append("    yearBuiltSource: ").append(toIndentedString(yearBuiltSource)).append("\n");
    sb.append("    yearEstablished: ").append(toIndentedString(yearEstablished)).append("\n");
    sb.append("    yearsCurrentOwner: ").append(toIndentedString(yearsCurrentOwner)).append("\n");
    sb.append("    zoning: ").append(toIndentedString(zoning)).append("\n");
    sb.append("    zoningDescription: ").append(toIndentedString(zoningDescription)).append("\n");
    sb.append("    originatingSystem: ").append(toIndentedString(originatingSystem)).append("\n");
    sb.append("    buyerAgent: ").append(toIndentedString(buyerAgent)).append("\n");
    sb.append("    buyerOffice: ").append(toIndentedString(buyerOffice)).append("\n");
    sb.append("    coBuyerAgent: ").append(toIndentedString(coBuyerAgent)).append("\n");
    sb.append("    coBuyerOffice: ").append(toIndentedString(coBuyerOffice)).append("\n");
    sb.append("    coListAgent: ").append(toIndentedString(coListAgent)).append("\n");
    sb.append("    coListOffice: ").append(toIndentedString(coListOffice)).append("\n");
    sb.append("    listAgent: ").append(toIndentedString(listAgent)).append("\n");
    sb.append("    listOffice: ").append(toIndentedString(listOffice)).append("\n");
    sb.append("    buyerTeam: ").append(toIndentedString(buyerTeam)).append("\n");
    sb.append("    listTeam: ").append(toIndentedString(listTeam)).append("\n");
    sb.append("    sourceSystem: ").append(toIndentedString(sourceSystem)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("    media: ").append(toIndentedString(media)).append("\n");
    sb.append("    socialMedia: ").append(toIndentedString(socialMedia)).append("\n");
    sb.append("    openHouse: ").append(toIndentedString(openHouse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
