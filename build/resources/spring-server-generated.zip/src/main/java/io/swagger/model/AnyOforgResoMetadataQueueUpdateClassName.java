package io.swagger.model;


/**
* AnyOforgResoMetadataQueueUpdateClassName
*/
public interface AnyOforgResoMetadataQueueUpdateClassName {

}
