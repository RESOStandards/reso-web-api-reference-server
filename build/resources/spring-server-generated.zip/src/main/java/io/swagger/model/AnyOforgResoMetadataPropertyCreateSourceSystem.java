package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateSourceSystem
*/
public interface AnyOforgResoMetadataPropertyCreateSourceSystem {

}
