package io.swagger.model;


/**
* AnyOforgResoMetadataMemberUpdateMemberCountyOrParish
*/
public interface AnyOforgResoMetadataMemberUpdateMemberCountyOrParish {

}
