package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets org.reso.metadata.enums.GreenSustainability
 */
public enum OrgResoMetadataEnumsGreenSustainability {
  CONSERVINGMETHODS("ConservingMethods"),
    ONSITERECYCLINGCENTER("OnsiteRecyclingCenter"),
    RECYCLABLEMATERIALS("RecyclableMaterials"),
    RECYCLEDMATERIALS("RecycledMaterials"),
    REGIONALLYSOURCEDMATERIALS("RegionallySourcedMaterials"),
    RENEWABLEMATERIALS("RenewableMaterials"),
    SALVAGEDMATERIALS("SalvagedMaterials");

  private String value;

  OrgResoMetadataEnumsGreenSustainability(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static OrgResoMetadataEnumsGreenSustainability fromValue(String text) {
    for (OrgResoMetadataEnumsGreenSustainability b : OrgResoMetadataEnumsGreenSustainability.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
