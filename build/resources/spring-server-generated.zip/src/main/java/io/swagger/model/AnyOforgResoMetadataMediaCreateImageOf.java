package io.swagger.model;


/**
* AnyOforgResoMetadataMediaCreateImageOf
*/
public interface AnyOforgResoMetadataMediaCreateImageOf {

}
