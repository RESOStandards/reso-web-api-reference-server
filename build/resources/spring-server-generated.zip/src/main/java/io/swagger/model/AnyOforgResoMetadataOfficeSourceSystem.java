package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeSourceSystem
*/
public interface AnyOforgResoMetadataOfficeSourceSystem {

}
