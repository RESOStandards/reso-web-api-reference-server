package io.swagger.model;


/**
* AnyOforgResoMetadataPropertySuppliesExpense
*/
public interface AnyOforgResoMetadataPropertySuppliesExpense {

}
