package io.swagger.model;


/**
* AnyOforgResoMetadataShowingUpdateShowingKeyNumeric
*/
public interface AnyOforgResoMetadataShowingUpdateShowingKeyNumeric {

}
