package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType
*/
public interface AnyOforgResoMetadataPropertyUpdateBuyerAgencyCompensationType {

}
