package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataEnumsSyndicateTo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOfficeUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOfficeUpdate   {
  @JsonProperty("FranchiseAffiliation")
  private String franchiseAffiliation = null;

  @JsonProperty("IDXOfficeParticipationYN")
  private Boolean idXOfficeParticipationYN = null;

  @JsonProperty("MainOfficeKey")
  private String mainOfficeKey = null;

  @JsonProperty("MainOfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric mainOfficeKeyNumeric = null;

  @JsonProperty("MainOfficeMlsId")
  private String mainOfficeMlsId = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OfficeAOR")
  private AnyOforgResoMetadataOfficeUpdateOfficeAOR officeAOR = null;

  @JsonProperty("OfficeAORMlsId")
  private String officeAORMlsId = null;

  @JsonProperty("OfficeAORkey")
  private String officeAORkey = null;

  @JsonProperty("OfficeAORkeyNumeric")
  private AnyOforgResoMetadataOfficeUpdateOfficeAORkeyNumeric officeAORkeyNumeric = null;

  @JsonProperty("OfficeAddress1")
  private String officeAddress1 = null;

  @JsonProperty("OfficeAddress2")
  private String officeAddress2 = null;

  @JsonProperty("OfficeAssociationComments")
  private String officeAssociationComments = null;

  @JsonProperty("OfficeBranchType")
  private AnyOforgResoMetadataOfficeUpdateOfficeBranchType officeBranchType = null;

  @JsonProperty("OfficeBrokerKey")
  private String officeBrokerKey = null;

  @JsonProperty("OfficeBrokerKeyNumeric")
  private AnyOforgResoMetadataOfficeUpdateOfficeBrokerKeyNumeric officeBrokerKeyNumeric = null;

  @JsonProperty("OfficeBrokerMlsId")
  private String officeBrokerMlsId = null;

  @JsonProperty("OfficeCity")
  private String officeCity = null;

  @JsonProperty("OfficeCorporateLicense")
  private String officeCorporateLicense = null;

  @JsonProperty("OfficeCountyOrParish")
  private AnyOforgResoMetadataOfficeUpdateOfficeCountyOrParish officeCountyOrParish = null;

  @JsonProperty("OfficeEmail")
  private String officeEmail = null;

  @JsonProperty("OfficeFax")
  private String officeFax = null;

  @JsonProperty("OfficeKeyNumeric")
  private AnyOforgResoMetadataOfficeUpdateOfficeKeyNumeric officeKeyNumeric = null;

  @JsonProperty("OfficeManagerKey")
  private String officeManagerKey = null;

  @JsonProperty("OfficeManagerKeyNumeric")
  private AnyOforgResoMetadataOfficeUpdateOfficeManagerKeyNumeric officeManagerKeyNumeric = null;

  @JsonProperty("OfficeManagerMlsId")
  private String officeManagerMlsId = null;

  @JsonProperty("OfficeMlsId")
  private String officeMlsId = null;

  @JsonProperty("OfficeName")
  private String officeName = null;

  @JsonProperty("OfficeNationalAssociationId")
  private String officeNationalAssociationId = null;

  @JsonProperty("OfficePhone")
  private String officePhone = null;

  @JsonProperty("OfficePhoneExt")
  private String officePhoneExt = null;

  @JsonProperty("OfficePostalCode")
  private String officePostalCode = null;

  @JsonProperty("OfficePostalCodePlus4")
  private String officePostalCodePlus4 = null;

  @JsonProperty("OfficeStateOrProvince")
  private AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince officeStateOrProvince = null;

  @JsonProperty("OfficeStatus")
  private AnyOforgResoMetadataOfficeUpdateOfficeStatus officeStatus = null;

  @JsonProperty("OfficeType")
  private AnyOforgResoMetadataOfficeUpdateOfficeType officeType = null;

  @JsonProperty("OriginalEntryTimestamp")
  private OffsetDateTime originalEntryTimestamp = null;

  @JsonProperty("OriginatingSystemID")
  private String originatingSystemID = null;

  @JsonProperty("OriginatingSystemName")
  private String originatingSystemName = null;

  @JsonProperty("OriginatingSystemOfficeKey")
  private String originatingSystemOfficeKey = null;

  @JsonProperty("SocialMediaType")
  private AnyOforgResoMetadataOfficeUpdateSocialMediaType socialMediaType = null;

  @JsonProperty("SourceSystemID")
  private String sourceSystemID = null;

  @JsonProperty("SourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("SourceSystemOfficeKey")
  private String sourceSystemOfficeKey = null;

  @JsonProperty("SyndicateAgentOption")
  private AnyOforgResoMetadataOfficeUpdateSyndicateAgentOption syndicateAgentOption = null;

  @JsonProperty("SyndicateTo")
  @Valid
  private List<OrgResoMetadataEnumsSyndicateTo> syndicateTo = null;

  public OrgResoMetadataOfficeUpdate franchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
    return this;
  }

  /**
   * Get franchiseAffiliation
   * @return franchiseAffiliation
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getFranchiseAffiliation() {
    return franchiseAffiliation;
  }

  public void setFranchiseAffiliation(String franchiseAffiliation) {
    this.franchiseAffiliation = franchiseAffiliation;
  }

  public OrgResoMetadataOfficeUpdate idXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
    return this;
  }

  /**
   * Get idXOfficeParticipationYN
   * @return idXOfficeParticipationYN
   **/
  @Schema(description = "")
  
    public Boolean isIdXOfficeParticipationYN() {
    return idXOfficeParticipationYN;
  }

  public void setIdXOfficeParticipationYN(Boolean idXOfficeParticipationYN) {
    this.idXOfficeParticipationYN = idXOfficeParticipationYN;
  }

  public OrgResoMetadataOfficeUpdate mainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
    return this;
  }

  /**
   * Get mainOfficeKey
   * @return mainOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getMainOfficeKey() {
    return mainOfficeKey;
  }

  public void setMainOfficeKey(String mainOfficeKey) {
    this.mainOfficeKey = mainOfficeKey;
  }

  public OrgResoMetadataOfficeUpdate mainOfficeKeyNumeric(AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
    return this;
  }

  /**
   * Get mainOfficeKeyNumeric
   * @return mainOfficeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric getMainOfficeKeyNumeric() {
    return mainOfficeKeyNumeric;
  }

  public void setMainOfficeKeyNumeric(AnyOforgResoMetadataOfficeUpdateMainOfficeKeyNumeric mainOfficeKeyNumeric) {
    this.mainOfficeKeyNumeric = mainOfficeKeyNumeric;
  }

  public OrgResoMetadataOfficeUpdate mainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
    return this;
  }

  /**
   * Get mainOfficeMlsId
   * @return mainOfficeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getMainOfficeMlsId() {
    return mainOfficeMlsId;
  }

  public void setMainOfficeMlsId(String mainOfficeMlsId) {
    this.mainOfficeMlsId = mainOfficeMlsId;
  }

  public OrgResoMetadataOfficeUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOfficeUpdate officeAOR(AnyOforgResoMetadataOfficeUpdateOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
    return this;
  }

  /**
   * Get officeAOR
   * @return officeAOR
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeAOR getOfficeAOR() {
    return officeAOR;
  }

  public void setOfficeAOR(AnyOforgResoMetadataOfficeUpdateOfficeAOR officeAOR) {
    this.officeAOR = officeAOR;
  }

  public OrgResoMetadataOfficeUpdate officeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
    return this;
  }

  /**
   * Get officeAORMlsId
   * @return officeAORMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeAORMlsId() {
    return officeAORMlsId;
  }

  public void setOfficeAORMlsId(String officeAORMlsId) {
    this.officeAORMlsId = officeAORMlsId;
  }

  public OrgResoMetadataOfficeUpdate officeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
    return this;
  }

  /**
   * Get officeAORkey
   * @return officeAORkey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeAORkey() {
    return officeAORkey;
  }

  public void setOfficeAORkey(String officeAORkey) {
    this.officeAORkey = officeAORkey;
  }

  public OrgResoMetadataOfficeUpdate officeAORkeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
    return this;
  }

  /**
   * Get officeAORkeyNumeric
   * @return officeAORkeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeAORkeyNumeric getOfficeAORkeyNumeric() {
    return officeAORkeyNumeric;
  }

  public void setOfficeAORkeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeAORkeyNumeric officeAORkeyNumeric) {
    this.officeAORkeyNumeric = officeAORkeyNumeric;
  }

  public OrgResoMetadataOfficeUpdate officeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
    return this;
  }

  /**
   * Get officeAddress1
   * @return officeAddress1
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress1() {
    return officeAddress1;
  }

  public void setOfficeAddress1(String officeAddress1) {
    this.officeAddress1 = officeAddress1;
  }

  public OrgResoMetadataOfficeUpdate officeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
    return this;
  }

  /**
   * Get officeAddress2
   * @return officeAddress2
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeAddress2() {
    return officeAddress2;
  }

  public void setOfficeAddress2(String officeAddress2) {
    this.officeAddress2 = officeAddress2;
  }

  public OrgResoMetadataOfficeUpdate officeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
    return this;
  }

  /**
   * Get officeAssociationComments
   * @return officeAssociationComments
   **/
  @Schema(description = "")
  
  @Size(max=500)   public String getOfficeAssociationComments() {
    return officeAssociationComments;
  }

  public void setOfficeAssociationComments(String officeAssociationComments) {
    this.officeAssociationComments = officeAssociationComments;
  }

  public OrgResoMetadataOfficeUpdate officeBranchType(AnyOforgResoMetadataOfficeUpdateOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
    return this;
  }

  /**
   * Get officeBranchType
   * @return officeBranchType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeBranchType getOfficeBranchType() {
    return officeBranchType;
  }

  public void setOfficeBranchType(AnyOforgResoMetadataOfficeUpdateOfficeBranchType officeBranchType) {
    this.officeBranchType = officeBranchType;
  }

  public OrgResoMetadataOfficeUpdate officeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
    return this;
  }

  /**
   * Get officeBrokerKey
   * @return officeBrokerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeBrokerKey() {
    return officeBrokerKey;
  }

  public void setOfficeBrokerKey(String officeBrokerKey) {
    this.officeBrokerKey = officeBrokerKey;
  }

  public OrgResoMetadataOfficeUpdate officeBrokerKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
    return this;
  }

  /**
   * Get officeBrokerKeyNumeric
   * @return officeBrokerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeBrokerKeyNumeric getOfficeBrokerKeyNumeric() {
    return officeBrokerKeyNumeric;
  }

  public void setOfficeBrokerKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeBrokerKeyNumeric officeBrokerKeyNumeric) {
    this.officeBrokerKeyNumeric = officeBrokerKeyNumeric;
  }

  public OrgResoMetadataOfficeUpdate officeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
    return this;
  }

  /**
   * Get officeBrokerMlsId
   * @return officeBrokerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeBrokerMlsId() {
    return officeBrokerMlsId;
  }

  public void setOfficeBrokerMlsId(String officeBrokerMlsId) {
    this.officeBrokerMlsId = officeBrokerMlsId;
  }

  public OrgResoMetadataOfficeUpdate officeCity(String officeCity) {
    this.officeCity = officeCity;
    return this;
  }

  /**
   * Get officeCity
   * @return officeCity
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCity() {
    return officeCity;
  }

  public void setOfficeCity(String officeCity) {
    this.officeCity = officeCity;
  }

  public OrgResoMetadataOfficeUpdate officeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
    return this;
  }

  /**
   * Get officeCorporateLicense
   * @return officeCorporateLicense
   **/
  @Schema(description = "")
  
  @Size(max=50)   public String getOfficeCorporateLicense() {
    return officeCorporateLicense;
  }

  public void setOfficeCorporateLicense(String officeCorporateLicense) {
    this.officeCorporateLicense = officeCorporateLicense;
  }

  public OrgResoMetadataOfficeUpdate officeCountyOrParish(AnyOforgResoMetadataOfficeUpdateOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
    return this;
  }

  /**
   * Get officeCountyOrParish
   * @return officeCountyOrParish
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeCountyOrParish getOfficeCountyOrParish() {
    return officeCountyOrParish;
  }

  public void setOfficeCountyOrParish(AnyOforgResoMetadataOfficeUpdateOfficeCountyOrParish officeCountyOrParish) {
    this.officeCountyOrParish = officeCountyOrParish;
  }

  public OrgResoMetadataOfficeUpdate officeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
    return this;
  }

  /**
   * Get officeEmail
   * @return officeEmail
   **/
  @Schema(description = "")
  
  @Size(max=80)   public String getOfficeEmail() {
    return officeEmail;
  }

  public void setOfficeEmail(String officeEmail) {
    this.officeEmail = officeEmail;
  }

  public OrgResoMetadataOfficeUpdate officeFax(String officeFax) {
    this.officeFax = officeFax;
    return this;
  }

  /**
   * Get officeFax
   * @return officeFax
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficeFax() {
    return officeFax;
  }

  public void setOfficeFax(String officeFax) {
    this.officeFax = officeFax;
  }

  public OrgResoMetadataOfficeUpdate officeKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
    return this;
  }

  /**
   * Get officeKeyNumeric
   * @return officeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeKeyNumeric getOfficeKeyNumeric() {
    return officeKeyNumeric;
  }

  public void setOfficeKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeKeyNumeric officeKeyNumeric) {
    this.officeKeyNumeric = officeKeyNumeric;
  }

  public OrgResoMetadataOfficeUpdate officeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
    return this;
  }

  /**
   * Get officeManagerKey
   * @return officeManagerKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeManagerKey() {
    return officeManagerKey;
  }

  public void setOfficeManagerKey(String officeManagerKey) {
    this.officeManagerKey = officeManagerKey;
  }

  public OrgResoMetadataOfficeUpdate officeManagerKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
    return this;
  }

  /**
   * Get officeManagerKeyNumeric
   * @return officeManagerKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeManagerKeyNumeric getOfficeManagerKeyNumeric() {
    return officeManagerKeyNumeric;
  }

  public void setOfficeManagerKeyNumeric(AnyOforgResoMetadataOfficeUpdateOfficeManagerKeyNumeric officeManagerKeyNumeric) {
    this.officeManagerKeyNumeric = officeManagerKeyNumeric;
  }

  public OrgResoMetadataOfficeUpdate officeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
    return this;
  }

  /**
   * Get officeManagerMlsId
   * @return officeManagerMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeManagerMlsId() {
    return officeManagerMlsId;
  }

  public void setOfficeManagerMlsId(String officeManagerMlsId) {
    this.officeManagerMlsId = officeManagerMlsId;
  }

  public OrgResoMetadataOfficeUpdate officeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
    return this;
  }

  /**
   * Get officeMlsId
   * @return officeMlsId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeMlsId() {
    return officeMlsId;
  }

  public void setOfficeMlsId(String officeMlsId) {
    this.officeMlsId = officeMlsId;
  }

  public OrgResoMetadataOfficeUpdate officeName(String officeName) {
    this.officeName = officeName;
    return this;
  }

  /**
   * Get officeName
   * @return officeName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOfficeName() {
    return officeName;
  }

  public void setOfficeName(String officeName) {
    this.officeName = officeName;
  }

  public OrgResoMetadataOfficeUpdate officeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
    return this;
  }

  /**
   * Get officeNationalAssociationId
   * @return officeNationalAssociationId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOfficeNationalAssociationId() {
    return officeNationalAssociationId;
  }

  public void setOfficeNationalAssociationId(String officeNationalAssociationId) {
    this.officeNationalAssociationId = officeNationalAssociationId;
  }

  public OrgResoMetadataOfficeUpdate officePhone(String officePhone) {
    this.officePhone = officePhone;
    return this;
  }

  /**
   * Get officePhone
   * @return officePhone
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOfficePhone() {
    return officePhone;
  }

  public void setOfficePhone(String officePhone) {
    this.officePhone = officePhone;
  }

  public OrgResoMetadataOfficeUpdate officePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
    return this;
  }

  /**
   * Get officePhoneExt
   * @return officePhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePhoneExt() {
    return officePhoneExt;
  }

  public void setOfficePhoneExt(String officePhoneExt) {
    this.officePhoneExt = officePhoneExt;
  }

  public OrgResoMetadataOfficeUpdate officePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
    return this;
  }

  /**
   * Get officePostalCode
   * @return officePostalCode
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOfficePostalCode() {
    return officePostalCode;
  }

  public void setOfficePostalCode(String officePostalCode) {
    this.officePostalCode = officePostalCode;
  }

  public OrgResoMetadataOfficeUpdate officePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
    return this;
  }

  /**
   * Get officePostalCodePlus4
   * @return officePostalCodePlus4
   **/
  @Schema(description = "")
  
  @Size(max=4)   public String getOfficePostalCodePlus4() {
    return officePostalCodePlus4;
  }

  public void setOfficePostalCodePlus4(String officePostalCodePlus4) {
    this.officePostalCodePlus4 = officePostalCodePlus4;
  }

  public OrgResoMetadataOfficeUpdate officeStateOrProvince(AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
    return this;
  }

  /**
   * Get officeStateOrProvince
   * @return officeStateOrProvince
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince getOfficeStateOrProvince() {
    return officeStateOrProvince;
  }

  public void setOfficeStateOrProvince(AnyOforgResoMetadataOfficeUpdateOfficeStateOrProvince officeStateOrProvince) {
    this.officeStateOrProvince = officeStateOrProvince;
  }

  public OrgResoMetadataOfficeUpdate officeStatus(AnyOforgResoMetadataOfficeUpdateOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
    return this;
  }

  /**
   * Get officeStatus
   * @return officeStatus
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeStatus getOfficeStatus() {
    return officeStatus;
  }

  public void setOfficeStatus(AnyOforgResoMetadataOfficeUpdateOfficeStatus officeStatus) {
    this.officeStatus = officeStatus;
  }

  public OrgResoMetadataOfficeUpdate officeType(AnyOforgResoMetadataOfficeUpdateOfficeType officeType) {
    this.officeType = officeType;
    return this;
  }

  /**
   * Get officeType
   * @return officeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateOfficeType getOfficeType() {
    return officeType;
  }

  public void setOfficeType(AnyOforgResoMetadataOfficeUpdateOfficeType officeType) {
    this.officeType = officeType;
  }

  public OrgResoMetadataOfficeUpdate originalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
    return this;
  }

  /**
   * Get originalEntryTimestamp
   * @return originalEntryTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getOriginalEntryTimestamp() {
    return originalEntryTimestamp;
  }

  public void setOriginalEntryTimestamp(OffsetDateTime originalEntryTimestamp) {
    this.originalEntryTimestamp = originalEntryTimestamp;
  }

  public OrgResoMetadataOfficeUpdate originatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
    return this;
  }

  /**
   * Get originatingSystemID
   * @return originatingSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getOriginatingSystemID() {
    return originatingSystemID;
  }

  public void setOriginatingSystemID(String originatingSystemID) {
    this.originatingSystemID = originatingSystemID;
  }

  public OrgResoMetadataOfficeUpdate originatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
    return this;
  }

  /**
   * Get originatingSystemName
   * @return originatingSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemName() {
    return originatingSystemName;
  }

  public void setOriginatingSystemName(String originatingSystemName) {
    this.originatingSystemName = originatingSystemName;
  }

  public OrgResoMetadataOfficeUpdate originatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
    return this;
  }

  /**
   * Get originatingSystemOfficeKey
   * @return originatingSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getOriginatingSystemOfficeKey() {
    return originatingSystemOfficeKey;
  }

  public void setOriginatingSystemOfficeKey(String originatingSystemOfficeKey) {
    this.originatingSystemOfficeKey = originatingSystemOfficeKey;
  }

  public OrgResoMetadataOfficeUpdate socialMediaType(AnyOforgResoMetadataOfficeUpdateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
    return this;
  }

  /**
   * Get socialMediaType
   * @return socialMediaType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateSocialMediaType getSocialMediaType() {
    return socialMediaType;
  }

  public void setSocialMediaType(AnyOforgResoMetadataOfficeUpdateSocialMediaType socialMediaType) {
    this.socialMediaType = socialMediaType;
  }

  public OrgResoMetadataOfficeUpdate sourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
    return this;
  }

  /**
   * Get sourceSystemID
   * @return sourceSystemID
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getSourceSystemID() {
    return sourceSystemID;
  }

  public void setSourceSystemID(String sourceSystemID) {
    this.sourceSystemID = sourceSystemID;
  }

  public OrgResoMetadataOfficeUpdate sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * @return sourceSystemName
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrgResoMetadataOfficeUpdate sourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
    return this;
  }

  /**
   * Get sourceSystemOfficeKey
   * @return sourceSystemOfficeKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getSourceSystemOfficeKey() {
    return sourceSystemOfficeKey;
  }

  public void setSourceSystemOfficeKey(String sourceSystemOfficeKey) {
    this.sourceSystemOfficeKey = sourceSystemOfficeKey;
  }

  public OrgResoMetadataOfficeUpdate syndicateAgentOption(AnyOforgResoMetadataOfficeUpdateSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
    return this;
  }

  /**
   * Get syndicateAgentOption
   * @return syndicateAgentOption
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOfficeUpdateSyndicateAgentOption getSyndicateAgentOption() {
    return syndicateAgentOption;
  }

  public void setSyndicateAgentOption(AnyOforgResoMetadataOfficeUpdateSyndicateAgentOption syndicateAgentOption) {
    this.syndicateAgentOption = syndicateAgentOption;
  }

  public OrgResoMetadataOfficeUpdate syndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
    return this;
  }

  public OrgResoMetadataOfficeUpdate addSyndicateToItem(OrgResoMetadataEnumsSyndicateTo syndicateToItem) {
    if (this.syndicateTo == null) {
      this.syndicateTo = new ArrayList<OrgResoMetadataEnumsSyndicateTo>();
    }
    this.syndicateTo.add(syndicateToItem);
    return this;
  }

  /**
   * Get syndicateTo
   * @return syndicateTo
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataEnumsSyndicateTo> getSyndicateTo() {
    return syndicateTo;
  }

  public void setSyndicateTo(List<OrgResoMetadataEnumsSyndicateTo> syndicateTo) {
    this.syndicateTo = syndicateTo;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOfficeUpdate orgResoMetadataOfficeUpdate = (OrgResoMetadataOfficeUpdate) o;
    return Objects.equals(this.franchiseAffiliation, orgResoMetadataOfficeUpdate.franchiseAffiliation) &&
        Objects.equals(this.idXOfficeParticipationYN, orgResoMetadataOfficeUpdate.idXOfficeParticipationYN) &&
        Objects.equals(this.mainOfficeKey, orgResoMetadataOfficeUpdate.mainOfficeKey) &&
        Objects.equals(this.mainOfficeKeyNumeric, orgResoMetadataOfficeUpdate.mainOfficeKeyNumeric) &&
        Objects.equals(this.mainOfficeMlsId, orgResoMetadataOfficeUpdate.mainOfficeMlsId) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOfficeUpdate.modificationTimestamp) &&
        Objects.equals(this.officeAOR, orgResoMetadataOfficeUpdate.officeAOR) &&
        Objects.equals(this.officeAORMlsId, orgResoMetadataOfficeUpdate.officeAORMlsId) &&
        Objects.equals(this.officeAORkey, orgResoMetadataOfficeUpdate.officeAORkey) &&
        Objects.equals(this.officeAORkeyNumeric, orgResoMetadataOfficeUpdate.officeAORkeyNumeric) &&
        Objects.equals(this.officeAddress1, orgResoMetadataOfficeUpdate.officeAddress1) &&
        Objects.equals(this.officeAddress2, orgResoMetadataOfficeUpdate.officeAddress2) &&
        Objects.equals(this.officeAssociationComments, orgResoMetadataOfficeUpdate.officeAssociationComments) &&
        Objects.equals(this.officeBranchType, orgResoMetadataOfficeUpdate.officeBranchType) &&
        Objects.equals(this.officeBrokerKey, orgResoMetadataOfficeUpdate.officeBrokerKey) &&
        Objects.equals(this.officeBrokerKeyNumeric, orgResoMetadataOfficeUpdate.officeBrokerKeyNumeric) &&
        Objects.equals(this.officeBrokerMlsId, orgResoMetadataOfficeUpdate.officeBrokerMlsId) &&
        Objects.equals(this.officeCity, orgResoMetadataOfficeUpdate.officeCity) &&
        Objects.equals(this.officeCorporateLicense, orgResoMetadataOfficeUpdate.officeCorporateLicense) &&
        Objects.equals(this.officeCountyOrParish, orgResoMetadataOfficeUpdate.officeCountyOrParish) &&
        Objects.equals(this.officeEmail, orgResoMetadataOfficeUpdate.officeEmail) &&
        Objects.equals(this.officeFax, orgResoMetadataOfficeUpdate.officeFax) &&
        Objects.equals(this.officeKeyNumeric, orgResoMetadataOfficeUpdate.officeKeyNumeric) &&
        Objects.equals(this.officeManagerKey, orgResoMetadataOfficeUpdate.officeManagerKey) &&
        Objects.equals(this.officeManagerKeyNumeric, orgResoMetadataOfficeUpdate.officeManagerKeyNumeric) &&
        Objects.equals(this.officeManagerMlsId, orgResoMetadataOfficeUpdate.officeManagerMlsId) &&
        Objects.equals(this.officeMlsId, orgResoMetadataOfficeUpdate.officeMlsId) &&
        Objects.equals(this.officeName, orgResoMetadataOfficeUpdate.officeName) &&
        Objects.equals(this.officeNationalAssociationId, orgResoMetadataOfficeUpdate.officeNationalAssociationId) &&
        Objects.equals(this.officePhone, orgResoMetadataOfficeUpdate.officePhone) &&
        Objects.equals(this.officePhoneExt, orgResoMetadataOfficeUpdate.officePhoneExt) &&
        Objects.equals(this.officePostalCode, orgResoMetadataOfficeUpdate.officePostalCode) &&
        Objects.equals(this.officePostalCodePlus4, orgResoMetadataOfficeUpdate.officePostalCodePlus4) &&
        Objects.equals(this.officeStateOrProvince, orgResoMetadataOfficeUpdate.officeStateOrProvince) &&
        Objects.equals(this.officeStatus, orgResoMetadataOfficeUpdate.officeStatus) &&
        Objects.equals(this.officeType, orgResoMetadataOfficeUpdate.officeType) &&
        Objects.equals(this.originalEntryTimestamp, orgResoMetadataOfficeUpdate.originalEntryTimestamp) &&
        Objects.equals(this.originatingSystemID, orgResoMetadataOfficeUpdate.originatingSystemID) &&
        Objects.equals(this.originatingSystemName, orgResoMetadataOfficeUpdate.originatingSystemName) &&
        Objects.equals(this.originatingSystemOfficeKey, orgResoMetadataOfficeUpdate.originatingSystemOfficeKey) &&
        Objects.equals(this.socialMediaType, orgResoMetadataOfficeUpdate.socialMediaType) &&
        Objects.equals(this.sourceSystemID, orgResoMetadataOfficeUpdate.sourceSystemID) &&
        Objects.equals(this.sourceSystemName, orgResoMetadataOfficeUpdate.sourceSystemName) &&
        Objects.equals(this.sourceSystemOfficeKey, orgResoMetadataOfficeUpdate.sourceSystemOfficeKey) &&
        Objects.equals(this.syndicateAgentOption, orgResoMetadataOfficeUpdate.syndicateAgentOption) &&
        Objects.equals(this.syndicateTo, orgResoMetadataOfficeUpdate.syndicateTo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(franchiseAffiliation, idXOfficeParticipationYN, mainOfficeKey, mainOfficeKeyNumeric, mainOfficeMlsId, modificationTimestamp, officeAOR, officeAORMlsId, officeAORkey, officeAORkeyNumeric, officeAddress1, officeAddress2, officeAssociationComments, officeBranchType, officeBrokerKey, officeBrokerKeyNumeric, officeBrokerMlsId, officeCity, officeCorporateLicense, officeCountyOrParish, officeEmail, officeFax, officeKeyNumeric, officeManagerKey, officeManagerKeyNumeric, officeManagerMlsId, officeMlsId, officeName, officeNationalAssociationId, officePhone, officePhoneExt, officePostalCode, officePostalCodePlus4, officeStateOrProvince, officeStatus, officeType, originalEntryTimestamp, originatingSystemID, originatingSystemName, originatingSystemOfficeKey, socialMediaType, sourceSystemID, sourceSystemName, sourceSystemOfficeKey, syndicateAgentOption, syndicateTo);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOfficeUpdate {\n");
    
    sb.append("    franchiseAffiliation: ").append(toIndentedString(franchiseAffiliation)).append("\n");
    sb.append("    idXOfficeParticipationYN: ").append(toIndentedString(idXOfficeParticipationYN)).append("\n");
    sb.append("    mainOfficeKey: ").append(toIndentedString(mainOfficeKey)).append("\n");
    sb.append("    mainOfficeKeyNumeric: ").append(toIndentedString(mainOfficeKeyNumeric)).append("\n");
    sb.append("    mainOfficeMlsId: ").append(toIndentedString(mainOfficeMlsId)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    officeAOR: ").append(toIndentedString(officeAOR)).append("\n");
    sb.append("    officeAORMlsId: ").append(toIndentedString(officeAORMlsId)).append("\n");
    sb.append("    officeAORkey: ").append(toIndentedString(officeAORkey)).append("\n");
    sb.append("    officeAORkeyNumeric: ").append(toIndentedString(officeAORkeyNumeric)).append("\n");
    sb.append("    officeAddress1: ").append(toIndentedString(officeAddress1)).append("\n");
    sb.append("    officeAddress2: ").append(toIndentedString(officeAddress2)).append("\n");
    sb.append("    officeAssociationComments: ").append(toIndentedString(officeAssociationComments)).append("\n");
    sb.append("    officeBranchType: ").append(toIndentedString(officeBranchType)).append("\n");
    sb.append("    officeBrokerKey: ").append(toIndentedString(officeBrokerKey)).append("\n");
    sb.append("    officeBrokerKeyNumeric: ").append(toIndentedString(officeBrokerKeyNumeric)).append("\n");
    sb.append("    officeBrokerMlsId: ").append(toIndentedString(officeBrokerMlsId)).append("\n");
    sb.append("    officeCity: ").append(toIndentedString(officeCity)).append("\n");
    sb.append("    officeCorporateLicense: ").append(toIndentedString(officeCorporateLicense)).append("\n");
    sb.append("    officeCountyOrParish: ").append(toIndentedString(officeCountyOrParish)).append("\n");
    sb.append("    officeEmail: ").append(toIndentedString(officeEmail)).append("\n");
    sb.append("    officeFax: ").append(toIndentedString(officeFax)).append("\n");
    sb.append("    officeKeyNumeric: ").append(toIndentedString(officeKeyNumeric)).append("\n");
    sb.append("    officeManagerKey: ").append(toIndentedString(officeManagerKey)).append("\n");
    sb.append("    officeManagerKeyNumeric: ").append(toIndentedString(officeManagerKeyNumeric)).append("\n");
    sb.append("    officeManagerMlsId: ").append(toIndentedString(officeManagerMlsId)).append("\n");
    sb.append("    officeMlsId: ").append(toIndentedString(officeMlsId)).append("\n");
    sb.append("    officeName: ").append(toIndentedString(officeName)).append("\n");
    sb.append("    officeNationalAssociationId: ").append(toIndentedString(officeNationalAssociationId)).append("\n");
    sb.append("    officePhone: ").append(toIndentedString(officePhone)).append("\n");
    sb.append("    officePhoneExt: ").append(toIndentedString(officePhoneExt)).append("\n");
    sb.append("    officePostalCode: ").append(toIndentedString(officePostalCode)).append("\n");
    sb.append("    officePostalCodePlus4: ").append(toIndentedString(officePostalCodePlus4)).append("\n");
    sb.append("    officeStateOrProvince: ").append(toIndentedString(officeStateOrProvince)).append("\n");
    sb.append("    officeStatus: ").append(toIndentedString(officeStatus)).append("\n");
    sb.append("    officeType: ").append(toIndentedString(officeType)).append("\n");
    sb.append("    originalEntryTimestamp: ").append(toIndentedString(originalEntryTimestamp)).append("\n");
    sb.append("    originatingSystemID: ").append(toIndentedString(originatingSystemID)).append("\n");
    sb.append("    originatingSystemName: ").append(toIndentedString(originatingSystemName)).append("\n");
    sb.append("    originatingSystemOfficeKey: ").append(toIndentedString(originatingSystemOfficeKey)).append("\n");
    sb.append("    socialMediaType: ").append(toIndentedString(socialMediaType)).append("\n");
    sb.append("    sourceSystemID: ").append(toIndentedString(sourceSystemID)).append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    sourceSystemOfficeKey: ").append(toIndentedString(sourceSystemOfficeKey)).append("\n");
    sb.append("    syndicateAgentOption: ").append(toIndentedString(syndicateAgentOption)).append("\n");
    sb.append("    syndicateTo: ").append(toIndentedString(syndicateTo)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
