package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDCreateOrganizationStateOrProvince
*/
public interface AnyOforgResoMetadataOUIDCreateOrganizationStateOrProvince {

}
