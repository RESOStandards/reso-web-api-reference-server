package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchUpdateMemberKeyNumeric
*/
public interface AnyOforgResoMetadataSavedSearchUpdateMemberKeyNumeric {

}
