package io.swagger.model;


/**
* AnyOforgResoMetadataContactsOtherStateOrProvince
*/
public interface AnyOforgResoMetadataContactsOtherStateOrProvince {

}
