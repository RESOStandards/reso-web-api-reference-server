package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingCreateObjectIdType
*/
public interface AnyOforgResoMetadataInternetTrackingCreateObjectIdType {

}
