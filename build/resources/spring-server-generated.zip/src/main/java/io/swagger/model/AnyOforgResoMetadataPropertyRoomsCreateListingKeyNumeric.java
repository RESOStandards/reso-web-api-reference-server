package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyRoomsCreateListingKeyNumeric {

}
