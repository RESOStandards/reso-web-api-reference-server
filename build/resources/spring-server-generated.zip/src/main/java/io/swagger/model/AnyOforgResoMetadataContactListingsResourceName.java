package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingsResourceName
*/
public interface AnyOforgResoMetadataContactListingsResourceName {

}
