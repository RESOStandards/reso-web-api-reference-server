package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateMlSAreaMinor
*/
public interface AnyOforgResoMetadataPropertyCreateMlSAreaMinor {

}
