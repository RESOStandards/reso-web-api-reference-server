package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToSewerNumeric {

}
