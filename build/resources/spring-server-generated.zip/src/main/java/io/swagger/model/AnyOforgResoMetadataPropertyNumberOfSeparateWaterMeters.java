package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters
*/
public interface AnyOforgResoMetadataPropertyNumberOfSeparateWaterMeters {

}
