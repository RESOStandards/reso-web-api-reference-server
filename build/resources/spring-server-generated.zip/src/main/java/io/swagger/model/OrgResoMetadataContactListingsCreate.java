package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataContactListingsCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataContactListingsCreate   {
  @JsonProperty("AgentNotesUnreadYN")
  private Boolean agentNotesUnreadYN = null;

  @JsonProperty("ClassName")
  private AnyOforgResoMetadataContactListingsCreateClassName className = null;

  @JsonProperty("ContactKey")
  private String contactKey = null;

  @JsonProperty("ContactKeyNumeric")
  private AnyOforgResoMetadataContactListingsCreateContactKeyNumeric contactKeyNumeric = null;

  @JsonProperty("ContactListingPreference")
  private AnyOforgResoMetadataContactListingsCreateContactListingPreference contactListingPreference = null;

  @JsonProperty("ContactListingsKey")
  private String contactListingsKey = null;

  @JsonProperty("ContactListingsKeyNumeric")
  private AnyOforgResoMetadataContactListingsCreateContactListingsKeyNumeric contactListingsKeyNumeric = null;

  @JsonProperty("ContactLoginId")
  private String contactLoginId = null;

  @JsonProperty("ContactNotesUnreadYN")
  private Boolean contactNotesUnreadYN = null;

  @JsonProperty("DirectEmailYN")
  private Boolean directEmailYN = null;

  @JsonProperty("LastAgentNoteTimestamp")
  private OffsetDateTime lastAgentNoteTimestamp = null;

  @JsonProperty("LastContactNoteTimestamp")
  private OffsetDateTime lastContactNoteTimestamp = null;

  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataContactListingsCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ListingModificationTimestamp")
  private OffsetDateTime listingModificationTimestamp = null;

  @JsonProperty("ListingSentTimestamp")
  private OffsetDateTime listingSentTimestamp = null;

  @JsonProperty("ListingViewedYN")
  private Boolean listingViewedYN = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("PortalLastVisitedTimestamp")
  private OffsetDateTime portalLastVisitedTimestamp = null;

  @JsonProperty("ResourceName")
  private AnyOforgResoMetadataContactListingsCreateResourceName resourceName = null;

  @JsonProperty("Contact")
  private AnyOforgResoMetadataContactListingsCreateContact contact = null;

  @JsonProperty("Listing")
  private AnyOforgResoMetadataContactListingsCreateListing listing = null;

  public OrgResoMetadataContactListingsCreate agentNotesUnreadYN(Boolean agentNotesUnreadYN) {
    this.agentNotesUnreadYN = agentNotesUnreadYN;
    return this;
  }

  /**
   * Get agentNotesUnreadYN
   * @return agentNotesUnreadYN
   **/
  @Schema(description = "")
  
    public Boolean isAgentNotesUnreadYN() {
    return agentNotesUnreadYN;
  }

  public void setAgentNotesUnreadYN(Boolean agentNotesUnreadYN) {
    this.agentNotesUnreadYN = agentNotesUnreadYN;
  }

  public OrgResoMetadataContactListingsCreate className(AnyOforgResoMetadataContactListingsCreateClassName className) {
    this.className = className;
    return this;
  }

  /**
   * Get className
   * @return className
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingsCreateClassName getClassName() {
    return className;
  }

  public void setClassName(AnyOforgResoMetadataContactListingsCreateClassName className) {
    this.className = className;
  }

  public OrgResoMetadataContactListingsCreate contactKey(String contactKey) {
    this.contactKey = contactKey;
    return this;
  }

  /**
   * Get contactKey
   * @return contactKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getContactKey() {
    return contactKey;
  }

  public void setContactKey(String contactKey) {
    this.contactKey = contactKey;
  }

  public OrgResoMetadataContactListingsCreate contactKeyNumeric(AnyOforgResoMetadataContactListingsCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
    return this;
  }

  /**
   * Get contactKeyNumeric
   * @return contactKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingsCreateContactKeyNumeric getContactKeyNumeric() {
    return contactKeyNumeric;
  }

  public void setContactKeyNumeric(AnyOforgResoMetadataContactListingsCreateContactKeyNumeric contactKeyNumeric) {
    this.contactKeyNumeric = contactKeyNumeric;
  }

  public OrgResoMetadataContactListingsCreate contactListingPreference(AnyOforgResoMetadataContactListingsCreateContactListingPreference contactListingPreference) {
    this.contactListingPreference = contactListingPreference;
    return this;
  }

  /**
   * Get contactListingPreference
   * @return contactListingPreference
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingsCreateContactListingPreference getContactListingPreference() {
    return contactListingPreference;
  }

  public void setContactListingPreference(AnyOforgResoMetadataContactListingsCreateContactListingPreference contactListingPreference) {
    this.contactListingPreference = contactListingPreference;
  }

  public OrgResoMetadataContactListingsCreate contactListingsKey(String contactListingsKey) {
    this.contactListingsKey = contactListingsKey;
    return this;
  }

  /**
   * Get contactListingsKey
   * @return contactListingsKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getContactListingsKey() {
    return contactListingsKey;
  }

  public void setContactListingsKey(String contactListingsKey) {
    this.contactListingsKey = contactListingsKey;
  }

  public OrgResoMetadataContactListingsCreate contactListingsKeyNumeric(AnyOforgResoMetadataContactListingsCreateContactListingsKeyNumeric contactListingsKeyNumeric) {
    this.contactListingsKeyNumeric = contactListingsKeyNumeric;
    return this;
  }

  /**
   * Get contactListingsKeyNumeric
   * @return contactListingsKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingsCreateContactListingsKeyNumeric getContactListingsKeyNumeric() {
    return contactListingsKeyNumeric;
  }

  public void setContactListingsKeyNumeric(AnyOforgResoMetadataContactListingsCreateContactListingsKeyNumeric contactListingsKeyNumeric) {
    this.contactListingsKeyNumeric = contactListingsKeyNumeric;
  }

  public OrgResoMetadataContactListingsCreate contactLoginId(String contactLoginId) {
    this.contactLoginId = contactLoginId;
    return this;
  }

  /**
   * Get contactLoginId
   * @return contactLoginId
   **/
  @Schema(description = "")
  
  @Size(max=25)   public String getContactLoginId() {
    return contactLoginId;
  }

  public void setContactLoginId(String contactLoginId) {
    this.contactLoginId = contactLoginId;
  }

  public OrgResoMetadataContactListingsCreate contactNotesUnreadYN(Boolean contactNotesUnreadYN) {
    this.contactNotesUnreadYN = contactNotesUnreadYN;
    return this;
  }

  /**
   * Get contactNotesUnreadYN
   * @return contactNotesUnreadYN
   **/
  @Schema(description = "")
  
    public Boolean isContactNotesUnreadYN() {
    return contactNotesUnreadYN;
  }

  public void setContactNotesUnreadYN(Boolean contactNotesUnreadYN) {
    this.contactNotesUnreadYN = contactNotesUnreadYN;
  }

  public OrgResoMetadataContactListingsCreate directEmailYN(Boolean directEmailYN) {
    this.directEmailYN = directEmailYN;
    return this;
  }

  /**
   * Get directEmailYN
   * @return directEmailYN
   **/
  @Schema(description = "")
  
    public Boolean isDirectEmailYN() {
    return directEmailYN;
  }

  public void setDirectEmailYN(Boolean directEmailYN) {
    this.directEmailYN = directEmailYN;
  }

  public OrgResoMetadataContactListingsCreate lastAgentNoteTimestamp(OffsetDateTime lastAgentNoteTimestamp) {
    this.lastAgentNoteTimestamp = lastAgentNoteTimestamp;
    return this;
  }

  /**
   * Get lastAgentNoteTimestamp
   * @return lastAgentNoteTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastAgentNoteTimestamp() {
    return lastAgentNoteTimestamp;
  }

  public void setLastAgentNoteTimestamp(OffsetDateTime lastAgentNoteTimestamp) {
    this.lastAgentNoteTimestamp = lastAgentNoteTimestamp;
  }

  public OrgResoMetadataContactListingsCreate lastContactNoteTimestamp(OffsetDateTime lastContactNoteTimestamp) {
    this.lastContactNoteTimestamp = lastContactNoteTimestamp;
    return this;
  }

  /**
   * Get lastContactNoteTimestamp
   * @return lastContactNoteTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getLastContactNoteTimestamp() {
    return lastContactNoteTimestamp;
  }

  public void setLastContactNoteTimestamp(OffsetDateTime lastContactNoteTimestamp) {
    this.lastContactNoteTimestamp = lastContactNoteTimestamp;
  }

  public OrgResoMetadataContactListingsCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataContactListingsCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataContactListingsCreate listingKeyNumeric(AnyOforgResoMetadataContactListingsCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataContactListingsCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataContactListingsCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataContactListingsCreate listingModificationTimestamp(OffsetDateTime listingModificationTimestamp) {
    this.listingModificationTimestamp = listingModificationTimestamp;
    return this;
  }

  /**
   * Get listingModificationTimestamp
   * @return listingModificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getListingModificationTimestamp() {
    return listingModificationTimestamp;
  }

  public void setListingModificationTimestamp(OffsetDateTime listingModificationTimestamp) {
    this.listingModificationTimestamp = listingModificationTimestamp;
  }

  public OrgResoMetadataContactListingsCreate listingSentTimestamp(OffsetDateTime listingSentTimestamp) {
    this.listingSentTimestamp = listingSentTimestamp;
    return this;
  }

  /**
   * Get listingSentTimestamp
   * @return listingSentTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getListingSentTimestamp() {
    return listingSentTimestamp;
  }

  public void setListingSentTimestamp(OffsetDateTime listingSentTimestamp) {
    this.listingSentTimestamp = listingSentTimestamp;
  }

  public OrgResoMetadataContactListingsCreate listingViewedYN(Boolean listingViewedYN) {
    this.listingViewedYN = listingViewedYN;
    return this;
  }

  /**
   * Get listingViewedYN
   * @return listingViewedYN
   **/
  @Schema(description = "")
  
    public Boolean isListingViewedYN() {
    return listingViewedYN;
  }

  public void setListingViewedYN(Boolean listingViewedYN) {
    this.listingViewedYN = listingViewedYN;
  }

  public OrgResoMetadataContactListingsCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataContactListingsCreate portalLastVisitedTimestamp(OffsetDateTime portalLastVisitedTimestamp) {
    this.portalLastVisitedTimestamp = portalLastVisitedTimestamp;
    return this;
  }

  /**
   * Get portalLastVisitedTimestamp
   * @return portalLastVisitedTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getPortalLastVisitedTimestamp() {
    return portalLastVisitedTimestamp;
  }

  public void setPortalLastVisitedTimestamp(OffsetDateTime portalLastVisitedTimestamp) {
    this.portalLastVisitedTimestamp = portalLastVisitedTimestamp;
  }

  public OrgResoMetadataContactListingsCreate resourceName(AnyOforgResoMetadataContactListingsCreateResourceName resourceName) {
    this.resourceName = resourceName;
    return this;
  }

  /**
   * Get resourceName
   * @return resourceName
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingsCreateResourceName getResourceName() {
    return resourceName;
  }

  public void setResourceName(AnyOforgResoMetadataContactListingsCreateResourceName resourceName) {
    this.resourceName = resourceName;
  }

  public OrgResoMetadataContactListingsCreate contact(AnyOforgResoMetadataContactListingsCreateContact contact) {
    this.contact = contact;
    return this;
  }

  /**
   * Get contact
   * @return contact
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingsCreateContact getContact() {
    return contact;
  }

  public void setContact(AnyOforgResoMetadataContactListingsCreateContact contact) {
    this.contact = contact;
  }

  public OrgResoMetadataContactListingsCreate listing(AnyOforgResoMetadataContactListingsCreateListing listing) {
    this.listing = listing;
    return this;
  }

  /**
   * Get listing
   * @return listing
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataContactListingsCreateListing getListing() {
    return listing;
  }

  public void setListing(AnyOforgResoMetadataContactListingsCreateListing listing) {
    this.listing = listing;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataContactListingsCreate orgResoMetadataContactListingsCreate = (OrgResoMetadataContactListingsCreate) o;
    return Objects.equals(this.agentNotesUnreadYN, orgResoMetadataContactListingsCreate.agentNotesUnreadYN) &&
        Objects.equals(this.className, orgResoMetadataContactListingsCreate.className) &&
        Objects.equals(this.contactKey, orgResoMetadataContactListingsCreate.contactKey) &&
        Objects.equals(this.contactKeyNumeric, orgResoMetadataContactListingsCreate.contactKeyNumeric) &&
        Objects.equals(this.contactListingPreference, orgResoMetadataContactListingsCreate.contactListingPreference) &&
        Objects.equals(this.contactListingsKey, orgResoMetadataContactListingsCreate.contactListingsKey) &&
        Objects.equals(this.contactListingsKeyNumeric, orgResoMetadataContactListingsCreate.contactListingsKeyNumeric) &&
        Objects.equals(this.contactLoginId, orgResoMetadataContactListingsCreate.contactLoginId) &&
        Objects.equals(this.contactNotesUnreadYN, orgResoMetadataContactListingsCreate.contactNotesUnreadYN) &&
        Objects.equals(this.directEmailYN, orgResoMetadataContactListingsCreate.directEmailYN) &&
        Objects.equals(this.lastAgentNoteTimestamp, orgResoMetadataContactListingsCreate.lastAgentNoteTimestamp) &&
        Objects.equals(this.lastContactNoteTimestamp, orgResoMetadataContactListingsCreate.lastContactNoteTimestamp) &&
        Objects.equals(this.listingId, orgResoMetadataContactListingsCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataContactListingsCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataContactListingsCreate.listingKeyNumeric) &&
        Objects.equals(this.listingModificationTimestamp, orgResoMetadataContactListingsCreate.listingModificationTimestamp) &&
        Objects.equals(this.listingSentTimestamp, orgResoMetadataContactListingsCreate.listingSentTimestamp) &&
        Objects.equals(this.listingViewedYN, orgResoMetadataContactListingsCreate.listingViewedYN) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataContactListingsCreate.modificationTimestamp) &&
        Objects.equals(this.portalLastVisitedTimestamp, orgResoMetadataContactListingsCreate.portalLastVisitedTimestamp) &&
        Objects.equals(this.resourceName, orgResoMetadataContactListingsCreate.resourceName) &&
        Objects.equals(this.contact, orgResoMetadataContactListingsCreate.contact) &&
        Objects.equals(this.listing, orgResoMetadataContactListingsCreate.listing);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agentNotesUnreadYN, className, contactKey, contactKeyNumeric, contactListingPreference, contactListingsKey, contactListingsKeyNumeric, contactLoginId, contactNotesUnreadYN, directEmailYN, lastAgentNoteTimestamp, lastContactNoteTimestamp, listingId, listingKey, listingKeyNumeric, listingModificationTimestamp, listingSentTimestamp, listingViewedYN, modificationTimestamp, portalLastVisitedTimestamp, resourceName, contact, listing);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataContactListingsCreate {\n");
    
    sb.append("    agentNotesUnreadYN: ").append(toIndentedString(agentNotesUnreadYN)).append("\n");
    sb.append("    className: ").append(toIndentedString(className)).append("\n");
    sb.append("    contactKey: ").append(toIndentedString(contactKey)).append("\n");
    sb.append("    contactKeyNumeric: ").append(toIndentedString(contactKeyNumeric)).append("\n");
    sb.append("    contactListingPreference: ").append(toIndentedString(contactListingPreference)).append("\n");
    sb.append("    contactListingsKey: ").append(toIndentedString(contactListingsKey)).append("\n");
    sb.append("    contactListingsKeyNumeric: ").append(toIndentedString(contactListingsKeyNumeric)).append("\n");
    sb.append("    contactLoginId: ").append(toIndentedString(contactLoginId)).append("\n");
    sb.append("    contactNotesUnreadYN: ").append(toIndentedString(contactNotesUnreadYN)).append("\n");
    sb.append("    directEmailYN: ").append(toIndentedString(directEmailYN)).append("\n");
    sb.append("    lastAgentNoteTimestamp: ").append(toIndentedString(lastAgentNoteTimestamp)).append("\n");
    sb.append("    lastContactNoteTimestamp: ").append(toIndentedString(lastContactNoteTimestamp)).append("\n");
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    listingModificationTimestamp: ").append(toIndentedString(listingModificationTimestamp)).append("\n");
    sb.append("    listingSentTimestamp: ").append(toIndentedString(listingSentTimestamp)).append("\n");
    sb.append("    listingViewedYN: ").append(toIndentedString(listingViewedYN)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    portalLastVisitedTimestamp: ").append(toIndentedString(portalLastVisitedTimestamp)).append("\n");
    sb.append("    resourceName: ").append(toIndentedString(resourceName)).append("\n");
    sb.append("    contact: ").append(toIndentedString(contact)).append("\n");
    sb.append("    listing: ").append(toIndentedString(listing)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
