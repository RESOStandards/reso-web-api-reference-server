package io.swagger.model;


/**
* AnyOforgResoMetadataProspectingContact
*/
public interface AnyOforgResoMetadataProspectingContact {

}
