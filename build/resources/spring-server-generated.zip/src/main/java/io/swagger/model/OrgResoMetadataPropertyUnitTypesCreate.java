package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.OrgResoMetadataHistoryTransactionalCreate;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataPropertyUnitTypesCreate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataPropertyUnitTypesCreate   {
  @JsonProperty("ListingId")
  private String listingId = null;

  @JsonProperty("ListingKey")
  private String listingKey = null;

  @JsonProperty("ListingKeyNumeric")
  private AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric listingKeyNumeric = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("UnitTypeActualRent")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeActualRent unitTypeActualRent = null;

  @JsonProperty("UnitTypeBathsTotal")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBathsTotal unitTypeBathsTotal = null;

  @JsonProperty("UnitTypeBedsTotal")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBedsTotal unitTypeBedsTotal = null;

  @JsonProperty("UnitTypeDescription")
  private String unitTypeDescription = null;

  @JsonProperty("UnitTypeFurnished")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeFurnished unitTypeFurnished = null;

  @JsonProperty("UnitTypeGarageAttachedYN")
  private Boolean unitTypeGarageAttachedYN = null;

  @JsonProperty("UnitTypeGarageSpaces")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeGarageSpaces unitTypeGarageSpaces = null;

  @JsonProperty("UnitTypeKey")
  private String unitTypeKey = null;

  @JsonProperty("UnitTypeKeyNumeric")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeKeyNumeric unitTypeKeyNumeric = null;

  @JsonProperty("UnitTypeProForma")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma unitTypeProForma = null;

  @JsonProperty("UnitTypeTotalRent")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeTotalRent unitTypeTotalRent = null;

  @JsonProperty("UnitTypeType")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType unitTypeType = null;

  @JsonProperty("UnitTypeUnitsTotal")
  private AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeUnitsTotal unitTypeUnitsTotal = null;

  @JsonProperty("Listing")
  private AnyOforgResoMetadataPropertyUnitTypesCreateListing listing = null;

  @JsonProperty("HistoryTransactional")
  @Valid
  private List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional = null;

  public OrgResoMetadataPropertyUnitTypesCreate listingId(String listingId) {
    this.listingId = listingId;
    return this;
  }

  /**
   * Get listingId
   * @return listingId
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingId() {
    return listingId;
  }

  public void setListingId(String listingId) {
    this.listingId = listingId;
  }

  public OrgResoMetadataPropertyUnitTypesCreate listingKey(String listingKey) {
    this.listingKey = listingKey;
    return this;
  }

  /**
   * Get listingKey
   * @return listingKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getListingKey() {
    return listingKey;
  }

  public void setListingKey(String listingKey) {
    this.listingKey = listingKey;
  }

  public OrgResoMetadataPropertyUnitTypesCreate listingKeyNumeric(AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
    return this;
  }

  /**
   * Get listingKeyNumeric
   * @return listingKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric getListingKeyNumeric() {
    return listingKeyNumeric;
  }

  public void setListingKeyNumeric(AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric listingKeyNumeric) {
    this.listingKeyNumeric = listingKeyNumeric;
  }

  public OrgResoMetadataPropertyUnitTypesCreate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeActualRent(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeActualRent unitTypeActualRent) {
    this.unitTypeActualRent = unitTypeActualRent;
    return this;
  }

  /**
   * Get unitTypeActualRent
   * @return unitTypeActualRent
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeActualRent getUnitTypeActualRent() {
    return unitTypeActualRent;
  }

  public void setUnitTypeActualRent(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeActualRent unitTypeActualRent) {
    this.unitTypeActualRent = unitTypeActualRent;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeBathsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBathsTotal unitTypeBathsTotal) {
    this.unitTypeBathsTotal = unitTypeBathsTotal;
    return this;
  }

  /**
   * Get unitTypeBathsTotal
   * @return unitTypeBathsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBathsTotal getUnitTypeBathsTotal() {
    return unitTypeBathsTotal;
  }

  public void setUnitTypeBathsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBathsTotal unitTypeBathsTotal) {
    this.unitTypeBathsTotal = unitTypeBathsTotal;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeBedsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBedsTotal unitTypeBedsTotal) {
    this.unitTypeBedsTotal = unitTypeBedsTotal;
    return this;
  }

  /**
   * Get unitTypeBedsTotal
   * @return unitTypeBedsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBedsTotal getUnitTypeBedsTotal() {
    return unitTypeBedsTotal;
  }

  public void setUnitTypeBedsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeBedsTotal unitTypeBedsTotal) {
    this.unitTypeBedsTotal = unitTypeBedsTotal;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeDescription(String unitTypeDescription) {
    this.unitTypeDescription = unitTypeDescription;
    return this;
  }

  /**
   * Get unitTypeDescription
   * @return unitTypeDescription
   **/
  @Schema(description = "")
  
  @Size(max=1024)   public String getUnitTypeDescription() {
    return unitTypeDescription;
  }

  public void setUnitTypeDescription(String unitTypeDescription) {
    this.unitTypeDescription = unitTypeDescription;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeFurnished(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeFurnished unitTypeFurnished) {
    this.unitTypeFurnished = unitTypeFurnished;
    return this;
  }

  /**
   * Get unitTypeFurnished
   * @return unitTypeFurnished
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeFurnished getUnitTypeFurnished() {
    return unitTypeFurnished;
  }

  public void setUnitTypeFurnished(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeFurnished unitTypeFurnished) {
    this.unitTypeFurnished = unitTypeFurnished;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeGarageAttachedYN(Boolean unitTypeGarageAttachedYN) {
    this.unitTypeGarageAttachedYN = unitTypeGarageAttachedYN;
    return this;
  }

  /**
   * Get unitTypeGarageAttachedYN
   * @return unitTypeGarageAttachedYN
   **/
  @Schema(description = "")
  
    public Boolean isUnitTypeGarageAttachedYN() {
    return unitTypeGarageAttachedYN;
  }

  public void setUnitTypeGarageAttachedYN(Boolean unitTypeGarageAttachedYN) {
    this.unitTypeGarageAttachedYN = unitTypeGarageAttachedYN;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeGarageSpaces(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeGarageSpaces unitTypeGarageSpaces) {
    this.unitTypeGarageSpaces = unitTypeGarageSpaces;
    return this;
  }

  /**
   * Get unitTypeGarageSpaces
   * @return unitTypeGarageSpaces
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeGarageSpaces getUnitTypeGarageSpaces() {
    return unitTypeGarageSpaces;
  }

  public void setUnitTypeGarageSpaces(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeGarageSpaces unitTypeGarageSpaces) {
    this.unitTypeGarageSpaces = unitTypeGarageSpaces;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeKey(String unitTypeKey) {
    this.unitTypeKey = unitTypeKey;
    return this;
  }

  /**
   * Get unitTypeKey
   * @return unitTypeKey
   **/
  @Schema(required = true, description = "")
      @NotNull

  @Size(max=255)   public String getUnitTypeKey() {
    return unitTypeKey;
  }

  public void setUnitTypeKey(String unitTypeKey) {
    this.unitTypeKey = unitTypeKey;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeKeyNumeric(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeKeyNumeric unitTypeKeyNumeric) {
    this.unitTypeKeyNumeric = unitTypeKeyNumeric;
    return this;
  }

  /**
   * Get unitTypeKeyNumeric
   * @return unitTypeKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeKeyNumeric getUnitTypeKeyNumeric() {
    return unitTypeKeyNumeric;
  }

  public void setUnitTypeKeyNumeric(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeKeyNumeric unitTypeKeyNumeric) {
    this.unitTypeKeyNumeric = unitTypeKeyNumeric;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeProForma(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma unitTypeProForma) {
    this.unitTypeProForma = unitTypeProForma;
    return this;
  }

  /**
   * Get unitTypeProForma
   * @return unitTypeProForma
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma getUnitTypeProForma() {
    return unitTypeProForma;
  }

  public void setUnitTypeProForma(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeProForma unitTypeProForma) {
    this.unitTypeProForma = unitTypeProForma;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeTotalRent(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeTotalRent unitTypeTotalRent) {
    this.unitTypeTotalRent = unitTypeTotalRent;
    return this;
  }

  /**
   * Get unitTypeTotalRent
   * @return unitTypeTotalRent
   **/
  @Schema(example = "0", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeTotalRent getUnitTypeTotalRent() {
    return unitTypeTotalRent;
  }

  public void setUnitTypeTotalRent(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeTotalRent unitTypeTotalRent) {
    this.unitTypeTotalRent = unitTypeTotalRent;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeType(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType unitTypeType) {
    this.unitTypeType = unitTypeType;
    return this;
  }

  /**
   * Get unitTypeType
   * @return unitTypeType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType getUnitTypeType() {
    return unitTypeType;
  }

  public void setUnitTypeType(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeType unitTypeType) {
    this.unitTypeType = unitTypeType;
  }

  public OrgResoMetadataPropertyUnitTypesCreate unitTypeUnitsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeUnitsTotal unitTypeUnitsTotal) {
    this.unitTypeUnitsTotal = unitTypeUnitsTotal;
    return this;
  }

  /**
   * Get unitTypeUnitsTotal
   * @return unitTypeUnitsTotal
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeUnitsTotal getUnitTypeUnitsTotal() {
    return unitTypeUnitsTotal;
  }

  public void setUnitTypeUnitsTotal(AnyOforgResoMetadataPropertyUnitTypesCreateUnitTypeUnitsTotal unitTypeUnitsTotal) {
    this.unitTypeUnitsTotal = unitTypeUnitsTotal;
  }

  public OrgResoMetadataPropertyUnitTypesCreate listing(AnyOforgResoMetadataPropertyUnitTypesCreateListing listing) {
    this.listing = listing;
    return this;
  }

  /**
   * Get listing
   * @return listing
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataPropertyUnitTypesCreateListing getListing() {
    return listing;
  }

  public void setListing(AnyOforgResoMetadataPropertyUnitTypesCreateListing listing) {
    this.listing = listing;
  }

  public OrgResoMetadataPropertyUnitTypesCreate historyTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
    return this;
  }

  public OrgResoMetadataPropertyUnitTypesCreate addHistoryTransactionalItem(OrgResoMetadataHistoryTransactionalCreate historyTransactionalItem) {
    if (this.historyTransactional == null) {
      this.historyTransactional = new ArrayList<OrgResoMetadataHistoryTransactionalCreate>();
    }
    this.historyTransactional.add(historyTransactionalItem);
    return this;
  }

  /**
   * Get historyTransactional
   * @return historyTransactional
   **/
  @Schema(description = "")
      @Valid
    public List<OrgResoMetadataHistoryTransactionalCreate> getHistoryTransactional() {
    return historyTransactional;
  }

  public void setHistoryTransactional(List<OrgResoMetadataHistoryTransactionalCreate> historyTransactional) {
    this.historyTransactional = historyTransactional;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataPropertyUnitTypesCreate orgResoMetadataPropertyUnitTypesCreate = (OrgResoMetadataPropertyUnitTypesCreate) o;
    return Objects.equals(this.listingId, orgResoMetadataPropertyUnitTypesCreate.listingId) &&
        Objects.equals(this.listingKey, orgResoMetadataPropertyUnitTypesCreate.listingKey) &&
        Objects.equals(this.listingKeyNumeric, orgResoMetadataPropertyUnitTypesCreate.listingKeyNumeric) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataPropertyUnitTypesCreate.modificationTimestamp) &&
        Objects.equals(this.unitTypeActualRent, orgResoMetadataPropertyUnitTypesCreate.unitTypeActualRent) &&
        Objects.equals(this.unitTypeBathsTotal, orgResoMetadataPropertyUnitTypesCreate.unitTypeBathsTotal) &&
        Objects.equals(this.unitTypeBedsTotal, orgResoMetadataPropertyUnitTypesCreate.unitTypeBedsTotal) &&
        Objects.equals(this.unitTypeDescription, orgResoMetadataPropertyUnitTypesCreate.unitTypeDescription) &&
        Objects.equals(this.unitTypeFurnished, orgResoMetadataPropertyUnitTypesCreate.unitTypeFurnished) &&
        Objects.equals(this.unitTypeGarageAttachedYN, orgResoMetadataPropertyUnitTypesCreate.unitTypeGarageAttachedYN) &&
        Objects.equals(this.unitTypeGarageSpaces, orgResoMetadataPropertyUnitTypesCreate.unitTypeGarageSpaces) &&
        Objects.equals(this.unitTypeKey, orgResoMetadataPropertyUnitTypesCreate.unitTypeKey) &&
        Objects.equals(this.unitTypeKeyNumeric, orgResoMetadataPropertyUnitTypesCreate.unitTypeKeyNumeric) &&
        Objects.equals(this.unitTypeProForma, orgResoMetadataPropertyUnitTypesCreate.unitTypeProForma) &&
        Objects.equals(this.unitTypeTotalRent, orgResoMetadataPropertyUnitTypesCreate.unitTypeTotalRent) &&
        Objects.equals(this.unitTypeType, orgResoMetadataPropertyUnitTypesCreate.unitTypeType) &&
        Objects.equals(this.unitTypeUnitsTotal, orgResoMetadataPropertyUnitTypesCreate.unitTypeUnitsTotal) &&
        Objects.equals(this.listing, orgResoMetadataPropertyUnitTypesCreate.listing) &&
        Objects.equals(this.historyTransactional, orgResoMetadataPropertyUnitTypesCreate.historyTransactional);
  }

  @Override
  public int hashCode() {
    return Objects.hash(listingId, listingKey, listingKeyNumeric, modificationTimestamp, unitTypeActualRent, unitTypeBathsTotal, unitTypeBedsTotal, unitTypeDescription, unitTypeFurnished, unitTypeGarageAttachedYN, unitTypeGarageSpaces, unitTypeKey, unitTypeKeyNumeric, unitTypeProForma, unitTypeTotalRent, unitTypeType, unitTypeUnitsTotal, listing, historyTransactional);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataPropertyUnitTypesCreate {\n");
    
    sb.append("    listingId: ").append(toIndentedString(listingId)).append("\n");
    sb.append("    listingKey: ").append(toIndentedString(listingKey)).append("\n");
    sb.append("    listingKeyNumeric: ").append(toIndentedString(listingKeyNumeric)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    unitTypeActualRent: ").append(toIndentedString(unitTypeActualRent)).append("\n");
    sb.append("    unitTypeBathsTotal: ").append(toIndentedString(unitTypeBathsTotal)).append("\n");
    sb.append("    unitTypeBedsTotal: ").append(toIndentedString(unitTypeBedsTotal)).append("\n");
    sb.append("    unitTypeDescription: ").append(toIndentedString(unitTypeDescription)).append("\n");
    sb.append("    unitTypeFurnished: ").append(toIndentedString(unitTypeFurnished)).append("\n");
    sb.append("    unitTypeGarageAttachedYN: ").append(toIndentedString(unitTypeGarageAttachedYN)).append("\n");
    sb.append("    unitTypeGarageSpaces: ").append(toIndentedString(unitTypeGarageSpaces)).append("\n");
    sb.append("    unitTypeKey: ").append(toIndentedString(unitTypeKey)).append("\n");
    sb.append("    unitTypeKeyNumeric: ").append(toIndentedString(unitTypeKeyNumeric)).append("\n");
    sb.append("    unitTypeProForma: ").append(toIndentedString(unitTypeProForma)).append("\n");
    sb.append("    unitTypeTotalRent: ").append(toIndentedString(unitTypeTotalRent)).append("\n");
    sb.append("    unitTypeType: ").append(toIndentedString(unitTypeType)).append("\n");
    sb.append("    unitTypeUnitsTotal: ").append(toIndentedString(unitTypeUnitsTotal)).append("\n");
    sb.append("    listing: ").append(toIndentedString(listing)).append("\n");
    sb.append("    historyTransactional: ").append(toIndentedString(historyTransactional)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
