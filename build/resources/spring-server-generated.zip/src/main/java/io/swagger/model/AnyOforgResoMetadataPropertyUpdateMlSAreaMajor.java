package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateMlSAreaMajor
*/
public interface AnyOforgResoMetadataPropertyUpdateMlSAreaMajor {

}
