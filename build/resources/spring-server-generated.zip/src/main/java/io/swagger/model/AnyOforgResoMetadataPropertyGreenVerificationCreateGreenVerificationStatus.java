package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationCreateGreenVerificationStatus
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationCreateGreenVerificationStatus {

}
