package io.swagger.model;


/**
* AnyOforgResoMetadataRulesUpdateFieldKeyNumeric
*/
public interface AnyOforgResoMetadataRulesUpdateFieldKeyNumeric {

}
