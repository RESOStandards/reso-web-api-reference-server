package io.swagger.model;


/**
* AnyOforgResoMetadataHistoryTransactionalCreateChangedByMember
*/
public interface AnyOforgResoMetadataHistoryTransactionalCreateChangedByMember {

}
