package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits
*/
public interface AnyOforgResoMetadataPropertyDistanceToSchoolBusUnits {

}
