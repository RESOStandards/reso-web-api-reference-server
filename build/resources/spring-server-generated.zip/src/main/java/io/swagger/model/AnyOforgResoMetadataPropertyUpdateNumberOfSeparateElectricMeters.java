package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters
*/
public interface AnyOforgResoMetadataPropertyUpdateNumberOfSeparateElectricMeters {

}
