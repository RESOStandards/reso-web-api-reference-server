package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateLatitude
*/
public interface AnyOforgResoMetadataPropertyCreateLatitude {

}
