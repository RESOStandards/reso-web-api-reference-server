package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBedroomsTotal
*/
public interface AnyOforgResoMetadataPropertyBedroomsTotal {

}
