package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateBedroomsTotal
*/
public interface AnyOforgResoMetadataPropertyUpdateBedroomsTotal {

}
