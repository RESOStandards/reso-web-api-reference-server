package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateObjectIdType
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateObjectIdType {

}
