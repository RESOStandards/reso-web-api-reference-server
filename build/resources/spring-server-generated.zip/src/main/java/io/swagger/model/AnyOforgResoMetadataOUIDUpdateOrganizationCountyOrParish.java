package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDUpdateOrganizationCountyOrParish
*/
public interface AnyOforgResoMetadataOUIDUpdateOrganizationCountyOrParish {

}
