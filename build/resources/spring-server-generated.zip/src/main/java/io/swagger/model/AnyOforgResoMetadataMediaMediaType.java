package io.swagger.model;


/**
* AnyOforgResoMetadataMediaMediaType
*/
public interface AnyOforgResoMetadataMediaMediaType {

}
