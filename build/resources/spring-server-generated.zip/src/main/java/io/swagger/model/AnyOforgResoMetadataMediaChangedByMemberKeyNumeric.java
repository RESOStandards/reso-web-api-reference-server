package io.swagger.model;


/**
* AnyOforgResoMetadataMediaChangedByMemberKeyNumeric
*/
public interface AnyOforgResoMetadataMediaChangedByMemberKeyNumeric {

}
