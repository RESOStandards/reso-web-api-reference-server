package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters
*/
public interface AnyOforgResoMetadataPropertyCreateNumberOfSeparateElectricMeters {

}
