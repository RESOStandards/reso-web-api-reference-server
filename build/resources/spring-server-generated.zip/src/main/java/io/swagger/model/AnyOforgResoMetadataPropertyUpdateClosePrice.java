package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateClosePrice
*/
public interface AnyOforgResoMetadataPropertyUpdateClosePrice {

}
