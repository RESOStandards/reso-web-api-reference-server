package io.swagger.model;


/**
* AnyOforgResoMetadataContactsUpdatePreferredPhone
*/
public interface AnyOforgResoMetadataContactsUpdatePreferredPhone {

}
