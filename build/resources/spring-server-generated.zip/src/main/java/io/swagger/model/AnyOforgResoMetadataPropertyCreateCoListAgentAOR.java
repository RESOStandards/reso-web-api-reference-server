package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoListAgentAOR
*/
public interface AnyOforgResoMetadataPropertyCreateCoListAgentAOR {

}
