package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeCreateSourceSystem
*/
public interface AnyOforgResoMetadataOfficeCreateSourceSystem {

}
