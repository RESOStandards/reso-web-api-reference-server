package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyMiddleOrJuniorSchool
*/
public interface AnyOforgResoMetadataPropertyMiddleOrJuniorSchool {

}
