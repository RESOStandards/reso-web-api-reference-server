package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdatePastureArea
*/
public interface AnyOforgResoMetadataPropertyUpdatePastureArea {

}
