package io.swagger.model;


/**
* AnyOforgResoMetadataOfficeCreateOfficeType
*/
public interface AnyOforgResoMetadataOfficeCreateOfficeType {

}
