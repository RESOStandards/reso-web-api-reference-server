package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity
*/
public interface AnyOforgResoMetadataPropertyCreateNumberOfUnitsInCommunity {

}
