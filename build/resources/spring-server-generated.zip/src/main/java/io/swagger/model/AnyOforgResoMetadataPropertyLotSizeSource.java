package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLotSizeSource
*/
public interface AnyOforgResoMetadataPropertyLotSizeSource {

}
