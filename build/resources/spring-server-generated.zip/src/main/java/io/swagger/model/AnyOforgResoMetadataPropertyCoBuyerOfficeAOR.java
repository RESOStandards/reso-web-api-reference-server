package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCoBuyerOfficeAOR
*/
public interface AnyOforgResoMetadataPropertyCoBuyerOfficeAOR {

}
