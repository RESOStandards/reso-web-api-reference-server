package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric
*/
public interface AnyOforgResoMetadataOpenHouseUpdateOpenHouseKeyNumeric {

}
