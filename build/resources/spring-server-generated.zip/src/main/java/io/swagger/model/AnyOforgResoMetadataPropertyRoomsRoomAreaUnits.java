package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsRoomAreaUnits
*/
public interface AnyOforgResoMetadataPropertyRoomsRoomAreaUnits {

}
