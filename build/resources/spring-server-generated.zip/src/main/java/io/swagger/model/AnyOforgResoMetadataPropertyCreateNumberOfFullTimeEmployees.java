package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees
*/
public interface AnyOforgResoMetadataPropertyCreateNumberOfFullTimeEmployees {

}
