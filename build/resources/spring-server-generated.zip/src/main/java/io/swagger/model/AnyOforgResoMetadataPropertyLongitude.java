package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLongitude
*/
public interface AnyOforgResoMetadataPropertyLongitude {

}
