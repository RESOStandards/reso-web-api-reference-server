package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLotSizeArea
*/
public interface AnyOforgResoMetadataPropertyLotSizeArea {

}
