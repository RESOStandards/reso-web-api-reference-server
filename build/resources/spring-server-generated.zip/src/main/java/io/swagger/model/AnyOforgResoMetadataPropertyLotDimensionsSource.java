package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLotDimensionsSource
*/
public interface AnyOforgResoMetadataPropertyLotDimensionsSource {

}
