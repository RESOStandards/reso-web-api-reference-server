package io.swagger.model;


/**
* AnyOforgResoMetadataQueueCreateOriginatingSystem
*/
public interface AnyOforgResoMetadataQueueCreateOriginatingSystem {

}
