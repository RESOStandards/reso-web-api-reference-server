package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToElectricNumeric {

}
