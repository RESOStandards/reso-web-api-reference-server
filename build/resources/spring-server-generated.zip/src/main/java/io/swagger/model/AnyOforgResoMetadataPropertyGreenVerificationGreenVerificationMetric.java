package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationGreenVerificationMetric
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationGreenVerificationMetric {

}
