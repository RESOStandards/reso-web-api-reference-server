package io.swagger.model;


/**
* AnyOforgResoMetadataContactListingsCreateListing
*/
public interface AnyOforgResoMetadataContactListingsCreateListing {

}
