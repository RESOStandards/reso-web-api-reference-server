package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationListingKeyNumeric {

}
