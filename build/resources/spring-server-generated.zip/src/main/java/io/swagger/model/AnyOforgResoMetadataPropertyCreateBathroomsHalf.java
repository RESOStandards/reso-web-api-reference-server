package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateBathroomsHalf
*/
public interface AnyOforgResoMetadataPropertyCreateBathroomsHalf {

}
