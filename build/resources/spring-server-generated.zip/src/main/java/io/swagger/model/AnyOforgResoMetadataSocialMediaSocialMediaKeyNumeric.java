package io.swagger.model;


/**
* AnyOforgResoMetadataSocialMediaSocialMediaKeyNumeric
*/
public interface AnyOforgResoMetadataSocialMediaSocialMediaKeyNumeric {

}
