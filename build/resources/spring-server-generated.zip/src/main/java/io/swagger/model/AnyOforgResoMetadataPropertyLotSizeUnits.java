package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyLotSizeUnits
*/
public interface AnyOforgResoMetadataPropertyLotSizeUnits {

}
