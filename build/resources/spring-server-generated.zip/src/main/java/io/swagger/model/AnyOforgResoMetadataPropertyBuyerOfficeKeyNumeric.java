package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyBuyerOfficeKeyNumeric {

}
