package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms
*/
public interface AnyOforgResoMetadataPropertyUpdateMainLevelBedrooms {

}
