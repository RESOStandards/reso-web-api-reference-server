package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateYearEstablished
*/
public interface AnyOforgResoMetadataPropertyCreateYearEstablished {

}
