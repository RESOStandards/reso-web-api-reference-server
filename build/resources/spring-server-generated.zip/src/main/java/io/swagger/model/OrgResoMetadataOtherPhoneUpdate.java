package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrgResoMetadataOtherPhoneUpdate
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-12T19:37:54.859Z[GMT]")


public class OrgResoMetadataOtherPhoneUpdate   {
  @JsonProperty("ClassName")
  private AnyOforgResoMetadataOtherPhoneUpdateClassName className = null;

  @JsonProperty("ModificationTimestamp")
  private OffsetDateTime modificationTimestamp = null;

  @JsonProperty("OtherPhoneExt")
  private String otherPhoneExt = null;

  @JsonProperty("OtherPhoneKeyNumeric")
  private AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneKeyNumeric otherPhoneKeyNumeric = null;

  @JsonProperty("OtherPhoneNumber")
  private String otherPhoneNumber = null;

  @JsonProperty("OtherPhoneType")
  private AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneType otherPhoneType = null;

  @JsonProperty("ResourceName")
  private AnyOforgResoMetadataOtherPhoneUpdateResourceName resourceName = null;

  @JsonProperty("ResourceRecordID")
  private String resourceRecordID = null;

  @JsonProperty("ResourceRecordKey")
  private String resourceRecordKey = null;

  @JsonProperty("ResourceRecordKeyNumeric")
  private AnyOforgResoMetadataOtherPhoneUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric = null;

  public OrgResoMetadataOtherPhoneUpdate className(AnyOforgResoMetadataOtherPhoneUpdateClassName className) {
    this.className = className;
    return this;
  }

  /**
   * Get className
   * @return className
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneUpdateClassName getClassName() {
    return className;
  }

  public void setClassName(AnyOforgResoMetadataOtherPhoneUpdateClassName className) {
    this.className = className;
  }

  public OrgResoMetadataOtherPhoneUpdate modificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
    return this;
  }

  /**
   * Get modificationTimestamp
   * @return modificationTimestamp
   **/
  @Schema(description = "")
  
    @Valid
    public OffsetDateTime getModificationTimestamp() {
    return modificationTimestamp;
  }

  public void setModificationTimestamp(OffsetDateTime modificationTimestamp) {
    this.modificationTimestamp = modificationTimestamp;
  }

  public OrgResoMetadataOtherPhoneUpdate otherPhoneExt(String otherPhoneExt) {
    this.otherPhoneExt = otherPhoneExt;
    return this;
  }

  /**
   * Get otherPhoneExt
   * @return otherPhoneExt
   **/
  @Schema(description = "")
  
  @Size(max=10)   public String getOtherPhoneExt() {
    return otherPhoneExt;
  }

  public void setOtherPhoneExt(String otherPhoneExt) {
    this.otherPhoneExt = otherPhoneExt;
  }

  public OrgResoMetadataOtherPhoneUpdate otherPhoneKeyNumeric(AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneKeyNumeric otherPhoneKeyNumeric) {
    this.otherPhoneKeyNumeric = otherPhoneKeyNumeric;
    return this;
  }

  /**
   * Get otherPhoneKeyNumeric
   * @return otherPhoneKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneKeyNumeric getOtherPhoneKeyNumeric() {
    return otherPhoneKeyNumeric;
  }

  public void setOtherPhoneKeyNumeric(AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneKeyNumeric otherPhoneKeyNumeric) {
    this.otherPhoneKeyNumeric = otherPhoneKeyNumeric;
  }

  public OrgResoMetadataOtherPhoneUpdate otherPhoneNumber(String otherPhoneNumber) {
    this.otherPhoneNumber = otherPhoneNumber;
    return this;
  }

  /**
   * Get otherPhoneNumber
   * @return otherPhoneNumber
   **/
  @Schema(description = "")
  
  @Size(max=16)   public String getOtherPhoneNumber() {
    return otherPhoneNumber;
  }

  public void setOtherPhoneNumber(String otherPhoneNumber) {
    this.otherPhoneNumber = otherPhoneNumber;
  }

  public OrgResoMetadataOtherPhoneUpdate otherPhoneType(AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
    return this;
  }

  /**
   * Get otherPhoneType
   * @return otherPhoneType
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneType getOtherPhoneType() {
    return otherPhoneType;
  }

  public void setOtherPhoneType(AnyOforgResoMetadataOtherPhoneUpdateOtherPhoneType otherPhoneType) {
    this.otherPhoneType = otherPhoneType;
  }

  public OrgResoMetadataOtherPhoneUpdate resourceName(AnyOforgResoMetadataOtherPhoneUpdateResourceName resourceName) {
    this.resourceName = resourceName;
    return this;
  }

  /**
   * Get resourceName
   * @return resourceName
   **/
  @Schema(description = "")
  
    public AnyOforgResoMetadataOtherPhoneUpdateResourceName getResourceName() {
    return resourceName;
  }

  public void setResourceName(AnyOforgResoMetadataOtherPhoneUpdateResourceName resourceName) {
    this.resourceName = resourceName;
  }

  public OrgResoMetadataOtherPhoneUpdate resourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
    return this;
  }

  /**
   * Get resourceRecordID
   * @return resourceRecordID
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordID() {
    return resourceRecordID;
  }

  public void setResourceRecordID(String resourceRecordID) {
    this.resourceRecordID = resourceRecordID;
  }

  public OrgResoMetadataOtherPhoneUpdate resourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
    return this;
  }

  /**
   * Get resourceRecordKey
   * @return resourceRecordKey
   **/
  @Schema(description = "")
  
  @Size(max=255)   public String getResourceRecordKey() {
    return resourceRecordKey;
  }

  public void setResourceRecordKey(String resourceRecordKey) {
    this.resourceRecordKey = resourceRecordKey;
  }

  public OrgResoMetadataOtherPhoneUpdate resourceRecordKeyNumeric(AnyOforgResoMetadataOtherPhoneUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
    return this;
  }

  /**
   * Get resourceRecordKeyNumeric
   * @return resourceRecordKeyNumeric
   **/
  @Schema(example = "42", description = "")
  
    public AnyOforgResoMetadataOtherPhoneUpdateResourceRecordKeyNumeric getResourceRecordKeyNumeric() {
    return resourceRecordKeyNumeric;
  }

  public void setResourceRecordKeyNumeric(AnyOforgResoMetadataOtherPhoneUpdateResourceRecordKeyNumeric resourceRecordKeyNumeric) {
    this.resourceRecordKeyNumeric = resourceRecordKeyNumeric;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgResoMetadataOtherPhoneUpdate orgResoMetadataOtherPhoneUpdate = (OrgResoMetadataOtherPhoneUpdate) o;
    return Objects.equals(this.className, orgResoMetadataOtherPhoneUpdate.className) &&
        Objects.equals(this.modificationTimestamp, orgResoMetadataOtherPhoneUpdate.modificationTimestamp) &&
        Objects.equals(this.otherPhoneExt, orgResoMetadataOtherPhoneUpdate.otherPhoneExt) &&
        Objects.equals(this.otherPhoneKeyNumeric, orgResoMetadataOtherPhoneUpdate.otherPhoneKeyNumeric) &&
        Objects.equals(this.otherPhoneNumber, orgResoMetadataOtherPhoneUpdate.otherPhoneNumber) &&
        Objects.equals(this.otherPhoneType, orgResoMetadataOtherPhoneUpdate.otherPhoneType) &&
        Objects.equals(this.resourceName, orgResoMetadataOtherPhoneUpdate.resourceName) &&
        Objects.equals(this.resourceRecordID, orgResoMetadataOtherPhoneUpdate.resourceRecordID) &&
        Objects.equals(this.resourceRecordKey, orgResoMetadataOtherPhoneUpdate.resourceRecordKey) &&
        Objects.equals(this.resourceRecordKeyNumeric, orgResoMetadataOtherPhoneUpdate.resourceRecordKeyNumeric);
  }

  @Override
  public int hashCode() {
    return Objects.hash(className, modificationTimestamp, otherPhoneExt, otherPhoneKeyNumeric, otherPhoneNumber, otherPhoneType, resourceName, resourceRecordID, resourceRecordKey, resourceRecordKeyNumeric);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrgResoMetadataOtherPhoneUpdate {\n");
    
    sb.append("    className: ").append(toIndentedString(className)).append("\n");
    sb.append("    modificationTimestamp: ").append(toIndentedString(modificationTimestamp)).append("\n");
    sb.append("    otherPhoneExt: ").append(toIndentedString(otherPhoneExt)).append("\n");
    sb.append("    otherPhoneKeyNumeric: ").append(toIndentedString(otherPhoneKeyNumeric)).append("\n");
    sb.append("    otherPhoneNumber: ").append(toIndentedString(otherPhoneNumber)).append("\n");
    sb.append("    otherPhoneType: ").append(toIndentedString(otherPhoneType)).append("\n");
    sb.append("    resourceName: ").append(toIndentedString(resourceName)).append("\n");
    sb.append("    resourceRecordID: ").append(toIndentedString(resourceRecordID)).append("\n");
    sb.append("    resourceRecordKey: ").append(toIndentedString(resourceRecordKey)).append("\n");
    sb.append("    resourceRecordKeyNumeric: ").append(toIndentedString(resourceRecordKeyNumeric)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
