package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket
*/
public interface AnyOforgResoMetadataPropertyCreateCumulativeDaysOnMarket {

}
