package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUnitTypesCreateListingKeyNumeric {

}
