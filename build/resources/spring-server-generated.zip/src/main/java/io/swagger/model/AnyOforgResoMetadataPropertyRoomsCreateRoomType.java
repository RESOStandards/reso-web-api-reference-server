package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyRoomsCreateRoomType
*/
public interface AnyOforgResoMetadataPropertyRoomsCreateRoomType {

}
