package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateLandLeaseAmount
*/
public interface AnyOforgResoMetadataPropertyUpdateLandLeaseAmount {

}
