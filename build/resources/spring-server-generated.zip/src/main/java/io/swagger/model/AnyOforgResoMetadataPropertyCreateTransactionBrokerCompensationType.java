package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType
*/
public interface AnyOforgResoMetadataPropertyCreateTransactionBrokerCompensationType {

}
