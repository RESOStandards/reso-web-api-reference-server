package io.swagger.model;


/**
* AnyOforgResoMetadataContactsHomeCountry
*/
public interface AnyOforgResoMetadataContactsHomeCountry {

}
