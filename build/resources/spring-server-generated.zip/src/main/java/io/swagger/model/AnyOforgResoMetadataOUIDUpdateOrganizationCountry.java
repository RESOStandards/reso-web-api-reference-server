package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDUpdateOrganizationCountry
*/
public interface AnyOforgResoMetadataOUIDUpdateOrganizationCountry {

}
