package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPowerProductionUpdatePowerProductionAnnual
*/
public interface AnyOforgResoMetadataPropertyPowerProductionUpdatePowerProductionAnnual {

}
