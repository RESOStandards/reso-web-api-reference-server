package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyGreenVerificationListing
*/
public interface AnyOforgResoMetadataPropertyGreenVerificationListing {

}
