package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateCoBuyerOfficeKeyNumeric {

}
