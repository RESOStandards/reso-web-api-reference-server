package io.swagger.model;


/**
* AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric
*/
public interface AnyOforgResoMetadataTeamsUpdateTeamLeadKeyNumeric {

}
