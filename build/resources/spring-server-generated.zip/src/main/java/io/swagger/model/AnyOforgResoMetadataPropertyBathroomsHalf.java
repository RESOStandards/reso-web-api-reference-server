package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyBathroomsHalf
*/
public interface AnyOforgResoMetadataPropertyBathroomsHalf {

}
