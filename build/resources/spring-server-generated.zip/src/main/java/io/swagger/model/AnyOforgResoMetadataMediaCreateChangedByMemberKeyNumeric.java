package io.swagger.model;


/**
* AnyOforgResoMetadataMediaCreateChangedByMemberKeyNumeric
*/
public interface AnyOforgResoMetadataMediaCreateChangedByMemberKeyNumeric {

}
