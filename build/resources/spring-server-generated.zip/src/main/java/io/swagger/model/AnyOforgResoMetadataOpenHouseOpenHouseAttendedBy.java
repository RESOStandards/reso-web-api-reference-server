package io.swagger.model;


/**
* AnyOforgResoMetadataOpenHouseOpenHouseAttendedBy
*/
public interface AnyOforgResoMetadataOpenHouseOpenHouseAttendedBy {

}
