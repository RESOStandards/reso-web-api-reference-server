package io.swagger.model;


/**
* AnyOforgResoMetadataInternetTrackingUpdateActorLongitude
*/
public interface AnyOforgResoMetadataInternetTrackingUpdateActorLongitude {

}
