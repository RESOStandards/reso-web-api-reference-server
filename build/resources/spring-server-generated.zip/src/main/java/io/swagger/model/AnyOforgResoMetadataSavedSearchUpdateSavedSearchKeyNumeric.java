package io.swagger.model;


/**
* AnyOforgResoMetadataSavedSearchUpdateSavedSearchKeyNumeric
*/
public interface AnyOforgResoMetadataSavedSearchUpdateSavedSearchKeyNumeric {

}
