package io.swagger.model;


/**
* AnyOforgResoMetadataOUIDOrganizationStateOrProvince
*/
public interface AnyOforgResoMetadataOUIDOrganizationStateOrProvince {

}
