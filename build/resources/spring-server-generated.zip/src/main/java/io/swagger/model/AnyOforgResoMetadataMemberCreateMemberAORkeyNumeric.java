package io.swagger.model;


/**
* AnyOforgResoMetadataMemberCreateMemberAORkeyNumeric
*/
public interface AnyOforgResoMetadataMemberCreateMemberAORkeyNumeric {

}
