package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyPropertyType
*/
public interface AnyOforgResoMetadataPropertyPropertyType {

}
