package io.swagger.model;


/**
* AnyOforgResoMetadataMemberCreateSocialMediaType
*/
public interface AnyOforgResoMetadataMemberCreateSocialMediaType {

}
