package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateDistanceToSewerNumeric {

}
