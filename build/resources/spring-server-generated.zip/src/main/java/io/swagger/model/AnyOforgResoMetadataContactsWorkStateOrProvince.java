package io.swagger.model;


/**
* AnyOforgResoMetadataContactsWorkStateOrProvince
*/
public interface AnyOforgResoMetadataContactsWorkStateOrProvince {

}
