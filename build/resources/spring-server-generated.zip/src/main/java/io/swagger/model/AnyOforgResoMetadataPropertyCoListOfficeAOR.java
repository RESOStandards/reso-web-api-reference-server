package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCoListOfficeAOR
*/
public interface AnyOforgResoMetadataPropertyCoListOfficeAOR {

}
