package io.swagger.model;


/**
* AnyOforgResoMetadataContactsCreateContactKeyNumeric
*/
public interface AnyOforgResoMetadataContactsCreateContactKeyNumeric {

}
