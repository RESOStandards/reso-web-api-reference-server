package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyUpdateListTeamKeyNumeric {

}
