package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateCoBuyerAgentKeyNumeric {

}
