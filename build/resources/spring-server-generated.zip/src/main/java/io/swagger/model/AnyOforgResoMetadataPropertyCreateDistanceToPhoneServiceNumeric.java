package io.swagger.model;


/**
* AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric
*/
public interface AnyOforgResoMetadataPropertyCreateDistanceToPhoneServiceNumeric {

}
